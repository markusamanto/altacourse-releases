<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\View\Commissionrate;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;

\defined('_JEXEC') or die;

final class HtmlView extends BaseHtmlView
{
    public string $month = '';
    public int $supplierId = 0;
    public string $company = '';
    public ?\Joomla\CMS\Form\Form $form = null;

    public function display($tpl = null): void
    {
        $row = $this->getModel()->getRate($this->supplierId);
        $this->company = $row->company ?? '';
        $this->form = $this->getModel()->getRateForm(['user_id' => $row->user_id, 'version' => $row->profile_version, 'month' => $this->month, 'fee' => $row->fee ?? '']);
        $this->getDocument()->setTitle(Text::_('COM_ALTACOURSES_COMMISSION_RATE'));
        $this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.site');
        parent::display($tpl);
    }
}
