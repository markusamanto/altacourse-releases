<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Model;

use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\CoursePriceAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\CoursePriceAwareTrait;
use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareTrait;
use Advenire\Component\Altacourses\Site\Exception\CourseValidationException;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Form\FormFactoryAwareInterface;
use Joomla\CMS\Form\FormFactoryAwareTrait;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\CMS\MVC\Model\BaseModel;
use Joomla\CMS\User\CurrentUserInterface;
use Joomla\CMS\User\User;
use Joomla\Database\DatabaseAwareInterface;
use Joomla\Database\DatabaseAwareTrait;
use Joomla\Database\ParameterType;

\defined('_JEXEC') or die;

abstract class CourseformModel extends BaseModel implements DatabaseAwareInterface, CurrentUserInterface, FormFactoryAwareInterface, CourseScheduleAwareInterface, CoursePriceAwareInterface
{
    use DatabaseAwareTrait;
    use FormFactoryAwareTrait;
    use CourseScheduleAwareTrait;
    use CoursePriceAwareTrait;

    protected ?User $currentUser = null;
    protected ?MVCFactoryInterface $modelFactory;

    public const FIELDS = ['submission', 'start_date', 'stop_date', 'second_start', 'second_end', 'course_type',
        'course_place', 'course_leader_1', 'course_leader_2', 'course_price', 'lodging_price', 'lodging_included',
        'course_notes', 'availability', 'supplier', 'state'];

    public function __construct($config = [], ?MVCFactoryInterface $factory = null)
    {
        parent::__construct($config);
        $this->modelFactory = $factory;
    }

    public function setCurrentUser(User $currentUser): void
    {
        $this->currentUser = $currentUser;
    }

    public function isAdministrator(): bool
    {
        $user = $this->currentUser;
        if ($user === null || $user->guest || $user->block
            || (!$user->authorise('altacourses.manage', 'com_altacourses') && !$user->authorise('altacourses.supplier', 'com_altacourses'))) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }
        return $user->authorise('altacourses.manage', 'com_altacourses');
    }

    public function getForm(array $data = [], ?array $original = null): Form
    {
        $administrator = $this->isAdministrator();
        $form = $this->getFormFactory()->createForm($original === null ? 'com_altacourses.newcourse' : 'com_altacourses.editcourse', ['control' => 'jform']);
        if (!$form->loadFile(dirname(__DIR__, 2) . '/forms/newcourse.xml')) {
            throw new \RuntimeException('Course form could not be loaded');
        }
        foreach (['course_type' => ['coursetypes', 'COM_ALTACOURSES_COURSE_TYPE', true],
            'course_place' => ['courseplaces', 'COM_ALTACOURSES_PLACE', true],
            'course_leader_1' => ['courseleaders', 'COM_ALTACOURSES_NEW_LEADER1', true],
            'course_leader_2' => ['courseleaders', 'COM_ALTACOURSES_NEW_LEADER2', false],
            'availability' => ['seats', 'COM_ALTACOURSES_AVAILABILITY', true]] as $name => [$table, $label, $required]) {
            $choices = $this->lookup($table);
            if ($original !== null) {
                $this->includeCurrentChoice($choices, $original[$name] ?? '0');
            }
            $this->addChoices($form, $name, $label, $choices, $required);
        }
        if ($administrator) {
            $assignment = $this->modelFactory?->createModel('Assignment', 'Site', ['ignore_request' => true]);
            if ($assignment === null) {
                throw new \LogicException('MVC factory has not been supplied');
            }
            $assignment->setCurrentUser($this->currentUser);
            $choices = $assignment->getChoices();
            if ($original === null) {
                $choices = array_values(array_filter($choices, static fn ($choice): bool => $choice->id > 0));
            } else {
                $this->includeCurrentChoice($choices, $original['supplier']);
            }
            $this->addChoices($form, 'supplier', 'COM_ALTACOURSES_ASSIGNMENT_SUPPLIER', $choices, true);
        }
        if (!$administrator) {
            $form->removeField('state');
        } elseif ($original !== null && !in_array($original['state'], ['0', '1'], true)) {
            $field = new \SimpleXMLElement('<field name="state" type="list" label="JSTATUS" filter="raw" validate="options" required="true" />');
            foreach (['1' => 'JPUBLISHED', '0' => 'JUNPUBLISHED'] as $value => $label) {
                $option = $field->addChild('option', Text::_($label));
                $option->addAttribute('value', (string) $value);
            }
            $option = $field->addChild('option');
            $option->addAttribute('value', $original['state']);
            $label = $original['state'] === '__keep_state' ? Text::_('COM_ALTACOURSES_UNSPECIFIED') : $original['state'];
            $option[0] = Text::sprintf('COM_ALTACOURSES_EDIT_KEEP_STATE', $label);
            $form->setField($field);
        }
        if ($original !== null) {
            foreach (['start_date', 'stop_date', 'course_price'] as $name) {
                if (($original[$name] ?? '') === '') {
                    $form->setFieldAttribute($name, 'required', 'false');
                }
            }
        }
        // Default only absent values; retain submitted choices and explicitly supplied existing values.
        $data += ['availability' => 1, 'state' => $original['state'] ?? '1'];
        $form->bind($data);
        return $form;
    }

    private function includeCurrentChoice(array &$choices, string $value): void
    {
        foreach ($choices as $choice) {
            if ((string) $choice->id === $value) {
                return;
            }
        }
        $choices[] = (object) ['id' => $value, 'label' => Text::sprintf('COM_ALTACOURSES_EDIT_EXISTING_VALUE', $value)];
    }

    protected function lookup(string $table): array
    {
        $db = $this->getDatabase();
        $query = $db->createQuery()->select($table === 'seats' ? ['seats AS id', 'label'] : ['id', 'name AS label'])
            ->from($db->quoteName('#__altacourses_' . $table))->where('state=1')->order('ordering, id');
        if ($table === 'seats') {
            $query->where('seats IN (1,2,3,4)');
        }
        return $db->setQuery($query)->loadObjectList();
    }

    protected function addChoices(Form $form, string $name, string $label, array $choices, bool $required): void
    {
        $field = new \SimpleXMLElement('<field type="list" filter="integer" validate="options" />');
        $field->addAttribute('name', $name);
        $field->addAttribute('label', $label);
        $field->addAttribute('required', $required ? 'true' : 'false');
        $empty = $field->addChild('option');
        $empty->addAttribute('value', $required ? '' : '0');
        $empty[0] = Text::_($required ? 'COM_ALTACOURSES_NEW_CHOOSE' : 'COM_ALTACOURSES_NEW_NONE');
        foreach ($choices as $choice) {
            $option = $field->addChild('option');
            $option->addAttribute('value', (string) $choice->id);
            $option[0] = (string) $choice->label;
        }
        $form->setField($field);
    }

    protected function validateData(array $input, ?array $original = null): array
    {
        $administrator = $this->isAdministrator();
        $errors = [];
        if (array_diff(array_keys($input), self::FIELDS) || (!$administrator && (array_key_exists('supplier', $input) || array_key_exists('state', $input)))) {
            $errors[] = Text::_('COM_ALTACOURSES_NEW_FIELDS_INVALID');
        }
        $data = [];
        foreach (self::FIELDS as $name) {
            $value = array_key_exists($name, $input) ? $input[$name] : ($name === 'state' ? ($original['state'] ?? '1') : '');
            if (!is_string($value) && !is_int($value)) {
                $errors[] = Text::_('COM_ALTACOURSES_NEW_FIELDS_INVALID');
                $value = '';
            }
            if (($original === null || (string) $value !== ($original[$name] ?? null))
                && (str_contains((string) $value, chr(0)) || mb_strlen((string) $value) > ($name === 'course_notes' ? 10000 : 255))) {
                $errors[] = Text::_('COM_ALTACOURSES_NEW_FIELDS_INVALID');
            }
            $data[$name] = $original !== null && (string) $value === ($original[$name] ?? null)
                ? (string) $value : trim((string) $value);
        }
        if ($this->getCoursePrice()->isIncludedLodging($data['lodging_price'])) {
            $data['lodging_price'] = '';
            $data['lodging_included'] = '1';
        }
        foreach (['course_type', 'course_place', 'course_leader_1', 'course_leader_2', 'availability', 'lodging_included', 'supplier'] as $name) {
            if ($data[$name] === '' && in_array($name, ['course_leader_2', 'lodging_included', 'supplier'], true)) {
                $data[$name] = '0';
            }
            if ($original !== null && $data[$name] === ($original[$name] ?? null)) {
                continue;
            }
            if (!ctype_digit($data[$name]) || (float) $data[$name] > 2147483647) {
                $errors[] = Text::_('COM_ALTACOURSES_NEW_CHOICES_INVALID');
            } else {
                $data[$name] = (string) (int) $data[$name];
            }
        }
        if (!in_array($data['state'], ['0', '1'], true) && ($original === null || $data['state'] !== $original['state'])) {
            $errors[] = Text::_('COM_ALTACOURSES_NEW_FIELDS_INVALID');
        }
        $form = $this->getForm([], $original);
        if (!$form->validate($data)) {
            foreach ($form->getErrors() as $error) {
                $errors[] = $error instanceof \Exception ? $error->getMessage() : (string) $error;
            }
        }
        $datesUnchanged = $original !== null;
        foreach (['start_date', 'stop_date', 'second_start', 'second_end'] as $name) {
            $datesUnchanged = $datesUnchanged && $data[$name] === $original[$name];
        }
        $data['ranges'] = null;
        if (!$datesUnchanged) {
            try {
                $data['ranges'] = $this->getCourseSchedule()->validateRanges($data['start_date'], $data['stop_date'], $data['second_start'], $data['second_end']);
            } catch (\InvalidArgumentException $exception) {
                $errors[] = Text::_('COM_ALTACOURSES_NEW_DATES_INVALID');
            }
        }
        foreach (['course_price', 'lodging_price'] as $name) {
            if ($original !== null && $data[$name] === $original[$name]) {
                continue;
            }
            if ($name === 'lodging_price' && $data[$name] === '') {
                continue;
            }
            $amount = $this->getCoursePrice()->normaliseAmount($data[$name]);
            if ($amount === null || strlen(explode('.', $amount)[0]) > 9) {
                $errors[] = Text::_('COM_ALTACOURSES_NEW_PRICE_INVALID');
            } else {
                $data[$name] = $amount;
            }
        }
        if ($data['course_leader_2'] !== '0' && $data['course_leader_1'] === $data['course_leader_2']
            && ($original === null || $data['course_leader_1'] !== $original['course_leader_1'] || $data['course_leader_2'] !== $original['course_leader_2'])) {
            $errors[] = Text::_('COM_ALTACOURSES_NEW_LEADERS_INVALID');
        }
        if (!in_array($data['lodging_included'], ['0', '1'], true) || (mb_strlen($data['course_notes']) > 10000 && ($original === null || $data['course_notes'] !== $original['course_notes']))) {
            $errors[] = Text::_('COM_ALTACOURSES_NEW_FIELDS_INVALID');
        }
        if ($errors) {
            throw new CourseValidationException(array_unique($errors));
        }
        return $data;
    }

}
