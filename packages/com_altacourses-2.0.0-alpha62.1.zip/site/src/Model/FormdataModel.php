<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Model;

use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareTrait;
use Advenire\Component\Altacourses\Administrator\Service\CoursePriceAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\CoursePriceAwareTrait;
use Joomla\CMS\Language\Text;
use Joomla\Database\ParameterType;

\defined('_JEXEC') or die;

/** Saved form data is addressed by request ID, independently of the live client record. */
final class FormdataModel extends RequestrecordsModel implements CourseScheduleAwareInterface, CoursePriceAwareInterface
{
    use ContactScopeTrait;
    use CourseScheduleAwareTrait;
    use CoursePriceAwareTrait;

    public function getRecord(int $requestId): object
    {
        $db = $this->getDatabase();
        $query = $db->createQuery()->select(['r.id AS request_id', 'r.clientid', 'r.asked_for_info',
            's.id AS submission_id', 's.created_at', 's.contact_json', 's.course_json', 's.supplier_email'])
            ->from('#__altacourses_requests AS r')
            ->join('LEFT', '#__altacourses_courses AS co ON co.id=r.courseid')
            ->join('LEFT', '#__altacourses_request_submissions AS s ON s.request_id=r.id')
            ->where('r.asked_for_info IN (0,1)')->where('r.id=:id')->bind(':id', $requestId, ParameterType::INTEGER);
        $this->scopeClientRecords($query);
        $record = $db->setQuery($query)->loadObject();
        if ($requestId <= 0 || $record === null || (int) $record->clientid <= 0) {
            throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'), 404);
        }
        $snapshot = $record->submission_id === null ? [] : json_decode($record->course_json, true, 512, JSON_THROW_ON_ERROR);
        $record->dates_changed = $this->getCourseSchedule()->hasChangedDates($snapshot);
        foreach ($this->detailChanges($snapshot) as $field => $changed) {
            $record->{$field} = $changed;
        }
        return $record;
    }
    /** Compare only the original course; a later rebooking has its own destination. */
    private function detailChanges(array $snapshot): array
    {
        $changes = ['place_changed' => false, 'leaders_changed' => false, 'price_changed' => false];
        $id = $this->referenceId($snapshot['id'] ?? null);
        if ($id === null || $id === 0) {
            return $changes;
        }
        $db = $this->getDatabase();
        $query = $db->createQuery()->select(['co.course_place', 'cp.name AS place_name',
            'co.course_leader_1', 'co.course_leader_2', 'l1.name AS leader1', 'l2.name AS leader2',
            'co.course_price', 'co.lodging_price', 'co.lodging_included'])
            ->from('#__altacourses_courses AS co')
            ->join('LEFT', '#__altacourses_courseplaces AS cp ON cp.id=co.course_place')
            ->join('LEFT', '#__altacourses_courseleaders AS l1 ON l1.id=co.course_leader_1')
            ->join('LEFT', '#__altacourses_courseleaders AS l2 ON l2.id=co.course_leader_2')
            ->where('co.id=:id')->bind(':id', $id, ParameterType::INTEGER);
        $current = $db->setQuery($query)->loadAssoc();
        if ($current === null) {
            return $changes;
        }
        $placeId = $this->referenceId($snapshot['place_id'] ?? null);
        if ($placeId !== null && $placeId > 0 && is_string($snapshot['course_place'] ?? null)
            && $snapshot['course_place'] !== '' && !empty($current['place_name'])) {
            $changes['place_changed'] = $placeId !== (int) $current['course_place']
                || $snapshot['course_place'] !== $current['place_name'];
        }
        $originalLeaders = array_key_exists('leader1_id', $snapshot) && array_key_exists('leader2_id', $snapshot)
            ? $this->leaderSet($snapshot['leader1_id'], $snapshot['leader1'] ?? null,
                $snapshot['leader2_id'], $snapshot['leader2'] ?? null) : null;
        $currentLeaders = $this->leaderSet($current['course_leader_1'], $current['leader1'],
            $current['course_leader_2'], $current['leader2']);
        if ($originalLeaders !== null && $currentLeaders !== null) {
            $changes['leaders_changed'] = $originalLeaders !== $currentLeaders;
        }
        $savedTotal = $snapshot['booking']['total_price'] ?? null;
        // Run both totals through the same integer-money formatter, including .00 variants.
        $originalPrice = is_string($savedTotal) ? $this->getCoursePrice()->formatTotal($savedTotal, '', '1') : null;
        $currentPrice = $this->getCoursePrice()->formatTotal($current['course_price'], $current['lodging_price'], $current['lodging_included']);
        if ($originalPrice !== null && $currentPrice !== null) {
            $changes['price_changed'] = $originalPrice !== $currentPrice;
        }
        return $changes;
    }

    /** NULL means unavailable; zero represents an explicitly unassigned leader. */
    private function referenceId(mixed $value): ?int
    {
        return (is_int($value) || is_string($value)) && preg_match('/^[0-9]+$/D', (string) $value)
            && strlen((string) $value) <= 10 && (int) $value <= 2147483647 ? (int) $value : null;
    }

    /** Leader order is immaterial; missing referenced records cannot be compared. */
    private function leaderSet(mixed $firstId, mixed $firstName, mixed $secondId, mixed $secondName): ?array
    {
        $leaders = [];
        foreach ([[$firstId, $firstName], [$secondId, $secondName]] as [$value, $name]) {
            $id = $value === null ? 0 : $this->referenceId($value);
            if ($id === null || ($id > 0 && (!is_string($name) || $name === ''))) {
                return null;
            }
            if ($id > 0) {
                $leaders[] = $id . ':' . $name;
            }
        }
        $leaders = array_values(array_unique($leaders));
        sort($leaders, SORT_STRING);
        return $leaders;
    }
}
