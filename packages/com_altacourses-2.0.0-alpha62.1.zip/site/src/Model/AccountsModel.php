<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Model;

use Advenire\Component\Altacourses\Site\Exception\CourseValidationException;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Form\FormFactoryAwareInterface;
use Joomla\CMS\Form\FormFactoryAwareTrait;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\BaseModel;
use Joomla\CMS\User\CurrentUserInterface;
use Joomla\CMS\User\User;
use Joomla\CMS\User\UserFactoryAwareInterface;
use Joomla\CMS\User\UserFactoryAwareTrait;
use Joomla\Database\DatabaseAwareInterface;
use Joomla\Database\DatabaseAwareTrait;
use Joomla\Database\ParameterType;

\defined('_JEXEC') or die;

/** Account management uses the original table and IDs; no delete operation. */
final class AccountsModel extends BaseModel implements DatabaseAwareInterface, CurrentUserInterface, UserFactoryAwareInterface, FormFactoryAwareInterface
{
    use DatabaseAwareTrait;
    use UserFactoryAwareTrait;
    use FormFactoryAwareTrait;

    public const TEXT_FIELDS = ['name', 'invoice_address', 'invoice_address_2', 'invoice_zip', 'invoice_city', 'invoice_country', 'note'];

    private ?User $currentUser = null;

    public function setCurrentUser(User $currentUser): void
    {
        $this->currentUser = $currentUser;
    }

    public function requireAdministrator(): void
    {
        $user = $this->currentUser;
        if ($user === null || $user->guest || $user->block
            || !$user->authorise('altacourses.manage', 'com_altacourses')) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }
        $fresh = $this->getUserFactory()->loadUserById((int) $user->id);
        if ($fresh->guest || $fresh->block || !$fresh->authorise('altacourses.manage', 'com_altacourses')) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }
    }

    public function getItems(): array
    {
        $this->requireAdministrator();
        $db = $this->getDatabase();
        return $db->setQuery($db->createQuery()->select(['id', 'name', 'invoice_city', 'invoice_country', 'state'])
            ->from($db->quoteName('#__altacourses_accounts'))->order($db->quoteName('name') . ', ' . $db->quoteName('id')))->loadObjectList();
    }

    public function getRecord(int $id): ?object
    {
        $this->requireAdministrator();
        if ($id === 0) {
            return null;
        }
        $db = $this->getDatabase();
        $query = $db->createQuery()->select('*')->from($db->quoteName('#__altacourses_accounts'))
            ->where($db->quoteName('id') . ' = :id')->bind(':id', $id, ParameterType::INTEGER);
        $record = $db->setQuery($query)->loadObject();
        if ($record === null) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_ACCOUNT_NOT_FOUND'), 404);
        }
        $this->requireUnlocked($record);
        return $record;
    }

    /** A fingerprint avoids adding a migration-only revision column to the legacy table. */
    public function formData(?object $record): array
    {
        $data = ['id' => (string) ($record->id ?? 0), 'state' => $record === null ? '1' : (string) $record->state,
            'version' => $record === null ? '' : hash('sha256', json_encode($record, JSON_THROW_ON_ERROR))];
        foreach (self::TEXT_FIELDS as $field) { $data[$field] = (string) ($record->$field ?? ''); }
        return $data;
    }

    public function getForm(array $data): Form
    {
        $this->requireAdministrator();
        $form = $this->getFormFactory()->createForm('com_altacourses.account', ['control' => 'jform']);
        if (!$form->loadFile(dirname(__DIR__, 2) . '/forms/account.xml')) {
            throw new \RuntimeException('Account form could not be loaded');
        }
        $form->bind($data);
        return $form;
    }

    public function saveAccount(int $id, string $version, array $input): int
    {
        $this->requireAdministrator();
        $state = $input['state'] ?? null;
        if (array_diff(array_keys($input), [...self::TEXT_FIELDS, 'state']) || !is_string($state) || !in_array($state, ['0', '1'], true)) {
            throw new CourseValidationException([Text::_('COM_ALTACOURSES_ACCOUNT_INVALID')]);
        }
        $values = [];
        foreach (self::TEXT_FIELDS as $field) {
            $value = $input[$field] ?? null;
            if (!is_string($value) || !mb_check_encoding($value, 'UTF-8')
                || ($field === 'note' ? strlen($value) > 65535 : mb_strlen($value) > 255)
                || preg_match($field === 'note' ? '/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u' : '/[\x00-\x1F\x7F]/u', $value)) {
                throw new CourseValidationException([Text::_('COM_ALTACOURSES_ACCOUNT_INVALID')]);
            }
            $values[$field] = $field === 'note' ? $value : trim($value);
        }
        if ($values['name'] === '' || !$this->getForm([])->validate($values + ['state' => $state])) {
            throw new CourseValidationException([Text::_('COM_ALTACOURSES_ACCOUNT_INVALID')]);
        }
        $db = $this->getDatabase();
        if ($id === 0) {
            if ($version !== '') {
                throw new \RuntimeException(Text::_('COM_ALTACOURSES_ACCOUNT_CONFLICT'), 409);
            }
            $row = (object) ($values + ['asset_id' => 0, 'state' => (int) $state, 'ordering' => 0, 'checked_out' => 0,
                'checked_out_time' => null, 'created_by' => (int) $this->currentUser->id, 'modified_by' => null]);
            $db->insertObject('#__altacourses_accounts', $row, 'id');
            return (int) $row->id;
        }
        $record = $this->getRecord($id);
        if (!hash_equals($this->formData($record)['version'], $version)) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_ACCOUNT_CONFLICT'), 409);
        }
        $published = (int) $state;
        $query = $db->createQuery()->update($db->quoteName('#__altacourses_accounts'))
            ->set($db->quoteName('state') . ' = :state')->bind(':state', $published, ParameterType::INTEGER);
        foreach ($values as $column => &$value) {
            $parameter = ':value_' . $column;
            $query->set($db->quoteName($column) . ' = ' . $parameter)->bind($parameter, $value);
        }
        unset($value);

        // Legacy imports can use MyISAM: FOR UPDATE/transactions do not protect them.
        // Compare every original field atomically, with byte-exact text comparisons.
        $original = [];
        foreach (get_object_vars($record) as $column => $value) {
            $field = $db->quoteName($column);
            if ($value === null) {
                $query->where($field . ' IS NULL');
            } else {
                $key = ':original' . count($original);
                $original[$key] = (string) $value;
                $query->where('CAST(' . $field . ' AS BINARY) = CAST(' . $key . ' AS BINARY)')
                    ->bind($key, $original[$key]);
            }
        }
        $db->setQuery($query)->execute();
        if ($db->getAffectedRows() === 0) {
            $current = $this->getRecord($id);
            if (!hash_equals($this->formData($current)['version'], $version)
                || array_filter($values, static fn ($value, $column): bool => (string) $current->$column !== $value, ARRAY_FILTER_USE_BOTH)
                || (int) $current->state !== $published) {
                throw new \RuntimeException(Text::_('COM_ALTACOURSES_ACCOUNT_CONFLICT'), 409);
            }
        }

        return $id;
    }

    private function getClientRecord(int $id): object
    {
        $this->requireAdministrator();
        $db = $this->getDatabase();
        $row = $db->setQuery($db->createQuery()->select('*')->from('#__altacourses_clients')
            ->where('id=:id')->bind(':id', $id, ParameterType::INTEGER))->loadObject();
        if ($id <= 0 || $row === null) { throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'), 404); }
        $this->requireUnlocked($row);
        return $row;
    }

    private function clientSelection(object $client): string
    {
        $raw = $client->account;
        if ($raw === null || $raw === '' || $raw === '0') { return '0'; }
        if (preg_match('/^[1-9][0-9]*$/D', (string) $raw) && (float) $raw <= 2147483647) { return (string) $raw; }
        return '__keep_account';
    }

    public function getClientForm(int $clientId): Form
    {
        $client = $this->getClientRecord($clientId);
        $selection = $this->clientSelection($client);
        $form = $this->getFormFactory()->createForm('com_altacourses.clientaccount', ['control' => 'jform']);
        if (!$form->loadFile(dirname(__DIR__, 2) . '/forms/clientaccount.xml')) {
            throw new \RuntimeException('Client account form could not be loaded');
        }
        $field = new \SimpleXMLElement('<field name="account" type="list" label="COM_ALTACOURSES_ACCOUNT_LABEL" filter="raw" validate="options" required="true" />');
        $option = $field->addChild('option'); $option->addAttribute('value', '0'); $option[0] = Text::_('COM_ALTACOURSES_ACCOUNT_NONE');
        $found = $selection === '0';
        foreach ($this->getItems() as $account) {
            if ((int) $account->state !== 1 && (string) $account->id !== $selection) { continue; }
            $option = $field->addChild('option'); $option->addAttribute('value', (string) $account->id);
            $option[0] = (string) $account->name . ((int) $account->state === 1 ? '' : ' (' . Text::_('JUNPUBLISHED') . ')');
            $found = $found || (string) $account->id === $selection;
        }
        if (!$found) {
            $option = $field->addChild('option'); $option->addAttribute('value', $selection);
            $option[0] = Text::sprintf('COM_ALTACOURSES_ACCOUNT_KEEP', (string) $client->account);
        }
        $form->setField($field);
        $form->bind(['client_id' => $clientId, 'account' => $selection,
            'version' => hash('sha256', json_encode($client, JSON_THROW_ON_ERROR))]);
        return $form;
    }

    /** Only the client's live account reference changes; submission snapshots remain immutable. */
    public function saveClientAccount(int $clientId, string $version, string $selection): void
    {
        $client = $this->getClientRecord($clientId);
        if (!hash_equals(hash('sha256', json_encode($client, JSON_THROW_ON_ERROR)), $version)) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_ACCOUNT_CONFLICT'), 409);
        }
        $originalSelection = $this->clientSelection($client);
        if ($selection === $originalSelection) { return; }
        if (!preg_match('/^(?:0|[1-9][0-9]*)$/D', $selection) || (float) $selection > 2147483647) {
            throw new CourseValidationException([Text::_('COM_ALTACOURSES_ACCOUNT_INVALID')]);
        }
        $db = $this->getDatabase();
        $query = $db->createQuery()->update($db->quoteName('#__altacourses_clients'));
        if ($selection === '0') {
            $query->set($db->quoteName('account') . ' = NULL');
        } else {
            $accountId = (int) $selection;
            $exists = $db->createQuery()->select('1')->from('#__altacourses_accounts')->where('id=:account_id AND state=1');
            $query->set($db->quoteName('account') . ' = :account')->bind(':account', $selection)
                ->where('EXISTS (' . $exists . ')')->bind(':account_id', $accountId, ParameterType::INTEGER);
        }
        $original = [];
        foreach (get_object_vars($client) as $column => $value) {
            $field = $db->quoteName($column);
            if ($value === null) { $query->where($field . ' IS NULL'); }
            else {
                $key = ':original' . count($original); $original[$key] = (string) $value;
                $query->where('CAST(' . $field . ' AS BINARY) = CAST(' . $key . ' AS BINARY)')->bind($key, $original[$key]);
            }
        }
        $db->setQuery($query)->execute();
        if ($db->getAffectedRows() !== 1) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_ACCOUNT_CONFLICT'), 409);
        }
    }

    private function requireUnlocked(object $record): void
    {
        if ((int) $record->checked_out !== 0 && (int) $record->checked_out !== (int) $this->currentUser->id) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_AVAILABILITY_LOCKED'), 409);
        }
    }
}
