<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Model;

use Advenire\Component\Altacourses\Site\Exception\CourseValidationException;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Form\FormFactoryAwareInterface;
use Joomla\CMS\Form\FormFactoryAwareTrait;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\BaseModel;
use Joomla\CMS\User\CurrentUserInterface;
use Joomla\CMS\User\User;
use Joomla\CMS\User\UserFactoryAwareInterface;
use Joomla\CMS\User\UserFactoryAwareTrait;
use Joomla\Database\DatabaseAwareInterface;
use Joomla\Database\DatabaseAwareTrait;
use Joomla\Database\ParameterType;

\defined('_JEXEC') or die;

/** Independent administrator last-minute list with guarded mutations. */
final class LastminutesModel extends BaseModel implements DatabaseAwareInterface, CurrentUserInterface, UserFactoryAwareInterface, FormFactoryAwareInterface
{
    use DatabaseAwareTrait;
    use UserFactoryAwareTrait;
    use FormFactoryAwareTrait;

    private ?User $currentUser = null;

    public function setCurrentUser(User $currentUser): void
    {
        $this->currentUser = $currentUser;
    }

    public function requireAdministrator(): void
    {
        $user = $this->currentUser;
        if ($user === null || $user->guest || $user->block
            || !$user->authorise('altacourses.manage', 'com_altacourses')) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }
        $fresh = $this->getUserFactory()->loadUserById((int) $user->id);
        if ($fresh->guest || $fresh->block || !$fresh->authorise('altacourses.manage', 'com_altacourses')) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }
    }

    private function query(bool $filtered = true): \Joomla\Database\QueryInterface
    {
        $this->requireAdministrator();
        $db = $this->getDatabase();
        $query = $db->createQuery()->from($db->quoteName('#__altacourses_lastminute'));
        $participated = $filtered ? $this->getState('filter.participated', '0') : '0';
        if (!in_array($participated, ['0', '1', 'all'], true)) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_FILTER'), 400);
        }
        if ($participated === '0') {
            $query->where("(participated IS NULL OR TRIM(participated) IN ('', '0'))");
        } elseif ($participated === '1') {
            $query->where("TRIM(participated) = '1'");
        }
        $search = $filtered ? $this->getState('filter.search', '') : '';
        if (!is_string($search) || mb_strlen($search) > 120 || preg_match('/[\x00-\x1f\x7f]/', $search)) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_FILTER'), 400);
        }
        if ($search !== '') {
            $pattern = $db->quote('%' . $db->escape($search, true) . '%', false);
            $query->where('(firstname LIKE ' . $pattern . ' OR lastname LIKE ' . $pattern
                . ' OR telephone LIKE ' . $pattern . ' OR email LIKE ' . $pattern . ')');
        }
        return $query;
    }

    public function getItems(): array
    {
        return $this->getDatabase()->setQuery($this->query()->select('*')->order('firstname, lastname, id'),
            (int) $this->getState('list.start', 0), 20)->loadObjectList();
    }

    public function getTotal(): int
    {
        return (int) $this->getDatabase()->setQuery($this->query()->select('COUNT(*)'))->loadResult();
    }

    /** Independent of search, selected filter, pagination and unused legacy state. */
    public function getCopyEmails(): array
    {
        $rows = $this->getDatabase()->setQuery($this->query(false)->select('email')->order('firstname, lastname, id'))->loadColumn();
        $emails = [];
        foreach ($rows as $value) {
            $email = trim((string) $value);
            if (filter_var($email, FILTER_VALIDATE_EMAIL) && !preg_match('/[\r\n]/', $email)) {
                $emails[strtolower($email)] ??= $email;
            }
        }
        return array_values($emails);
    }

    public function getRecord(int $id): ?object
    {
        $this->requireAdministrator();
        if ($id === 0) {
            return null;
        }
        $db = $this->getDatabase();
        $query = $db->createQuery()->select('*')->from($db->quoteName('#__altacourses_lastminute'))
            ->where($db->quoteName('id') . ' = :id')->bind(':id', $id, ParameterType::INTEGER);
        $record = $db->setQuery($query)->loadObject();
        if ($record === null) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_LASTMINUTE_NOT_FOUND'), 404);
        }
        $this->requireUnlocked($record);
        return $record;
    }

    /** A fingerprint avoids adding a migration-only revision column to the legacy table. */
    public function formData(?object $record): array
    {
        $data = ['id' => (string) ($record->id ?? 0),
            'version' => $record === null ? '' : hash('sha256', json_encode($record, JSON_THROW_ON_ERROR))];
        foreach (['firstname', 'lastname', 'telephone', 'email', 'notes'] as $field) {
            $data[$field] = (string) ($record->$field ?? '');
        }
        $data['participated'] = trim((string) ($record->participated ?? '0')) === '1' ? '1' : '0';
        return $data;
    }

    public function getForm(array $data): Form
    {
        $this->requireAdministrator();
        $form = $this->getFormFactory()->createForm('com_altacourses.lastminute', ['control' => 'jform']);
        if (!$form->loadFile(dirname(__DIR__, 2) . '/forms/lastminute.xml')) {
            throw new \RuntimeException('Last-minute form could not be loaded');
        }
        $form->bind($data);
        return $form;
    }

    public function saveLastminute(int $id, string $version, array $input): int
    {
        $this->requireAdministrator();
        $fields = ['firstname', 'lastname', 'telephone', 'email', 'participated', 'notes'];
        if (array_diff(array_keys($input), $fields) || array_diff($fields, array_keys($input))) {
            throw new CourseValidationException([Text::_('COM_ALTACOURSES_LASTMINUTE_INVALID')]);
        }
        foreach ($fields as $field) {
            if (!is_string($input[$field]) || !mb_check_encoding($input[$field], 'UTF-8')) {
                throw new CourseValidationException([Text::_('COM_ALTACOURSES_LASTMINUTE_INVALID')]);
            }
            $input[$field] = trim(str_replace(["\r\n", "\r"], "\n", $input[$field]));
            $invalid = $field === 'notes' ? preg_match('/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/', $input[$field])
                : preg_match('/[\x00-\x1f\x7f]/', $input[$field]);
            if ($invalid || ($field === 'notes' ? strlen($input[$field]) > 65535 : mb_strlen($input[$field]) > 255)) {
                throw new CourseValidationException([Text::_('COM_ALTACOURSES_LASTMINUTE_INVALID')]);
            }
        }
        if ($input['firstname'] === '' || !in_array($input['participated'], ['0', '1'], true)
            || ($input['email'] !== '' && !filter_var($input['email'], FILTER_VALIDATE_EMAIL))) {
            throw new CourseValidationException([Text::_('COM_ALTACOURSES_LASTMINUTE_INVALID')]);
        }
        $db = $this->getDatabase();
        if ($id === 0) {
            if ($version !== '') { throw new \RuntimeException(Text::_('COM_ALTACOURSES_LASTMINUTE_CONFLICT'), 409); }
            $row = (object) ($input + ['created_by' => (int) $this->currentUser->id, 'state' => 0, 'ordering' => 0, 'checked_out' => 0]);
            $db->insertObject('#__altacourses_lastminute', $row, 'id');
            return (int) $row->id;
        }
        $db->transactionStart();
        try {
            $this->lockedRecord($id, $version);
            $row = (object) ($input + ['id' => $id]);
            $db->updateObject('#__altacourses_lastminute', $row, 'id');
            $db->transactionCommit();
            return $id;
        } catch (\Throwable $exception) {
            $db->transactionRollback();
            throw $exception;
        }
    }

    public function deleteLastminute(int $id, string $version): void
    {
        $this->requireAdministrator();
        if ($id < 1) { throw new \RuntimeException(Text::_('COM_ALTACOURSES_LASTMINUTE_NOT_FOUND'), 404); }
        $db = $this->getDatabase();
        $db->transactionStart();
        try {
            $this->lockedRecord($id, $version);
            $db->setQuery($db->createQuery()->delete($db->quoteName('#__altacourses_lastminute'))
                ->where('id = :id')->bind(':id', $id, ParameterType::INTEGER))->execute();
            $db->transactionCommit();
        } catch (\Throwable $exception) {
            $db->transactionRollback();
            throw $exception;
        }
    }

    private function lockedRecord(int $id, string $version): object
    {
        $db = $this->getDatabase();
        $query = $db->createQuery()->select('*')->from($db->quoteName('#__altacourses_lastminute'))
            ->where('id = :id')->bind(':id', $id, ParameterType::INTEGER);
        $query->setQuery((string) $query . ' FOR UPDATE');
        $record = $db->setQuery($query)->loadObject();
        if ($record === null) { throw new \RuntimeException(Text::_('COM_ALTACOURSES_LASTMINUTE_NOT_FOUND'), 404); }
        $this->requireUnlocked($record);
        if (!hash_equals($this->formData($record)['version'], $version)) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_LASTMINUTE_CONFLICT'), 409);
        }
        return $record;
    }

    private function requireUnlocked(object $record): void
    {
        if ((int) $record->checked_out !== 0 && (int) $record->checked_out !== (int) $this->currentUser->id) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_AVAILABILITY_LOCKED'), 409);
        }
    }
}
