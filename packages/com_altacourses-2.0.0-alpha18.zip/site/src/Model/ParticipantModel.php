<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Model;

use Joomla\CMS\Language\Text;
use Joomla\Database\ParameterType;

\defined('_JEXEC') or die;

/** Read-only submitted contact details and history linked by the stored participant ID. */
final class ParticipantModel extends EnquiriesModel
{
    public function getRecord(int $requestId): array
    {
        $this->requireAdministrator();
        $db = $this->getDatabase();
        $query = $db->createQuery()
            ->select(['s.request_id', 's.created_at', 's.contact_json', 's.course_json', 's.supplier_email',
                'r.clientid', 'r.asked_for_info'])
            ->from('#__altacourses_request_submissions AS s')
            ->join('INNER', '#__altacourses_requests AS r ON r.id=s.request_id')
            ->where('r.asked_for_info IN (0, 1)')
            ->where('r.id=:request')->bind(':request', $requestId, ParameterType::INTEGER);
        $selected = $db->setQuery($query)->loadObject();

        if ($requestId <= 0 || $selected === null || (int) $selected->clientid <= 0) {
            throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'), 404);
        }

        $clientId = (int) $selected->clientid;
        $query = $db->createQuery()
            ->select(['s.request_id', 's.created_at', 's.course_json', 'r.asked_for_info'])
            ->from('#__altacourses_request_submissions AS s')
            ->join('INNER', '#__altacourses_requests AS r ON r.id=s.request_id')
            ->where('r.asked_for_info IN (0, 1)')
            ->where('r.clientid=:client')->bind(':client', $clientId, ParameterType::INTEGER)
            ->order('s.created_at DESC, s.request_id DESC');

        return ['selected' => $selected, 'history' => $db->setQuery($query)->loadObjectList()];
    }
}
