<?php
/** @package Altacourses.Module @license GNU General Public License version 2 or later */
namespace Advenire\Module\Altacoursedetails\Site\Dispatcher;
use Joomla\CMS\Dispatcher\AbstractModuleDispatcher;
use Joomla\CMS\Event\PageCache\IsExcludedEvent;
use Joomla\CMS\Helper\HelperFactoryAwareInterface;
use Joomla\CMS\Helper\HelperFactoryAwareTrait;
\defined('_JEXEC') or die;
final class Dispatcher extends AbstractModuleDispatcher implements HelperFactoryAwareInterface
{
    use HelperFactoryAwareTrait;
    protected function getLayoutData(): array|false
    {
        // No own output cache. Course context and availability must be rechecked on every coid URL.
        if ($this->input->get('coid',null,'raw')!==null) {
            $this->app->allowCache(false);
            $this->app->getDispatcher()->addListener('onPageCacheIsExcluded',static function(IsExcludedEvent $e):void{$e->addResult(true);});
        }
        $data=parent::getLayoutData();$details=$this->getHelperFactory()->getHelper('AltacoursedetailsHelper')->details($this->app);
        if ($details===null) { return false; }
        $wa=$this->app->getDocument()->getWebAssetManager();$wa->getRegistry()->addRegistryFile('media/mod_altacoursedetails/joomla.asset.json');
        $wa->useStyle('mod_altacoursedetails.site')->useScript('mod_altacoursedetails.back');
        $data['details']=$details;return $data;
    }
}
