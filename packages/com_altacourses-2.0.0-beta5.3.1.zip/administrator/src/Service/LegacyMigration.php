<?php
/** @package Altacourses.Installer @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Administrator\Service;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\Database\DatabaseInterface;
use Joomla\Database\DatabaseDriver;

\defined('_JEXEC') or die;

/** Explicit legacy adoption. Originals stay in a separate namespace; no outbound work is created. */
final class LegacyMigration
{
    private array $details = [];
    private string $status = '';

    public function __construct(private readonly DatabaseInterface $db, private readonly string $source)
    {
    }

    public function pending(): bool
    {
        if (!in_array($this->db->getPrefix().'altamigration', $this->db->getTableList(), true)) { return false; }
        $this->readJournal();
        return $this->status !== 'complete';
    }

    public function prepare(): void
    {
        if (!Factory::getApplication()->get('offline')) { throw new \RuntimeException(Text::_('COM_ALTACOURSES_MIGRATION_OFFLINE')); }
        $lock = 'altacourses-migrate-'.substr(hash('sha256', $this->db->getPrefix()), 0, 24);
        if ((int)$this->db->setQuery('SELECT GET_LOCK('.$this->db->quote($lock).',0)')->loadResult() !== 1) {
            throw new \RuntimeException('Another legacy migration is running.');
        }
        try {
            $exists = in_array($this->db->getPrefix().'altamigration', $this->db->getTableList(), true);
            if (!$exists) {
                $this->preflight();
                $this->db->setQuery('CREATE TABLE #__altamigration (id INT PRIMARY KEY,status VARCHAR(24) NOT NULL,details LONGTEXT NOT NULL) ENGINE=InnoDB')->execute();
                $row=(object)['id'=>1,'status'=>'preparing','details'=>json_encode($this->details,JSON_THROW_ON_ERROR)];
                $this->db->insertObject('#__altamigration',$row);$this->status='preparing';
            } else { $this->readJournal(); }
            if ($this->status==='complete') { return; }
            $tables=$this->db->getTableList();
            $archived=in_array($this->db->getPrefix().'altalegacy_b5_courses',$tables,true);
            if ($this->status==='switching' && $archived) {
                foreach ($this->details['targets'] as $name) {
                    if (!in_array($this->db->getPrefix().'altacourses_'.$name,$tables,true)
                        || in_array($this->db->getPrefix().'altastage_b5_'.$name,$tables,true)) { throw new \RuntimeException('Incomplete table switch; restore the complete backup.'); }
                }
                $this->save('switched');
            }
            if (in_array($this->status,['preparing','switching'],true) && !$archived) {
                $this->stage();
                $renames=[];
                foreach ($this->details['sources'] as $name) {
                    $renames[]=$this->db->quoteName('#__altacourses_'.$name).' TO '.$this->db->quoteName('#__altalegacy_b5_'.$name);
                }
                foreach ($this->details['targets'] as $name) {
                    $renames[]=$this->db->quoteName('#__altastage_b5_'.$name).' TO '.$this->db->quoteName('#__altacourses_'.$name);
                }
                foreach ($this->details['sources'] as $name) {
                    if ($this->signature('#__altacourses_'.$name)!==$this->details['signatures'][$name]) { throw new \RuntimeException('Source changed during migration: '.$name); }
                }
                $this->save('switching');
                // One MySQL table-name switch. Files/metadata remain separate recoverable stages.
                $this->db->setQuery('RENAME TABLE '.implode(', ', $renames))->execute();
                $this->save('switched');
            }
            if ($this->status==='switched') {
                $this->db->transactionStart();
                try { $this->metadata();$this->save('metadata');$this->db->transactionCommit(); }
                catch (\Throwable $e) { $this->db->transactionRollback();throw $e; }
            }
            if ($this->status!=='metadata') { throw new \RuntimeException('Unrecognised migration recovery state.'); }
            $id=(int)$this->details['extension_id'];
            $this->db->setQuery('DELETE FROM #__schemas WHERE extension_id='.$id)->execute();
            $row=(object)['extension_id'=>$id,'version_id'=>'2.0.28'];$this->db->insertObject('#__schemas',$row);
        } finally { $this->db->setQuery('SELECT RELEASE_LOCK('.$this->db->quote($lock).')')->loadResult(); }
    }

    private function sqlPath(string $file): string
    {
        $root=$this->source.'/administrator/sql/'.$file;
        return is_file($root)?$root:$this->source.'/sql/'.$file;
    }

    private function preflight(): void
    {
        $catalog=json_decode(file_get_contents($this->sqlPath('legacy-schema.json')),true,512,JSON_THROW_ON_ERROR);
        $tables=$this->db->getTableList();
        $expected=array_map(fn($name)=>$this->db->getPrefix().'altacourses_'.$name,array_keys($catalog));
        $actual=array_values(array_filter($tables,fn($name)=>str_starts_with($name,$this->db->getPrefix().'altacourses_')));
        if (array_diff($expected,$actual)||array_diff($actual,$expected)) { throw new \RuntimeException('Unsupported legacy business table inventory.'); }
        foreach ($tables as $table) {
            if (str_starts_with($table,$this->db->getPrefix().'altalegacy_b5_') || str_starts_with($table,$this->db->getPrefix().'altastage_b5_')) {
                throw new \RuntimeException('Migration archive/staging names already exist without a journal.');
            }
        }
        foreach ($catalog as $name=>$columns) {
            $table='#__altacourses_'.$name;$found=$this->db->getTableColumns($table,false);
            if (array_diff($columns,array_keys($found))||array_diff(array_keys($found),$columns)) { throw new \RuntimeException('Unsupported legacy columns: '.$name); }
            if ((int)$this->db->setQuery('SELECT COUNT(*) FROM '.$this->db->quoteName($table).' WHERE id IS NULL OR id<=0')->loadResult()
                || (int)$this->db->setQuery('SELECT COUNT(*) FROM (SELECT id FROM '.$this->db->quoteName($table).' GROUP BY id HAVING COUNT(*)>1) AS duplicates')->loadResult()) {
                throw new \RuntimeException('Invalid or duplicate record IDs: '.$name);
            }
        }
        foreach (['managers','rebooked','keyaccount'] as $name) {
            if ((int)$this->db->setQuery('SELECT COUNT(*) FROM #__altacourses_'.$name)->loadResult()) {
                throw new \RuntimeException('This first legacy installer requires separate review of nonempty '.$name.' history. Source data is untouched.');
            }
        }
        $extension=$this->db->setQuery("SELECT extension_id,params FROM #__extensions WHERE element='com_altacourses' AND type='component'")->loadObject();
        if (!$extension) { throw new \RuntimeException('Missing legacy component registration.'); }
        $params=json_decode($extension->params?:'{}',true,512,JSON_THROW_ON_ERROR);
        foreach (['admingroup','suppliergroup'] as $key) {
            $groups=(array)($params[$key]??[]);
            if (!$groups) { throw new \RuntimeException('Missing legacy role configuration: '.$key); }
            foreach ($groups as $group) {
                if (!ctype_digit((string)$group)||(int)$group<1||!(int)$this->db->setQuery('SELECT COUNT(*) FROM #__usergroups WHERE id='.(int)$group)->loadResult()) {
                    throw new \RuntimeException('Unknown legacy role group: '.$key);
                }
            }
        }
        $rules=$this->db->setQuery("SELECT rules FROM #__assets WHERE name='com_altacourses'")->loadResult();
        if ($rules===null) { throw new \RuntimeException('Missing legacy component ACL asset.'); }
        $this->details=['format'=>1,'extension_id'=>(int)$extension->extension_id,'sources'=>array_keys($catalog),'targets'=>[],
            'params'=>$params,'rules'=>$rules,'counts'=>[],'conversions'=>[],'modules'=>[],'menu_changes'=>[],'unmapped_menus'=>[],
            'schema'=>'2.0.28'];
        foreach ($catalog as $name=>$unused) { $this->details['counts'][$name]=(int)$this->db->setQuery('SELECT COUNT(*) FROM #__altacourses_'.$name)->loadResult();
            $this->details['signatures'][$name]=$this->signature('#__altacourses_'.$name); }
    }

    private function stage(): void
    {
        $statements=DatabaseDriver::splitSql(file_get_contents($this->sqlPath('install.mysql.utf8.sql')));
        $ddl=[];
        foreach ($statements as $sql) {
            $sql=preg_replace('/^\s*--[^\n]*\n/m','',$sql);
            if (preg_match('/^\s*CREATE TABLE IF NOT EXISTS `#__altacourses_([a-z_]+)`/',$sql,$m)) { $ddl[$m[1]]=$sql; }
        }
        if (count($ddl)!==24) { throw new \RuntimeException('Unexpected target schema inventory.'); }
        $this->details['targets']=array_keys($ddl);$this->details['conversions']=[];$this->save('preparing');
        foreach (array_reverse(array_keys($ddl)) as $name) {
            $this->db->setQuery('DROP TABLE IF EXISTS '.$this->db->quoteName('#__altastage_b5_'.$name))->execute();
        }
        foreach ($ddl as $name=>$sql) {
            $stage='#__altastage_b5_'.$name;
            $this->db->setQuery(str_replace('#__altacourses_','#__altastage_b5_',$sql))->execute();
            if (!in_array($name,$this->details['sources'],true)||$name==='keyaccount') { continue; }
            $target=$this->db->getTableColumns($stage,false);
            $source=$this->db->getTableColumns('#__altacourses_'.$name,false);
            if (array_diff(array_keys($source),array_keys($target))) { throw new \RuntimeException('Unmapped source fields: '.$name); }
            $after=0;$count=0;
            while ($rows=$this->db->setQuery('SELECT * FROM #__altacourses_'.$name.' WHERE id>'.(int)$after.' ORDER BY id',0,200)->loadAssocList()) {
                foreach ($rows as $row) {
                    $values=[];
                    foreach ($row as $field=>$value) {
                        $column=$target[$field];$old=$value;
                        if (preg_match('/^(date|datetime|timestamp)/i',$column->Type) && $value!==null && str_starts_with($value,'0000-')) { $value=null; }
                        if ($value===null && $column->Null==='NO') {
                            if ($column->Default===null) { throw new \RuntimeException('Required value missing: '.$name.'.'.$field); }
                            $value=$column->Default;
                        }
                        if ($value!==$old) { $key=$name.'.'.$field;$this->details['conversions'][$key]=($this->details['conversions'][$key]??0)+1; }
                        $values[$field]=$value;
                    }
                    $query=$this->db->createQuery()->insert($this->db->quoteName($stage))
                        ->columns(array_map(fn($key)=>$this->db->quoteName($key),array_keys($values)))
                        ->values(implode(',',array_map(fn($value)=>$value===null?'NULL':$this->db->quote((string)$value),$values)));
                    $this->db->setQuery($query)->execute();
                    $stored=$this->db->setQuery('SELECT * FROM '.$this->db->quoteName($stage).' WHERE id='.(int)$row['id'])->loadAssoc();
                    foreach ($values as $field=>$value) {
                        if (($stored[$field]===null)!==($value===null) || ($value!==null && (string)$stored[$field] !== (string)$value)) {
                            throw new \RuntimeException('Value reconciliation failed: '.$name.'.'.$field);
                        }
                    }
                    $after=(int)$row['id'];++$count;
                }
            }
            if ($count!==$this->details['counts'][$name]) { throw new \RuntimeException('Source changed during migration: '.$name); }
            $status=$this->db->setQuery('SHOW TABLE STATUS WHERE Name='.$this->db->quote($this->db->getPrefix().'altacourses_'.$name))->loadObject();
            if ((int)$status->Auto_increment>0) { $this->db->setQuery('ALTER TABLE '.$this->db->quoteName($stage).' AUTO_INCREMENT='.(int)$status->Auto_increment)->execute(); }
        }
        // Archive counts and the value-by-value checks are recorded before switching.
        $this->save('preparing');
    }

    private function metadata(): void
    {
        $p=$this->details['params'];
        foreach (['notification_mode','monthly_mode','reminder_mode','evaluation_mode','mailchimp_mode','zenler_mode'] as $key) { $p[$key]='off'; }
        $p['price_display_mode']='T';$p['public_multiple_types']=1;
        $rules=json_decode($this->details['rules']?:'{}',true,512,JSON_THROW_ON_ERROR);
        foreach (['admingroup'=>'altacourses.manage','suppliergroup'=>'altacourses.supplier'] as $old=>$action) {
            foreach ((array)$p[$old] as $group) { $rules[$action][(string)(int)$group]=1; }
        }
        $this->db->setQuery('UPDATE #__assets SET rules='.$this->db->quote(json_encode($rules,JSON_THROW_ON_ERROR))." WHERE name='com_altacourses'")->execute();
        $this->db->setQuery("UPDATE #__extensions SET enabled=0 WHERE type='plugin' AND folder='finder' AND element LIKE 'altacourses%'")->execute();
        $map=['requests'=>'signups','informations'=>'enquiries','clients'=>'contacts','courses'=>'managecourses','courseform'=>'newcourse',
            'supplierform'=>'supplierprofile','requestform'=>'participations','unconfirmeds'=>'unconfirmed','rebookings'=>'rebooking',
            'users'=>'suppliers','signupform'=>'signup','informationform'=>'enquiry','evaluationform'=>'evaluation'];
        $native=['dashboard','alerts','mailtemplates','courseleaders','regions','courseplaces','coursetypes','seats','suppliers','client',
            'keyaccounts','lastminutes','unreads','accounts','evaluations','signups'];
        foreach ($this->db->setQuery("SELECT id,link,params FROM #__menu WHERE client_id=0 AND link LIKE '%option=com_altacourses%'")->loadObjectList() as $menu) {
            parse_str((string)parse_url($menu->link,PHP_URL_QUERY),$q);$view=$q['view']??'dashboard';$layout=$q['layout']??'default';
            if ($view==='courses' && $layout==='seats') { $new='courseavailability'; }
            elseif ($view==='clients' && $layout==='requests') { $new='signups'; }
            elseif (in_array($view,['signupform','informationform'],true)&&$layout==='thanks') { $new=$view==='signupform'?'signupreceipt':'enquiryreceipt'; }
            elseif ($view==='courseform' && !empty($q['id'])) { $new='editcourse'; }
            elseif (isset($map[$view])) { $new=$map[$view]; }
            elseif (in_array($view,$native,true)&&in_array($layout,['default','client','courses'],true)) { $new=$view; }
            else { $this->details['unmapped_menus'][]=(int)$menu->id;continue; }
            unset($q['layout']);$q['view']=$new;$q['option']='com_altacourses';
            if (isset($q['coid'])&&$new==='course') { $q['id']=$q['coid'];unset($q['coid']); }
            $this->details['menu_changes'][]=['id'=>(int)$menu->id,'before'=>$menu->link,'after'=>'index.php?'.http_build_query($q)];
            $this->db->setQuery('UPDATE #__menu SET link='.$this->db->quote('index.php?'.http_build_query($q)).',component_id='.(int)$this->details['extension_id'].' WHERE id='.(int)$menu->id)->execute();
        }
        $this->convertInformationMenus($p);
        foreach ($this->db->setQuery("SELECT * FROM #__modules WHERE client_id=0 AND module LIKE 'mod_alta%'")->loadAssocList() as $module) {
            $original=$module;$params=json_decode($module['params']?:'{}',true,512,JSON_THROW_ON_ERROR);$name=$module['module'];$enable=false;
            if (in_array($name,['mod_altacourseleader','mod_altacourseplace'],true)) {
                $module['module']='mod_altarelatedcourses';$params['mode']=$name==='mod_altacourseleader'?'leader':'place';$enable=true;
            } elseif ($name==='mod_altacoursedetails') {
                $enable=in_array($params['layout']??'_:default',['_:default','default'],true);
            } elseif (in_array($name,['mod_altaevaluations','mod_altacoursesletter'],true)) {
                $enable=true;
                if ($name==='mod_altacoursesletter'&&!isset($params['letter'])) {
                    $file=JPATH_SITE.'/modules/mod_altacoursesletter/tmpl/default.php';
                    if (is_file($file)) {
                        $letter=file_get_contents($file);
                        $letter=preg_replace('/\A\s*<\?php.*?\?>/s','',$letter);
                        $letter=preg_replace('/<script\b[^>]*>.*?<\/script>/si','{today}',$letter);
                        $letter=preg_replace('/<\?php\s+echo\s+\$number\s*;?\s*\?>/','{course_count}',$letter);
                        if (!str_contains($letter,'<?')) { $params['letter']=$letter; }
                    }
                }
                if ($name==='mod_altaevaluations'&&isset($params['evaluationsstoshow'])) { $params['evaluationstoshow']=$params['evaluationsstoshow']; }
            } elseif ($name==='mod_altaquickstats') {
                if (isset($params['average_fee'])) { $p['statistics_average_commission']=$params['average_fee']; }
                if (isset($params['year_goal'])) { $p['statistics_income_goal']=$params['year_goal']; }
            }
            if ($name==='mod_altacourses'&&(int)$original['published']===1) {
                $this->convertListingArticles($module);
            }
            $params['layout']='_:default';$params['cache']=0;$module['params']=json_encode($params,JSON_THROW_ON_ERROR);$module['published']=min(0,(int)$module['published']);
            $object=(object)$module;$this->db->updateObject('#__modules',$object,'id');
            $this->details['modules'][]=['original'=>$original,'target'=>$module['module'],'restore_after_install'=>$enable,'restored'=>false];
        }
        $this->details['target_params']=$p;$this->details['target_rules']=$rules;
        $this->applyConfiguration();
    }

    private function convertInformationMenus(array $params): void
    {
        $article=(int)($params['informationarticle']??0);$item=(int)($params['infopageitemid']??0);
        foreach ($this->db->setQuery("SELECT id,link FROM #__menu WHERE client_id=0 AND link LIKE 'index.php?option=com_content%'")->loadObjectList() as $menu) {
            parse_str((string)parse_url($menu->link,PHP_URL_QUERY),$q);
            if (!(($article>0&&($q['view']??'')==='article'&&(int)($q['id']??0)===$article)||($item>0&&(int)$menu->id===$item))) { continue; }
            $link='index.php?option=com_altacourses&view=course';
            $this->db->setQuery('UPDATE #__menu SET link='.$this->db->quote($link).',component_id='.(int)$this->details['extension_id'].' WHERE id='.(int)$menu->id)->execute();
            $this->details['menu_changes'][]=['id'=>(int)$menu->id,'before'=>$menu->link,'after'=>$link];
        }
    }

    private function convertListingArticles(array $module): void
    {
        foreach ($this->db->setQuery('SELECT id,introtext,`fulltext` FROM #__content')->loadObjectList() as $article) {
            $body=$article->introtext.' '.$article->fulltext;
            $position=(string)$module['position'];
            $byPosition=$position!==''&&preg_match('/\{loadposition\s+'.preg_quote($position,'/').'(?:\s*,[^}]*)?\s*\}/u',$body);
            $byId=preg_match('/\{loadmoduleid\s+'.(int)$module['id'].'(?:\s*,[^}]*)?\s*\}/u',$body);
            if (!$byPosition&&!$byId) { continue; }
            foreach ($this->db->setQuery("SELECT id,link FROM #__menu WHERE client_id=0 AND link LIKE 'index.php?option=com_content%'")->loadObjectList() as $menu) {
                parse_str((string)parse_url($menu->link,PHP_URL_QUERY),$q);
                if (($q['view']??'')!=='article'||(int)($q['id']??0)!==(int)$article->id) { continue; }
                $link='index.php?option=com_altacourses&view=courses';
                $this->db->setQuery('UPDATE #__menu SET link='.$this->db->quote($link).',component_id='.(int)$this->details['extension_id'].' WHERE id='.(int)$menu->id)->execute();
                $this->details['menu_changes'][]=['id'=>(int)$menu->id,'before'=>$menu->link,'after'=>$link];
            }
        }
    }

    public function finish(): void
    {
        if (!in_array($this->db->getPrefix().'altamigration',$this->db->getTableList(),true)) { return; }
        $this->readJournal();
        if ($this->status==='metadata') { $this->applyConfiguration();$this->cleanupFiles();
            \JLoader::register('JNamespacePsr4Map',JPATH_LIBRARIES.'/namespacemap.php');
            (new \JNamespacePsr4Map())->create();
            $this->save('complete'); }
        Factory::getApplication()->enqueueMessage(Text::_('COM_ALTACOURSES_MIGRATION_COMPLETE'),'warning');
    }

    public static function installedModule(DatabaseInterface $db,string $name): void
    {
        if (!in_array($db->getPrefix().'altamigration',$db->getTableList(),true)) { return; }
        $self=new self($db,'');$self->readJournal();if ($self->status!=='complete') { return; }
        foreach ($self->details['modules'] as &$module) {
            if ($module['target']!==$name||!$module['restore_after_install']||$module['restored']) { continue; }
            $id=(int)$module['original']['id'];
            // Restore only a still-unpublished mapped instance, once; subsequent updates do not republish it.
            $db->setQuery('UPDATE #__modules SET published='.(int)$module['original']['published'].' WHERE id='.$id.' AND published=0 AND module='.$db->quote($name))->execute();
            $module['restored']=true;
        }
        unset($module);$self->save('complete');
    }

    private function applyConfiguration(): void
    {
        // Joomla's adapter loaded the old extension row before preflight; reapply after its store.
        $this->db->setQuery('UPDATE #__extensions SET params='.$this->db->quote(json_encode($this->details['target_params'],JSON_THROW_ON_ERROR)).' WHERE extension_id='.(int)$this->details['extension_id'])->execute();
        $this->db->setQuery('UPDATE #__assets SET rules='.$this->db->quote(json_encode($this->details['target_rules'],JSON_THROW_ON_ERROR))." WHERE name='com_altacourses'")->execute();
    }

    private function signature(string $table): string
    {
        $hash=hash_init('sha256');$after=0;
        while ($rows=$this->db->setQuery('SELECT * FROM '.$this->db->quoteName($table).' WHERE id>'.(int)$after.' ORDER BY id',0,200)->loadAssocList()) {
            foreach ($rows as $row) { hash_update($hash,json_encode($row,JSON_THROW_ON_ERROR));$after=(int)$row['id']; }
        }
        return hash_final($hash);
    }

    private function cleanupFiles(): void
    {
        foreach (['site'=>JPATH_SITE.'/components/com_altacourses','administrator'=>JPATH_ADMINISTRATOR.'/components/com_altacourses'] as $area=>$destination) {
            foreach (['src','forms','tmpl','layouts','services'] as $folder) {
                $base=$destination.'/'.$folder;if (!is_dir($base)) { continue; }
                $iterator=new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($base,\FilesystemIterator::SKIP_DOTS));
                foreach ($iterator as $file) {
                    if (!$file->isFile()&&!$file->isLink()) { continue; }
                    $relative=substr($file->getPathname(),strlen($destination)+1);
                    if (!is_file($this->source.'/'.$area.'/'.$relative)&&!unlink($file->getPathname())) { throw new \RuntimeException('Cannot remove a retired component file.'); }
                }
            }
        }
    }

    /** Safe backend report; never expose archived parameters, emails, private text or original URLs. */
    public static function summary(DatabaseInterface $db): ?array
    {
        if (!in_array($db->getPrefix().'altamigration',$db->getTableList(),true)) { return null; }
        $self=new self($db,'');$self->readJournal();
        $incomplete=$db->setQuery('SELECT r.id FROM #__altacourses_requests AS r LEFT JOIN #__altacourses_clients AS c ON c.id=r.clientid WHERE c.id IS NULL ORDER BY r.id')->loadColumn();
        return ['incomplete_requests'=>array_map('intval',$incomplete),'status'=>$self->status,'counts'=>$self->details['counts'],'conversions'=>$self->details['conversions'],
            'menu_count'=>count($self->details['menu_changes']),'unmapped'=>$self->details['unmapped_menus'],
            'modules'=>array_map(static fn($m)=>['id'=>(int)$m['original']['id'],'target'=>$m['target'],
                'pending'=>$m['restore_after_install']&&!$m['restored']],$self->details['modules'])];
    }

    private function readJournal(): void
    {
        $row=$this->db->setQuery('SELECT status,details FROM #__altamigration WHERE id=1')->loadObject();
        if (!$row) { throw new \RuntimeException('Migration journal is missing its recovery record.'); }
        $this->status=$row->status;$this->details=json_decode($row->details,true,512,JSON_THROW_ON_ERROR);
        if (($this->details['format']??0)!==1) { throw new \RuntimeException('Unsupported migration journal.'); }
    }

    private function save(string $status): void
    {
        $this->status=$status;
        $this->db->setQuery('UPDATE #__altamigration SET status='.$this->db->quote($status).',details='.$this->db->quote(json_encode($this->details,JSON_THROW_ON_ERROR)).' WHERE id=1')->execute();
    }
}
