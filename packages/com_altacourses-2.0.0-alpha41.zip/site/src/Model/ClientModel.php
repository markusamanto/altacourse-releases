<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Model;

use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareTrait;
use Joomla\CMS\Language\Text;
use Joomla\Database\ParameterType;

\defined('_JEXEC') or die;

/** Client identity and current details are separate from each submitted form. */
final class ClientModel extends RequestrecordsModel implements CourseScheduleAwareInterface
{
    use ContactScopeTrait;
    use CourseScheduleAwareTrait;

    public function getRecord(int $clientId): array
    {
        $administrator = $this->isContactAdministrator();
        $db = $this->getDatabase();
        $client = $db->setQuery($db->createQuery()->select('*')->from('#__altacourses_clients')
            ->where('id=:id')->bind(':id', $clientId, ParameterType::INTEGER))->loadObject();
        if ($clientId <= 0 || $client === null) { throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'), 404); }
        $query = $db->createQuery()->select(['r.id AS request_id', 'r.courseid', 'r.asked_for_info',
            "COALESCE(s.created_at,NULLIF(CAST(r.date_created AS CHAR),'0000-00-00 00:00:00')) AS created_at",
            's.id AS submission_id', 's.contact_json', $this->currentCourseExpression() . ' AS course_json',
            'ct.name AS legacy_type', 'cp.name AS legacy_place'])
            ->from('#__altacourses_requests AS r')
            ->join('LEFT', '#__altacourses_request_submissions AS s ON s.request_id=r.id')
            ->join('LEFT', '#__altacourses_courses AS co ON co.id=r.courseid')
            ->join('LEFT', '#__altacourses_coursetypes AS ct ON ct.id=co.course_type')
            ->join('LEFT', '#__altacourses_courseplaces AS cp ON cp.id=co.course_place')
            ->where('r.asked_for_info IN (0,1)')->where('r.clientid=:client')->bind(':client', $clientId, ParameterType::INTEGER)
            ->order('created_at DESC,r.id DESC');
        $this->scopeClientRecords($query);
        $history = $db->setQuery($query)->loadObjectList();
        if (!$administrator && !$history) { throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'), 404); }
        $courseIds = array_values(array_unique(array_map(static fn ($row): int => (int) $row->courseid, $history)));
        $sessions = $this->getCourseSchedule()->currentSessions($courseIds);
        foreach ($history as $row) {
            $course = $row->course_json === null
                ? ['course_type' => $row->legacy_type, 'course_place' => $row->legacy_place]
                : json_decode($row->course_json, true, 512, JSON_THROW_ON_ERROR);
            $course['sessions'] = $sessions[(int) $row->courseid] ?? [];
            $row->course_json = json_encode($course, JSON_THROW_ON_ERROR);
        }
        $contact = get_object_vars($client);
        return ['client_id' => $clientId, 'contact' => $contact, 'history' => $history, 'administrator' => $administrator];
    }
}
