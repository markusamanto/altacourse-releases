-- Add receipt metadata without inventing dates for historical acknowledgements.
ALTER TABLE `#__altacourses_requests`
  ADD COLUMN `received_at` datetime DEFAULT NULL COMMENT 'First receipt link acknowledgement, UTC',
  ADD COLUMN `receipt_token_hash` char(64) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL,
  ADD UNIQUE KEY `idx_receipt_token_hash` (`receipt_token_hash`);
