<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
use Joomla\CMS\Language\Text;
\defined('_JEXEC') or die;
$view = $displayData['view'];
?>
<dl data-contact-details>
<?php foreach (['firstname' => 'SUPPLIER_FIRSTNAME', 'lastname' => 'SUPPLIER_LASTNAME', 'company' => 'ENQUIRY_ORGANISATION', 'email' => 'ENQUIRY_EMAIL', 'phone' => 'SUPPLIER_PHONE', 'mobile' => 'SUPPLIER_MOBILE', 'age' => 'SIGNUP_AGE', 'profession' => 'SIGNUP_PROFESSION', 'specialmeal' => 'SIGNUP_SPECIALMEAL', 'postal_address' => 'SIGNUP_POSTAL_ADDRESS', 'postal_zip' => 'SIGNUP_POSTAL_ZIP', 'postal_city' => 'SIGNUP_POSTAL_CITY', 'postal_state' => 'CLIENT_POSTAL_STATE', 'postal_country' => 'CLIENT_POSTAL_COUNTRY', 'invoice_address' => 'SIGNUP_INVOICE_ADDRESS', 'invoice_zip' => 'SIGNUP_INVOICE_ZIP', 'invoice_city' => 'SIGNUP_INVOICE_CITY'] as $field => $label) : ?>
    <?php if (!empty($displayData['submitted']) && !array_key_exists($field, $view->contact)) { continue; } ?>
    <dt><?php echo $view->escape(Text::_('COM_ALTACOURSES_' . $label)); ?></dt><dd><?php echo $view->escape(is_scalar($view->contact[$field] ?? null) ? (string) $view->contact[$field] : ''); ?></dd>
<?php endforeach; ?>
</dl>
