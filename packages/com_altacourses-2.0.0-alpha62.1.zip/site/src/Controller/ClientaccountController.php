<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Controller;

use Advenire\Component\Altacourses\Site\Exception\CourseValidationException;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;

final class ClientaccountController extends BaseController
{
    public function execute($task)
    {
        if (strtolower((string) $task) !== 'save') { throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'), 404); }
        return parent::execute($task);
    }

    public function save(): void
    {
        $model = $this->getModel('Accounts', 'Site', ['ignore_request' => true]);
        $model->requireAdministrator();
        if ($this->input->getMethod() !== 'POST') { throw new \RuntimeException(Text::_('COM_ALTACOURSES_SAMPLE_POST_REQUIRED'), 405); }
        if (!$this->checkToken('post', false)) { throw new \RuntimeException(Text::_('JINVALID_TOKEN'), 403); }
        $raw = $this->input->post->get('jform', [], 'array');
        if (array_diff(array_keys($raw), ['client_id', 'version', 'account'])
            || !isset($raw['client_id'], $raw['version'], $raw['account'])
            || !is_string($raw['client_id']) || !ctype_digit($raw['client_id']) || (float) $raw['client_id'] > 2147483647
            || !is_string($raw['version']) || !preg_match('/^[a-f0-9]{64}$/D', $raw['version']) || !is_string($raw['account'])) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_ACCOUNT_INVALID'), 400);
        }
        $navigation = ['return_start' => $this->input->get('return_start', '0', 'raw')];
        if (!is_string($navigation['return_start']) || !ctype_digit($navigation['return_start']) || (float) $navigation['return_start'] > 2147483647) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_FILTER'), 400);
        }
        foreach (['kind' => 10, 'search' => 120, 'type' => 255] as $key => $length) {
            $value = $this->input->get($key, $key === 'kind' ? 'all' : '', 'raw');
            if (!is_string($value) || mb_strlen($value) > $length || preg_match('/[\x00-\x1f\x7f]/', $value)) {
                throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_FILTER'), 400);
            }
            $navigation[$key] = trim($value);
        }
        if (!in_array($navigation['kind'], ['all', 'signup', 'enquiry'], true)) { throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_FILTER'), 400); }
        $return = Route::_('index.php?' . http_build_query(['option' => 'com_altacourses', 'view' => 'client', 'id' => (int) $raw['client_id']] + $navigation), false);
        try {
            $model->saveClientAccount((int) $raw['client_id'], $raw['version'], $raw['account']);
        } catch (CourseValidationException $exception) {
            $this->setMessage(Text::_('COM_ALTACOURSES_ACCOUNT_INVALID'), 'warning');
            $this->setRedirect($return);
            return;
        } catch (\Throwable $exception) {
            if (in_array($exception->getCode(), [403, 404, 409], true)) { throw $exception; }
            $this->app->getLogger()->error('Altacourses client account save failed', ['exception' => $exception]);
            $this->setMessage(Text::_('COM_ALTACOURSES_ACCOUNT_FAILED'), 'warning');
            $this->setRedirect($return);
            return;
        }
        $this->setMessage(Text::_('COM_ALTACOURSES_CLIENTACCOUNT_SAVED'));
        $this->setRedirect($return);
    }
}
