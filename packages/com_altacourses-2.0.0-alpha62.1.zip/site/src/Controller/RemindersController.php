<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Controller;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;

final class RemindersController extends BaseController
{
    public function execute($task)
    {
        if (!in_array(strtolower((string) $task), ['send', 'retry', 'confirm'], true) || $this->app->getDocument()->getType() !== 'html') {
            throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'), 404);
        }
        $model = $this->getModel('Reminders', 'Site', ['ignore_request' => true]);
        $model->requireAdministrator();
        if ($this->input->getMethod() !== 'POST') { throw new \RuntimeException(Text::_('COM_ALTACOURSES_AVAILABILITY_POST_REQUIRED'), 405); }
        if (!$this->checkToken('post', false)) { throw new \RuntimeException(Text::_('JINVALID_TOKEN'), 403); }
        $data = $this->input->post->get('jform', [], 'array');
        $allowed = strtolower($task) === 'send' ? ['month'] : ['month', 'id', 'token', 'review'];
        if (count($data) !== count($allowed) || array_diff(array_keys($data), $allowed) || !is_string($data['month'] ?? null)) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_COMMISSION_INVALID'), 400);
        }
        $model->validateMonth($data['month']);
        if (isset($data['id']) && (!is_string($data['id']) || !ctype_digit($data['id']) || (float) $data['id'] > 2147483647 || (int) $data['id'] < 1)) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_COMMISSION_INVALID'), 400);
        }
        if (in_array(strtolower($task), ['retry', 'confirm'], true)
            && (($data['review'] ?? null) !== '1' || !is_string($data['token'] ?? null) || !preg_match('/^[a-f0-9]{64}$/D', $data['token']))) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_COMMISSION_INVALID'), 400);
        }
        try {
            if (strtolower($task) === 'send') {
                $result = $model->runPeriod($data['month']);
                $this->setMessage(Text::_('COM_ALTACOURSES_REMINDER_RESULT_' . strtoupper($result)), $result === 'complete' ? 'message' : 'warning');
            } else {
                $model->review($data['month'], (int) $data['id'], $data['token'], strtolower($task) === 'confirm');
                $this->setMessage(Text::_('COM_ALTACOURSES_REMINDER_REVIEW_SAVED'));
            }
        } catch (\Throwable $error) {
            if (in_array($error->getCode(), [400, 403, 404, 409], true)) { throw $error; }
            $this->app->getLogger()->error('Altacourses supplier reminder failed; inspect private archive');
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_COMMISSION_FAILED'), 500);
        }
        $this->setRedirect(Route::_('index.php?option=com_altacourses&view=reminders&month=' . rawurlencode($data['month']), false));
        return true;
    }
}
