<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Field;

use Joomla\CMS\Form\Field\CalendarField;

\defined('_JEXEC') or die;

/** Joomla calendar with date-only values and unchanged strict server validation. */
final class CoursedateField extends CalendarField
{
    protected $type = 'Coursedate';

    public function setup(\SimpleXMLElement $element, $value, $group = null)
    {
        $element['format'] = '%Y-%m-%d';
        $element['translateformat'] = 'false';
        $element['showtime'] = 'false';
        $element['weeknumbers'] = 'true';
        $element['filter'] = 'string';
        $element['hint'] = 'COM_ALTACOURSES_DATE_HINT';
        return parent::setup($element, $value, $group);
    }

    protected function getInput()
    {
        // CalendarField::getInput uses strtotime, which can normalise an invalid date.
        // Render the native layout directly so failed validation retains the typed value.
        return $this->getRenderer($this->layout)->render($this->collectLayoutData());
    }
}
