<?php
/** @package Altacourses.Administrator @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Administrator\Service;
use Joomla\Database\DatabaseInterface;
\defined('_JEXEC') or die;
/** Shared read projection; callers enforce their own administrator/task access. */
final class PendingParticipation
{
    public function __construct(private readonly DatabaseInterface $database) {}
    public function items(string $today): array
    {
        $supplier = "COALESCE(NULLIF(TRIM(sp.company),''),NULLIF(TRIM(u.name),''),'')";
        $query = $this->database->createQuery()->select([
            'r.id', 'r.asked_for_info', 'r.rebooked', 'co.start_date', 'co.cr AS supplier_user_id',
            $supplier . ' AS supplier_name', 'cl.firstname', 'cl.lastname', 'cl.id AS linked_client_id', 'u.email AS supplier_email', 'u.id AS supplier_account_id', 'u.block AS supplier_blocked',
        ])->from('#__altacourses_requests AS r')
            ->join('INNER', '#__altacourses_courses AS co ON co.id=r.courseid')
            ->join('LEFT', '#__altacourses_clients AS cl ON cl.id=r.clientid')
            ->join('LEFT', '#__altacourses_suppliers AS sp ON sp.user_id=co.cr')
            ->join('LEFT', '#__users AS u ON u.id=co.cr')
            ->where('r.asked_for_info IN (0,1)')
            ->where('COALESCE(r.participated,0)=0')->where('COALESCE(r.canceled,0)=0')
            ->where('COALESCE(r.rebooked,0) IN (0,1)')
            ->where("(r.date_reported IS NULL OR CAST(r.date_reported AS CHAR) LIKE '0000-%')")
            ->where("co.start_date IS NOT NULL AND CAST(co.start_date AS CHAR) NOT LIKE '0000-%' AND DATE(co.start_date)<=:unconfirmed_today")
            ->bind(':unconfirmed_today', $today)
            ->order(['supplier_name ASC', 'DATE(co.start_date) ASC', 'cl.firstname ASC', 'cl.lastname ASC', 'r.id ASC']);
        $rows = $this->database->setQuery($query)->loadObjectList();
        foreach ($rows as $row) {
            $row->client_name = trim(($row->firstname ?? '') . ' ' . ($row->lastname ?? ''));
        }
        return $rows;
    }
}
