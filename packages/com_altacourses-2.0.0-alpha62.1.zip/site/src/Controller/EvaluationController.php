<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Controller;
use Advenire\Component\Altacourses\Site\Exception\CourseValidationException;
use Joomla\CMS\Event\PageCache\IsExcludedEvent;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;
\defined('_JEXEC') or die;
final class EvaluationController extends BaseController
{
    public function execute($task)
    {
        $this->app->allowCache(false);
        foreach (['Cache-Control'=>'private, no-store, no-cache, must-revalidate','Referrer-Policy'=>'no-referrer','X-Robots-Tag'=>'noindex, nofollow'] as $k=>$v) { $this->app->setHeader($k,$v,true); }
        $this->app->getDispatcher()->addListener('onPageCacheIsExcluded',static function(IsExcludedEvent $e):void{$e->addResult(true);});$this->app->sendHeaders();
        if (!in_array(strtolower((string)$task),['edit','submit'],true)||$this->app->getDocument()->getType()!=='html') { throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'),404); }
        return parent::execute($task);
    }
    public function edit(): void
    {
        if ($this->input->getMethod()!=='GET') { throw new \RuntimeException(Text::_('COM_ALTACOURSES_RECEIPT_GET_REQUIRED'),405); }
        $raw=$this->input->get('requestid','0','raw');
        $id=is_string($raw)&&ctype_digit($raw)&&(float)$raw<=4294967295?(int)$raw:0;
        $entry=$this->getModel('Evaluation','Site',['ignore_request'=>true])->enter($id,$this->input->get('code',null,'raw'));
        $ticket=bin2hex(random_bytes(32));$slots=$this->app->getUserState('com_altacourses.evaluation.slots',[])?:[];
        $slots=array_slice($slots,-19,null,true);$slots[$ticket]=$entry+['created'=>time(),'draft'=>[]];
        $this->app->setUserState('com_altacourses.evaluation.slots',$slots);
        $this->setRedirect(Route::_('index.php?option=com_altacourses&view=evaluation&ticket='.$ticket,false));
    }
    public function submit(): void
    {
        if ($this->input->getMethod()!=='POST') { throw new \RuntimeException(Text::_('COM_ALTACOURSES_SAMPLE_POST_REQUIRED'),405); }
        if (!$this->checkToken('post',false)) { throw new \RuntimeException(Text::_('JINVALID_TOKEN'),403); }
        $raw=$this->input->post->get('jform',[],'array');$ticket=$raw['ticket']??null;
        if (!is_string($ticket)||!preg_match('/^[a-f0-9]{64}$/D',$ticket)) { throw new \RuntimeException(Text::_('COM_ALTACOURSES_EVALUATION_INVALID'),400); }
        $slots=$this->app->getUserState('com_altacourses.evaluation.slots',[])?:[];$slot=$slots[$ticket]??[];
        if (!isset($slot['request_id'],$slot['proof'])) { $this->setRedirect(Route::_('index.php?option=com_altacourses&view=evaluation',false));return; }
        unset($raw['ticket']);
        try { $status=$this->getModel('Evaluation','Site',['ignore_request'=>true])->submit((int)$slot['request_id'],$slot['proof'],$raw); }
        catch (CourseValidationException $e) {
            foreach ($e->messages as $message) { $this->app->enqueueMessage($message,'warning'); }
            $draft=array_intersect_key($raw,array_flip(['rating_overall','rating_leaders','rating_place','review','feedback','correction']));
            foreach ($draft as $k=>$v) { if (!is_string($v)||strlen($v)>65535) { unset($draft[$k]); } }
            $slots[$ticket]['draft']=$draft;$this->app->setUserState('com_altacourses.evaluation.slots',$slots);
            $this->setRedirect(Route::_('index.php?option=com_altacourses&view=evaluation&ticket='.$ticket,false));return;
        }
        $slots[$ticket]['status']=$status;$slots[$ticket]['draft']=[];
        if ($status==='invalid') { unset($slots[$ticket]['proof'],$slots[$ticket]['request_id']); }
        $this->app->setUserState('com_altacourses.evaluation.slots',$slots);
        $this->setRedirect(Route::_('index.php?option=com_altacourses&view='.($status==='thanks'?'evaluationthanks':'evaluation').'&ticket='.$ticket,false));
    }
}
