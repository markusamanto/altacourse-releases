-- Preserve all existing participation flags and reporting dates.
ALTER TABLE `#__altacourses_requests`
  ADD COLUMN `participation_version` int UNSIGNED NOT NULL DEFAULT '0',
  ADD COLUMN `reported_by` int DEFAULT NULL;
