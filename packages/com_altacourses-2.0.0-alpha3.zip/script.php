<?php

/**
 * @package     Altacourses.Installer
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Installer;

use Joomla\CMS\Installer\InstallerAdapter;
use Joomla\CMS\Installer\InstallerScriptInterface;
use Joomla\CMS\Language\Text;
use Joomla\Database\DatabaseInterface;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;

\defined('_JEXEC') or die;

return new class () implements ServiceProviderInterface {
    public function register(Container $container): void
    {
        $container->set(
            InstallerScriptInterface::class,
            static fn (Container $container): InstallerScriptInterface => new class ($container->get(DatabaseInterface::class)) implements InstallerScriptInterface {
                public function __construct(private readonly DatabaseInterface $database)
                {
                }

                public function preflight(string $type, InstallerAdapter $adapter): bool
                {
                    if ($type === 'uninstall') {
                        return true;
                    }

                    if (version_compare(JVERSION, '6.2.0', '<') || version_compare(PHP_VERSION, '8.4.0', '<')) {
                        throw new \RuntimeException(Text::_('COM_ALTACOURSES_INSTALL_REQUIREMENTS'));
                    }

                    $prefix = $this->database->getPrefix() . 'altacourses_';

                    foreach ($this->database->getTableList() as $table) {
                        if (str_starts_with($table, $prefix)) {
                            throw new \RuntimeException(Text::_('COM_ALTACOURSES_INSTALL_EXISTING_DATA'));
                        }
                    }

                    $manifest = JPATH_ADMINISTRATOR . '/components/com_altacourses/altacourses.xml';

                    if (is_file($manifest)) {
                        $installed = simplexml_load_file($manifest);

                        if ($installed === false || (string) $installed->namespace !== 'Advenire\\Component\\Altacourses') {
                            throw new \RuntimeException(Text::_('COM_ALTACOURSES_INSTALL_LEGACY'));
                        }
                    }

                    return true;
                }

                public function install(InstallerAdapter $adapter): bool
                {
                    return true;
                }

                public function update(InstallerAdapter $adapter): bool
                {
                    return true;
                }

                public function uninstall(InstallerAdapter $adapter): bool
                {
                    return true;
                }

                public function postflight(string $type, InstallerAdapter $adapter): bool
                {
                    return true;
                }
            }
        );
    }
};
