<?php
/** @package Altacourses.Administrator @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Administrator\Service;
use Joomla\CMS\Http\HttpFactory;
use Joomla\CMS\String\PunycodeHelper;
use Joomla\Database\DatabaseInterface;
use Joomla\Registry\Registry;
\defined('_JEXEC') or die;

/** Daily, resumable audience enrolment; preview never invokes the transport or writes a ledger. */
final class MailchimpEnrollments
{
    public function __construct(private readonly DatabaseInterface $db, private readonly ?\Closure $transport = null, private readonly ?\Closure $clock = null) {}
    private function now(): \DateTimeImmutable { return $this->clock ? ($this->clock)() : new \DateTimeImmutable('now',new \DateTimeZone('UTC')); }
    private function stamp(): string { return $this->now()->setTimezone(new \DateTimeZone('UTC'))->format('Y-m-d H:i:s'); }
    private function config(): array
    {
        return json_decode($this->db->setQuery("SELECT params FROM #__extensions WHERE element='com_altacourses' AND type='component' AND enabled=1")->loadResult()?:'{}',true,flags:JSON_THROW_ON_ERROR);
    }
    /** Safe for the admin page: never return credentials. */
    public function settings(): array
    {
        $p=$this->config();$type=(int)($p['mailchimp_course_type']??0);$audience=(string)($p['mailchimp_audience']??'');
        return ['mode'=>in_array($p['mailchimp_mode']??'off',['off','preview','live'],true)?$p['mailchimp_mode']??'off':'off','type'=>$type,'audience'=>$audience,
            'configured'=>$type>0&&preg_match('/^[a-zA-Z0-9]{1,32}$/D',$audience)===1,
            'key_configured'=>preg_match('/^[a-f0-9]{32}-[a-z]{2}[0-9]{1,4}$/D',(string)($p['mailchimp_key']??''))===1];
    }
    private function address(string $value): ?string
    {
        $value=strtolower(trim($value));
        try {$value=PunycodeHelper::emailToPunycode($value);} catch (\Throwable) { return null; }
        return strlen($value)<=254&&filter_var($value,FILTER_VALIDATE_EMAIL)?$value:null;
    }
    private function eligibleQuery(array $s): \Joomla\Database\QueryInterface
    {
        $today=$this->now()->setTimezone(new \DateTimeZone('Europe/Stockholm'));
        $from=$today->modify('+7 days')->format('Y-m-d');$until=$today->modify('+14 days')->format('Y-m-d');$type=$s['type'];
        // Preserve the legacy strict datetime/date-string window, including the seventh day after midnight.
        $q=$this->db->createQuery()->select(['r.id AS request_id','r.clientid','cl.firstname','cl.lastname','cl.email','co.start_date','cp.name AS course_place'])
            ->from('#__altacourses_requests AS r')->join('INNER','#__altacourses_clients AS cl ON cl.id=r.clientid')
            ->join('INNER','#__altacourses_courses AS co ON co.id=r.courseid')->join('LEFT','#__altacourses_courseplaces AS cp ON cp.id=co.course_place')
            ->where('r.asked_for_info=0 AND COALESCE(r.canceled,0)=0 AND COALESCE(r.rebooked,0) IN (0,1)')
            ->where('co.course_type='.(int)$type)->where('co.start_date>'.$this->db->quote($from))->where('co.start_date<'.$this->db->quote($until))->order(['co.start_date','r.id']);
        return $q;
    }
    public function candidates(): array
    {
        $s=$this->settings();if(!$s['configured']){return [];}
        $rows=$this->db->setQuery($this->eligibleQuery($s))->loadObjectList();$out=[];
        foreach($rows as $row){$email=$this->address((string)$row->email);$hash=$email!==null?md5($email):null;$row->email=$email??$row->email;$row->hash=$hash;
            if($hash!==null&&isset($out[$hash])){continue;}
            $row->record=$hash!==null?$this->db->setQuery('SELECT * FROM #__altacourses_mailchimp_enrollments WHERE audience_id='.$this->db->quote($s['audience']).' AND email_hash='.$this->db->quote($hash))->loadObject():null;
            $out[$hash??'invalid-'.$row->request_id]=$row;
        }
        return array_values($out);
    }
    private function stillEligible(object $candidate,array $settings): bool
    {
        $current=$this->settings();
        if($current['mode']!=='live'||$current['type']!==$settings['type']||$current['audience']!==$settings['audience']){return false;}
        $row=$this->db->setQuery($this->eligibleQuery($settings)->where('r.id='.(int)$candidate->request_id))->loadObject();
        return $row!==null&&$this->address((string)$row->email)===$candidate->email;
    }
    public function history(): array
    {
        return $this->db->setQuery('SELECT m.*,cl.firstname,cl.lastname FROM #__altacourses_mailchimp_enrollments m LEFT JOIN #__altacourses_clients cl ON cl.id=m.client_id ORDER BY m.updated_at DESC,m.id DESC',0,100)->loadObjectList();
    }
    /** Requeue only a reviewed error. It still must pass current eligibility on the next task run. */
    public function retry(int $id,string $revision): void
    {
        $this->db->setQuery("UPDATE #__altacourses_mailchimp_enrollments SET state='retry',next_attempt_at=NULL,last_error=NULL,revision=revision+1 WHERE id=".$id." AND state='error' AND revision=".(int)$revision)->execute();
        if($this->db->getAffectedRows()!==1){throw new \RuntimeException('Enrolment changed',409);}
    }
    private function request(string $method,string $url,?array $data,string $key): array
    {
        try{
            if($this->transport){return ($this->transport)($method,$url,$data);}
            $http=HttpFactory::getHttp(new Registry(['follow_location'=>false]));$headers=['Authorization'=>'Bearer '.$key,'Content-Type'=>'application/json','Accept'=>'application/json'];
            $r=$method==='GET'?$http->get($url,$headers,8):$http->put($url,json_encode($data,JSON_THROW_ON_ERROR),$headers,8);
            return ['code'=>(int)$r->code,'body'=>(string)$r->body,'headers'=>$r->headers];
        }catch(\Throwable){return ['code'=>0,'body'=>'','headers'=>[]];}
    }
    private function body(array $response): ?array
    {
        if(!is_string($response['body']??null)||strlen($response['body'])>1048576){return null;}
        try{$data=json_decode($response['body'],true,32,JSON_THROW_ON_ERROR);return is_array($data)?$data:null;}catch(\Throwable){return null;}
    }
    private function save(int $id,string $state,?string $error=null,int $code=0,int $delay=0): void
    {
        $row=(object)['id'=>$id,'state'=>$state,'last_error'=>$error,'http_status'=>$code,'updated_at'=>$this->stamp(),
            'next_attempt_at'=>$delay>0?$this->now()->modify('+'.$delay.' seconds')->setTimezone(new \DateTimeZone('UTC'))->format('Y-m-d H:i:s'):null];
        $this->db->updateObject('#__altacourses_mailchimp_enrollments',$row,'id',true);
    }
    private function failed(int $id,array $r): void
    {
        $code=(int)($r['code']??0);$transient=$code===0||in_array($code,[408,425,429],true)||$code>=500;
        // Store fixed codes only: API bodies/exceptions can contain addresses, keys and other private data.
        $delay=$transient?3600:0;
        if($code===429){foreach($r['headers']??[] as $name=>$value){if(strtolower((string)$name)==='retry-after'&&is_scalar($value)){if(ctype_digit((string)$value)){$delay=max($delay,min(2147483647,(int)$value));}elseif(($at=strtotime((string)$value))!==false){$delay=max($delay,$at-$this->now()->getTimestamp());}}}}
        $this->save($id,$transient?'retry':'error',$code===0?'transport_failure':'http_'.$code,$code,$delay);
    }
    public function runDue(): string
    {
        $s=$this->settings();if($s['mode']==='off'){return 'blocked';}if($s['mode']==='preview'){return 'preview';}
        if(!$s['configured']||!$s['key_configured']){return 'blocked';}
        $p=$this->config();$key=$p['mailchimp_key'];preg_match('/-([a-z]{2}[0-9]{1,4})$/D',$key,$match);
        $root='https://'.$match[1].'.api.mailchimp.com/3.0/lists/'.rawurlencode($s['audience']).'/members/';
        $lock='alta-mc-'.substr(hash('sha256',$this->db->getPrefix()),0,32);
        if((int)$this->db->setQuery('SELECT GET_LOCK('.$this->db->quote($lock).',0)')->loadResult()!==1){return 'busy';}
        try{
            $started=microtime(true);$review=false;
            foreach($this->candidates() as $c){
                if($c->hash===null){$review=true;continue;}
                $r=$c->record;
                if($r!==null&&in_array($r->state,['enrolled','existing','suppressed'],true)){continue;}
                if($r!==null&&$r->state==='error'){$review=true;continue;}
                if($r!==null&&$r->state==='retry'&&$r->next_attempt_at!==null&&$r->next_attempt_at>$this->stamp()){continue;}
                if(microtime(true)-$started>=20){return 'pending';}
                if($r===null){$r=(object)['audience_id'=>$s['audience'],'email_hash'=>$c->hash,'request_id'=>(int)$c->request_id,'client_id'=>(int)$c->clientid,'state'=>'retry','attempts'=>0,'revision'=>0,'created_at'=>$this->stamp(),'updated_at'=>$this->stamp()];$this->db->insertObject('#__altacourses_mailchimp_enrollments',$r,'id');}
                // Claim before HTTP; interrupted PUTs are reconciled through GET on the next run.
                $this->db->setQuery("UPDATE #__altacourses_mailchimp_enrollments SET state='retry',attempts=attempts+1,revision=revision+1,updated_at=".$this->db->quote($this->stamp()).',request_id='.(int)$c->request_id.',client_id='.(int)$c->clientid.' WHERE id='.(int)$r->id)->execute();
                if(!$this->stillEligible($c,$s)){$this->save((int)$r->id,'retry','request_changed');continue;}
                $url=$root.$c->hash;$response=$this->request('GET',$url,null,$key);$body=$this->body($response);$code=(int)$response['code'];$created=false;
                if($code===404&&($body['status']??null)===404){
                    if(!$this->stillEligible($c,$s)){$this->save((int)$r->id,'retry','request_changed');continue;}
                    $response=$this->request('PUT',$url,['email_address'=>$c->email,'status_if_new'=>'subscribed','language'=>'sv','merge_fields'=>['FNAME'=>$c->firstname??'','LNAME'=>$c->lastname??'','USERID'=>(string)$c->clientid]],$key);
                    $body=$this->body($response);$code=(int)$response['code'];$created=true;
                }
                if($code===200&&$body!==null&&$this->address((string)($body['email_address']??''))===$c->email&&in_array($body['status']??null,['subscribed','unsubscribed','cleaned','pending','transactional','archived'],true)){
                    $this->save((int)$r->id,$body['status']==='subscribed'?($created?'enrolled':'existing'):'suppressed',null,$code);
                }elseif($code===200||$code===404&&$body===null){$this->save((int)$r->id,'retry','invalid_response',$code,3600);$review=true;}
                else{$this->failed((int)$r->id,$response);$review=true;}
                if(in_array($code,[401,403,429],true)){return 'review';}
            }
            return $review?'review':'complete';
        }finally{$this->db->setQuery('SELECT RELEASE_LOCK('.$this->db->quote($lock).')')->loadResult();}
    }
}
