<?php
/** @package Altacourses.Administrator @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Administrator\Service;

use Joomla\CMS\Mail\Mail;
use Joomla\CMS\Mail\MailerFactoryInterface;
use Joomla\CMS\String\PunycodeHelper;
use Joomla\Database\DatabaseInterface;
use Joomla\Registry\Registry;

\defined('_JEXEC') or die;

/** Monthly per-supplier claims, immutable prepared mail and explicit recovery of uncertain delivery. */
final class SupplierReminders
{
    public function __construct(private readonly DatabaseInterface $db, private readonly Registry $config,
        private readonly NotificationService $notifications, private readonly MailerFactoryInterface $mailers,
        private readonly ?\Closure $clock = null) {}

    private function now(): \DateTimeImmutable { return $this->clock !== null ? ($this->clock)() : new \DateTimeImmutable('now', new \DateTimeZone('UTC')); }
    private function timestamp(): string { return $this->now()->setTimezone(new \DateTimeZone('UTC'))->format('Y-m-d H:i:s'); }
    private function localNow(): \DateTimeImmutable { return $this->now()->setTimezone(new \DateTimeZone('Europe/Stockholm')); }
    public function currentPeriod(): string { return $this->localNow()->format('Y-m'); }
    public function validatePeriod(string $period): void
    {
        if (!preg_match('/^(?:19|[2-9]\d)\d{2}-(?:0[1-9]|1[0-2])$/D', $period)) { throw new \RuntimeException('Invalid reminder month', 400); }
    }
    public function blockedReason(): ?string
    {
        $params = json_decode($this->db->setQuery("SELECT params FROM #__extensions WHERE element='com_altacourses' AND type='component' AND enabled=1")->loadResult() ?: '{}', true, flags: JSON_THROW_ON_ERROR);
        return $this->notifications->sandboxReason(($params['reminder_mode'] ?? 'off') === 'sandbox');
    }
    public function messages(string $period): array
    {
        $this->validatePeriod($period);
        return $this->db->setQuery('SELECT * FROM #__altacourses_supplier_reminders WHERE period=' . $this->db->quote($period) . ' ORDER BY supplier_name,supplier_user_id,id')->loadObjectList();
    }
    private function eligible(): array
    {
        $today = $this->now()->setTimezone(new \DateTimeZone((string) $this->config->get('offset', 'UTC')))->format('Y-m-d');
        $groups = [];
        foreach ((new PendingParticipation($this->db))->items($today) as $row) {
            $id = max(0, (int) $row->supplier_user_id);
            if (!isset($groups[$id])) { $groups[$id] = $row; }
        }
        return $groups;
    }
    public function runDue(): string
    {
        $local = $this->localNow();
        if ($local < new \DateTimeImmutable($local->format('Y-m') . '-20 09:00:00', new \DateTimeZone('Europe/Stockholm'))) { return 'not_due'; }
        if ($this->blockedReason() !== null) { return 'blocked'; }
        return $this->runPeriod($this->currentPeriod());
    }
    /** Explicit administrator test/recovery run; may prepare previews while delivery is disabled. */
    public function runPeriod(string $period): string
    {
        $this->validatePeriod($period);
        if ($period !== $this->currentPeriod()) { throw new \RuntimeException('Only the current reminder month can be prepared', 409); }
        $eligible = $this->eligible();
        $template = $this->db->setQuery('SELECT * FROM #__altacourses_mailtemplates WHERE type=3 AND COALESCE(course_type,0)=0 AND state=1')->loadObject();
        foreach ($eligible as $id => $supplier) { $this->prepare($period, $id, $supplier, $template); }
        if ($this->blockedReason() !== null) { return 'blocked'; }
        foreach ($this->messages($period) as $row) {
            if (!isset($eligible[(int) $row->supplier_user_id]) && in_array($row->state, ['pending','blocked'], true) && (int) $row->attempts === 0) {
                $this->db->setQuery("UPDATE #__altacourses_supplier_reminders SET state='skipped',last_error='no_pending_requests' WHERE id=" . (int) $row->id . " AND state IN ('pending','blocked') AND attempts=0")->execute();
            } elseif ($row->state === 'pending') { $this->deliver($row); }
        }
        foreach ($this->messages($period) as $row) { if (!in_array($row->state, ['sent','skipped'], true)) { return 'review'; } }
        return 'complete';
    }
    private function templateError(?object $template): ?string
    {
        if ($template === null) { return 'missing_template_3'; }
        if (!$this->notifications->validAddress((string) $template->from_email)) { return 'invalid_template_sender'; }
        foreach (['subject','from_name'] as $field) {
            if (trim((string) $template->$field) === '' || mb_strlen($template->$field) > 255 || preg_match('/[\r\n\x00]/', $template->$field)) { return 'invalid_template_headers'; }
        }
        if (trim((string) $template->message) === '' || !mb_check_encoding($template->message, 'UTF-8') || preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', $template->message)) { return 'invalid_template_body'; }
        return null;
    }
    private function prepare(string $period, int $id, object $supplier, ?object $template): void
    {
        $error = ((int) $supplier->supplier_account_id <= 0 || (int) $supplier->supplier_blocked !== 0) ? 'supplier_unavailable'
            : (!$this->notifications->validAddress((string) $supplier->supplier_email) ? 'invalid_supplier_email' : $this->templateError($template));
        $row = (object) ['period'=>$period,'supplier_user_id'=>$id,'supplier_name'=>mb_substr(trim($supplier->supplier_name) ?: ($id > 0 ? 'Supplier #' . $id : 'Unassigned'),0,255),
            'recipient'=>$error === null ? PunycodeHelper::emailToPunycode($supplier->supplier_email) : '',
            'from_email'=>$error === null ? PunycodeHelper::emailToPunycode($template->from_email) : '',
            'from_name'=>$error === null ? $template->from_name : '', 'subject'=>$error === null ? '[TEST] ' . mb_substr($template->subject,0,248) : '',
            'body'=>$error === null ? $template->message : '', 'template_id'=>$template?->id,
            'message_id'=>'<' . bin2hex(random_bytes(24)) . '@altacourses.invalid>', 'state'=>$error === null ? 'pending' : 'blocked',
            'last_error'=>$error,'created_at'=>$this->timestamp()];
        $row->payload_hash = $this->digest($row);
        try { $this->db->insertObject('#__altacourses_supplier_reminders', $row, 'id'); }
        catch (\Throwable $e) {
            $old = $this->db->setQuery('SELECT * FROM #__altacourses_supplier_reminders WHERE period=' . $this->db->quote($period) . ' AND supplier_user_id=' . $id)->loadObject();
            if ($old === null) { throw $e; }
            if ((int) $old->attempts !== 0 || !in_array($old->state, ['blocked','skipped'], true)) { return; }
            // Only an unattempted blocked/skipped placeholder can be prepared again after correction.
            $q = $this->db->createQuery()->update('#__altacourses_supplier_reminders');
            foreach (get_object_vars($row) as $key=>$value) { if ($key !== 'id') { $q->set($this->db->quoteName($key) . '=' . ($value === null ? 'NULL' : $this->db->quote((string)$value))); } }
            $q->where('id=' . (int)$old->id)->where("state IN ('blocked','skipped') AND attempts=0");$this->db->setQuery($q)->execute();
        }
    }
    private function digest(object $r): string
    {
        return hash('sha256', json_encode([$r->period,(int)$r->supplier_user_id,$r->recipient,$r->from_email,$r->from_name,$r->subject,$r->body,$r->template_id === null ? null : (int)$r->template_id,$r->message_id],JSON_THROW_ON_ERROR));
    }
    private function deliver(object $row): void
    {
        if ($this->blockedReason() !== null) { return; }
        if (!hash_equals($row->payload_hash, $this->digest($row)) || !$this->notifications->validAddress($row->recipient)) { throw new \RuntimeException('Reminder archive integrity check failed'); }
        $activeTemplate = $this->db->setQuery('SELECT * FROM #__altacourses_mailtemplates WHERE type=3 AND COALESCE(course_type,0)=0 AND state=1')->loadObject();
        $templateIssue = $this->templateError($activeTemplate) ?? ((int)$activeTemplate->id !== (int)$row->template_id ? 'template_changed' : null);
        if ($templateIssue !== null) {
            $state = (int)$row->attempts > 0 ? 'uncertain' : 'blocked';
            $this->db->setQuery('UPDATE #__altacourses_supplier_reminders SET state=' . $this->db->quote($state) . ',last_error=' . $this->db->quote($templateIssue) . ' WHERE id=' . (int)$row->id . " AND state='pending'")->execute();return;
        }
        $current = $this->eligible()[(int)$row->supplier_user_id] ?? null;
        $reason = $current === null ? 'no_pending_requests' : ((int)$current->supplier_blocked !== 0 || !$this->notifications->validAddress((string)$current->supplier_email) ? 'supplier_unavailable' : (PunycodeHelper::emailToPunycode($current->supplier_email) !== $row->recipient ? 'recipient_changed' : null));
        if ($reason !== null) {
            $this->db->setQuery("UPDATE #__altacourses_supplier_reminders SET state=" . $this->db->quote($current === null ? 'skipped' : 'blocked') . ',last_error=' . $this->db->quote($reason) . ' WHERE id=' . (int)$row->id . " AND state='pending'")->execute();return;
        }
        $token = bin2hex(random_bytes(32));
        $this->db->setQuery("UPDATE #__altacourses_supplier_reminders SET state='sending',attempts=attempts+1,attempt_token=" . $this->db->quote($token) . ',claimed_at=' . $this->db->quote($this->timestamp()) . ' WHERE id=' . (int)$row->id . " AND state='pending'")->execute();
        if ($this->db->getAffectedRows() !== 1) { return; }
        $mailer = null; $accepted = false;
        try {
            $mailer = $this->mailers->createMailer(new Registry(['throw_exceptions'=>true]));
            if (!$mailer instanceof Mail) { throw new \RuntimeException('Unsupported mailer'); }
            $mailer->SMTPAutoTLS=false;$mailer->Timeout=10;$mailer->getSMTPInstance()->Timelimit=10;$mailer->SMTPDebug=0;
            $mailer->MessageID=$row->message_id;$mailer->setSender($row->from_email,$row->from_name);$mailer->addRecipient($row->recipient);$mailer->setSubject($row->subject);$mailer->setBody($row->body);
            if ($mailer->send() !== true) { throw new \RuntimeException('No SMTP acceptance'); }
            $accepted=true;$this->finish((int)$row->id,$token,'sent',null);
        } catch (\Throwable $e) { $this->finish((int)$row->id,$token,'uncertain',$this->notifications->failureDiagnostic($mailer instanceof Mail ? $mailer : null,$e,$accepted)); }
    }
    private function finish(int $id,string $token,string $state,?string $error): void
    {
        $this->db->setQuery('UPDATE #__altacourses_supplier_reminders SET state=' . $this->db->quote($state) . ',last_error=' . ($error === null ? 'NULL' : $this->db->quote($error)) . ($state === 'sent' ? ',sent_at=' . $this->db->quote($this->timestamp()) : '') . ' WHERE id=' . $id . " AND state='sending' AND attempt_token=" . $this->db->quote($token))->execute();
        if ($this->db->getAffectedRows() !== 1) { throw new \RuntimeException('Reminder delivery state changed'); }
    }
    public function review(string $period,int $id,string $token,int $actor,bool $captured): void
    {
        $this->validatePeriod($period);$rows=array_filter($this->messages($period),static fn($r)=>(int)$r->id===$id);$row=reset($rows);
        if (!$row || $actor<=0 || !hash_equals((string)$row->attempt_token,$token)
            || !($row->state==='uncertain'||($row->state==='sending'&&strtotime($row->claimed_at.' UTC')<$this->now()->getTimestamp()-300))) { throw new \RuntimeException('Reminder changed; reload and review Mailtrap',409); }
        if (!$captured && ($this->blockedReason()!==null || $period!==$this->currentPeriod())) { throw new \RuntimeException('Reminder retry blocked',409); }
        if (!hash_equals($row->payload_hash,$this->digest($row))) { throw new \RuntimeException('Reminder archive integrity check failed',409); }
        $this->db->setQuery('UPDATE #__altacourses_supplier_reminders SET state=' . $this->db->quote($captured?'sent':'pending') . ',reviewed_by=' . $actor . ',reviewed_at=' . $this->db->quote($this->timestamp()) . ',last_error=' . $this->db->quote($captured?'operator_confirmed':'operator_retry') . ($captured?',sent_at='.$this->db->quote($this->timestamp()):'') . ' WHERE id=' . $id . ' AND state=' . $this->db->quote($row->state) . ' AND attempt_token=' . $this->db->quote($token))->execute();
        if ($this->db->getAffectedRows()!==1) { throw new \RuntimeException('Reminder review changed',409); }
        if (!$captured) { $row->state='pending';$this->deliver($row); }
    }
}
