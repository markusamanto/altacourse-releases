<?php
/** @package Altacourses.Administrator @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Administrator\Service;
use Joomla\CMS\Http\HttpFactory;
use Joomla\CMS\String\PunycodeHelper;
use Joomla\Database\DatabaseInterface;
use Joomla\Registry\Registry;
\defined('_JEXEC') or die;

/** Explicit submitted opt-ins only; Zenler owns subsequent unsubscribe preferences. */
final class ZenlerNewsletter
{
    public function __construct(private readonly DatabaseInterface $db,private readonly ?\Closure $transport=null,private readonly ?\Closure $clock=null) {}
    private function now(): \DateTimeImmutable { return $this->clock?($this->clock)():new \DateTimeImmutable('now',new \DateTimeZone('UTC')); }
    private function stamp(): string { return $this->now()->setTimezone(new \DateTimeZone('UTC'))->format('Y-m-d H:i:s'); }
    private function config(): array { return json_decode($this->db->setQuery("SELECT params FROM #__extensions WHERE element='com_altacourses' AND type='component' AND enabled=1")->loadResult()?:'{}',true,flags:JSON_THROW_ON_ERROR); }
    public function settings(): array
    {
        $p=$this->config();$account=$p['zenler_account']??'';$funnel=$p['zenler_funnel']??0;
        return ['mode'=>in_array($p['zenler_mode']??'off',['off','preview','live'],true)?($p['zenler_mode']??'off'):'off',
            'account'=>(string)$account,'funnel'=>(int)$funnel,'configured'=>is_string($account)&&preg_match('/^[a-z0-9][a-z0-9-]{0,62}$/D',$account)===1&&is_scalar($funnel)&&ctype_digit((string)$funnel)&&(float)$funnel>0&&(float)$funnel<=4294967295,
            'key_configured'=>is_string($p['zenler_key']??null)&&preg_match('/^[A-Za-z0-9_.-]{16,512}$/D',$p['zenler_key'])===1];
    }
    private function address(string $email): ?string
    {
        try{$email=strtolower(PunycodeHelper::emailToPunycode(trim($email)));}catch(\Throwable){return null;}
        return strlen($email)<=254&&filter_var($email,FILTER_VALIDATE_EMAIL)?$email:null;
    }
    /** Called within the successful form's database transaction. No external calls or flag changes. */
    public function queue(int $submissionId): void
    {
        $source=$this->db->setQuery('SELECT s.contact_json,r.clientid FROM #__altacourses_request_submissions s JOIN #__altacourses_requests r ON r.id=s.request_id WHERE s.id='.$submissionId)->loadObject();
        if($source===null){throw new \RuntimeException('Newsletter submission missing');}
        $contact=json_decode($source->contact_json,true,flags:JSON_THROW_ON_ERROR);
        if(($contact['newsletter']??'0')!=='1'){return;}
        $email=$this->address((string)($contact['email']??''));if($email===null){throw new \RuntimeException('Newsletter address invalid');}
        if($this->db->setQuery('SELECT id FROM #__altacourses_newsletter_deliveries WHERE submission_id='.$submissionId)->loadResult()!==null){return;}
        $s=$this->settings();$row=(object)['submission_id'=>$submissionId,'client_id'=>(int)$source->clientid,'email_hash'=>hash('sha256',$email),
            'account_name'=>$s['configured']?$s['account']:'','funnel_id'=>$s['configured']?$s['funnel']:0,'state'=>'pending','created_at'=>$this->stamp(),'updated_at'=>$this->stamp()];
        $this->db->insertObject('#__altacourses_newsletter_deliveries',$row,'id');
    }
    public function history(): array
    {
        return $this->db->setQuery('SELECT n.*,s.contact_json,s.request_id FROM #__altacourses_newsletter_deliveries n JOIN #__altacourses_request_submissions s ON s.id=n.submission_id ORDER BY n.updated_at DESC,n.id DESC',0,100)->loadObjectList();
    }
    private function lockName(): string { return 'alta-nl-'.substr(hash('sha256',$this->db->getPrefix()),0,32); }
    private function lock(): bool { return (int)$this->db->setQuery('SELECT GET_LOCK('.$this->db->quote($this->lockName()).',0)')->loadResult()===1; }
    private function unlock(): void { $this->db->setQuery('SELECT RELEASE_LOCK('.$this->db->quote($this->lockName()).')')->loadResult(); }
    private function outcome(int $id,string $state,?string $error=null,int $code=0,int $delay=0): void
    {
        $r=(object)['id'=>$id,'state'=>$state,'last_error'=>$error,'http_status'=>$code,'updated_at'=>$this->stamp(),'next_attempt_at'=>$delay?$this->now()->modify('+'.$delay.' seconds')->setTimezone(new \DateTimeZone('UTC'))->format('Y-m-d H:i:s'):null];
        $this->db->updateObject('#__altacourses_newsletter_deliveries',$r,'id',true);
    }
    private function succeeded(object $row,string $state,int $code=0): void
    {
        $this->db->transactionStart();try{
            $this->outcome((int)$row->id,$state,null,$code);
            // Historical fact, not a mirror of Zenler's current subscription status. Stable ID survives email edits.
            $this->db->setQuery('UPDATE #__altacourses_clients SET newsletter=1 WHERE id='.(int)$row->client_id)->execute();
            $this->db->transactionCommit();
        }catch(\Throwable $e){$this->db->transactionRollback();throw $e;}
    }
    public function review(int $id,int $revision,bool $confirmed): void
    {
        if(!$this->lock()){throw new \RuntimeException('Newsletter processing busy',409);}
        try{
            $r=$this->db->setQuery('SELECT * FROM #__altacourses_newsletter_deliveries WHERE id='.$id)->loadObject();
            if($r===null||(int)$r->revision!==$revision||!in_array($r->state,['error','uncertain'],true)){throw new \RuntimeException('Newsletter record changed',409);}
            $this->db->setQuery('UPDATE #__altacourses_newsletter_deliveries SET revision=revision+1 WHERE id='.$id)->execute();
            if($confirmed){$this->succeeded($r,'confirmed');}else{$this->outcome($id,'pending');}
        }finally{$this->unlock();}
    }
    private function request(string $url,array $payload,string $key,string $account): array
    {
        try{
            if($this->transport){return ($this->transport)($url,$payload);}
            $http=HttpFactory::getHttp(new Registry(['follow_location'=>false]));$response=$http->post($url,json_encode($payload,JSON_THROW_ON_ERROR),['X-API-Key'=>$key,'X-Account-Name'=>$account,'Content-Type'=>'application/json','Accept'=>'application/json'],8);
            return ['code'=>(int)$response->code,'body'=>(string)$response->body,'headers'=>$response->headers];
        }catch(\Throwable){return ['code'=>0,'body'=>''];}
    }
    public function runDue(): string
    {
        $s=$this->settings();if($s['mode']==='off'){return 'blocked';}if($s['mode']==='preview'){return 'preview';}if(!$s['configured']||!$s['key_configured']){return 'blocked';}
        if(!$this->lock()){return 'busy';}
        try{
            $started=microtime(true);$review=false;$key=$this->config()['zenler_key'];
            foreach($this->db->setQuery("SELECT * FROM #__altacourses_newsletter_deliveries WHERE state IN ('pending','retry','sending','error','uncertain') ORDER BY id")->loadObjectList() as $r){
                if($r->state==='sending'){$this->outcome((int)$r->id,'uncertain','interrupted_request');$review=true;continue;}
                if(in_array($r->state,['error','uncertain'],true)){$review=true;continue;}
                if($r->next_attempt_at!==null&&$r->next_attempt_at>$this->stamp()){continue;}
                if(microtime(true)-$started>=20){return 'pending';}
                $current=$this->settings();if($current['mode']!=='live'||$current['account']!==$s['account']||$current['funnel']!==$s['funnel']){return 'blocked';}
                if($r->account_name===''&&(int)$r->funnel_id===0){$r->account_name=$s['account'];$r->funnel_id=$s['funnel'];$target=(object)['id'=>$r->id,'account_name'=>$r->account_name,'funnel_id'=>$r->funnel_id];$this->db->updateObject('#__altacourses_newsletter_deliveries',$target,'id');}
                if($r->account_name!==$s['account']||(int)$r->funnel_id!==$s['funnel']){continue;}
                $source=$this->db->setQuery('SELECT s.contact_json,r.clientid FROM #__altacourses_request_submissions s JOIN #__altacourses_requests r ON r.id=s.request_id WHERE s.id='.(int)$r->submission_id)->loadObject();
                try{$contact=$source?json_decode($source->contact_json,true,32,JSON_THROW_ON_ERROR):null;}catch(\Throwable){$contact=null;}
                $email=$contact!==null?$this->address((string)($contact['email']??'')):null;
                if(($contact['newsletter']??'0')!=='1'||$email===null||!hash_equals($r->email_hash,hash('sha256',$email))||$source===null||(int)$source->clientid!==(int)$r->client_id){$this->outcome((int)$r->id,'error','invalid_consent_source');$review=true;continue;}
                $prior=$this->db->setQuery('SELECT id FROM #__altacourses_newsletter_deliveries WHERE account_name='.$this->db->quote($r->account_name).' AND funnel_id='.(int)$r->funnel_id.' AND email_hash='.$this->db->quote($r->email_hash)." AND state IN ('sent','confirmed')")->loadResult();
                if($prior!==null){$this->succeeded($r,'duplicate');continue;}
                // A crashed/ambiguous earlier attempt must be reviewed, never replaced with a new automatic subscribe.
                $unknown=$this->db->setQuery('SELECT id FROM #__altacourses_newsletter_deliveries WHERE account_name='.$this->db->quote($r->account_name).' AND funnel_id='.(int)$r->funnel_id.' AND email_hash='.$this->db->quote($r->email_hash)." AND attempts>0 AND state IN ('sending','uncertain') AND id<>".(int)$r->id)->loadResult();
                if($unknown!==null){$this->outcome((int)$r->id,'uncertain','earlier_attempt_uncertain');$review=true;continue;}
                $this->db->setQuery("UPDATE #__altacourses_newsletter_deliveries SET state='sending',attempts=attempts+1,revision=revision+1,updated_at=".$this->db->quote($this->stamp()).' WHERE id='.(int)$r->id)->execute();
                $response=$this->request('https://api.newzenler.com/api/v1/funnels/'.(int)$r->funnel_id.'/subscribe',['name'=>(string)($contact['firstname']??''),'last_name'=>(string)($contact['lastname']??''),'email'=>$email,'state'=>(string)$r->client_id],$key,$s['account']);
                $code=(int)($response['code']??0);$body=null;try{if(is_string($response['body']??null)&&strlen($response['body'])<=1048576){$body=json_decode($response['body'],true,32,JSON_THROW_ON_ERROR);}}catch(\Throwable){}
                $api=is_array($body)?(int)($body['response_code']??0):0;
                if($code>=200&&$code<300&&$api>=200&&$api<300&&($body['message']??'')==='success'&&(!isset($body['data']['email'])||$this->address((string)$body['data']['email'])===$email)){$this->succeeded($r,'sent',$code);}
                elseif($code===429||$api===429||(($code===403||$api===403)&&str_contains(strtolower((string)($body['message']??'')),'rate limit'))){$delay=60;foreach($response['headers']??[] as $h=>$v){if(strtolower((string)$h)==='retry-after'&&is_scalar($v)&&ctype_digit((string)$v)){$delay=max($delay,min(2147483647,(int)$v));}}$this->outcome((int)$r->id,'retry','rate_limited',$code,$delay);return 'review';}
                elseif($code===0||$code>=500||$api>=500||$code===408||($code>=200&&$code<300&&($api===0||($api>=200&&$api<300)))){$this->outcome((int)$r->id,'uncertain','response_uncertain',$code);$review=true;}
                else{$this->outcome((int)$r->id,'error',$api>0?'api_'.$api:'http_'.$code,$code);$review=true;}
                if(in_array($code,[401,403],true)){return 'review';}
            }
            return $review?'review':'complete';
        }finally{$this->unlock();}
    }
}
