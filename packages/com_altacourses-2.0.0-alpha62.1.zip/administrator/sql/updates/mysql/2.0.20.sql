-- Request-based billing plus retained unlinked legacy identities.
-- Conditional rename/engine conversion/index adoption is in script.php.
CREATE TABLE IF NOT EXISTS `#__altacourses_keyaccount` (
 `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
 `request_id` int UNSIGNED DEFAULT NULL,
 `firstname` varchar(255) DEFAULT '',
 `lastname` varchar(255) DEFAULT '',
 `organisation` varchar(255) DEFAULT '',
 `startdate` datetime DEFAULT NULL,
 `invoiced` varchar(11) DEFAULT '0',
 `received` tinyint(1) DEFAULT '0',
 `no_invoicing` tinyint(1) NOT NULL DEFAULT '0',
 `notes` text,
 `ordering` int DEFAULT '0',
 `state` tinyint(1) DEFAULT '1',
 `checked_out` int DEFAULT NULL,
 `checked_out_time` datetime DEFAULT NULL,
 `created_by` int DEFAULT '0',
 PRIMARY KEY (`id`),
 UNIQUE KEY `idx_keyaccount_request` (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
