<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */
namespace Advenire\Component\Altacourses\Site\Model;

\defined('_JEXEC') or die;

final class SignupsModel extends EnquiriesModel
{
    protected const ASKED_FOR_INFO = 0;
}
