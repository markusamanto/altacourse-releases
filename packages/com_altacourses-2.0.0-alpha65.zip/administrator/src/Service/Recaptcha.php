<?php
/** @package Altacourses.Administrator @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Administrator\Service;
use Advenire\Component\Altacourses\Site\Exception\CourseValidationException;
use Joomla\CMS\Http\HttpFactory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;
use Joomla\Database\DatabaseInterface;
use Joomla\Registry\Registry;
\defined('_JEXEC') or die;

/** Shared v2 checkbox verification. Tokens, secrets and provider bodies are never persisted. */
final class Recaptcha
{
    public function __construct(private readonly DatabaseInterface $db,private readonly ?\Closure $transport=null) {}
    private function config(): array
    {
        return json_decode($this->db->setQuery("SELECT params FROM #__extensions WHERE element='com_altacourses' AND type='component' AND enabled=1")->loadResult()?:'{}',true,flags:JSON_THROW_ON_ERROR);
    }
    public function settings(): array
    {
        $p=$this->config();$site=$p['recaptcha_site_key']??'';$secret=$p['recaptcha_secret_key']??'';
        $valid=static fn($v)=>is_string($v)&&preg_match('/^[A-Za-z0-9_-]{16,512}$/D',$v)===1;
        return ['enabled'=>($p['recaptcha_enabled']??false)===true||($p['recaptcha_enabled']??0)===1||($p['recaptcha_enabled']??'')==='1',
            'configured'=>$valid($site)&&$valid($secret),'site_key'=>$valid($site)?$site:''];
    }
    private function failed(string $key): never { throw new CourseValidationException([Text::_('COM_ALTACOURSES_RECAPTCHA_'.$key)]); }
    public function verify(#[\SensitiveParameter] ?string $token): void
    {
        $s=$this->settings();if(!$s['enabled']){return;}
        if(!$s['configured']){$this->failed('UNAVAILABLE');}
        if($token===null||$token===''){$this->failed('REQUIRED');}
        if(strlen($token)>8192||preg_match('/[\x00-\x20\x7f]/',$token)){$this->failed('INVALID');}
        $secret=$this->config()['recaptcha_secret_key'];$url='https://www.recaptcha.net/recaptcha/api/siteverify';
        // The optional remoteip field is deliberately omitted.
        try{
            $payload=['secret'=>$secret,'response'=>$token];
            if($this->transport){$r=($this->transport)($url,$payload);$code=(int)($r['code']??0);$raw=$r['body']??'';}
            else{$http=HttpFactory::getHttp(new Registry(['follow_location'=>false]));$r=$http->post($url,http_build_query($payload),['Content-Type'=>'application/x-www-form-urlencoded','Accept'=>'application/json'],8);$code=(int)$r->code;$raw=(string)$r->body;}
            if($code!==200||!is_string($raw)||strlen($raw)>65536){$this->failed('UNAVAILABLE');}
            $body=json_decode($raw,true,16,JSON_THROW_ON_ERROR);
        }catch(CourseValidationException $e){throw $e;}catch(\Throwable){$this->failed('UNAVAILABLE');}
        if(!is_array($body)||!is_bool($body['success']??null)){$this->failed('UNAVAILABLE');}
        if(!$body['success']){
            $codes=$body['error-codes']??[];
            if(is_array($codes)&&(in_array('invalid-input-secret',$codes,true)||in_array('missing-input-secret',$codes,true))){$this->failed('UNAVAILABLE');}
            $this->failed('INVALID');
        }
        $host=strtolower(rtrim(Uri::getInstance()->getHost(),'.'));
        $reported=$body['hostname']??null;
        if($host===''||!is_string($reported)||strtolower(rtrim($reported,'.'))!==$host){$this->failed('INVALID');}
        // Google enforces the response token's two-minute lifetime and single use at siteverify.
    }
}
