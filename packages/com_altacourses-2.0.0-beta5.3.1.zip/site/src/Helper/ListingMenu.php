<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Helper;
use Joomla\CMS\Application\SiteApplication;
use Joomla\CMS\Menu\MenuItem;
\defined('_JEXEC') or die;

/** Only the active native listing menu can supply listing scope or document settings. */
final class ListingMenu
{
    public static function active(SiteApplication $app): ?MenuItem
    {
        $item = $app->getMenu()->getActive();
        return $item !== null && (int)$item->id === $app->getInput()->getInt('Itemid')
            && ($item->query['option'] ?? '') === 'com_altacourses'
            && ($item->query['view'] ?? '') === 'courses' && $item->type === 'component'
            ? $item : null;
    }
    public static function types(MenuItem $item): array
    {
        $value = $item->getParams()->get('listing_course_types', []);
        // Joomla can store the initial All selection as scalar 0; saved multi-selections are arrays.
        if ($value === '0' || $value === 0 || $value === '') { return []; }
        try { return CourseTypes::normalise($value); }
        catch (\InvalidArgumentException $e) { throw new \RuntimeException('Invalid course listing menu configuration', 500, $e); }
    }
}
