<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\View\Courses;

use Advenire\Component\Altacourses\Administrator\Service\CoursePriceAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\CoursePriceAwareTrait;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Pagination\Pagination;

use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareTrait;

\defined('_JEXEC') or die;

final class HtmlView extends BaseHtmlView implements CourseScheduleAwareInterface, CoursePriceAwareInterface
{
    use CourseScheduleAwareTrait;
    use CoursePriceAwareTrait;

    public array $sessions = [];
    public array $totalPrices = [];
    public array $items = [];
    public array $types = [];
    public array $regions = [];
    public array $filters = [];
    public ?Pagination $pagination = null;

    public function display($tpl = null): void
    {
        $model = $this->getModel();
        $this->items = $model->getItems();
        foreach ($this->items as $item) {
            $amount = $this->getCoursePrice()->formatTotal($item->course_price, $item->lodging_price, $item->lodging_included);
            $this->totalPrices[(int) $item->id] = $amount === null ? '—' : $amount . ' ' . Text::_('COM_ALTACOURSES_CURRENCY');
        }
        $this->sessions = $this->getCourseSchedule()->additionalSessions(array_map(static fn ($course): int => (int) $course->id, $this->items));
        $this->types = $model->getOptions('coursetypes');
        $this->regions = $model->getOptions('regions');
        $this->getDocument()->setTitle(Text::_('COM_ALTACOURSES_COURSES_TITLE'));
        $this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.site');
        parent::display($tpl);
    }
}
