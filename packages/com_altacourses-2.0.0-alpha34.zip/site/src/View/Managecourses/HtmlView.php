<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\View\Managecourses;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Pagination\Pagination;

use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareTrait;

\defined('_JEXEC') or die;

final class HtmlView extends BaseHtmlView implements CourseScheduleAwareInterface
{
    use CourseScheduleAwareTrait;

    public array $sessions = [];
    public array $items = [];
    public array $types = [];
    public array $regions = [];
    public array $filters = [];
    public ?Pagination $pagination = null;
    public bool $isCourseAdministrator = false;

    public function display($tpl = null): void
    {
        $user = $this->getCurrentUser();
        $this->isCourseAdministrator = $user->authorise('altacourses.manage', 'com_altacourses');
        if ($user->guest || (!$this->isCourseAdministrator && !$user->authorise('altacourses.supplier', 'com_altacourses'))) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }

        $model = $this->getModel();
        $this->items = $model->getItems();
        $this->sessions = $this->getCourseSchedule()->additionalSessions(array_map(static fn ($course): int => (int) $course->id, $this->items));
        $this->types = $model->getOptions('coursetypes');
        $this->regions = $model->getOptions('regions');
        $this->getDocument()->setTitle(Text::_('COM_ALTACOURSES_MANAGE_COURSES'));
        $this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.site');
        parent::display($tpl);
    }
}
