<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Model;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\BaseModel;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\Database\DatabaseAwareInterface;
use Joomla\Database\DatabaseAwareTrait;

\defined('_JEXEC') or die;

final class FixturesModel extends BaseModel implements DatabaseAwareInterface
{
    use DatabaseAwareTrait;

    public function __construct($config = [], ?MVCFactoryInterface $factory = null)
    {
        parent::__construct($config);
    }

    /** Extend only the original eight synthetic samples, without rewriting the first dates. */
    public function loadSampleSessions(): void
    {
        $db = $this->getDatabase();
        $db->transactionStart();
        try {
            if ((int) $db->setQuery('SELECT COUNT(*) FROM #__altacourses_courses')->loadResult() !== 8
                || (int) $db->setQuery('SELECT COUNT(*) FROM #__altacourses_course_sessions')->loadResult() !== 0) {
                throw new \RuntimeException(Text::_('COM_ALTACOURSES_SESSION_SAMPLE_REFUSED'));
            }
            $query = $db->createQuery()->select(['co.id', 'co.stop_date', 'co.availability_version'])
                ->from('#__altacourses_courses AS co')
                ->join('INNER', '#__altacourses_coursetypes AS ct ON ct.id=co.course_type')
                ->join('INNER', '#__altacourses_courseplaces AS cp ON cp.id=co.course_place')
                ->where('(co.checked_out IS NULL OR co.checked_out=0)')->where('co.state=1')->where('co.nr_of_participants IN (1,3)')->where('co.start_date >= CURRENT_TIMESTAMP')
                ->where('co.course_notes=' . $db->quote('Syntetiskt testdata. Ingen bokning eller notifiering.'))
                ->where('co.course_price=' . $db->quote('22000 kr (test)'))
                ->where('ct.name=' . $db->quote('UL'))->where('cp.name=' . $db->quote('Testgården Söder'))
                ->order('co.id');
            $courses = $db->setQuery($query)->loadObjectList();
            if (count($courses) !== 2) {
                throw new \RuntimeException(Text::_('COM_ALTACOURSES_SESSION_SAMPLE_REFUSED'));
            }
            foreach ($courses as $course) {
                $start = (new \DateTimeImmutable($course->stop_date, new \DateTimeZone('UTC')))->modify('+21 days');
                $session = (object) ['course_id' => (int) $course->id, 'ordering' => 2,
                    'start_date' => $start->format('Y-m-d H:i:s'), 'stop_date' => $start->format('Y-m-d H:i:s')];
                $db->insertObject('#__altacourses_course_sessions', $session, 'id');
                $id = (int) $course->id;
                $version = (int) $course->availability_version;
                $update = $db->createQuery()->update('#__altacourses_courses')
                    ->set('availability_version=availability_version+1')
                    ->where('id=:id')->bind(':id', $id, \Joomla\Database\ParameterType::INTEGER)
                    ->where('availability_version=:revision')->bind(':revision', $version, \Joomla\Database\ParameterType::INTEGER)
                    ->where('(checked_out IS NULL OR checked_out=0)');
                $db->setQuery($update)->execute();
                if ($db->getAffectedRows() !== 1) {
                    throw new \RuntimeException(Text::_('COM_ALTACOURSES_SESSION_SAMPLE_REFUSED'));
                }
            }
            $db->transactionCommit();
        } catch (\Throwable $exception) {
            $db->transactionRollback();
            throw $exception;
        }
    }

    /** Load only invented course data, only into empty tables, in one transaction. */
    public function loadSampleCourses(int $createdBy): void
    {
        $db = $this->getDatabase();
        $db->transactionStart();
        try {
            foreach (['courses', 'coursetypes', 'courseplaces', 'courseleaders', 'regions', 'seats', 'course_sessions'] as $name) {
                if ((int) $db->setQuery('SELECT COUNT(*) FROM ' . $db->quoteName('#__altacourses_' . $name))->loadResult() > 0) {
                    throw new \RuntimeException(Text::_('COM_ALTACOURSES_SAMPLE_NOT_EMPTY'));
                }
            }
            $insert = static function (string $table, array $data) use ($db, $createdBy): int {
                $row = (object) ($data + ['ordering' => 0, 'state' => 1, 'checked_out' => 0, 'created_by' => $createdBy]);
                $db->insertObject('#__altacourses_' . $table, $row, 'id');
                return (int) $row->id;
            };
            $ugl = $insert('coursetypes', ['name' => 'UGL']);
            $ul = $insert('coursetypes', ['name' => 'UL']);
            $north = $insert('regions', ['name' => 'Testregion Norr']);
            $south = $insert('regions', ['name' => 'Testregion Söder']);
            $place1 = $insert('courseplaces', ['name' => 'Testgården Norr', 'region_id' => $north]);
            $place2 = $insert('courseplaces', ['name' => 'Testgården Söder', 'region_id' => $south]);
            $leader1 = $insert('courseleaders', ['name' => 'Testhandledare A']);
            $leader2 = $insert('courseleaders', ['name' => 'Testhandledare B']);
            foreach ([1 => '3+', 3 => 'Få', 2 => 'Full', 4 => 'Inställd'] as $code => $label) {
                $insert('seats', ['seats' => $code, 'label' => $label]);
            }
            $today = new \DateTimeImmutable('today', new \DateTimeZone('UTC'));
            foreach ([30, 40, 50, 60, 70, 80, -7, 90] as $index => $days) {
                $start = $today->modify(($days >= 0 ? '+' : '') . $days . ' days');
                $insert('courses', [
                    'start_date' => $start->format('Y-m-d H:i:s'),
                    'stop_date' => $start->modify('+' . ($index % 2 ? 2 : 4) . ' days')->format('Y-m-d H:i:s'),
                    'course_type' => $index % 2 ? $ul : $ugl,
                    'course_place' => $index % 2 ? $place2 : $place1,
                    'course_leader_1' => $leader1,
                    'course_leader_2' => $index % 2 ? null : $leader2,
                    'nr_of_participants' => $index === 4 ? 2 : ($index === 5 ? 4 : ($index % 2 ? 3 : 1)),
                    'course_price' => '22000 kr (test)',
                    'lodging_price' => '7000 kr (test)',
                    'course_notes' => 'Syntetiskt testdata. Ingen bokning eller notifiering.',
                    'state' => $index === 7 ? 0 : 1,
                    'cr' => null,
                ]);
            }
            $db->transactionCommit();
        } catch (\Throwable $exception) {
            $db->transactionRollback();
            throw $exception;
        }
    }
}
