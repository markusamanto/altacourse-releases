<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Controller;

use Joomla\CMS\Language\Text;
use Joomla\CMS\Event\PageCache\IsExcludedEvent;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;
use Joomla\CMS\MVC\View\ViewInterface;
use Joomla\CMS\Pagination\Pagination;

\defined('_JEXEC') or die;

final class DisplayController extends BaseController
{
    protected $default_view = 'dashboard';

    public function execute($task)
    {
        if (!in_array(strtolower((string) $task), ['', 'display'], true)) {
            throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'), 404);
        }

        return parent::execute($task);
    }

    public function display($cachable = false, $urlparams = [])
    {
        $viewName = $this->input->getCmd('view', 'dashboard');
        if (!in_array($viewName, ['dashboard', 'courses', 'managecourses', 'availability', 'assignment', 'newcourse', 'editcourse', 'course', 'suppliers', 'supplierprofile', 'enquiry', 'enquiryreceipt', 'enquiries', 'signup', 'signupreceipt', 'signups', 'participant'], true)
            || $this->input->getCmd('layout', 'default') !== 'default'
            || $this->app->getDocument()->getType() !== 'html') {
            throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'), 404);
        }

        if (in_array($viewName, ['enquiry', 'enquiryreceipt', 'enquiries', 'signup', 'signupreceipt', 'signups', 'participant'], true)) {
            $this->app->allowCache(false);
            $this->app->setHeader('Cache-Control', 'private, no-store, no-cache, must-revalidate', true);
            $this->app->getDispatcher()->addListener('onPageCacheIsExcluded', static function (IsExcludedEvent $event): void {
                $event->addResult(true);
            });
        }
        if (in_array($viewName, ['courses', 'course', 'enquiry', 'enquiryreceipt', 'signup', 'signupreceipt'], true)) {
            return parent::display(false, []);
        }

        $user = $this->app->getIdentity();

        if ($user->guest) {
            $return = 'index.php?option=com_altacourses&view=' . $viewName;
            if (in_array($viewName, ['availability', 'assignment', 'editcourse', 'participant'], true)) {
                $return .= '&id=' . $this->readInteger('id');
            }
            if ($viewName === 'supplierprofile' && $this->input->get('user_id', null, 'raw') !== null) {
                $return .= '&user_id=' . $this->readInteger('user_id');
            }
            if ($viewName === 'participant') { $return .= '&return_start=' . $this->readInteger('return_start'); }
            $itemId = $this->input->getInt('Itemid');

            if ($itemId > 0) {
                $return .= '&Itemid=' . $itemId;
            }

            // Joomla validates index.php-relative returns; format the SEF URL after login.
            // Never accept a return URL supplied by the visitor.
            $this->setRedirect(Route::_('index.php?option=com_users&view=login&return=' . rawurlencode(base64_encode($return)), false));

            return $this;
        }

        if (!$user->authorise('altacourses.manage', 'com_altacourses')
            && !$user->authorise('altacourses.supplier', 'com_altacourses')) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }

        if ($viewName === 'assignment') {
            if (!$user->authorise('altacourses.manage', 'com_altacourses')) {
                throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
            }
            $this->setRedirect(Route::_('index.php?option=com_altacourses&view=editcourse&id=' . $this->readInteger('id'), false));
            return $this;
        }

        // Never cache a page whose content depends on the current user's role.
        return parent::display(false, []);
    }

    protected function prepareViewModel(ViewInterface $view)
    {
        if (in_array($view->getName(), ['enquiryreceipt', 'signupreceipt'], true)) {
            $mode = $view->getName() === 'signupreceipt' ? 'signup' : 'enquiry';
            $id = $this->readInteger('coid');
            $receipt = $this->app->getUserState('com_altacourses.' . $mode . '.' . $id . '.receipt', []);
            if (!$id || ($receipt['course_id'] ?? 0) !== $id || empty($receipt['request_id'])) { throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'), 404); }
            $view->courseId = $id;
            return;
        }
        if (in_array($view->getName(), ['enquiry', 'signup'], true)) {
            $mode = $view->getName();
            $id = $this->readInteger('coid');
            $model = $this->getModel(ucfirst($mode), 'Site', ['ignore_request' => true]);
            $course = $model->getCourse($id);
            $key = 'com_altacourses.' . $mode . '.' . $id;
            $data = $this->app->getUserState($key . '.draft', []) ?: [];
            $tickets = array_filter($this->app->getUserState('com_altacourses.' . $mode . '.tickets', []), static fn ($ticket): bool => $ticket['time'] >= time() - 14400);
            $ticket = isset($data['submission']) ? ($tickets[$data['submission']] ?? null) : null;
            $agreement = $mode === 'signup' ? $model->fingerprint($course) : null;
            if ($ticket === null || $ticket['course_id'] !== $id || $ticket['revision'] !== (int) $course->availability_version
                || ($ticket['agreement'] ?? null) !== $agreement) {
                if ($ticket !== null) { $this->app->enqueueMessage(Text::_($mode === 'signup' ? 'COM_ALTACOURSES_SIGNUP_CONFLICT' : 'COM_ALTACOURSES_ENQUIRY_CONFLICT'), 'warning'); }
                if ($mode === 'signup') { unset($data['accept_terms']); }
                $data['submission'] = bin2hex(random_bytes(32));
                $tickets = array_slice($tickets, -19, null, true);
                $tickets[$data['submission']] = ['time' => time(), 'course_id' => $id, 'revision' => (int) $course->availability_version, 'agreement' => $agreement];
            }
            $data['coid'] = $id;
            $this->app->setUserState('com_altacourses.' . $mode . '.tickets', $tickets);
            $view->summary = $model->summary($course);
            if ($mode === 'signup') {
                $view->terms = $course->supplier_terms;
                $view->totalPrice = $model->agreement($course)['total_price'];
            }
            $view->form = $model->getForm($data);
            $view->setModel($model, true);
            return;
        }
        if ($view->getName() === 'participant') {
            $model = $this->getModel('Participant', 'Site', ['ignore_request' => true]);
            $model->requireAdministrator();
            $model->setState('request.id', $this->readInteger('id'));
            $view->returnStart = $this->readInteger('return_start');
            $view->setModel($model, true);
            return;
        }
        if (in_array($view->getName(), ['enquiries', 'signups'], true)) {
            $model = $this->getModel(ucfirst($view->getName()), 'Site', ['ignore_request' => true]);
            $model->requireAdministrator();
            $pagination = new Pagination($model->getTotal(), $this->readInteger('limitstart'), 20, '', $this->app);
            $pagination->setAdditionalUrlParam('option', 'com_altacourses'); $pagination->setAdditionalUrlParam('view', $view->getName());
            $model->setState('list.start', $pagination->limitstart);
            $view->pagination = $pagination;
            $view->setModel($model, true);
            return;
        }
        if (in_array($view->getName(), ['suppliers', 'supplierprofile'], true)) {
            $model = $this->getModel('Supplierprofile', 'Site', ['ignore_request' => true]);
            $administrator = $model->isAdministrator();
            if ($view->getName() === 'suppliers') {
                if (!$administrator) { throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403); }
                $view->setModel($model, true);
                return;
            }
            $userId = $this->readInteger('user_id');
            if ($userId === 0 && !$administrator) { $userId = (int) $this->app->getIdentity()->id; }
            $record = $model->getRecord($userId);
            $key = 'com_altacourses.supplierprofile.' . (int) $this->app->getIdentity()->id . '.' . $userId;
            if ($this->input->getBool('fresh')) { $this->app->setUserState($key, null); }
            $original = $model->formData($record);
            $draft = $this->app->getUserState($key, []) ?: [];
            if (isset($draft['version']) && ($draft['version'] !== $original['version'] || ($draft['id'] ?? '') !== $original['id'])) {
                $this->app->enqueueMessage(Text::_('COM_ALTACOURSES_SUPPLIER_DRAFT_STALE'), 'warning');
            }
            $view->form = $model->getForm($record, $draft + $original);
            $view->accountName = $record['account']->name . ' (' . $record['account']->username . ')';
            $view->accountEmail = $record['account']->email;
            $view->accountBlocked = (bool) $record['account']->block;
            $view->supplierUserId = $userId;
            $view->setModel($model, true);
            return;
        }
        if ($view->getName() === 'course') {
            $model = $this->getModel('Course', 'Site', ['ignore_request' => true]);
            $id = $this->readInteger('id');
            $model->setState('course.id', $id);
            $view->canSignup = $this->getModel('Signup', 'Site', ['ignore_request' => true])->canEnquire($this->readInteger('id'));
            $view->canEnquire = $this->getModel('Enquiry', 'Site', ['ignore_request' => true])->canEnquire($id);
            $view->filters = $this->readCourseFilters();
            $view->setModel($model, true);
            return;
        }
        if ($view->getName() === 'editcourse') {
            $model = $this->getModel('Editcourse', 'Site', ['ignore_request' => true]);
            $id = $this->readInteger('id');
            $record = $model->getRecord($id);
            $key = 'com_altacourses.editcourse.' . (int) $this->app->getIdentity()->id . '.' . $id;
            if ($this->input->getBool('fresh')) {
                $this->app->setUserState($key, null);
            }
            $original = $model->formData($record);
            $draft = $this->app->getUserState($key, []) ?: [];
            if (isset($draft['version']) && $draft['version'] !== $original['version']) {
                $this->app->enqueueMessage(Text::_('COM_ALTACOURSES_EDIT_DRAFT_STALE'), 'warning');
            }
            $view->form = $model->getEditForm($record, $draft + $original);
            $view->courseId = $id;
            $view->hasStoredSecond = (bool) $record['sessions'];
            $view->laterSessions = array_slice($record['sessions'], 1);
            $view->setModel($model, true);
            return;
        }
        if ($view->getName() === 'newcourse') {
            $model = $this->getModel('Newcourse', 'Site', ['ignore_request' => true]);
            $model->isAdministrator();
            $key = 'com_altacourses.newcourse.' . (int) $this->app->getIdentity()->id;
            if ($this->input->getBool('fresh')) {
                $this->app->setUserState($key . '.draft', null);
            }
            $data = $this->app->getUserState($key . '.draft', []) ?: [];
            $tickets = array_filter($this->app->getUserState($key . '.tickets', []), static fn ($time): bool => $time >= time() - 14400);
            if (!isset($data['submission']) || !isset($tickets[$data['submission']])) {
                $data['submission'] = bin2hex(random_bytes(32));
                $tickets = array_slice($tickets, -19, null, true);
                $tickets[$data['submission']] = time();
            }
            $this->app->setUserState($key . '.tickets', $tickets);
            $view->form = $model->getForm($data);
            $view->setModel($model, true);
            return;
        }
        if ($view->getName() === 'availability') {
            $model = $this->getModel(ucfirst($view->getName()), 'Site', ['ignore_request' => true]);
            $view->course = $model->getCourse($this->readInteger('id'));
            $view->form = $model->getForm([
                'id' => (int) $view->course->id,
                'version' => (int) $view->course->availability_version,
                'availability' => $view->course->nr_of_participants,
            ]);
            $view->setModel($model, true);
            return;
        }
        $managed = $view->getName() === 'managecourses';
        if (!$managed && $view->getName() !== 'courses') {
            parent::prepareViewModel($view);
            $view->allowTestData = (bool) $this->app->getParams('com_altacourses')->get('allow_test_data', false);
            return;
        }

        $model = $this->getModel($managed ? 'Managecourses' : 'Courses', 'Site', ['ignore_request' => true]);
        $filters = $this->readCourseFilters();
        if ($managed) {
            $filters['id'] = $this->readInteger('id');
        }
        unset($filters['limitstart']);
        foreach ($filters as $key => $value) {
            $model->setState('filter.' . $key, $value);
        }

        $pagination = new Pagination($model->getTotal(), $this->readInteger('limitstart'), 20, '', $this->app);
        foreach (['option' => 'com_altacourses', 'view' => $view->getName()] + $filters as $key => $value) {
            $pagination->setAdditionalUrlParam($key, $value);
        }
        $itemId = $this->input->getInt('Itemid');
        if ($itemId > 0) {
            $pagination->setAdditionalUrlParam('Itemid', $itemId);
        }
        $model->setState('list.start', $pagination->limitstart);
        $model->setState('list.limit', 20);
        $view->setModel($model, true);
        $view->pagination = $pagination;
        $view->filters = $filters;
    }

    private function readCourseFilters(): array
    {
        $filters = [
            'type' => $this->readInteger('type'),
            'region' => $this->readInteger('region'),
            'from' => $this->readDate('from'),
            'to' => $this->readDate('to'),
        ];
        if ($filters['from'] !== '' && $filters['to'] !== '' && $filters['from'] > $filters['to']) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_FILTER'), 400);
        }
        $filters['limitstart'] = $this->readInteger('limitstart');
        return $filters;
    }

    private function readInteger(string $name): int
    {
        $raw = $this->input->get($name, '0', 'raw');
        if (!is_scalar($raw) || !ctype_digit((string) $raw) || (float) $raw > 2147483647) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_FILTER'), 400);
        }
        return (int) $raw;
    }

    private function readDate(string $name): string
    {
        $raw = $this->input->get($name, '', 'raw');
        if (!is_string($raw)) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_FILTER'), 400);
        }
        if ($raw === '') {
            return '';
        }
        $date = \DateTimeImmutable::createFromFormat('!Y-m-d', $raw, new \DateTimeZone('UTC'));
        if (!$date || $date->format('Y-m-d') !== $raw || (int) $date->format('Y') < 1000) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_FILTER'), 400);
        }
        return $raw;
    }
}
