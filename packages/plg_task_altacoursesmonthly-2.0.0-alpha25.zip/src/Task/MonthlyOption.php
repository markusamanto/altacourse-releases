<?php

/** @package Altacourses.Task @license GNU General Public License version 2 or later */
namespace Advenire\Plugin\Task\Altacoursesmonthly\Task;

use Joomla\CMS\Language\Language;
use Joomla\Component\Scheduler\Administrator\Task\TaskOption;

\defined('_JEXEC') or die;

/** TaskOption's documented protected properties, translated using an injected language. */
final class MonthlyOption extends TaskOption
{
    public function __construct(Language $language)
    {
        $this->id = 'altacourses.monthly';
        $this->langConstPrefix = 'PLG_TASK_ALTACOURSESMONTHLY';
        $this->title = $language->_($this->langConstPrefix . '_TITLE');
        $this->desc = $language->_($this->langConstPrefix . '_DESC');
    }
}
