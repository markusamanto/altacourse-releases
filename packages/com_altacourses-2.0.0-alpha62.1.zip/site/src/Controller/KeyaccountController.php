<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Controller;
use Advenire\Component\Altacourses\Site\Exception\CourseValidationException;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;
\defined('_JEXEC') or die;
final class KeyaccountController extends BaseController
{
    public function execute($task)
    {
        if (strtolower((string)$task)!=='save') { throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'),404); }
        return parent::execute($task);
    }
    public function save(): void
    {
        $model=$this->getModel('Keyaccounts','Site',['ignore_request'=>true]);$model->requireAdministrator();
        if ($this->input->getMethod()!=='POST') { throw new \RuntimeException(Text::_('COM_ALTACOURSES_SAMPLE_POST_REQUIRED'),405); }
        if (!$this->checkToken('post',false)) { throw new \RuntimeException(Text::_('JINVALID_TOKEN'),403); }
        $raw=$this->input->post->get('jform',[],'array');
        if (!isset($raw['id'],$raw['legacy'],$raw['version'])||!is_string($raw['id'])||!ctype_digit($raw['id'])||(float)$raw['id']>4294967295
            ||!is_string($raw['legacy'])||!in_array($raw['legacy'],['0','1'],true)||!is_string($raw['version'])||!preg_match('/^[a-f0-9]{64}$/D',$raw['version'])) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_BILLING_INVALID'),400);
        }
        $id=(int)$raw['id'];$legacy=$raw['legacy']==='1';$version=$raw['version'];unset($raw['id'],$raw['legacy'],$raw['version']);
        $key='com_altacourses.billing.'.(int)$this->app->getIdentity()->id.'.'.(int)$legacy.'.'.$id;
        $draft=array_intersect_key($raw,array_flip(['invoiced','received','no_invoicing','notes']));
        foreach ($draft as $k=>$v) { if (!is_string($v)||strlen($v)>65535) { unset($draft[$k]); } }
        $this->app->setUserState($key,$draft+['version'=>$version]);
        try { $model->saveBilling($id,$legacy,$version,$raw); }
        catch (CourseValidationException $e) {
            foreach ($e->messages as $message) { $this->app->enqueueMessage($message,'warning'); }
            $this->setRedirect(Route::_('index.php?option=com_altacourses&view=keyaccount&id='.$id.'&legacy='.(int)$legacy,false));return;
        }
        catch (\Throwable $e) {
            if (in_array($e->getCode(),[403,404,409],true)) { throw $e; }
            $this->app->getLogger()->error('Altacourses key-account billing save failed',['exception'=>$e]);
            $this->setMessage(Text::_('COM_ALTACOURSES_BILLING_FAILED'),'warning');
            $this->setRedirect(Route::_('index.php?option=com_altacourses&view=keyaccount&id='.$id.'&legacy='.(int)$legacy,false));return;
        }
        $this->app->setUserState($key,null);$this->setMessage(Text::_('COM_ALTACOURSES_BILLING_SAVED'));
        $this->setRedirect(Route::_('index.php?option=com_altacourses&view='.($legacy?'legacykeyaccounts':'keyaccounts'),false));
    }
}
