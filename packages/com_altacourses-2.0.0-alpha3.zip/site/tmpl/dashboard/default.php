<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 * @var         \Advenire\Component\Altacourses\Site\View\Dashboard\HtmlView $this
 */

use Joomla\CMS\Language\Text;

\defined('_JEXEC') or die;
?>
<section class="altacourses-portal" aria-labelledby="altacourses-portal-heading">
    <h1 id="altacourses-portal-heading">
        <?php echo $this->escape(Text::_($this->isCourseAdministrator ? 'COM_ALTACOURSES_PORTAL_ADMIN_TITLE' : 'COM_ALTACOURSES_PORTAL_SUPPLIER_TITLE')); ?>
    </h1>
    <p><?php echo $this->escape(Text::sprintf('COM_ALTACOURSES_PORTAL_WELCOME', $this->displayName)); ?></p>
    <p><?php echo $this->escape(Text::_($this->isCourseAdministrator ? 'COM_ALTACOURSES_PORTAL_ADMIN_INTRO' : 'COM_ALTACOURSES_PORTAL_SUPPLIER_INTRO')); ?></p>
    <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_PORTAL_TEST_NOTICE')); ?></p>
</section>
