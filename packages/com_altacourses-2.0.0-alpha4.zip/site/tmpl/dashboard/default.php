<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 * @var         \Advenire\Component\Altacourses\Site\View\Dashboard\HtmlView $this
 */

use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\HTML\HTMLHelper;

\defined('_JEXEC') or die;
?>
<section class="altacourses-portal" aria-labelledby="altacourses-portal-heading">
    <h1 id="altacourses-portal-heading">
        <?php echo $this->escape(Text::_($this->isCourseAdministrator ? 'COM_ALTACOURSES_PORTAL_ADMIN_TITLE' : 'COM_ALTACOURSES_PORTAL_SUPPLIER_TITLE')); ?>
    </h1>
    <p><?php echo $this->escape(Text::sprintf('COM_ALTACOURSES_PORTAL_WELCOME', $this->displayName)); ?></p>
    <p><?php echo $this->escape(Text::_($this->isCourseAdministrator ? 'COM_ALTACOURSES_PORTAL_ADMIN_INTRO' : 'COM_ALTACOURSES_PORTAL_SUPPLIER_INTRO')); ?></p>
    <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_PORTAL_TEST_NOTICE')); ?></p>
    <p><a class="btn btn-primary" href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=courses')); ?>">
        <?php echo $this->escape(Text::_('COM_ALTACOURSES_VIEW_COURSES')); ?>
    </a></p>
    <?php if ($this->isCourseAdministrator && $this->allowTestData) : ?>
        <form action="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&task=fixtures.load')); ?>" method="post">
            <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_SAMPLE_HELP')); ?></p>
            <button type="submit" class="btn btn-secondary"><?php echo $this->escape(Text::_('COM_ALTACOURSES_LOAD_SAMPLES')); ?></button>
            <?php echo HTMLHelper::_('form.token'); ?>
        </form>
    <?php endif; ?>
</section>
