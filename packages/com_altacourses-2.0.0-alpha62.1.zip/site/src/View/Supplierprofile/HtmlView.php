<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\View\Supplierprofile;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;

\defined('_JEXEC') or die;

final class HtmlView extends BaseHtmlView
{
    public ?\Joomla\CMS\Form\Form $form = null;
    public string $accountName = '';
    public string $accountEmail = '';
    public bool $isCourseAdministrator = false;
    public bool $accountBlocked = false;
    public int $supplierUserId = 0;

    public function display($tpl = null): void
    {
        $this->isCourseAdministrator = $this->getModel()->isAdministrator();
        $this->getDocument()->setTitle(Text::_('COM_ALTACOURSES_SUPPLIER_PROFILE_TITLE'));
        $this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.site');
        parent::display($tpl);
    }
}
