<?php

/**
 * @package     Altacourses.Administrator
 * @license     GNU General Public License version 2 or later
 * @var         \Advenire\Component\Altacourses\Administrator\View\Dashboard\HtmlView $this
 */

use Joomla\CMS\Language\Text;

\defined('_JEXEC') or die;
?>
<section class="altacourses-dashboard" aria-labelledby="altacourses-heading">
    <div class="card">
        <div class="card-body">
            <h2 id="altacourses-heading" class="card-title">
                <?php echo $this->escape(Text::_('COM_ALTACOURSES_FOUNDATION_HEADING')); ?>
            </h2>
            <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_FOUNDATION_DESCRIPTION')); ?></p>
            <p class="mb-0"><?php echo $this->escape(Text::_('COM_ALTACOURSES_FOUNDATION_NEXT')); ?></p>
        </div>
    </div>
</section>
