/* Existing-image selection only. Saving remains the normal protected form POST. */
for(const picker of document.querySelectorAll('[data-course-photo-picker]')){
 const select=picker.querySelector('select'),preview=picker.querySelector('[data-photo-preview]'),clear=picker.querySelector('[data-photo-clear]');
 const refresh=()=>{const path=select.value;if(!path||path.startsWith('/')||/[\\%?#\x00-\x1f\x7f]/.test(path)||path.split('/').some(p=>!p||p.startsWith('.'))){preview.hidden=true;preview.removeAttribute('src');return;}preview.hidden=false;preview.src=picker.dataset.photoRoot+'/'+path.split('/').map(encodeURIComponent).join('/');};
 select.addEventListener('change',refresh);preview.addEventListener('error',()=>{preview.hidden=true;});clear.hidden=false;clear.addEventListener('click',()=>{select.value='';select.dispatchEvent(new Event('change',{bubbles:true}));});
}
