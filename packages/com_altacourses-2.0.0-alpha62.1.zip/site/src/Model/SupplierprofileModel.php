<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Model;

use Advenire\Component\Altacourses\Site\Exception\CourseValidationException;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Form\FormFactoryAwareInterface;
use Joomla\CMS\Form\FormFactoryAwareTrait;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\CMS\MVC\Model\BaseModel;
use Joomla\CMS\User\CurrentUserInterface;
use Joomla\CMS\User\User;
use Joomla\CMS\User\UserFactoryAwareInterface;
use Joomla\CMS\User\UserFactoryAwareTrait;
use Joomla\Database\DatabaseAwareInterface;
use Joomla\Database\DatabaseAwareTrait;
use Joomla\Database\ParameterType;

\defined('_JEXEC') or die;

final class SupplierprofileModel extends BaseModel implements DatabaseAwareInterface, CurrentUserInterface, UserFactoryAwareInterface, FormFactoryAwareInterface
{
    use DatabaseAwareTrait;
    use UserFactoryAwareTrait;
    use FormFactoryAwareTrait;

    public const FIELDS = ['firstname', 'lastname', 'company', 'phone', 'mobile', 'postal_address', 'postal_zip',
        'postal_city', 'postal_country', 'invoice_address', 'invoice_zip', 'invoice_city', 'org_name', 'website', 'terms'];

    private ?User $currentUser = null;
    private ?MVCFactoryInterface $modelFactory;

    public function __construct($config = [], ?MVCFactoryInterface $factory = null)
    {
        parent::__construct($config);
        $this->modelFactory = $factory;
    }

    public function setCurrentUser(User $currentUser): void
    {
        $this->currentUser = $currentUser;
    }

    public function isAdministrator(): bool
    {
        $user = $this->currentUser;
        if ($user === null || $user->guest || $user->block
            || (!$user->authorise('altacourses.manage', 'com_altacourses') && !$user->authorise('altacourses.supplier', 'com_altacourses'))) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }
        $fresh = $this->getUserFactory()->loadUserById((int) $user->id);
        if ($fresh->guest || $fresh->block || (!$fresh->authorise('altacourses.manage', 'com_altacourses')
            && !$fresh->authorise('altacourses.supplier', 'com_altacourses'))) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }
        return $fresh->authorise('altacourses.manage', 'com_altacourses');

    }

    public function getSuppliers(): array
    {
        if (!$this->isAdministrator()) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }
        $assignment = $this->modelFactory?->createModel('Assignment', 'Site', ['ignore_request' => true]);
        if ($assignment === null) {
            throw new \LogicException('MVC factory has not been supplied');
        }
        $assignment->setCurrentUser($this->currentUser);
        $ids = array_map(static fn ($choice): int => (int) $choice->id, $assignment->getChoices());
        // Existing profiles remain accessible to administrators if their account is disabled or changes role.
        $db = $this->getDatabase();
        $ids = array_values(array_unique(array_filter(array_merge($ids, $db->setQuery('SELECT user_id FROM #__altacourses_suppliers WHERE user_id>0')->loadColumn()))));
        if (!$ids) {
            return [];
        }
        $query = $db->createQuery()->select(['u.id AS user_id', 'u.name', 'u.username', 'u.email', 'u.block',
            's.id AS profile_id', 's.company', 's.terms'])->from('#__users AS u')
            ->join('LEFT', '#__altacourses_suppliers AS s ON s.user_id=u.id')->order('u.name, u.id');
        $parameters = [];
        foreach ($ids as $index => $id) {
            $id = (int) $id;
            $parameter = ':supplier_' . $index;
            $parameters[] = $parameter;
            $query->bind($parameter, $id, ParameterType::INTEGER);
            unset($id);
        }
        $query->where('u.id IN (' . implode(',', $parameters) . ')');
        return $db->setQuery($query)->loadObjectList();
    }

    public function getRecord(int $userId): array
    {
        $administrator = $this->isAdministrator();
        if ($userId <= 0 || (!$administrator && $userId !== (int) $this->currentUser->id)) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_SUPPLIER_NOT_FOUND'), 404);
        }
        $db = $this->getDatabase();
        $query = $db->createQuery()->select('*')->from('#__altacourses_suppliers')
            ->where('user_id=:account')->bind(':account', $userId, ParameterType::INTEGER);
        $profile = $db->setQuery($query)->loadObject();
        $account = $this->getUserFactory()->loadUserById($userId);
        if ($account->guest || (int) $account->id !== $userId
            || ($profile === null && ($account->block || !$account->authorise('altacourses.supplier', 'com_altacourses')))) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_SUPPLIER_NOT_FOUND'), 404);
        }
        if ($profile !== null && (int) $profile->checked_out !== 0 && (int) $profile->checked_out !== (int) $this->currentUser->id) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_AVAILABILITY_LOCKED'), 409);
        }
        return ['account' => $account, 'profile' => $profile];
    }

    public function formData(array $record): array
    {
        $data = [];
        foreach (self::FIELDS as $field) {
            $data[$field] = (string) ($record['profile']->$field ?? '');
        }
        $data['user_id'] = (string) $record['account']->id;
        $data['id'] = (string) ($record['profile']->id ?? 0);
        $data['version'] = (string) ($record['profile']->profile_version ?? 0);
        return $data;
    }

    public function getForm(array $record, array $data): Form
    {
        $this->isAdministrator();
        $form = $this->getFormFactory()->createForm('com_altacourses.supplierprofile', ['control' => 'jform']);
        if (!$form->loadFile(dirname(__DIR__, 2) . '/forms/supplierprofile.xml')) {
            throw new \RuntimeException('Supplier form could not be loaded');
        }
        if ($record['profile'] !== null && empty($record['profile']->company)) {
            $form->setFieldAttribute('company', 'required', 'false');
        }
        $form->bind($data);
        return $form;
    }

    public function saveProfile(int $userId, int $id, int $version, array $input): void
    {
        $this->isAdministrator();
        $record = $this->getRecord($userId);
        $profile = $record['profile'];
        if ($id !== (int) ($profile->id ?? 0) || $version !== (int) ($profile->profile_version ?? 0)) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_SUPPLIER_CONFLICT'), 409);
        }
        $original = $this->formData($record);
        $data = $this->validateData($record, $input);
        $db = $this->getDatabase();
        $actor = (int) $this->currentUser->id;
        if ($profile === null) {
            $row = (object) ($data + ['user_id' => $userId, 'created_by' => $actor, 'state' => 1, 'ordering' => 0, 'checked_out' => 0, 'profile_version' => 1]);
            try {
                $db->insertObject('#__altacourses_suppliers', $row, 'id');
            } catch (\Throwable $exception) {
                // A unique account key prevents duplicate profiles from concurrent first saves.
                $query = $db->createQuery()->select('id')->from('#__altacourses_suppliers')->where('user_id=:account')->bind(':account', $userId, ParameterType::INTEGER);
                if ($db->setQuery($query)->loadResult() !== null) {
                    throw new \RuntimeException(Text::_('COM_ALTACOURSES_SUPPLIER_CONFLICT'), 409, $exception);
                }
                throw $exception;
            }
            return;
        }
        $query = $db->createQuery()->update('#__altacourses_suppliers')->set('profile_version=profile_version+1')
            ->where('id=:profile')->bind(':profile', $id, ParameterType::INTEGER)
            ->where('user_id=:account')->bind(':account', $userId, ParameterType::INTEGER)
            ->where('profile_version=:revision')->bind(':revision', $version, ParameterType::INTEGER)
            ->where('(checked_out IS NULL OR checked_out=0 OR checked_out=:actor)')->bind(':actor', $actor, ParameterType::INTEGER);
        $values = [];
        foreach (self::FIELDS as $field) {
            if ($data[$field] !== $original[$field]) {
                $parameter = ':field_' . $field;
                $values[$field] = $data[$field];
                $query->set($db->quoteName($field) . '=' . $parameter)->bind($parameter, $values[$field]);
            }
        }
        $db->setQuery($query)->execute();
        if ($db->getAffectedRows() !== 1) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_SUPPLIER_CONFLICT'), 409);
        }
    }

    private function validateData(array $record, array $input): array
    {
        $errors = [];
        if (array_diff(array_keys($input), self::FIELDS)) {
            $errors[] = Text::_('COM_ALTACOURSES_NEW_FIELDS_INVALID');
        }
        $original = $this->formData($record);
        $data = [];
        foreach (self::FIELDS as $field) {
            $value = $input[$field] ?? '';
            if (!is_string($value)) {
                $errors[] = Text::_('COM_ALTACOURSES_NEW_FIELDS_INVALID');
                $value = '';
            }
            $unchanged = $record['profile'] !== null && $value === $original[$field];
            if (!$unchanged) {
                $value = trim($value);
                if (str_contains($value, chr(0)) || preg_match('/[\x01-\x08\x0B\x0C\x0E-\x1F\x7F]/', $value)
                    || ($field !== 'terms' && preg_match('/[\r\n\t]/', $value))
                    || mb_strlen($value) > ($field === 'terms' ? 15000 : 255) || ($field === 'terms' && strlen($value) > 60000)) {
                    $errors[] = Text::_('COM_ALTACOURSES_NEW_FIELDS_INVALID');
                }
                if ($field === 'website' && $value !== '') {
                    $parts = parse_url($value);
                    if (filter_var($value, FILTER_VALIDATE_URL) === false || !is_array($parts)
                        || !in_array(strtolower($parts['scheme'] ?? ''), ['http', 'https'], true)
                        || isset($parts['user']) || isset($parts['pass'])) {
                        $errors[] = Text::_('COM_ALTACOURSES_SUPPLIER_WEBSITE_INVALID');
                    }
                }
            }
            $data[$field] = $value;
        }
        $form = $this->getForm($record, []);
        $validation = $data + array_intersect_key($original, array_flip(['user_id', 'id', 'version']));
        if (!$form->validate($validation)) {
            foreach ($form->getErrors() as $error) {
                $errors[] = $error instanceof \Exception ? $error->getMessage() : (string) $error;
            }
        }
        if ($errors) {
            throw new CourseValidationException(array_unique($errors));
        }
        return $data;
    }
}
