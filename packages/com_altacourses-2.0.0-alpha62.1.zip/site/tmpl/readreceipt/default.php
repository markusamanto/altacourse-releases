<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
use Joomla\CMS\Language\Text;
\defined('_JEXEC') or die;
?>
<section aria-labelledby="altacourses-read-receipt-heading">
    <h1 id="altacourses-read-receipt-heading"><?php echo $this->escape(Text::_('COM_ALTACOURSES_RECEIPT_TITLE')); ?></h1>
    <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_RECEIPT_PAGE')); ?></p>
</section>
