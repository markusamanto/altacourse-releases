<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;
$report = $this->report;
?>
<section aria-labelledby="commissions-title">
    <h1 id="commissions-title"><?php echo $this->escape(Text::_('COM_ALTACOURSES_COMMISSION_TITLE')); ?></h1>
    <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_COMMISSION_INTRO')); ?></p>
    <p><a href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=dashboard', false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_BACK_TO_DASHBOARD')); ?></a></p>
    <form id="commission-month-form" method="get" action="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=commissions', false)); ?>">
        <input type="hidden" name="option" value="com_altacourses" /><input type="hidden" name="view" value="commissions" />
        <label for="commission-month"><?php echo $this->escape(Text::_('COM_ALTACOURSES_COMMISSION_MONTH')); ?></label>
        <input type="month" id="commission-month" name="month" required value="<?php echo $this->escape($this->month); ?>" />
        <button class="btn btn-primary" type="submit"><?php echo $this->escape(Text::_('COM_ALTACOURSES_CONTACTS_FILTER')); ?></button>
    </form>
    <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_COMMISSION_PREVIEW')); ?></p>
    <?php if (!$report['rows']) : ?><p><?php echo $this->escape(Text::_('COM_ALTACOURSES_COMMISSION_EMPTY')); ?></p><?php endif; ?>
    <?php foreach ($report['groups'] as $supplierId => $group) : ?>
        <section data-commission-supplier="<?php echo (int) $supplierId; ?>">
            <h2><?php echo $this->escape($group['name']); ?></h2>
            <p><?php echo $this->escape(Text::sprintf('COM_ALTACOURSES_COMMISSION_COUNT', count($group['rows']))); ?> · <?php echo $this->escape(Text::_('COM_ALTACOURSES_COMMISSION_TOTAL')); ?>:
                <?php echo $this->escape($group['missing'] ? Text::_('COM_ALTACOURSES_COMMISSION_MISSING') : number_format($group['total'], 0, ',', ' ') . ' ' . Text::_('COM_ALTACOURSES_CURRENCY')); ?></p>
            <div class="table-responsive"><table class="table table-striped"><thead><tr>
                <?php foreach (['ENQUIRY_NAME', 'ENQUIRY_ORGANISATION', 'COMMISSION_AMOUNT', 'COMMISSION_STATE', 'COURSE_TYPE', 'PLACE', 'DATES', 'COMMISSION_REPORTED_AT', 'PARTICIPATION_NOTE'] as $label) : ?><th scope="col"><?php echo $this->escape(Text::_('COM_ALTACOURSES_' . $label)); ?></th><?php endforeach; ?>
            </tr></thead><tbody>
            <?php foreach ($group['rows'] as $row) : ?>
                <tr data-commission-request="<?php echo (int) $row->id; ?>">
                    <td><a href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=participant&id=' . (int) $row->id, false)); ?>"><?php echo $this->escape(trim(($row->contact['firstname'] ?? '') . ' ' . ($row->contact['lastname'] ?? ''))); ?></a></td>
                    <td><?php echo $this->escape($row->contact['company'] ?? ''); ?></td><td><?php echo $this->escape($row->effective_fee === null ? Text::_('COM_ALTACOURSES_COMMISSION_UNKNOWN') : number_format($row->effective_fee, 0, ',', ' ') . ' ' . Text::_('COM_ALTACOURSES_CURRENCY')); ?></td><td><?php echo $this->escape(Text::_($row->commission_fee === null ? 'COM_ALTACOURSES_COMMISSION_PRELIMINARY' : 'COM_ALTACOURSES_COMMISSION_RECORDED')); ?></td><td><?php echo $this->escape($row->course['course_type'] ?? ''); ?></td><td><?php echo $this->escape($row->course['course_place'] ?? ''); ?></td>
                    <td><?php foreach ($row->course['sessions'] ?? [] as $session) : ?><div><?php echo $this->escape(substr($session['start_date'] ?? '', 0, 10) . ' – ' . substr($session['stop_date'] ?? '', 0, 10)); ?></div><?php endforeach; ?></td>
                    <td><?php echo $this->escape($row->reported_local); ?></td>
                    
                    <td><?php echo nl2br($this->escape($row->note ?? '')); ?></td>
                </tr>
            <?php endforeach; ?></tbody></table></div>
        </section>
    <?php endforeach; ?>
    <?php if ($report['rows']) : ?>
        <p><strong><?php echo $this->escape(Text::_('COM_ALTACOURSES_COMMISSION_TOTAL')); ?>: <?php echo $this->escape($report['missing'] ? Text::_('COM_ALTACOURSES_COMMISSION_MISSING') : number_format($report['total'], 0, ',', ' ') . ' ' . Text::_('COM_ALTACOURSES_CURRENCY')); ?></strong></p>
        <?php if (!$report['missing']) : ?>
        <form id="commission-export-form" method="post" action="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&task=commissions.export', false)); ?>">
            <input type="hidden" name="jform[month]" value="<?php echo $this->escape($this->month); ?>" />
            <input type="hidden" name="jform[fingerprint]" value="<?php echo $this->escape($report['fingerprint']); ?>" />
            <p><label><input type="checkbox" name="jform[confirm]" value="1" required /> <?php echo $this->escape(Text::_('COM_ALTACOURSES_COMMISSION_CONFIRM')); ?></label></p>
            <?php echo HTMLHelper::_('form.token'); ?>
            <button class="btn btn-primary" type="submit"><?php echo $this->escape(Text::_('COM_ALTACOURSES_COMMISSION_EXPORT')); ?></button>
        </form>
        <?php endif; ?>
    <?php endif; ?>
    <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_COMMISSION_LIMITS')); ?></p>
    <h2><?php echo $this->escape(Text::_('COM_ALTACOURSES_COMMISSION_RATES')); ?></h2>
    <div class="table-responsive"><table class="table"><thead><tr><th scope="col"><?php echo $this->escape(Text::_('COM_ALTACOURSES_COMMISSION_SUPPLIER')); ?></th><th scope="col"><?php echo $this->escape(Text::_('COM_ALTACOURSES_COMMISSION_RATE')); ?></th><th scope="col"><?php echo $this->escape(Text::_('COM_ALTACOURSES_COMMISSION_EDIT_RATE')); ?></th></tr></thead><tbody>
        <?php foreach ($this->rates as $rate) : ?><tr data-commission-rate="<?php echo (int) $rate->user_id; ?>"><td><?php echo $this->escape($rate->company ?? ''); ?></td><td><?php echo $this->escape($rate->fee === null ? Text::_('COM_ALTACOURSES_COMMISSION_UNKNOWN') : $rate->fee . ' ' . Text::_('COM_ALTACOURSES_CURRENCY')); ?></td>
            <td><a href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=commissionrate&user_id=' . (int) $rate->user_id . '&month=' . rawurlencode($this->month), false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_COMMISSION_EDIT_RATE')); ?></a></td></tr><?php endforeach; ?>
    </tbody></table></div>
</section>

<p><a href="<?php echo Route::_('index.php?option=com_altacourses&view=monthlyreports&month=' . rawurlencode($this->month)); ?>"><?php echo Text::_('COM_ALTACOURSES_MONTHLY_TITLE'); ?></a></p>
