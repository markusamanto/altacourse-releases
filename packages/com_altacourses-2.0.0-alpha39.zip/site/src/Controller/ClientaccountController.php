<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Controller;

use Advenire\Component\Altacourses\Site\Exception\CourseValidationException;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;

final class ClientaccountController extends BaseController
{
    public function execute($task)
    {
        if (strtolower((string) $task) !== 'save') { throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'), 404); }
        return parent::execute($task);
    }

    public function save(): void
    {
        $model = $this->getModel('Accounts', 'Site', ['ignore_request' => true]);
        $model->requireAdministrator();
        if ($this->input->getMethod() !== 'POST') { throw new \RuntimeException(Text::_('COM_ALTACOURSES_SAMPLE_POST_REQUIRED'), 405); }
        if (!$this->checkToken('post', false)) { throw new \RuntimeException(Text::_('JINVALID_TOKEN'), 403); }
        $raw = $this->input->post->get('jform', [], 'array');
        if (array_diff(array_keys($raw), ['request_id', 'version', 'account'])
            || !isset($raw['request_id'], $raw['version'], $raw['account'])
            || !is_string($raw['request_id']) || !ctype_digit($raw['request_id']) || (float) $raw['request_id'] > 2147483647
            || !is_string($raw['version']) || !preg_match('/^[a-f0-9]{64}$/D', $raw['version']) || !is_string($raw['account'])) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_ACCOUNT_INVALID'), 400);
        }
        $participant = $this->getModel('Participant', 'Site', ['ignore_request' => true])->getRecord((int) $raw['request_id']);
        try {
            $model->saveClientAccount((int) $participant['selected']->clientid, $raw['version'], $raw['account']);
        } catch (CourseValidationException $exception) {
            $this->setMessage(Text::_('COM_ALTACOURSES_ACCOUNT_INVALID'), 'warning');
            $this->setRedirect(Route::_('index.php?option=com_altacourses&view=participant&id=' . (int) $raw['request_id'], false));
            return;
        } catch (\Throwable $exception) {
            if (in_array($exception->getCode(), [403, 404, 409], true)) { throw $exception; }
            $this->app->getLogger()->error('Altacourses client account save failed', ['exception' => $exception]);
            $this->setMessage(Text::_('COM_ALTACOURSES_ACCOUNT_FAILED'), 'warning');
            $this->setRedirect(Route::_('index.php?option=com_altacourses&view=participant&id=' . (int) $raw['request_id'], false));
            return;
        }
        $this->setMessage(Text::_('COM_ALTACOURSES_CLIENTACCOUNT_SAVED'));
        $this->setRedirect(Route::_('index.php?option=com_altacourses&view=participant&id=' . (int) $raw['request_id'], false));
    }
}
