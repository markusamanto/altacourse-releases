<?php
namespace Advenire\Component\Altacourses\Site\View\Mailchimp;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Language\Text;
\defined('_JEXEC') or die;
final class HtmlView extends BaseHtmlView
{
    public array $settings=[];
    public array $candidates=[];
    public array $history=[];
    public function display($tpl=null):void
    {
        $m=$this->getModel();$this->settings=$m->settings();$this->candidates=$m->candidates();$this->history=$m->history();
        $this->getDocument()->setTitle(Text::_('COM_ALTACOURSES_MC_TITLE'));$this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.site');parent::display($tpl);
    }
}
