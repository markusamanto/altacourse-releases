<?php
/** @package Altacourses.Module @license GNU General Public License version 2 or later */
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
\defined('_JEXEC') or die;
$escape=static fn(mixed $v):string=>htmlspecialchars((string)$v,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');$course=$details['course'];
$date=static fn(mixed $v):string=>is_string($v)&&preg_match('/^[1-9][0-9]{3}-[0-9]{2}-[0-9]{2}/',$v)?HTMLHelper::_('date',substr($v,0,10).' 12:00:00',Text::_('MOD_ALTACOURSEDETAILS_DATE_FORMAT'),false):Text::_('MOD_ALTACOURSEDETAILS_UNKNOWN');
?>
<div class="altacoursedetails" data-altacoursedetails="<?php echo (int)$course->id; ?>">
 <p><strong><?php echo $escape(Text::_('MOD_ALTACOURSEDETAILS_TOTAL_PRICE')); ?></strong><br><span data-course-total><?php echo $escape($details['price']); ?></span></p>
 <p class="small"><?php echo $escape(Text::_('MOD_ALTACOURSEDETAILS_PRICE_DESCRIPTION')); ?></p>
 <p><?php if ($details['signup']!==null) : ?><a class="btn btn-primary" data-course-signup href="<?php echo $escape($details['signup']); ?>"><?php echo $escape(Text::_('MOD_ALTACOURSEDETAILS_SIGNUP')); ?></a><?php else : ?><span class="btn btn-secondary disabled" aria-disabled="true"><?php echo $escape(Text::_('MOD_ALTACOURSEDETAILS_SIGNUP')); ?></span><?php endif; ?> <a class="btn btn-light" data-course-information href="<?php echo $escape($details['information']); ?>"><?php echo $escape(Text::_('MOD_ALTACOURSEDETAILS_INFORMATION')); ?></a></p>
 <p><strong><?php echo $escape(Text::_('MOD_ALTACOURSEDETAILS_DATES')); ?></strong><br><?php foreach ($details['sessions'] as $part) : ?><span class="altacoursedetails-session"><time datetime="<?php echo $escape(substr($part['start_date']??'',0,10)); ?>"><?php echo $escape($date($part['start_date'])); ?></time><?php if (substr($part['stop_date']??'',0,10)!==substr($part['start_date']??'',0,10)) : ?> – <time datetime="<?php echo $escape(substr($part['stop_date']??'',0,10)); ?>"><?php echo $escape($date($part['stop_date'])); ?></time><?php endif; ?></span><?php endforeach; ?></p>
 <p><strong><?php echo $escape(Text::_('MOD_ALTACOURSEDETAILS_PLACE')); ?></strong><br><?php if ($details['placeLink']!==null) : ?><a data-course-article="place" href="<?php echo $escape($details['placeLink']); ?>"><?php echo $escape($course->course_place); ?></a><?php else : ?><?php echo $escape($course->course_place); ?><?php endif; ?></p>
 <p><strong><?php echo $escape(Text::_('MOD_ALTACOURSEDETAILS_LEADERS')); ?></strong><?php foreach (['leader1','leader2'] as $f) : if(trim((string)($course->$f??''))===''){continue;} ?><br><?php if ($details[$f.'Link']!==null) : ?><a data-course-article="<?php echo $f; ?>" href="<?php echo $escape($details[$f.'Link']); ?>"><?php echo $escape($course->$f); ?></a><?php else : ?><?php echo $escape($course->$f); ?><?php endif; ?><?php endforeach; ?></p>
 <p><strong><?php echo $escape(Text::_('MOD_ALTACOURSEDETAILS_SEATS')); ?></strong><br><span data-course-seats><?php echo $escape($course->seats_label?:Text::_('MOD_ALTACOURSEDETAILS_UNKNOWN')); ?></span></p>
 <p><strong><?php echo $escape(Text::_('MOD_ALTACOURSEDETAILS_OTHER')); ?></strong></p>
 <?php if (trim((string)$course->course_notes)!=='') : ?><p class="altacoursedetails-notes" data-course-notes><?php echo $escape($course->course_notes); ?></p><?php endif; ?>
 <p><?php echo $escape(Text::_('MOD_ALTACOURSEDETAILS_VAT')); ?></p>
 <p><?php if ($details['signup']!==null) : ?><a class="btn btn-primary" data-course-signup href="<?php echo $escape($details['signup']); ?>"><?php echo $escape(Text::_('MOD_ALTACOURSEDETAILS_SIGNUP')); ?></a><?php else : ?><span class="btn btn-secondary disabled" aria-disabled="true"><?php echo $escape(Text::_('MOD_ALTACOURSEDETAILS_SIGNUP')); ?></span><?php endif; ?> <a class="btn btn-light" data-course-information href="<?php echo $escape($details['information']); ?>"><?php echo $escape(Text::_('MOD_ALTACOURSEDETAILS_INFORMATION')); ?></a></p>
 <p><a class="btn btn-light btn-sm" data-altacourses-back href="<?php echo $escape($details['back']); ?>"><?php echo $escape(Text::_('MOD_ALTACOURSEDETAILS_BACK')); ?></a></p>
</div>
