<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
use Joomla\CMS\Language\Text;
use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\Router\Route;
\defined('_JEXEC') or die;
?>
<?php $back = Route::_('index.php?' . http_build_query(['option' => 'com_altacourses', 'view' => 'client', 'id' => (int) $this->item->clientid, 'return_start' => $this->returnStart] + $this->returnFilters), false); ?>
<section aria-labelledby="altacourses-formdata-heading" data-formdata-request="<?php echo (int) $this->item->request_id; ?>">
    <h1 id="altacourses-formdata-heading"><?php echo $this->escape(Text::_('COM_ALTACOURSES_FORMDATA_TITLE')); ?> #<?php echo (int) $this->item->request_id; ?></h1>
    <p><a data-back-client href="<?php echo $this->escape($back); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_CLIENT_BACK')); ?></a></p>
    <?php if ($this->item->submission_id === null) : ?>
        <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_FORMDATA_MISSING')); ?></p>
    <?php else : ?>
        <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_FORMDATA_SAVED')); ?></p>
        <?php echo LayoutHelper::render('contactfields', ['view' => $this, 'submitted' => true], dirname(__DIR__, 2) . '/layouts'); ?>
        <?php if(array_key_exists('newsletter',$this->contact)): ?><dl data-newsletter-consent><dt><?php echo Text::_('COM_ALTACOURSES_NL_SUBMITTED'); ?></dt><dd><?php echo Text::_($this->contact['newsletter']==='1'?'JYES':'JNO'); ?></dd><?php if(isset($this->contact['newsletter_consent_at'])): ?><dt><?php echo Text::_('COM_ALTACOURSES_NL_CONSENT_AT'); ?></dt><dd><?php echo $this->escape($this->contact['newsletter_consent_at']); ?></dd><?php endif; ?></dl><?php endif; ?>
        <dl data-submitted-course>
            <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_PARTICIPANT_KIND')); ?></dt><dd><?php echo $this->escape(Text::_((int) $this->item->asked_for_info === 1 ? 'COM_ALTACOURSES_ENQUIRY_TITLE' : 'COM_ALTACOURSES_SIGNUP_TITLE')); ?></dd>
            <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_SIGNUP_CREATED')); ?></dt><dd><?php echo $this->escape($this->item->created_at); ?></dd>
            <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_COURSE_TYPE')); ?></dt><dd><?php echo $this->escape($this->course['course_type'] ?? ''); ?></dd>
            <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_PLACE')); ?></dt><dd><?php echo $this->escape($this->course['course_place'] ?? ''); ?><?php if ($this->item->place_changed) : ?><p class="small text-muted mt-2" role="note" data-course-place-changed><?php echo $this->escape(Text::_('COM_ALTACOURSES_FORMDATA_PLACE_CHANGED')); ?></p><?php endif; ?></dd>
            <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_DATES')); ?></dt><dd><?php foreach ($this->course['sessions'] ?? [] as $part) : ?><div><?php echo $this->escape(substr($part['start_date'] ?? '', 0, 10) . ' – ' . substr($part['stop_date'] ?? '', 0, 10)); ?></div><?php endforeach; ?><?php if ($this->item->dates_changed) : ?><p class="small text-muted mt-2" role="note" data-course-dates-changed><?php echo $this->escape(Text::_('COM_ALTACOURSES_FORMDATA_DATES_CHANGED')); ?></p><?php endif; ?></dd>
            <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_LEADERS')); ?></dt><dd><?php echo $this->escape(implode(', ', array_filter([$this->course['leader1'] ?? '', $this->course['leader2'] ?? '']))); ?><?php if ($this->item->leaders_changed) : ?><p class="small text-muted mt-2" role="note" data-course-leaders-changed><?php echo $this->escape(Text::_('COM_ALTACOURSES_FORMDATA_LEADERS_CHANGED')); ?></p><?php endif; ?></dd>
            <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_ENQUIRY_SUPPLIER')); ?></dt><dd><?php echo $this->escape($this->item->supplier_email); ?></dd>
            <?php if ((int) $this->item->asked_for_info === 0) : ?>
                <?php $booking = $this->course['booking'] ?? []; ?>
                <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_TOTAL_PRICE')); ?></dt><dd><?php echo $this->escape(($booking['total_price'] ?? '') . ' ' . Text::_('COM_ALTACOURSES_CURRENCY')); ?><?php if ($this->item->price_changed) : ?><p class="small text-muted mt-2" role="note" data-course-price-changed><?php echo $this->escape(Text::_('COM_ALTACOURSES_FORMDATA_PRICE_CHANGED')); ?></p><?php endif; ?></dd>
                <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_SUPPLIER_TERMS')); ?></dt><dd><?php echo nl2br($this->escape($booking['terms'] ?? '')); ?></dd>
                <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_FORMDATA_TERMS_ACCEPTED')); ?></dt><dd><?php echo $this->escape(Text::_(array_key_exists('terms_accepted', $booking) ? ($booking['terms_accepted'] ? 'JYES' : 'JNO') : 'COM_ALTACOURSES_UNSPECIFIED')); ?></dd>
                <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_SIGNUP_ACCEPTED_AT')); ?></dt><dd><?php echo $this->escape($booking['accepted_at'] ?? ''); ?></dd>
            <?php endif; ?>
        </dl>
    <?php endif; ?>
    <p><a data-back-client href="<?php echo $this->escape($back); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_CLIENT_BACK')); ?></a></p>
</section>
