<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
\defined('_JEXEC') or die;
?>
<section aria-labelledby="altacourses-signups-heading">
    <h1 id="altacourses-signups-heading"><?php echo $this->escape(Text::_('COM_ALTACOURSES_SIGNUPS_TITLE')); ?></h1>
    <p><a href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=dashboard', false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_BACK_TO_DASHBOARD')); ?></a></p>
    <?php if (!$this->items) : ?><p><?php echo $this->escape(Text::_('COM_ALTACOURSES_SIGNUPS_EMPTY')); ?></p><?php else : ?>
    <div class="table-responsive"><table class="table table-striped"><thead><tr>
        <?php foreach (['SIGNUP_CREATED', 'ENQUIRY_NAME', 'ENQUIRY_ORGANISATION', 'COURSE_TYPE', 'PLACE', 'DATES', 'SIGNUP_VIEW'] as $label) : ?>
            <th scope="col"><?php echo $this->escape(Text::_('COM_ALTACOURSES_' . $label)); ?></th>
        <?php endforeach; ?>
    </tr></thead><tbody>
    <?php foreach ($this->items as $item) : ?>
        <?php
        $contact = json_decode($item->contact_json, true, 512, JSON_THROW_ON_ERROR);
        $course = json_decode($item->course_json, true, 512, JSON_THROW_ON_ERROR);
        $booking = $course['booking'] ?? [];
        ?>
        <tr data-signup-id="<?php echo (int) $item->request_id; ?>">
            <td><?php echo $this->escape($item->created_at); ?></td>
            <td><?php echo $this->escape(($contact['firstname'] ?? '') . ' ' . ($contact['lastname'] ?? '')); ?></td>
            <td><?php echo $this->escape($contact['company'] ?? ''); ?></td>
            <td><?php echo $this->escape($course['course_type'] ?? ''); ?></td>
            <td><?php echo $this->escape($course['course_place'] ?? ''); ?></td>
            <td><?php foreach ($course['sessions'] ?? [] as $part) : ?><div><?php echo $this->escape(substr($part['start_date'] ?? '', 0, 10) . ' – ' . substr($part['stop_date'] ?? '', 0, 10)); ?></div><?php endforeach; ?></td>
            <td><details><summary><?php echo $this->escape(Text::_('COM_ALTACOURSES_SIGNUP_VIEW')); ?></summary>
                <dl>
                    <?php foreach (['firstname' => 'SUPPLIER_FIRSTNAME', 'lastname' => 'SUPPLIER_LASTNAME', 'company' => 'ENQUIRY_ORGANISATION', 'email' => 'ENQUIRY_EMAIL', 'phone' => 'SUPPLIER_PHONE', 'mobile' => 'SUPPLIER_MOBILE', 'age' => 'SIGNUP_AGE', 'profession' => 'SIGNUP_PROFESSION', 'specialmeal' => 'SIGNUP_SPECIALMEAL', 'postal_address' => 'SIGNUP_POSTAL_ADDRESS', 'postal_zip' => 'SIGNUP_POSTAL_ZIP', 'postal_city' => 'SIGNUP_POSTAL_CITY', 'invoice_address' => 'SIGNUP_INVOICE_ADDRESS', 'invoice_zip' => 'SIGNUP_INVOICE_ZIP', 'invoice_city' => 'SIGNUP_INVOICE_CITY'] as $field => $label) : ?>
                        <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_' . $label)); ?></dt><dd><?php echo $this->escape($contact[$field] ?? ''); ?></dd>
                    <?php endforeach; ?>
                    <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_LEADERS')); ?></dt><dd><?php echo $this->escape(implode(', ', array_filter([$course['leader1'] ?? '', $course['leader2'] ?? '']))); ?></dd>
                    <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_TOTAL_PRICE')); ?></dt><dd><?php echo $this->escape(($booking['total_price'] ?? '') . ' ' . Text::_('COM_ALTACOURSES_CURRENCY')); ?></dd>
                    <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_ENQUIRY_SUPPLIER')); ?></dt><dd><?php echo $this->escape($item->supplier_email); ?></dd>
                    <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_SUPPLIER_TERMS')); ?></dt><dd><?php echo nl2br($this->escape($booking['terms'] ?? '')); ?></dd>
                    <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_SIGNUP_ACCEPTED_AT')); ?></dt><dd><?php echo $this->escape($booking['accepted_at'] ?? ''); ?></dd>
                </dl>
            </details></td>
        </tr>
    <?php endforeach; ?></tbody></table></div>
    <?php echo $this->pagination->getPagesLinks(); ?>
    <?php endif; ?>
</section>
