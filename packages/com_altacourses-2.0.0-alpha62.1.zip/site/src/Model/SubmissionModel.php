<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Model;

use Advenire\Component\Altacourses\Administrator\Service\NotificationAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\NotificationAwareTrait;
use Advenire\Component\Altacourses\Site\Exception\CourseValidationException;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Form\FormFactoryAwareInterface;
use Joomla\CMS\Form\FormFactoryAwareTrait;
use Joomla\CMS\Language\Text;
use Joomla\CMS\String\PunycodeHelper;
use Joomla\CMS\User\UserFactoryAwareInterface;
use Joomla\CMS\User\UserFactoryAwareTrait;
use Joomla\Database\ParameterType;

\defined('_JEXEC') or die;

abstract class SubmissionModel extends PubliccourseModel implements FormFactoryAwareInterface, UserFactoryAwareInterface, NotificationAwareInterface
{
    use FormFactoryAwareTrait;
    use UserFactoryAwareTrait;
    use NotificationAwareTrait;

    protected const FORM = 'enquiry';
    protected const ASKED_FOR_INFO = 1;

    public const FIELDS = ['firstname', 'lastname', 'company', 'email', 'phone', 'mobile'];

    public function getForm(array $data = []): Form
    {
        $form = $this->getFormFactory()->createForm('com_altacourses.' . static::FORM, ['control' => 'jform']);
        if (!$form->loadFile(dirname(__DIR__, 2) . '/forms/' . static::FORM . '.xml')) {
            throw new \RuntimeException('Enquiry form could not be loaded');
        }
        $form->bind($data);
        return $form;
    }

    public function canEnquire(int $id): bool
    {
        try { $this->getCourse($id); return true; } catch (\RuntimeException $exception) {
            if ($exception->getCode() === 404) { return false; }
            throw $exception;
        }
    }

    /** Private eligibility/recipient projection; only the public summary is passed to the view. */
    public function getCourse(int $id, bool $lock = false): object
    {
        if ($id <= 0) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_' . strtoupper(static::FORM) . '_UNAVAILABLE'), 404);
        }
        $query = $this->publicQuery()->select(['co.id', 'co.start_date', 'co.stop_date', 'co.course_price', 'co.lodging_price',
            'co.lodging_included', 'co.availability_version', 'co.cr AS supplier_user_id', 'co.course_type AS type_id',
            'co.course_place AS place_id', 'co.course_leader_1 AS leader1_id', 'co.course_leader_2 AS leader2_id',
            'ct.name AS course_type', 'cp.name AS course_place', 'l1.name AS leader1', 'l2.name AS leader2',
            'sp.id AS supplier_id', 'sp.terms AS supplier_terms', 'sp.profile_version', 'u.email AS supplier_email'])
            ->join('INNER', '#__altacourses_suppliers AS sp ON sp.user_id=co.cr AND sp.state=1')
            ->join('INNER', '#__users AS u ON u.id=co.cr AND u.block=0')
            ->where('co.id=:course')->bind(':course', $id, ParameterType::INTEGER);
        if ($lock) {
            // Verified MySQL row-lock SQL through Joomla's bound direct-query API.
            $query->setQuery((string) $query . ' FOR UPDATE');
        }
        $record = $this->getDatabase()->setQuery($query)->loadObject();
        if ($record === null) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_' . strtoupper(static::FORM) . '_UNAVAILABLE'), 404);
        }
        $supplier = $this->getUserFactory()->loadUserById((int) $record->supplier_user_id);
        if ($supplier->guest || $supplier->block || !$supplier->authorise('altacourses.supplier', 'com_altacourses')
            || !filter_var(PunycodeHelper::emailToPunycode($record->supplier_email), FILTER_VALIDATE_EMAIL)) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_' . strtoupper(static::FORM) . '_UNAVAILABLE'), 404);
        }
        return $record;
    }

    public function summary(object $record): array
    {
        $sessions = $this->getCourseSchedule()->additionalSessions([(int) $record->id])[(int) $record->id] ?? [];
        return ['id' => (int) $record->id, 'course_type' => $record->course_type, 'course_place' => $record->course_place,
            'leader1' => $record->leader1, 'leader2' => $record->leader2,
            'sessions' => array_merge([['start_date' => $record->start_date, 'stop_date' => $record->stop_date]],
                array_map(static fn ($part): array => ['start_date' => $part->start_date, 'stop_date' => $part->stop_date], $sessions))];
    }

    public function submit(int $courseId, int $expectedRevision, string $token, array $input, ?string $agreement = null): int
    {
        if (!preg_match('/^[a-f0-9]{64}$/D', $token) || $courseId <= 0 || $expectedRevision < 0) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_ENQUIRY_EXPIRED'), 409);
        }
        $data = $this->validateData($input);
        $hash = hash('sha256', $token);
        $existing = $this->existingSubmission($hash, $courseId);
        if ($existing !== null) { return $existing; }
        $db = $this->getDatabase();
        $db->transactionStart();
        try {
            $course = $this->getCourse($courseId, true);
            if ((int) $course->availability_version !== $expectedRevision) {
                throw new \RuntimeException(Text::_('COM_ALTACOURSES_ENQUIRY_CONFLICT'), 409);
            }
            $this->checkAgreement($course, $agreement);
            $query = $db->createQuery()->select('id')->from('#__altacourses_clients')->where('email=:email')
                ->bind(':email', $data['email'])->order('id');
            $clientId = (int) $db->setQuery($query, 0, 1)->loadResult();
            if ($clientId === 0) {
                // Existing participant rows are never overwritten by an unauthenticated email match.
                $client = (object) ($data + ['state' => 1, 'created_by' => 0]);
                $db->insertObject('#__altacourses_clients', $client, 'id');
                $clientId = (int) $client->id;
            }
            $now = (new \DateTimeImmutable('now', new \DateTimeZone('UTC')))->format('Y-m-d H:i:s');
            $request = (object) ['courseid' => $courseId, 'clientid' => $clientId, 'asked_for_info' => static::ASKED_FOR_INFO,
                'date_created' => $now, 'state' => 1, 'created_by' => 0];
            $db->insertObject('#__altacourses_requests', $request, 'id');
            $snapshot = $this->summary($course) + ['type_id' => $course->type_id, 'place_id' => $course->place_id,
                'leader1_id' => $course->leader1_id, 'leader2_id' => $course->leader2_id,
                'course_price' => $course->course_price, 'lodging_price' => $course->lodging_price,
                'lodging_included' => $course->lodging_included];
            $snapshot = $this->submissionSnapshot($course, $snapshot, $now);
            $submission = (object) ['request_id' => (int) $request->id, 'supplier_id' => (int) $course->supplier_id,
                'supplier_user_id' => (int) $course->supplier_user_id, 'supplier_email' => $course->supplier_email,
                'token_hash' => $hash, 'contact_json' => json_encode($data, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE),
                'course_json' => json_encode($snapshot, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE),
                'created_at' => $now, 'delivery_state' => 'not_sent'];
            $db->insertObject('#__altacourses_request_submissions', $submission, 'id');
            $this->getNotifications()->prepare((int) $request->id);
            $db->transactionCommit();
        } catch (\Throwable $exception) {
            $db->transactionRollback();
            $existing = $this->existingSubmission($hash, $courseId);
            if ($existing !== null) { return $existing; }
            throw $exception;
        }
        // SMTP happens only after commit, only for a newly-created submission.
        // Duplicate/replayed POSTs returned above and cannot dispatch a backlog.
        try { $this->getNotifications()->deliver((int) $request->id); } catch (\Throwable) {
            // The persisted outbox remains available for administrator review.
        }
        return (int) $request->id;
    }

    private function existingSubmission(string $hash, int $courseId): ?int
    {
        $query = $this->getDatabase()->createQuery()->select('s.request_id')->from('#__altacourses_request_submissions AS s')
            ->join('INNER', '#__altacourses_requests AS r ON r.id=s.request_id')
            ->where('s.token_hash=:token')->bind(':token', $hash)
            ->where('r.courseid=:course')->bind(':course', $courseId, ParameterType::INTEGER)
            ->where('r.asked_for_info=' . static::ASKED_FOR_INFO);
        $id = $this->getDatabase()->setQuery($query)->loadResult();
        return $id === null ? null : (int) $id;
    }

    protected function checkAgreement(object $course, ?string $agreement): void
    {
    }

    protected function submissionSnapshot(object $course, array $snapshot, string $now): array
    {
        return $snapshot;
    }

    protected function validateData(array $input): array
    {
        $errors = [];
        if (array_diff(array_keys($input), static::FIELDS)) { $errors[] = Text::_('COM_ALTACOURSES_NEW_FIELDS_INVALID'); }
        $data = [];
        foreach (static::FIELDS as $field) {
            $value = $input[$field] ?? '';
            if (!is_string($value)) { $errors[] = Text::_('COM_ALTACOURSES_NEW_FIELDS_INVALID'); $value = ''; }
            $value = trim($value);
            if (mb_strlen($value) > 255 || preg_match('/[\x00-\x1F\x7F]/', $value)) {
                $errors[] = Text::_('COM_ALTACOURSES_NEW_FIELDS_INVALID');
            }
            $data[$field] = $value;
        }
        $form = $this->getForm();
        if (!$form->validate($data)) {
            foreach ($form->getErrors() as $error) { $errors[] = $error instanceof \Exception ? $error->getMessage() : (string) $error; }
        }
        if (!$errors) {
            $data['email'] = PunycodeHelper::emailToPunycode($data['email']);
            if (strlen($data['email']) > 254) { $errors[] = Text::_('COM_ALTACOURSES_NEW_FIELDS_INVALID'); }
        }
        if ($errors) { throw new CourseValidationException(array_unique($errors)); }
        return $data;
    }
}
