-- Widen only the Alpha62 enrolment references to match unsigned legacy request/client IDs.
ALTER TABLE `#__altacourses_mailchimp_enrollments`
 MODIFY COLUMN `request_id` int unsigned NOT NULL,
 MODIFY COLUMN `client_id` int unsigned NOT NULL;
