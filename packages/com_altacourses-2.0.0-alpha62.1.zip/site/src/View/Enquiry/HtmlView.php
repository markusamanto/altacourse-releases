<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */
namespace Advenire\Component\Altacourses\Site\View\Enquiry;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
\defined('_JEXEC') or die;
final class HtmlView extends BaseHtmlView
{
    public ?\Joomla\CMS\Form\Form $form = null;
    public array $summary = [];
    public function display($tpl = null): void
    {
        $this->getDocument()->setTitle(Text::_('COM_ALTACOURSES_ENQUIRY_TITLE'));
        $this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.site');
        parent::display($tpl);
    }
}
