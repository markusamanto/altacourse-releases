CREATE TABLE IF NOT EXISTS `#__altacourses_newsletter_deliveries` (
 `id` int unsigned NOT NULL AUTO_INCREMENT,
 `submission_id` int unsigned NOT NULL,
 `client_id` int unsigned NOT NULL,
 `email_hash` char(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `account_name` varchar(63) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
 `funnel_id` int unsigned NOT NULL DEFAULT 0,
 `state` varchar(16) NOT NULL DEFAULT 'pending',
 `attempts` int unsigned NOT NULL DEFAULT 0,
 `revision` int unsigned NOT NULL DEFAULT 0,
 `last_error` varchar(64) DEFAULT NULL,
 `http_status` smallint unsigned NOT NULL DEFAULT 0,
 `next_attempt_at` datetime DEFAULT NULL,
 `created_at` datetime NOT NULL,
 `updated_at` datetime NOT NULL,
 PRIMARY KEY (`id`),
 UNIQUE KEY `submission` (`submission_id`),
 KEY `audience_email` (`account_name`,`funnel_id`,`email_hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
