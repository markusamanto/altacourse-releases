<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
\defined('_JEXEC') or die;
?>
<section aria-labelledby="altacourses-signups-heading">
    <h1 id="altacourses-signups-heading"><?php echo $this->escape(Text::_('COM_ALTACOURSES_SIGNUPS_TITLE')); ?></h1>
    <p><a href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=dashboard', false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_BACK_TO_DASHBOARD')); ?></a></p>
    <?php if (!$this->items) : ?><p><?php echo $this->escape(Text::_('COM_ALTACOURSES_SIGNUPS_EMPTY')); ?></p><?php else : ?>
    <div class="table-responsive"><table class="table table-striped"><thead><tr>
        <?php foreach (['SIGNUP_CREATED', 'ENQUIRY_NAME', 'ENQUIRY_ORGANISATION', 'COURSE_TYPE', 'PLACE', 'DATES', 'SIGNUP_VIEW'] as $label) : ?>
            <th scope="col"><?php echo $this->escape(Text::_('COM_ALTACOURSES_' . $label)); ?></th>
        <?php endforeach; ?>
    </tr></thead><tbody>
    <?php foreach ($this->items as $item) : ?>
        <?php
        $contact = json_decode($item->contact_json, true, 512, JSON_THROW_ON_ERROR);
        $course = json_decode($item->course_json, true, 512, JSON_THROW_ON_ERROR);
        ?>
        <tr data-signup-id="<?php echo (int) $item->request_id; ?>">
            <td><?php echo $this->escape($item->created_at); ?></td>
            <td><?php echo $this->escape(($contact['firstname'] ?? '') . ' ' . ($contact['lastname'] ?? '')); ?></td>
            <td><?php echo $this->escape($contact['company'] ?? ''); ?></td>
            <td><?php echo $this->escape($course['course_type'] ?? ''); ?></td>
            <td><?php echo $this->escape($course['course_place'] ?? ''); ?></td>
            <td><?php foreach ($course['sessions'] ?? [] as $part) : ?><div><?php echo $this->escape(substr($part['start_date'] ?? '', 0, 10) . ' – ' . substr($part['stop_date'] ?? '', 0, 10)); ?></div><?php endforeach; ?></td>
            <td><a data-signup-details href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=participant&id=' . (int) $item->request_id . '&return_start=' . (int) $this->pagination->limitstart, false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_SIGNUP_VIEW')); ?></a></td>
        </tr>
    <?php endforeach; ?></tbody></table></div>
    <?php echo $this->pagination->getPagesLinks(); ?>
    <?php endif; ?>
</section>
