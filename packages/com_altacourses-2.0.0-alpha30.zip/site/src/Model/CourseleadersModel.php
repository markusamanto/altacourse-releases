<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Model;

use Advenire\Component\Altacourses\Site\Exception\CourseValidationException;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Form\FormFactoryAwareInterface;
use Joomla\CMS\Form\FormFactoryAwareTrait;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\BaseModel;
use Joomla\CMS\User\CurrentUserInterface;
use Joomla\CMS\User\User;
use Joomla\CMS\User\UserFactoryAwareInterface;
use Joomla\CMS\User\UserFactoryAwareTrait;
use Joomla\Database\DatabaseAwareInterface;
use Joomla\Database\DatabaseAwareTrait;
use Joomla\Database\ParameterType;

\defined('_JEXEC') or die;

/** Courseleader management uses the original table and IDs; no delete operation. */
final class CourseleadersModel extends BaseModel implements DatabaseAwareInterface, CurrentUserInterface, UserFactoryAwareInterface, FormFactoryAwareInterface
{
    use DatabaseAwareTrait;
    use UserFactoryAwareTrait;
    use FormFactoryAwareTrait;

    private ?User $currentUser = null;
    private int $articleCategory = 0;

    public function setArticleCategory(int $category): void
    {
        $this->articleCategory = $category > 0 && $category <= 2147483647 ? $category : 0;
    }

    /** Choices are scoped to the configured exact category and the administrator's view access. */
    public function getArticleChoices(): array
    {
        $this->requireAdministrator();
        if ($this->articleCategory === 0) { return []; }
        $db = $this->getDatabase();
        $category = $this->articleCategory;
        $levels = array_map('intval', $this->currentUser->getAuthorisedViewLevels());
        $access = implode(',', $levels ?: [0]);
        $query = $db->createQuery()->select(['a.id', 'a.title', 'a.state'])
            ->from($db->quoteName('#__content', 'a'))
            ->join('INNER', $db->quoteName('#__categories', 'c') . ' ON c.id = a.catid')
            ->where('a.catid = :category')->bind(':category', $category, ParameterType::INTEGER)
            ->where("c.extension = 'com_content'")->where('c.published IN (0,1,2)')
            ->where('a.state IN (0,1,2)')->where('a.access IN (' . $access . ')')->where('c.access IN (' . $access . ')')
            ->order('a.title, a.id');
        return $db->setQuery($query)->loadObjectList();
    }

    private function articleId(?string $value): ?string
    {
        if ($value === null || !ctype_digit($value) || (float) $value > 2147483647 || (int) $value <= 0) { return null; }
        return (string) (int) $value;
    }

    private function linkSelection(?object $record): string
    {
        $value = $record->url ?? null;
        return $value === null || $value === '' || $value === '0' ? '' : ($this->articleId($value) ?? '__keep');
    }

    /** Omitted URL preserves older forms/API calls; only explicit clearing removes a stored link. */
    private function validateLink(array $input, ?object $record): ?string
    {
        if (!array_key_exists('url', $input)) { return $record->url ?? null; }
        $value = $input['url'];
        if (!is_string($value) || strlen($value) > 255) {
            throw new CourseValidationException([Text::_('COM_ALTACOURSES_LEADER_ARTICLE_INVALID')]);
        }
        if ($value === '') {
            // Preserve existing empty representations; new/explicitly cleared active links use NULL.
            return $this->linkSelection($record) === '' ? ($record->url ?? null) : null;
        }
        if ($value === '__keep' && $this->linkSelection($record) !== '') { return $record->url; }
        $id = $this->articleId($value);
        if ($id !== null) {
            if ($id === $this->articleId($record->url ?? null)) { return $record->url; }
            foreach ($this->getArticleChoices() as $choice) {
                if ($id === (string) $choice->id) { return $id; }
            }
        }
        throw new CourseValidationException([Text::_('COM_ALTACOURSES_LEADER_ARTICLE_INVALID')]);
    }

    public function setCurrentUser(User $currentUser): void
    {
        $this->currentUser = $currentUser;
    }

    public function requireAdministrator(): void
    {
        $user = $this->currentUser;
        if ($user === null || $user->guest || $user->block
            || !$user->authorise('altacourses.manage', 'com_altacourses')) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }
        $fresh = $this->getUserFactory()->loadUserById((int) $user->id);
        if ($fresh->guest || $fresh->block || !$fresh->authorise('altacourses.manage', 'com_altacourses')) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }
    }

    public function getItems(): array
    {
        $this->requireAdministrator();
        $db = $this->getDatabase();
        return $db->setQuery($db->createQuery()->select(['id', 'name', 'state'])
            ->from($db->quoteName('#__altacourses_courseleaders'))->order($db->quoteName('name') . ', ' . $db->quoteName('id')))->loadObjectList();
    }

    public function getRecord(int $id): ?object
    {
        $this->requireAdministrator();
        if ($id === 0) {
            return null;
        }
        $db = $this->getDatabase();
        $query = $db->createQuery()->select('*')->from($db->quoteName('#__altacourses_courseleaders'))
            ->where($db->quoteName('id') . ' = :id')->bind(':id', $id, ParameterType::INTEGER);
        $record = $db->setQuery($query)->loadObject();
        if ($record === null) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_COURSELEADER_NOT_FOUND'), 404);
        }
        $this->requireUnlocked($record);
        return $record;
    }

    /** A fingerprint avoids adding a migration-only revision column to the legacy table. */
    public function formData(?object $record): array
    {
        return [
            'id' => (string) ($record->id ?? 0),
            'name' => (string) ($record->name ?? ''),
            'state' => $record === null ? '1' : (string) $record->state,
            'url' => $this->linkSelection($record),
            'version' => $record === null ? '' : hash('sha256', json_encode($record, JSON_THROW_ON_ERROR)),
        ];
    }

    public function getForm(array $data): Form
    {
        $this->requireAdministrator();
        $form = $this->getFormFactory()->createForm('com_altacourses.courseleader', ['control' => 'jform']);
        if (!$form->loadFile(dirname(__DIR__, 2) . '/forms/courseleader.xml')) {
            throw new \RuntimeException('Courseleader form could not be loaded');
        }
        $record = $this->getRecord((int) ($data['id'] ?? 0));
        $choices = $this->getArticleChoices();
        $default = $this->linkSelection($record);
        $field = new \SimpleXMLElement('<field />');
        foreach (['name' => 'url', 'type' => 'list', 'filter' => 'raw', 'label' => 'COM_ALTACOURSES_LEADER_ARTICLE',
            'description' => $this->articleCategory === 0 ? 'COM_ALTACOURSES_LEADER_ARTICLE_UNCONFIGURED' : 'COM_ALTACOURSES_LEADER_ARTICLE_HELP'] as $key => $value) {
            $field->addAttribute($key, $value);
        }
        $empty = $field->addChild('option'); $empty->addAttribute('value', '');
        $empty[0] = Text::_('COM_ALTACOURSES_LEADER_ARTICLE_NONE');
        $values = [''];
        foreach ($choices as $choice) {
            $value = (string) $choice->id;
            $option = $field->addChild('option'); $option->addAttribute('value', $value);
            $label = $choice->title . ' (#' . $value . ')';
            if ((int) $choice->state !== 1) { $label .= ' — ' . Text::_((int) $choice->state === 0 ? 'JUNPUBLISHED' : 'JARCHIVED'); }
            $option[0] = $label;
            $values[] = $value;
        }
        if ($default !== '' && !in_array($default, $values, true)) {
            $option = $field->addChild('option'); $option->addAttribute('value', '__keep');
            $id = $this->articleId($record->url ?? null);
            $option[0] = $id === null ? Text::_('COM_ALTACOURSES_LEADER_ARTICLE_KEEP_LEGACY') : Text::sprintf('COM_ALTACOURSES_LEADER_ARTICLE_KEEP_ID', $id);
            if (($data['url'] ?? $default) === $default) { $data['url'] = '__keep'; }
            $default = '__keep'; $values[] = '__keep';
        }
        if (!isset($data['url']) || !is_string($data['url']) || !in_array($data['url'], $values, true)) { $data['url'] = $default; }
        $form->setField($field);
        $form->bind($data);
        return $form;
    }

    public function saveLeader(int $id, string $version, array $input): int
    {
        $this->requireAdministrator();
        $name = $input['name'] ?? null;
        $state = $input['state'] ?? null;
        if (array_diff(array_keys($input), ['name', 'state', 'url']) || !is_string($name) || !is_string($state)
            || !in_array($state, ['0', '1'], true)) {
            throw new CourseValidationException([Text::_('COM_ALTACOURSES_COURSELEADER_INVALID')]);
        }
        $name = trim($name);
        if ($name === '' || mb_strlen($name) > 255 || preg_match('/[\x00-\x1F\x7F]/u', $name)) {
            throw new CourseValidationException([Text::_('COM_ALTACOURSES_COURSELEADER_INVALID')]);
        }
        $form = $this->getForm([]);
        if (!$form->validate(['id' => $id, 'name' => $name, 'state' => $state])) {
            throw new CourseValidationException([Text::_('COM_ALTACOURSES_COURSELEADER_INVALID')]);
        }
        $db = $this->getDatabase();
        if ($id === 0) {
            if ($version !== '') {
                throw new \RuntimeException(Text::_('COM_ALTACOURSES_COURSELEADER_CONFLICT'), 409);
            }
            $url = $this->validateLink($input, null);
            $row = (object) ['url' => $url, 'name' => $name, 'state' => (int) $state, 'created_by' => (int) $this->currentUser->id];
            $db->insertObject('#__altacourses_courseleaders', $row, 'id');
            return (int) $row->id;
        }
        $db->transactionStart();
        try {
            $query = $db->createQuery()->select('*')->from($db->quoteName('#__altacourses_courseleaders'))
                ->where($db->quoteName('id') . ' = :id')->bind(':id', $id, ParameterType::INTEGER);
            $query->setQuery((string) $query . ' FOR UPDATE');
            $record = $db->setQuery($query)->loadObject();
            if ($record === null) {
                throw new \RuntimeException(Text::_('COM_ALTACOURSES_COURSELEADER_NOT_FOUND'), 404);
            }
            $this->requireUnlocked($record);
            if (!hash_equals($this->formData($record)['version'], $version)) {
                throw new \RuntimeException(Text::_('COM_ALTACOURSES_COURSELEADER_CONFLICT'), 409);
            }
            $url = $this->validateLink($input, $record);
            $published = (int) $state;
            $query = $db->createQuery()->update($db->quoteName('#__altacourses_courseleaders'))
                ->set($db->quoteName('name') . ' = :name')->bind(':name', $name)
                ->set($db->quoteName('state') . ' = :state')->bind(':state', $published, ParameterType::INTEGER)
                ->where($db->quoteName('id') . ' = :id')->bind(':id', $id, ParameterType::INTEGER);
            if ($url !== $record->url) {
                if ($url === null) { $query->set($db->quoteName('url') . ' = NULL'); }
                else { $query->set($db->quoteName('url') . ' = :article')->bind(':article', $url); }
            }
            $db->setQuery($query)->execute();
            $db->transactionCommit();
            return $id;
        } catch (\Throwable $exception) {
            $db->transactionRollback();
            throw $exception;
        }
    }

    private function requireUnlocked(object $record): void
    {
        if ((int) $record->checked_out !== 0 && (int) $record->checked_out !== (int) $this->currentUser->id) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_AVAILABILITY_LOCKED'), 409);
        }
    }
}
