<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Model;
use Joomla\CMS\Language\Text;
\defined('_JEXEC') or die;

/** Reuse management-list scoping/filters; expose only availability for inline writes. */
final class CourseavailabilityModel extends RequestrecordsModel
{
    use ContactScopeTrait;
    private ?ManagecoursesModel $managed=null;
    private ?AvailabilityModel $availability=null;
    public function setModels(ManagecoursesModel $managed,AvailabilityModel $availability): void { $this->managed=$managed;$this->availability=$availability; }
    private function managed(): ManagecoursesModel
    {
        $this->requireContactAccess();$m=$this->managed??throw new \RuntimeException('Course list unavailable');$m->setCurrentUser($this->getActor());
        foreach(['period','supplier'] as $key){$m->setState('filter.'.$key,$this->getState('filter.'.$key,$key==='period'?'future':0));}
        foreach(['start'=>0,'limit'=>20] as $key=>$default){$m->setState('list.'.$key,$this->getState('list.'.$key,$default));}
        return $m;
    }
    public function getItems(): array
    {
        $items=$this->managed()->getItems();if(!$items){return [];}
        $db=$this->getDatabase();$ids=implode(',',array_map(static fn($r)=>(int)$r->id,$items));
        $details=$db->setQuery('SELECT co.id,co.availability_version,co.checked_out,l1.name AS leader1,l2.name AS leader2,sp.company FROM #__altacourses_courses co LEFT JOIN #__altacourses_courseleaders l1 ON l1.id=co.course_leader_1 LEFT JOIN #__altacourses_courseleaders l2 ON l2.id=co.course_leader_2 LEFT JOIN #__altacourses_suppliers sp ON sp.user_id=co.cr WHERE co.id IN ('.$ids.')')->loadObjectList('id');
        $actor=$this->getActor();$admin=$this->isContactAdministrator();
        foreach($items as $item){$d=$details[(int)$item->id]??null;$item->version=(int)($d->availability_version??0);$item->leader1=$d->leader1??'';$item->leader2=$d->leader2??'';$item->supplier=trim((string)($d->company??''))?:($item->owner_name??($item->cr?Text::sprintf('COM_ALTACOURSES_OWNER_ID',(int)$item->cr):Text::_('COM_ALTACOURSES_UNASSIGNED')));$locked=$d===null||((int)$d->checked_out!==0&&(int)$d->checked_out!==(int)$actor->id);$item->editable=!$locked&&($admin||(bool)$item->availability_upcoming)&&$item->version<4294967295;$item->reason=$locked?Text::_('COM_ALTACOURSES_AVAILABILITY_LOCKED'):Text::_('COM_ALTACOURSES_INLINE_READONLY');}
        return $items;
    }
    public function getTotal(): int { return $this->managed()->getTotal(); }
    public function getSuppliers(): array { return $this->managed()->getOptions('suppliers'); }
    public function getChoices(): array
    {
        $this->requireContactAccess();return ($this->availability??throw new \RuntimeException('Availability unavailable'))->getChoices();
    }
    /** Read current state after uncertain saves, including newly historical/locked own rows. */
    public function readState(int $id): array
    {
        $this->requireContactAccess();if($id<1||$id>4294967295){throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_AVAILABILITY'),400);}
        $actor=$this->getActor();$admin=$this->isContactAdministrator();$db=$this->getDatabase();$where=$admin?'':' AND cr='.(int)$actor->id;
        $r=$db->setQuery('SELECT id,nr_of_participants,availability_version,checked_out,start_date>=CURRENT_TIMESTAMP AS upcoming FROM #__altacourses_courses WHERE id='.$id.$where)->loadObject();
        if($r===null){throw new \RuntimeException(Text::_('COM_ALTACOURSES_AVAILABILITY_NOT_FOUND'),404);}
        $choices=array_map(static fn($c)=>['value'=>(int)$c->seats,'label'=>(string)$c->label],$this->getChoices());
        $locked=(int)$r->checked_out!==0&&(int)$r->checked_out!==(int)$actor->id;
        return ['id'=>(int)$r->id,'availability'=>$r->nr_of_participants===null?null:(int)$r->nr_of_participants,'version'=>(int)$r->availability_version,'editable'=>!$locked&&($admin||(bool)$r->upcoming)&&$choices!==[]&&(int)$r->availability_version<4294967295,'reason'=>$locked?Text::_('COM_ALTACOURSES_AVAILABILITY_LOCKED'):Text::_('COM_ALTACOURSES_INLINE_READONLY'),'choices'=>$choices];
    }
}
