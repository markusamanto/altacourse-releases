<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\View\Rebooking;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Language\Text;
\defined('_JEXEC') or die;
final class HtmlView extends BaseHtmlView
{
    public object $record;
    public array $options = [];
    public array $context = [];
    public function display($tpl = null): void
    {
        $model = $this->getModel(); $this->record = $model->getRecord((int) $model->getState('request.id'));
        $this->context = $model->getContext((int) $this->record->id);
        $this->options = $model->getOptions((int) $this->record->id);
        $this->getDocument()->setTitle(Text::_('COM_ALTACOURSES_REBOOK_ACTION'));
        parent::display($tpl);
    }
}
