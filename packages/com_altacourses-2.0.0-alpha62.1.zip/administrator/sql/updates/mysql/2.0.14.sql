ALTER TABLE `#__altacourses_request_rebookings`
 ADD COLUMN `destination_request_id` int UNSIGNED DEFAULT NULL,
 ADD UNIQUE KEY `idx_rebooking_destination` (`destination_request_id`);
