<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Model;

use Advenire\Component\Altacourses\Site\Exception\CourseValidationException;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Form\FormFactoryAwareInterface;
use Joomla\CMS\Form\FormFactoryAwareTrait;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\BaseModel;
use Joomla\CMS\User\CurrentUserInterface;
use Joomla\CMS\User\User;
use Joomla\CMS\User\UserFactoryAwareInterface;
use Joomla\CMS\User\UserFactoryAwareTrait;
use Joomla\Database\DatabaseAwareInterface;
use Joomla\Database\DatabaseAwareTrait;
use Joomla\Database\ParameterType;

\defined('_JEXEC') or die;

/** Alert management uses the original table and IDs; no delete operation. */
final class AlertsModel extends BaseModel implements DatabaseAwareInterface, CurrentUserInterface, UserFactoryAwareInterface, FormFactoryAwareInterface
{
    use DatabaseAwareTrait;
    use UserFactoryAwareTrait;
    use FormFactoryAwareTrait;

    private ?User $currentUser = null;

    public function setCurrentUser(User $currentUser): void
    {
        $this->currentUser = $currentUser;
    }

    public function requireAdministrator(): void
    {
        $user = $this->currentUser;
        if ($user === null || $user->guest || $user->block
            || !$user->authorise('altacourses.manage', 'com_altacourses')) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }
        $fresh = $this->getUserFactory()->loadUserById((int) $user->id);
        if ($fresh->guest || $fresh->block || !$fresh->authorise('altacourses.manage', 'com_altacourses')) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }
    }

    public function getItems(): array
    {
        $this->requireAdministrator();
        $db = $this->getDatabase();
        return $db->setQuery($db->createQuery()->select(['id', 'name', 'alert', 'state'])
            ->from($db->quoteName('#__altacourses_alerts'))->order($db->quoteName('name') . ', ' . $db->quoteName('id')))->loadObjectList();
    }

    public function getRecord(int $id): ?object
    {
        $this->requireAdministrator();
        if ($id === 0) {
            return null;
        }
        $db = $this->getDatabase();
        $query = $db->createQuery()->select('*')->from($db->quoteName('#__altacourses_alerts'))
            ->where($db->quoteName('id') . ' = :id')->bind(':id', $id, ParameterType::INTEGER);
        $record = $db->setQuery($query)->loadObject();
        if ($record === null) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_ALERT_NOT_FOUND'), 404);
        }
        $this->requireUnlocked($record);
        return $record;
    }

    /** A fingerprint avoids adding a migration-only revision column to the legacy table. */
    public function formData(?object $record): array
    {
        return [
            'id' => (string) ($record->id ?? 0),
            'name' => (string) ($record->name ?? ''),
            'alert' => (string) ($record->alert ?? ''),
            'state' => $record === null ? '1' : (string) $record->state,
            'version' => $record === null ? '' : hash('sha256', json_encode($record, JSON_THROW_ON_ERROR)),
        ];
    }

    public function getForm(array $data): Form
    {
        $this->requireAdministrator();
        $form = $this->getFormFactory()->createForm('com_altacourses.alert', ['control' => 'jform']);
        if (!$form->loadFile(dirname(__DIR__, 2) . '/forms/alert.xml')) {
            throw new \RuntimeException('Alert form could not be loaded');
        }
        $form->bind($data);
        return $form;
    }

    public function saveAlert(int $id, string $version, array $input): int
    {
        $this->requireAdministrator();
        $name = $input['name'] ?? null;
        $state = $input['state'] ?? null;
        $alert = $input['alert'] ?? null;
        if (array_diff(array_keys($input), ['name', 'alert', 'state']) || !is_string($name) || !is_string($alert) || !is_string($state)
            || !in_array($state, ['0', '1'], true)) {
            throw new CourseValidationException([Text::_('COM_ALTACOURSES_ALERT_INVALID')]);
        }
        $name = trim($name);
        if (!mb_check_encoding($name, 'UTF-8') || $name === '' || mb_strlen($name) > 255 || preg_match('/[\x00-\x1F\x7F]/u', $name)) {
            throw new CourseValidationException([Text::_('COM_ALTACOURSES_ALERT_INVALID')]);
        }
        if (!mb_check_encoding($alert, 'UTF-8') || strlen($alert) > 65535 || preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', $alert)) {
            throw new CourseValidationException([Text::_('COM_ALTACOURSES_ALERT_INVALID')]);
        }
        $form = $this->getForm([]);
        if (!$form->validate(['id' => $id, 'name' => $name, 'alert' => $alert, 'state' => $state])) {
            throw new CourseValidationException([Text::_('COM_ALTACOURSES_ALERT_INVALID')]);
        }
        $db = $this->getDatabase();
        if ($id === 0) {
            if ($version !== '') {
                throw new \RuntimeException(Text::_('COM_ALTACOURSES_ALERT_CONFLICT'), 409);
            }
            $row = (object) ['name' => $name, 'alert' => $alert, 'state' => (int) $state, 'ordering' => 0, 'checked_out' => 0,
                'checked_out_time' => gmdate('Y-m-d H:i:s'), 'created_by' => (int) $this->currentUser->id];
            $db->insertObject('#__altacourses_alerts', $row, 'id');
            return (int) $row->id;
        }
        $record = $this->getRecord($id);
        if (!hash_equals($this->formData($record)['version'], $version)) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_ALERT_CONFLICT'), 409);
        }
        $published = (int) $state;
        $query = $db->createQuery()->update($db->quoteName('#__altacourses_alerts'))
            ->set($db->quoteName('name') . ' = :name')->bind(':name', $name)
            ->set($db->quoteName('alert') . ' = :alert')->bind(':alert', $alert)
            ->set($db->quoteName('state') . ' = :state')->bind(':state', $published, ParameterType::INTEGER);

        // Legacy imports can use MyISAM: FOR UPDATE/transactions do not protect them.
        // Compare every original field atomically, with byte-exact text comparisons.
        $original = [];
        foreach (get_object_vars($record) as $column => $value) {
            $field = $db->quoteName($column);
            if ($value === null) {
                $query->where($field . ' IS NULL');
            } else {
                $key = ':original' . count($original);
                $original[$key] = (string) $value;
                $query->where('CAST(' . $field . ' AS BINARY) = CAST(' . $key . ' AS BINARY)')
                    ->bind($key, $original[$key]);
            }
        }
        $db->setQuery($query)->execute();
        if ($db->getAffectedRows() === 0) {
            $current = $this->getRecord($id);
            if (!hash_equals($this->formData($current)['version'], $version)
                || (string) $current->name !== $name || (string) $current->alert !== $alert
                || (int) $current->state !== $published) {
                throw new \RuntimeException(Text::_('COM_ALTACOURSES_ALERT_CONFLICT'), 409);
            }
        }
        return $id;
    }

    private function requireUnlocked(object $record): void
    {
        if ((int) $record->checked_out !== 0 && (int) $record->checked_out !== (int) $this->currentUser->id) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_AVAILABILITY_LOCKED'), 409);
        }
    }
}
