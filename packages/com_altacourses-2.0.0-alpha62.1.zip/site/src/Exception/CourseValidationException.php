<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Exception;

\defined('_JEXEC') or die;

final class CourseValidationException extends \RuntimeException
{
    public function __construct(public readonly array $messages)
    {
        parent::__construct('Course validation failed', 400);
    }
}
