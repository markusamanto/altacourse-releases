<?php

/** @package Altacourses.Task @license GNU General Public License version 2 or later */
namespace Advenire\Plugin\Task\Altacoursesmonthly\Extension;

use Advenire\Component\Altacourses\Administrator\Service\MonthlyReport;
use Advenire\Component\Altacourses\Administrator\Service\SupplierReminders;
use Advenire\Plugin\Task\Altacoursesmonthly\Task\ReminderOption;
use Advenire\Plugin\Task\Altacoursesmonthly\Task\MonthlyOption;
use Joomla\CMS\Language\Language;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\Component\Scheduler\Administrator\Event\ExecuteTaskEvent;
use Joomla\Component\Scheduler\Administrator\Task\Status;
use Joomla\Event\EventInterface;
use Joomla\Event\SubscriberInterface;

\defined('_JEXEC') or die;

final class Altacoursesmonthly extends CMSPlugin implements SubscriberInterface
{
    public function __construct(array $config, private readonly ?MonthlyReport $reports, private readonly Language $language, private readonly ?SupplierReminders $reminders = null, private readonly ?\Advenire\Component\Altacourses\Administrator\Service\EvaluationInvitations $invitations=null)
    {
        parent::__construct($config);
    }

    public static function getSubscribedEvents(): array
    {
        return ['onTaskOptionsList' => 'advertise', 'onExecuteTask' => 'executeMonthly'];
    }

    public function advertise(EventInterface $event): void
    {
        $event->getArgument('subject')->options[] = new MonthlyOption($this->language);
        if($this->invitations!==null){$event->getArgument('subject')->options[]=new \Advenire\Plugin\Task\Altacoursesmonthly\Task\EvaluationOption($this->language);}
        if($this->reminders!==null){$event->getArgument('subject')->options[]=new ReminderOption($this->language);}
    }

    public function executeMonthly(ExecuteTaskEvent $event): void
    {
        if (!in_array($event->getRoutineId(),['altacourses.monthly','altacourses.supplierreminders','altacourses.evaluationinvitations'],true)) { return; }
        $start = microtime(true);
        try {
            if($event->getRoutineId()==='altacourses.monthly'){$status=$this->reports?->runDue()==='complete'?Status::OK:Status::NO_RUN;}
            else{$result=$event->getRoutineId()==='altacourses.evaluationinvitations'?$this->invitations?->runDue():$this->reminders?->runDue();$status=match($result){'complete','not_due'=>Status::OK,'review'=>Status::KNOCKOUT,default=>Status::NO_RUN};}
        } catch (\Throwable) { $status = $event->getRoutineId()==='altacourses.monthly'?Status::NO_RUN:Status::KNOCKOUT; }
        $end = microtime(true);
        $event->setResult(['startTime' => $start, 'endTime' => $end, 'duration' => $end - $start, 'status' => $status,
            'plugin' => 'altacoursesmonthly', 'logCategory' => $event->getArgument('subject')->logCategory]);
    }
}
