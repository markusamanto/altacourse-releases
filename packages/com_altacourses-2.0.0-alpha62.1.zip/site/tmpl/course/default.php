<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
\defined('_JEXEC') or die;
$signup=Route::_('index.php?option=com_altacourses&view=signup&coid='.(int)$this->item->id,false);
?>
<article class="altacourses-details" aria-labelledby="altacourses-course-heading" data-course-id="<?php echo (int)$this->item->id; ?>">
 <h1 id="altacourses-course-heading"><?php echo $this->escape($this->heading); ?></h1>
 <p><strong><?php echo $this->escape(Text::_('COM_ALTACOURSES_TOTAL_PRICE')); ?></strong><br><span data-total-price><?php echo $this->escape($this->totalPrice); ?></span></p>
 <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_COURSE_PRICE_DESCRIPTION')); ?></p>
 <?php if ($this->canSignup) : ?><p><a class="btn btn-primary" data-signup-link href="<?php echo $this->escape($signup); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_COURSE_SIGNUP_DIRECT')); ?></a></p><?php endif; ?>
 <dl>
  <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_COURSE_TYPE')); ?></dt><dd><?php echo $this->escape($this->item->course_type??''); ?></dd>
  <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_DATES')); ?></dt><dd>
   <?php foreach ($this->sessions as $index=>$part) : ?><div data-session="<?php echo $index+1; ?>">
    <?php if (count($this->sessions)>1) : ?><strong><?php echo $this->escape(Text::sprintf('COM_ALTACOURSES_SESSION_NUMBER',$index+1)); ?>:</strong><?php endif; ?>
    <time datetime="<?php echo $this->escape(substr($part['start_date']??'',0,10)); ?>"><?php echo $this->escape(substr($part['start_date']??'',0,10)); ?></time>
    <?php if ($part['stop_date']&&substr($part['stop_date'],0,10)!==substr($part['start_date']??'',0,10)) : ?> – <time datetime="<?php echo $this->escape(substr($part['stop_date'],0,10)); ?>"><?php echo $this->escape(substr($part['stop_date'],0,10)); ?></time><?php endif; ?>
   </div><?php endforeach; ?>
  </dd>
  <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_PLACE')); ?></dt><dd><?php $href=$this->articleHref($this->item->place_article); ?><?php if($href!==null) : ?><a data-course-article="place" href="<?php echo $this->escape($href); ?>"><?php echo $this->escape($this->item->course_place); ?></a><?php else : ?><?php echo $this->escape($this->item->course_place?:Text::_('COM_ALTACOURSES_UNSPECIFIED')); ?><?php endif; ?></dd>
  <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_REGION')); ?></dt><dd><?php echo $this->escape($this->item->region?:Text::_('COM_ALTACOURSES_UNSPECIFIED')); ?></dd>
  <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_LEADERS')); ?></dt><dd><?php foreach(['leader1','leader2'] as $f) : if(trim((string)($this->item->$f??''))===''){continue;}$href=$this->articleHref($this->item->{$f.'_article'}); ?><div><?php if($href!==null) : ?><a data-course-article="<?php echo $f; ?>" href="<?php echo $this->escape($href); ?>"><?php echo $this->escape($this->item->$f); ?></a><?php else : ?><?php echo $this->escape($this->item->$f); ?><?php endif; ?></div><?php endforeach; ?></dd>
  <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_AVAILABILITY')); ?></dt><dd data-course-seats><?php echo $this->escape($this->item->seats_label??Text::_('COM_ALTACOURSES_UNSPECIFIED')); ?></dd>
 </dl>
 <h2><?php echo $this->escape(Text::_('COM_ALTACOURSES_COURSE_OTHER')); ?></h2>
 <?php if(trim((string)$this->item->course_notes)!=='') : ?><p class="altacourses-course-notes" data-course-notes><?php echo $this->escape($this->item->course_notes); ?></p><?php endif; ?>
 <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_COURSE_VAT')); ?></p>
 <?php if($this->canSignup) : ?><p><a class="btn btn-primary" data-signup-link href="<?php echo $this->escape($signup); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_COURSE_SIGNUP_DIRECT')); ?></a></p><?php endif; ?>
 <?php if($this->canEnquire) : ?>
  <h2><?php echo $this->escape(Text::_('COM_ALTACOURSES_COURSE_MORE_INFO')); ?></h2>
  <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_COURSE_MORE_INFO_DESC')); ?></p>
  <p><a data-enquiry-link href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=enquiry&coid='.(int)$this->item->id,false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_COURSE_MORE_INFO_LINK')); ?></a></p>
 <?php endif; ?>
 <p><a data-back-courses class="btn btn-secondary btn-sm" href="<?php echo $this->escape(Route::_('index.php?'.http_build_query(['option'=>'com_altacourses','view'=>'courses']+$this->filters),false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_BACK_TO_COURSES')); ?></a></p>
</article>
