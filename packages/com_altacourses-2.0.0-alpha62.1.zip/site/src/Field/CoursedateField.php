<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Field;

use Joomla\CMS\Form\FormField;

\defined('_JEXEC') or die;

/** Browser calendar input; keeps the submitted value instead of normalising invalid dates. */
final class CoursedateField extends FormField
{
    protected $type = 'Coursedate';

    protected function getInput(): string
    {
        $escape = static fn ($value): string => htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        return '<input type="date" class="form-control" min="1000-01-01" max="9999-12-31" id="' . $escape($this->id)
            . '" name="' . $escape($this->name) . '" value="' . $escape($this->value) . '"'
            . ($this->required ? ' required aria-required="true"' : '') . '>';
    }
}
