<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;
?>
<section aria-labelledby="participation-title">
    <h1 id="participation-title"><?php echo $this->escape(Text::_('COM_ALTACOURSES_PARTICIPATION_TITLE')); ?></h1>
    <p><a href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=participations', false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_PARTICIPATION_BACK')); ?></a></p>
    <h2><?php echo $this->escape(($this->occasion->course_type ?? '') . ' – ' . ($this->occasion->course_place ?? '')); ?></h2>
    <?php foreach ($this->occasion->sessions as $part) : ?><div><?php echo $this->escape(substr($part->start_date ?? '', 0, 10) . ' – ' . substr($part->stop_date ?? '', 0, 10)); ?></div><?php endforeach; ?>
    <p><?php echo $this->escape(implode(', ', array_filter([$this->occasion->leader1, $this->occasion->leader2]))); ?></p>
    <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_PARTICIPATION_BATCH_INTRO')); ?></p>
    <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_REBOOK_HELP')); ?></p>
    <form id="participation-course-form" method="post" action="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&task=participation.savecourse', false)); ?>">
        <input type="hidden" name="jform[course_id]" value="<?php echo (int) $this->occasion->id; ?>" />
        <input type="hidden" name="jform[course_version]" value="<?php echo (int) $this->rows[0]->course_version; ?>" />
        <div class="table-responsive"><table class="table"><thead><tr>
            <?php foreach (['ENQUIRY_NAME', 'PARTICIPATION_STATUS', 'PARTICIPATION_NOTE', 'REBOOK_TO'] as $label) : ?><th scope="col"><?php echo $this->escape(Text::_('COM_ALTACOURSES_' . $label)); ?></th><?php endforeach; ?>
        </tr></thead><tbody>
        <?php foreach ($this->rows as $row) : ?>
            <?php $person = json_decode($row->contact_json, true, 512, JSON_THROW_ON_ERROR); $form = $this->forms[(int) $row->id]; ?>
            <tr data-participation-request="<?php echo (int) $row->id; ?>">
                <th scope="row"><?php echo $this->escape(($person['firstname'] ?? '') . ' ' . ($person['lastname'] ?? '')); ?><br />
                    <small><?php echo $this->escape($person['company'] ?? ''); ?><br /><?php echo $this->escape(Text::_((int) $row->asked_for_info === 1 ? 'COM_ALTACOURSES_ENQUIRY_TITLE' : 'COM_ALTACOURSES_SIGNUP_TITLE')); ?></small>
                </th>
                <td><?php echo $form->renderField('version'), $form->renderField('status'); ?></td>
                <td><?php echo $form->renderField('note'); ?></td>
                <td><?php echo $form->renderField('rebook'); ?></td>
            </tr>
        <?php endforeach; ?></tbody></table></div>
        <button class="btn btn-primary" type="submit"><?php echo $this->escape(Text::_('JSAVE')); ?></button>
        <?php echo HTMLHelper::_('form.token'); ?>
    </form>
</section>
