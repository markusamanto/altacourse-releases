<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Model;

use Joomla\CMS\Language\Text;
use Joomla\CMS\User\User;
use Joomla\Database\ParameterType;
use Joomla\Database\QueryInterface;

\defined('_JEXEC') or die;

/** One ownership predicate for lists, totals, choices and selected/history reads. */
trait ContactScopeTrait
{
    public function requireContactAccess(): void
    {
        $this->contactActor();
    }

    public function isContactAdministrator(): bool
    {
        return $this->contactActor()->authorise('altacourses.manage', 'com_altacourses');
    }

    protected function scopeContacts(QueryInterface $query): void
    {
        $actor = $this->contactActor();
        if (!$actor->authorise('altacourses.manage', 'com_altacourses')) {
            $id = (int) $actor->id;
            $query->where('s.supplier_user_id=:contact_supplier')->bind(':contact_supplier', $id, ParameterType::INTEGER);
        }
    }

    private function contactActor(): User
    {
        $actor = $this->getActor();
        if (!$actor->authorise('altacourses.manage', 'com_altacourses') && !$actor->authorise('altacourses.supplier', 'com_altacourses')) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }
        return $actor;
    }
}
