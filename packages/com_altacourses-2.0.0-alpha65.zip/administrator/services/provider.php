<?php

/**
 * @package     Altacourses.Administrator
 * @license     GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

use Joomla\CMS\Dispatcher\ComponentDispatcherFactoryInterface;
use Advenire\Component\Altacourses\Administrator\Extension\AltacoursesComponent;
use Joomla\CMS\Component\Router\RouterFactoryInterface;
use Joomla\CMS\Extension\ComponentInterface;
use Joomla\CMS\Extension\Service\Provider\ComponentDispatcherFactory;
use Joomla\CMS\Extension\Service\Provider\MVCFactory;
use Joomla\CMS\Extension\Service\Provider\RouterFactory;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\Database\DatabaseInterface;
use Advenire\Component\Altacourses\Administrator\Factory\MVCFactory as ScheduleMVCFactory;
use Advenire\Component\Altacourses\Administrator\Service\CourseSchedule;
use Advenire\Component\Altacourses\Administrator\Service\CoursePrice;
use Joomla\CMS\Mail\MailerFactoryInterface;
use Joomla\CMS\Language\LanguageFactoryInterface;
use Advenire\Component\Altacourses\Administrator\Service\NotificationService;
use Advenire\Component\Altacourses\Administrator\Service\CommissionReport;
use Advenire\Component\Altacourses\Administrator\Service\MonthlyReport;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;

return new class () implements ServiceProviderInterface {
    public function register(Container $container): void
    {
        $container->registerServiceProvider(require __DIR__ . '/business.php');
        $container->registerServiceProvider(new class ('\\Advenire\\Component\\Altacourses') extends MVCFactory {
            protected function createMVCFactory(): MVCFactoryInterface
            {
                return new ScheduleMVCFactory($this->getNamespace());
            }

            protected function injectServicesIntoFactory(MVCFactoryInterface $factory, Container $container): void
            {
                parent::injectServicesIntoFactory($factory, $container);
                $factory->setSupplierReminders($container->get(\Advenire\Component\Altacourses\Administrator\Service\SupplierReminders::class));
                $factory->setEvaluationInvitations($container->get(\Advenire\Component\Altacourses\Administrator\Service\EvaluationInvitations::class));
                $factory->setMailchimpEnrollments($container->get(\Advenire\Component\Altacourses\Administrator\Service\MailchimpEnrollments::class));
                $factory->setRecaptcha($container->get(\Advenire\Component\Altacourses\Administrator\Service\Recaptcha::class));
                $factory->setZenlerNewsletter($container->get(\Advenire\Component\Altacourses\Administrator\Service\ZenlerNewsletter::class));
                $factory->setReceiptSecret((string) $container->get('config')->get('secret', ''));
                $factory->setReportingTimezone((string) $container->get('config')->get('offset', 'UTC'));
                $factory->setCourseSchedule($container->get(CourseSchedule::class));
                $factory->setCoursePrice($container->get(CoursePrice::class));
                $factory->setMonthlyReport($container->get(MonthlyReport::class));
                $factory->setCommissionReport($container->get(CommissionReport::class));
                $factory->setNotifications($container->get(NotificationService::class));
            }
        });
        $container->registerServiceProvider(new ComponentDispatcherFactory('\\Advenire\\Component\\Altacourses'));
        $container->registerServiceProvider(new RouterFactory('\\Advenire\\Component\\Altacourses'));

        $container->set(
            ComponentInterface::class,
            static function (Container $container): AltacoursesComponent {
                $component = new AltacoursesComponent($container->get(ComponentDispatcherFactoryInterface::class));
                $component->setMVCFactory($container->get(MVCFactoryInterface::class));
                $component->setRouterFactory($container->get(RouterFactoryInterface::class));

                return $component;
            }
        );
    }
};
