<?php
/** @package Altacourses.Administrator @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Administrator\Service;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
\defined('_JEXEC') or die;

/** Presentation only. CoursePrice remains the sole interpreter of monetary amounts. */
final class PriceDisplay
{
    /** Display suffix only; stored monetary values and ISO currency remain unchanged. */
    public static function currency(): string
    {
        $label = ComponentHelper::getParams('com_altacourses')->get('currency_label', 'kr');
        return is_string($label) && trim($label) !== '' ? trim($label) : 'kr';
    }
    public static function mode(): string
    {
        return ComponentHelper::getParams('com_altacourses')->get('price_display_mode', 'T') === 'V' ? 'V' : 'T';
    }
    public static function residential(mixed $value): int
    {
        return (string) $value === '2' ? 2 : 1;
    }
    private static function loadLanguage(): void
    {
        Factory::getApplication()->getLanguage()->load('com_altacourses', JPATH_SITE . '/components/com_altacourses');
    }
    public static function label(string $fallback): string
    {
        self::loadLanguage();
        return Text::_(self::mode() === 'V' ? 'COM_ALTACOURSES_VARIABLE_PRICE' : $fallback);
    }
    public static function descriptionKey(mixed $residential): string
    {
        return 'COM_ALTACOURSES_PRICE_DESCRIPTION_' . self::residential($residential);
    }
    public static function description(mixed $residential, string $fallback): string
    {
        self::loadLanguage();
        return Text::_(self::mode() === 'V' ? self::descriptionKey($residential) : $fallback);
    }
    public static function tooltipAssets(): void
    {
        if (self::mode() !== 'V') { return; }
        $wa = Factory::getApplication()->getDocument()->getWebAssetManager();
        $wa->getRegistry()->addRegistryFile('media/com_altacourses/joomla.asset.json');
        $wa->useStyle('com_altacourses.price-tooltips')->useScript('com_altacourses.price-tooltips');
    }
    /** Trusted markup; all editable text is escaped and markers are fixed integers. */
    public static function marker(mixed $residential): string
    {
        if (self::mode() !== 'V') { return ''; }
        self::loadLanguage();
        self::tooltipAssets();
        $number = self::residential($residential);
        $id = 'altacourses-price-' . bin2hex(random_bytes(12));
        $escape = static fn(string $s): string => htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        return '<sup class="altacourses-price-marker"><button type="button" class="altacourses-price-trigger" data-price-tooltip aria-label="'
            . $escape(Text::sprintf('COM_ALTACOURSES_PRICE_EXPLANATION', $number)) . '" aria-describedby="' . $id . '">'
            . $number . '</button><span id="' . $id . '" class="altacourses-price-tooltip" role="tooltip" hidden>'
            . $escape(Text::_(self::descriptionKey($number))) . '</span></sup>';
    }
    /** Separate, stable styling hooks; shared inclusion strings also supply each tooltip. */
    public static function paragraphs(string $prefix, string $notice): string
    {
        self::loadLanguage();
        self::tooltipAssets();
        $escape = static fn(string $s): string => htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $html = '<p class="' . $escape($prefix . '-notice') . '">' . $escape(Text::_($notice)) . '</p>';
        if (self::mode() === 'T') {
            return $html . '<p class="' . $escape($prefix . '-total') . '">' . $escape(Text::_('COM_ALTACOURSES_COURSE_PRICE_DESCRIPTION')) . '</p>';
        }
        foreach ([1 => 'internat', 2 => 'externat'] as $number => $format) {
            $html .= '<p class="' . $escape($prefix . '-' . $format) . '"><sup>' . $number . '</sup> '
                . $escape(Text::_(self::descriptionKey($number))) . '</p>';
        }
        return $html;
    }

    public static function intro(string $fallback, string $suffix): string
    {
        self::loadLanguage();
        $escape = static fn(string $text): string => htmlspecialchars($text, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        if (self::mode() !== 'V') { return $escape(Text::_($fallback)); }
        return '<sup>1</sup> ' . $escape(Text::_(self::descriptionKey(1))) . '<br><sup>2</sup> '
            . $escape(Text::_(self::descriptionKey(2))) . ' ' . $escape(Text::_($suffix));
    }
}
