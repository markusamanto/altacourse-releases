<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Controller;

use Advenire\Component\Altacourses\Site\Exception\CourseValidationException;
use Advenire\Component\Altacourses\Site\Model\NewcourseModel;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;

final class NewcourseController extends BaseController
{
    public function execute($task)
    {
        if (strtolower((string) $task) !== 'save') {
            throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'), 404);
        }
        return parent::execute($task);
    }

    public function save(): void
    {
        $model = $this->getModel('Newcourse', 'Site', ['ignore_request' => true]);
        $model->isAdministrator(); // Also validates supplier/guest authority.
        if ($this->input->getMethod() !== 'POST') {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_SAMPLE_POST_REQUIRED'), 405);
        }
        if (!$this->checkToken('post', false)) {
            throw new \RuntimeException(Text::_('JINVALID_TOKEN'), 403);
        }
        $userId = (int) $this->app->getIdentity()->id;
        $key = 'com_altacourses.newcourse.' . $userId;
        $raw = $this->input->post->get('jform', [], 'array');
        // Keep only bounded scalar known fields in the private per-user draft.
        $draft = [];
        foreach (NewcourseModel::FIELDS as $name) {
            if (isset($raw[$name]) && is_scalar($raw[$name])) {
                $draft[$name] = mb_substr((string) $raw[$name], 0, $name === 'course_notes' ? 10000 : 255);
            }
        }
        $this->app->setUserState($key . '.draft', $draft);
        $token = $raw['submission'] ?? '';
        $tickets = $this->app->getUserState($key . '.tickets', []);
        if (!is_string($token) || !isset($tickets[$token]) || $tickets[$token] < time() - 14400) {
            $this->setMessage(Text::_('COM_ALTACOURSES_NEW_EXPIRED'), 'warning');
            $this->setRedirect(Route::_('index.php?option=com_altacourses&view=newcourse', false));
            return;
        }
        try {
            $id = $model->createCourse($raw, $token);
        } catch (CourseValidationException $exception) {
            foreach ($exception->messages as $message) {
                $this->app->enqueueMessage($message, 'warning');
            }
            $this->setRedirect(Route::_('index.php?option=com_altacourses&view=newcourse', false));
            return;
        } catch (\Throwable $exception) {
            if (($exception->getCode() === 403 && $exception->getMessage() === Text::_('JERROR_ALERTNOAUTHOR'))
                || ($exception->getCode() === 409 && $exception->getMessage() === Text::_('COM_ALTACOURSES_NEW_EXPIRED'))) {
                throw $exception;
            }
            $this->app->getLogger()->error('Altacourses course creation failed', ['exception' => $exception]);
            $this->setMessage(Text::_('COM_ALTACOURSES_NEW_FAILED'), 'warning');
            $this->setRedirect(Route::_('index.php?option=com_altacourses&view=newcourse', false));
            return;
        }
        $this->app->setUserState($key . '.draft', null);
        $this->setMessage(Text::_($model->getState('creation.reused', false) ? 'COM_ALTACOURSES_NEW_ALREADY_SAVED' : 'COM_ALTACOURSES_NEW_SAVED'));
        $this->setRedirect(Route::_('index.php?option=com_altacourses&view=managecourses&id=' . $id, false));
    }
}
