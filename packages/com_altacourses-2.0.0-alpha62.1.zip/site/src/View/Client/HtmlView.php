<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\View\Client;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;

\defined('_JEXEC') or die;

final class HtmlView extends BaseHtmlView
{
    public int $clientId = 0;
    public array $contact = [];
    public array $history = [];
    public bool $administrator = false;
    public ?\Joomla\CMS\Form\Form $accountForm = null;
    public int $returnStart = 0;
    public array $returnFilters = [];

    public function display($tpl = null): void
    {
        $record = $this->getModel()->getRecord((int) $this->getModel()->getState('client.id'));
        $this->clientId = $record['client_id'];
        $this->contact = $record['contact'];
        $this->history = $record['history'];
        $this->administrator = $record['administrator'];
        if ($this->administrator) { $this->accountForm = $this->getModel('Accounts')->getClientForm($this->clientId); }
        $this->getDocument()->setTitle(Text::_('COM_ALTACOURSES_CLIENT_TITLE'));
        $this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.site');
        parent::display($tpl);
    }
}
