<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Controller;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;

final class AvailabilityController extends BaseController
{
    public function execute($task)
    {
        if (strtolower((string) $task) !== 'save') {
            throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'), 404);
        }

        return parent::execute($task);
    }

    public function save(): void
    {
        $user = $this->app->getIdentity();
        if ($user->guest || (!$user->authorise('altacourses.manage', 'com_altacourses')
            && !$user->authorise('altacourses.supplier', 'com_altacourses'))) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }
        if ($this->input->getMethod() !== 'POST') {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_AVAILABILITY_POST_REQUIRED'), 405);
        }
        if (!$this->checkToken('post', false)) {
            throw new \RuntimeException(Text::_('JINVALID_TOKEN'), 403);
        }
        $data = $this->input->post->get('jform', [], 'array');
        if (count($data) !== 3 || array_diff(array_keys($data), ['id', 'availability', 'version'])) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_AVAILABILITY'), 400);
        }
        foreach ($data as $key => $value) {
            if (!is_scalar($value) || !ctype_digit((string) $value) || (float) $value > 2147483647) {
                throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_AVAILABILITY'), 400);
            }
            $data[$key] = (int) $value;
        }

        $model = $this->getModel('Availability', 'Site', ['ignore_request' => true]);
        try {
            $form = $model->getForm();
            if (!$form->validate($data)) {
                throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_AVAILABILITY'), 400);
            }
            $model->saveAvailability($data['id'], $data['availability'], $data['version']);
        } catch (\RuntimeException $exception) {
            if (in_array($exception->getCode(), [400, 403, 404, 409], true)) {
                throw $exception;
            }
            $this->app->getLogger()->error('Altacourses availability update failed', ['exception' => $exception]);
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_AVAILABILITY_FAILED'), 500);
        }
        $this->setMessage(Text::_('COM_ALTACOURSES_AVAILABILITY_SAVED'));
        // Return only to our fixed management route, never to a submitted URL.
        $this->setRedirect(Route::_('index.php?option=com_altacourses&view=managecourses&id=' . $data['id'], false));
    }
}
