<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;
?>
<section aria-labelledby="participations-title">
    <h1 id="participations-title"><?php echo $this->escape(Text::_('COM_ALTACOURSES_PARTICIPATION_TITLE')); ?></h1>
    <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_PARTICIPATION_COURSES_INTRO')); ?></p>
    <p><a href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=dashboard', false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_BACK_TO_DASHBOARD')); ?></a></p>
    <?php if (!$this->items) : ?><p><?php echo $this->escape(Text::_('COM_ALTACOURSES_PARTICIPATION_EMPTY')); ?></p><?php else : ?>
    <div class="table-responsive"><table class="table table-striped"><thead><tr>
        <?php foreach (['COURSE_TYPE', 'PLACE', 'DATES', 'PARTICIPATION_REVIEW'] as $label) : ?><th scope="col"><?php echo $this->escape(Text::_('COM_ALTACOURSES_' . $label)); ?></th><?php endforeach; ?>
    </tr></thead><tbody>
    <?php foreach ($this->items as $item) : ?>
        <tr data-participation-course="<?php echo (int) $item->id; ?>">
            <td><?php echo $this->escape($item->course_type ?? ''); ?></td><td><?php echo $this->escape($item->course_place ?? ''); ?></td>
            <td><?php foreach ($item->sessions as $part) : ?><div><?php echo $this->escape(substr($part->start_date ?? '', 0, 10) . ' – ' . substr($part->stop_date ?? '', 0, 10)); ?></div><?php endforeach; ?></td>
            <td><a class="btn btn-primary" href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=participation&course_id=' . (int) $item->id, false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_PARTICIPATION_REVIEW')); ?></a></td>
        </tr>
    <?php endforeach; ?></tbody></table></div>
    <?php echo $this->pagination->getPagesLinks(); ?>
    <?php endif; ?>
</section>
