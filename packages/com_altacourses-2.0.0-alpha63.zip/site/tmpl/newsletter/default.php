<?php
\defined('_JEXEC') or die;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
?>
<h1 id="altacourses-newsletter-heading"><?php echo Text::_('COM_ALTACOURSES_NL_TITLE'); ?></h1>
<p><?php echo Text::_('COM_ALTACOURSES_NL_INTRO'); ?></p>
<p><?php echo Text::_('COM_ALTACOURSES_NL_MODE'); ?>: <strong><?php echo Text::_('COM_ALTACOURSES_NL_MODE_'.strtoupper($this->settings['mode'])); ?></strong></p>
<?php if(!$this->settings['configured']||($this->settings['mode']==='live'&&!$this->settings['key_configured'])): ?><p class="alert alert-warning"><?php echo Text::_('COM_ALTACOURSES_NL_CONFIGURE'); ?></p><?php endif; ?>
<p><?php echo Text::_('COM_ALTACOURSES_NL_HISTORY_HELP'); ?></p>
<?php if(!$this->history): ?><p><?php echo Text::_('COM_ALTACOURSES_NL_EMPTY'); ?></p><?php else: ?>
<div class="table-responsive"><table class="table"><thead><tr><?php foreach(['UPDATED','NAME','EMAIL','TARGET','STATUS','ERROR','ACTIONS'] as $key): ?><th><?php echo Text::_('COM_ALTACOURSES_NL_'.$key); ?></th><?php endforeach; ?></tr></thead><tbody>
<?php foreach($this->history as $row): ?><?php $c=json_decode($row->contact_json,true)??[]; ?><tr data-newsletter-id="<?php echo (int)$row->id; ?>"><td><?php echo $this->escape($row->updated_at); ?></td><td><?php echo $this->escape(trim(($c['firstname']??'').' '.($c['lastname']??''))); ?> (#<?php echo (int)$row->client_id; ?>)</td><td><?php echo $this->escape($c['email']??''); ?></td><td><?php echo $this->escape($row->account_name).' / '.(int)$row->funnel_id; ?></td><td><?php echo Text::_('COM_ALTACOURSES_NL_STATE_'.strtoupper($row->state)); ?></td><td><?php echo $this->escape($row->last_error??''); ?></td><td><?php if(in_array($row->state,['error','uncertain'],true)): ?><form method="post" action="<?php echo Route::_('index.php?option=com_altacourses&task=newsletter.retry'); ?>"><input type="hidden" name="jform[id]" value="<?php echo (int)$row->id; ?>"><input type="hidden" name="jform[revision]" value="<?php echo (int)$row->revision; ?>"><label><input type="checkbox" name="jform[review]" value="1" required> <?php echo Text::_('COM_ALTACOURSES_NL_REVIEW'); ?></label><?php echo HTMLHelper::_('form.token'); ?><button type="submit" class="btn btn-warning"><?php echo Text::_('COM_ALTACOURSES_NL_RETRY'); ?></button><button type="submit" class="btn btn-secondary" formaction="<?php echo Route::_('index.php?option=com_altacourses&task=newsletter.confirm'); ?>"><?php echo Text::_('COM_ALTACOURSES_NL_CONFIRM'); ?></button></form><?php endif; ?></td></tr><?php endforeach; ?>
</tbody></table></div><?php endif; ?>
