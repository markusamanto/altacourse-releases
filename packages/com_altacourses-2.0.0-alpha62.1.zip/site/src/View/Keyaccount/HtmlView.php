<?php
namespace Advenire\Component\Altacourses\Site\View\Keyaccount;
use Joomla\CMS\Language\Text;
\defined('_JEXEC') or die;
final class HtmlView extends \Joomla\CMS\MVC\View\HtmlView
{
 public object $record;
 public array $data=[];
 public bool $legacy=false;
 public int $recordId=0;
 public function display($tpl=null):void
 {
  $this->getModel()->requireAdministrator();$this->getDocument()->setTitle(Text::_('COM_ALTACOURSES_BILLING_EDIT'));
  $this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.site')->useScript('com_altacourses.billing');parent::display($tpl);
 }
}
