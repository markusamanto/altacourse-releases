<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Controller;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;

final class FixturesController extends BaseController
{
    public function execute($task)
    {
        if (!in_array(strtolower((string) $task), ['load', 'sessions'], true)) {
            throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'), 404);
        }

        return parent::execute($task);
    }

    public function sessions(): void
    {
        $this->loadFixture(true);
    }

    public function load(): void
    {
        $this->loadFixture(false);
    }

    private function loadFixture(bool $sessions): void
    {
        if (!$this->app->getIdentity()->authorise('altacourses.manage', 'com_altacourses')
            || !$this->app->getParams('com_altacourses')->get('allow_test_data', false)) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }
        if ($this->input->getMethod() !== 'POST') {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_SAMPLE_POST_REQUIRED'), 405);
        }
        if (!$this->checkToken('post', false)) {
            throw new \RuntimeException(Text::_('JINVALID_TOKEN'), 403);
        }
        $model = $this->getModel('Fixtures', 'Site', ['ignore_request' => true]);
        try {
            if ($sessions) {
                $model->loadSampleSessions();
            } else {
                $model->loadSampleCourses((int) $this->app->getIdentity()->id);
            }
            $this->setMessage(Text::_($sessions ? 'COM_ALTACOURSES_SESSION_SAMPLE_LOADED' : 'COM_ALTACOURSES_SAMPLE_LOADED'));
        } catch (\RuntimeException $exception) {
            $message = Text::_($sessions ? 'COM_ALTACOURSES_SESSION_SAMPLE_REFUSED' : 'COM_ALTACOURSES_SAMPLE_NOT_EMPTY');
            if ($exception->getMessage() !== $message) {
                $this->app->getLogger()->error('Altacourses sample load failed', ['exception' => $exception]);
                $message = Text::_('COM_ALTACOURSES_SAMPLE_FAILED');
            }
            $this->setMessage($message, 'warning');
        }
        $this->setRedirect(Route::_('index.php?option=com_altacourses&view=courses', false));
    }
}
