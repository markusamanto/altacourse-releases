<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 * @var         \Advenire\Component\Altacourses\Site\View\Dashboard\HtmlView $this
 */

use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\HTML\HTMLHelper;

\defined('_JEXEC') or die;
?>
<section class="altacourses-portal" aria-labelledby="altacourses-portal-heading">
    <h1 id="altacourses-portal-heading">
        <?php echo $this->escape(Text::_($this->isCourseAdministrator ? 'COM_ALTACOURSES_PORTAL_ADMIN_TITLE' : 'COM_ALTACOURSES_PORTAL_SUPPLIER_TITLE')); ?>
    </h1>
    <?php if ($this->isCourseAdministrator) : ?>
        <p><a class="btn btn-success" href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=coursetypes', false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_COURSETYPES_TITLE')); ?></a></p>
        <p><a class="btn btn-success" href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=regions', false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_REGIONS_TITLE')); ?></a></p>
        <p><a class="btn btn-success" href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=courseleaders', false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_COURSELEADERS_TITLE')); ?></a></p>
        <p><a class="btn btn-success" href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=courseplaces', false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_COURSEPLACES_TITLE')); ?></a></p>
    <?php endif; ?>
    <p><a class="btn btn-primary" href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=newcourse&fresh=1')); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_NEW_TITLE')); ?></a></p>
    <p><?php echo $this->escape(Text::sprintf('COM_ALTACOURSES_PORTAL_WELCOME', $this->displayName)); ?></p>
    <p><?php echo $this->escape(Text::_($this->isCourseAdministrator ? 'COM_ALTACOURSES_PORTAL_ADMIN_INTRO' : 'COM_ALTACOURSES_PORTAL_SUPPLIER_INTRO')); ?></p>
    <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_PORTAL_TEST_NOTICE')); ?></p>
    <p><a class="btn btn-primary" href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=managecourses')); ?>">
        <?php echo $this->escape(Text::_('COM_ALTACOURSES_MANAGE_COURSES')); ?>
    </a></p>
    <p><a class="btn btn-primary" href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=courses')); ?>">
        <?php echo $this->escape(Text::_('COM_ALTACOURSES_VIEW_COURSES')); ?>
    </a></p>
    <p><a class="btn btn-primary" href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=' . ($this->isCourseAdministrator ? 'suppliers' : 'supplierprofile'), false)); ?>"><?php echo $this->escape(Text::_($this->isCourseAdministrator ? 'COM_ALTACOURSES_SUPPLIERS_TITLE' : 'COM_ALTACOURSES_SUPPLIER_PROFILE_TITLE')); ?></a></p>
    <p><a class="btn btn-primary" href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=contacts', false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_CONTACTS_TITLE')); ?></a></p>
    <p><a class="btn btn-primary" href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=participations', false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_PARTICIPATION_TITLE')); ?></a></p>
    <?php if ($this->isCourseAdministrator) : ?><p><a class="btn btn-primary" href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=enquiries', false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_ENQUIRIES_TITLE')); ?></a></p><?php endif; ?>
    <?php if ($this->isCourseAdministrator) : ?><p><a class="btn btn-primary" href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=commissions', false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_COMMISSION_TITLE')); ?></a></p><?php endif; ?>
    <?php if ($this->isCourseAdministrator) : ?><p><a class="btn btn-primary" href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=signups', false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_SIGNUPS_TITLE')); ?></a></p><?php endif; ?>
    <?php if ($this->isCourseAdministrator) : ?><p><a class="btn btn-primary" href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=deliveries', false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_DELIVERIES_TITLE')); ?></a></p><?php endif; ?>
    <?php if ($this->isCourseAdministrator && $this->allowTestData) : ?>
        <form action="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&task=fixtures.load')); ?>" method="post">
            <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_SAMPLE_HELP')); ?></p>
            <button type="submit" class="btn btn-secondary"><?php echo $this->escape(Text::_('COM_ALTACOURSES_LOAD_SAMPLES')); ?></button>
            <?php echo HTMLHelper::_('form.token'); ?>
        </form>
        <form id="altacourses-session-fixtures" action="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&task=fixtures.sessions')); ?>" method="post">
            <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_SESSION_SAMPLE_HELP')); ?></p>
            <button type="submit" class="btn btn-secondary"><?php echo $this->escape(Text::_('COM_ALTACOURSES_SESSION_SAMPLE_BUTTON')); ?></button>
            <?php echo HTMLHelper::_('form.token'); ?>
        </form>
    <?php endif; ?>
</section>
