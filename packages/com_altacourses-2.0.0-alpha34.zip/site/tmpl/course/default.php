<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 * @var         \Advenire\Component\Altacourses\Site\View\Course\HtmlView $this
 */

use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;
?>
<article class="altacourses-details" aria-labelledby="altacourses-course-heading" data-course-id="<?php echo (int) $this->item->id; ?>">
    <h1 id="altacourses-course-heading"><?php echo $this->escape($this->heading); ?></h1>
    <dl>
        <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_COURSE_TYPE')); ?></dt>
        <dd><?php echo $this->escape($this->item->course_type ?? ''); ?></dd>
        <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_DATES')); ?></dt>
        <dd>
            <?php $parts = array_merge([$this->item], $this->sessions); ?>
            <?php foreach ($parts as $index => $part) : ?>
                <div data-session="<?php echo $index + 1; ?>">
                    <?php if (count($parts) > 1) : ?><strong><?php echo $this->escape(Text::sprintf('COM_ALTACOURSES_SESSION_NUMBER', $index + 1)); ?>:</strong><?php endif; ?>
                    <time datetime="<?php echo $this->escape(substr($part->start_date ?? '', 0, 10)); ?>"><?php echo $this->escape(substr($part->start_date ?? '', 0, 10)); ?></time>
                    <?php if ($part->stop_date && substr($part->stop_date, 0, 10) !== substr($part->start_date ?? '', 0, 10)) : ?>
                        – <time datetime="<?php echo $this->escape(substr($part->stop_date, 0, 10)); ?>"><?php echo $this->escape(substr($part->stop_date, 0, 10)); ?></time>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </dd>
        <?php foreach (['course_place' => 'PLACE', 'region' => 'REGION'] as $field => $label) : ?>
            <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_' . $label)); ?></dt>
            <dd><?php echo $this->escape($this->item->$field ?: Text::_('COM_ALTACOURSES_UNSPECIFIED')); ?></dd>
        <?php endforeach; ?>
        <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_LEADERS')); ?></dt>
        <dd><?php echo $this->escape(implode(', ', array_filter([$this->item->leader1, $this->item->leader2])) ?: Text::_('COM_ALTACOURSES_UNSPECIFIED')); ?></dd>
        <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_TOTAL_PRICE')); ?></dt>
        <dd data-total-price><?php echo $this->escape($this->totalPrice); ?></dd>
        <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_AVAILABILITY')); ?></dt>
        <dd><?php echo $this->escape($this->item->seats_label ?? Text::_('COM_ALTACOURSES_UNSPECIFIED')); ?></dd>
    </dl>
    <?php if ($this->item->course_notes !== null && $this->item->course_notes !== '') : ?>
        <h2><?php echo $this->escape(Text::_('COM_ALTACOURSES_COURSE_NOTES')); ?></h2>
        <p class="altacourses-course-notes"><?php echo $this->escape($this->item->course_notes); ?></p>
    <?php endif; ?>
    <?php if ($this->canSignup) : ?><a class="btn btn-primary" data-signup-link href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=signup&coid=' . (int) $this->item->id, false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_SIGNUP_TITLE')); ?></a><?php endif; ?>
    <?php if ($this->canEnquire) : ?><p><a class="btn btn-primary" data-enquiry-link href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=enquiry&coid=' . (int) $this->item->id, false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_ENQUIRY_TITLE')); ?></a></p><?php endif; ?>
    <p><a data-back-courses class="btn btn-secondary" href="<?php echo $this->escape(Route::_('index.php?' . http_build_query(['option' => 'com_altacourses', 'view' => 'courses'] + $this->filters), false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_BACK_TO_COURSES')); ?></a></p>
</article>
