<?php

/**
 * @package Altacourses.Site
 * @license GNU General Public License version 2 or later
 * @var \Advenire\Component\Altacourses\Site\View\Managecourses\HtmlView $this
 */

use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;
?>
<section class="altacourses-list" aria-labelledby="altacourses-manage-heading">
    <h1 id="altacourses-manage-heading"><?php echo $this->escape(Text::_('COM_ALTACOURSES_MANAGE_COURSES')); ?></h1>
    <p><?php echo $this->escape(Text::_($this->isCourseAdministrator ? 'COM_ALTACOURSES_MANAGED_ADMIN_INTRO' : 'COM_ALTACOURSES_MANAGED_SUPPLIER_INTRO')); ?></p>
    <p><a href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=dashboard')); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_BACK_TO_DASHBOARD')); ?></a></p>
    <form action="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=managecourses')); ?>" method="get" class="altacourses-filters">
        <input type="hidden" name="option" value="com_altacourses">
        <input type="hidden" name="view" value="managecourses">
        <div>
            <label for="altacourses-type"><?php echo $this->escape(Text::_('COM_ALTACOURSES_COURSE_TYPE')); ?></label>
            <select id="altacourses-type" name="type" class="form-select">
                <option value="0"><?php echo $this->escape(Text::_('COM_ALTACOURSES_ALL_TYPES')); ?></option>
                <?php foreach ($this->types as $type) : ?>
                    <option value="<?php echo (int) $type->id; ?>"<?php echo (int) $type->id === $this->filters['type'] ? ' selected' : ''; ?>><?php echo $this->escape($type->name ?? ''); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div>
            <label for="altacourses-region"><?php echo $this->escape(Text::_('COM_ALTACOURSES_REGION')); ?></label>
            <select id="altacourses-region" name="region" class="form-select">
                <option value="0"><?php echo $this->escape(Text::_('COM_ALTACOURSES_ALL_REGIONS')); ?></option>
                <?php foreach ($this->regions as $region) : ?>
                    <option value="<?php echo (int) $region->id; ?>"<?php echo (int) $region->id === $this->filters['region'] ? ' selected' : ''; ?>><?php echo $this->escape($region->name ?? ''); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div>
            <label for="altacourses-from"><?php echo $this->escape(Text::_('COM_ALTACOURSES_FROM_DATE')); ?></label>
            <input type="date" class="form-control" name="from" id="altacourses-from" min="1000-01-01" value="<?php echo $this->escape($this->filters['from']); ?>">
        </div>
        <div>
            <label for="altacourses-to"><?php echo $this->escape(Text::_('COM_ALTACOURSES_TO_DATE')); ?></label>
            <input type="date" class="form-control" name="to" id="altacourses-to" min="1000-01-01" value="<?php echo $this->escape($this->filters['to']); ?>">
        </div>
        <div>
            <label for="altacourses-id"><?php echo $this->escape(Text::_('COM_ALTACOURSES_COURSE_ID_FILTER')); ?></label>
            <input type="number" min="0" max="2147483647" class="form-control" name="id" id="altacourses-id" value="<?php echo (int) $this->filters['id']; ?>">
        </div>
        <div class="altacourses-filter-actions">
            <button type="submit" class="btn btn-primary"><?php echo $this->escape(Text::_('COM_ALTACOURSES_FILTER')); ?></button>
            <a href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=managecourses')); ?>" class="btn btn-secondary"><?php echo $this->escape(Text::_('COM_ALTACOURSES_CLEAR_FILTERS')); ?></a>
        </div>
    </form>
    <?php if (!$this->items) : ?>
        <p role="status"><?php echo $this->escape(Text::_('COM_ALTACOURSES_NO_MANAGED_COURSES')); ?></p>
    <?php else : ?>
        <div class="table-responsive">
            <table class="table table-striped">
                <caption><?php echo $this->escape(Text::_('COM_ALTACOURSES_MANAGED_CAPTION')); ?></caption>
                <thead><tr>
                    <?php foreach (['COURSE_ID', 'COURSE_TYPE', 'DATES', 'PLACE', 'OWNER', 'PRICE', 'AVAILABILITY', 'PUBLICATION', 'ACTIONS'] as $column) : ?>
                        <th scope="col"><?php echo $this->escape(Text::_('COM_ALTACOURSES_' . $column)); ?></th>
                    <?php endforeach; ?>
                </tr></thead>
                <tbody>
                    <?php foreach ($this->items as $item) : ?>
                        <tr data-course-id="<?php echo (int) $item->id; ?>">
                            <td><?php echo (int) $item->id; ?></td>
                            <td><?php echo $this->escape($item->course_type ?? ''); ?></td>
                            <td>
                                <?php if ($item->start_date) : ?><time datetime="<?php echo $this->escape(substr($item->start_date, 0, 10)); ?>"><?php echo $this->escape(substr($item->start_date, 0, 10)); ?></time><?php endif; ?>
                                <?php if ($item->stop_date) : ?>
                                    – <time datetime="<?php echo $this->escape(substr($item->stop_date, 0, 10)); ?>"><?php echo $this->escape(substr($item->stop_date, 0, 10)); ?></time>
                                <?php endif; ?>
                            </td>
                            <td><?php echo $this->escape($item->course_place ?? ''); ?></td>
                            <td><?php echo $this->escape($item->cr ? ($item->owner_name ?? Text::sprintf('COM_ALTACOURSES_OWNER_ID', (int) $item->cr)) : Text::_('COM_ALTACOURSES_UNASSIGNED')); ?></td>
                            <td><?php echo $this->escape($item->course_price ?? ''); ?></td>
                            <td><?php echo $this->escape($item->seats_label ?? Text::_('COM_ALTACOURSES_UNSPECIFIED')); ?></td>
                            <td><?php echo $this->escape(Text::_(match ($item->state === null ? null : (int) $item->state) {
                                1 => 'COM_ALTACOURSES_PUBLISHED',
                                0 => 'COM_ALTACOURSES_UNPUBLISHED',
                                2 => 'COM_ALTACOURSES_ARCHIVED',
                                -2 => 'COM_ALTACOURSES_TRASHED',
                                default => 'COM_ALTACOURSES_UNSPECIFIED',
                            })); ?></td>
                            <td>
                                <?php if ($this->isCourseAdministrator) : ?>
                                    <a href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=assignment&id=' . (int) $item->id)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_ASSIGN_SUPPLIER')); ?></a>
                                <?php endif; ?>
                                <?php if ($this->isCourseAdministrator || $item->availability_upcoming) : ?>
                                    <a href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=availability&id=' . (int) $item->id)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_EDIT_AVAILABILITY')); ?></a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php echo $this->pagination->getPagesLinks(); ?>
        <p><?php echo $this->escape($this->pagination->getPagesCounter()); ?></p>
    <?php endif; ?>
</section>
