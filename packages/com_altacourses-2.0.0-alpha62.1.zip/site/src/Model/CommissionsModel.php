<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Model;

use Advenire\Component\Altacourses\Administrator\Service\CommissionAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\CommissionAwareTrait;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Form\FormFactoryAwareInterface;
use Joomla\CMS\Form\FormFactoryAwareTrait;
use Joomla\CMS\Language\Text;
use Joomla\Database\ParameterType;

\defined('_JEXEC') or die;

final class CommissionsModel extends RequestrecordsModel implements CommissionAwareInterface, FormFactoryAwareInterface
{
    use CommissionAwareTrait;
    use FormFactoryAwareTrait;

    public function previousMonth(): string { $this->requireAdministrator(); return $this->getCommissionReport()->previousMonth(); }
    public function validateMonth(string $month): void { $this->requireAdministrator(); $this->getCommissionReport()->bounds($month); }
    public function getReport(string $month): array { $this->requireAdministrator(); return $this->getCommissionReport()->read($month); }

    public function download(string $month, string $fingerprint): string
    {
        $this->requireAdministrator();
        $headers = array_map(static fn ($label): string => Text::_('COM_ALTACOURSES_' . $label),
            ['COMMISSION_SUPPLIER', 'COURSE_TYPE', 'DATES', 'ENQUIRY_NAME', 'ENQUIRY_ORGANISATION', 'COMMISSION_AMOUNT', 'PARTICIPATION_NOTE']);
        return $this->getCommissionReport()->captureCsv($month, $fingerprint, $this->currentActorId(), $headers);
    }

    public function getRates(): array
    {
        $this->requireAdministrator();
        return $this->getDatabase()->setQuery('SELECT id,user_id,company,fee,profile_version FROM #__altacourses_suppliers ORDER BY company,user_id')->loadObjectList();
    }

    public function getRate(int $userId): object
    {
        $this->requireAdministrator();
        $query = $this->getDatabase()->createQuery()->select('*')->from('#__altacourses_suppliers')
            ->where('user_id=:commission_account')->bind(':commission_account', $userId, ParameterType::INTEGER);
        $row = $this->getDatabase()->setQuery($query)->loadObject();
        if ($row === null) { throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'), 404); }
        return $row;
    }

    public function getRateForm(array $data): Form
    {
        $this->requireAdministrator();
        $form = $this->getFormFactory()->createForm('com_altacourses.commissionrate', ['control' => 'jform']);
        if (!$form->loadFile(dirname(__DIR__, 2) . '/forms/commissionrate.xml')) { throw new \RuntimeException('Commission rate form could not be loaded'); }
        $form->bind($data);
        return $form;
    }

    public function saveRate(int $userId, int $version, string $value): void
    {
        $this->requireAdministrator();
        if ($userId <= 0 || $version < 0 || ($value !== '' && (!ctype_digit($value) || (float) $value > 2147483647))) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_COMMISSION_INVALID'), 400);
        }
        $this->getRate($userId);
        $fee = $value === '' ? null : (int) $value; $editor = $this->currentActorId();
        $query = $this->getDatabase()->createQuery()->update('#__altacourses_suppliers')
            ->set('fee=:commission_fee')->bind(':commission_fee', $fee, $fee === null ? ParameterType::NULL : ParameterType::INTEGER)
            ->set('profile_version=profile_version+1')
            ->where('user_id=:commission_account')->bind(':commission_account', $userId, ParameterType::INTEGER)
            ->where('profile_version=:commission_revision')->bind(':commission_revision', $version, ParameterType::INTEGER)
            ->where('(checked_out IS NULL OR checked_out=0 OR checked_out=:commission_editor)')->bind(':commission_editor', $editor, ParameterType::INTEGER);
        $this->getDatabase()->setQuery($query)->execute();
        if ($this->getDatabase()->getAffectedRows() !== 1) { throw new \RuntimeException(Text::_('COM_ALTACOURSES_COMMISSION_CONFLICT'), 409); }
    }
}
