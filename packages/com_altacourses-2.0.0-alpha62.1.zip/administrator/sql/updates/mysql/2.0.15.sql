-- Preserve existing timestamps. NULL retains the original timestamp provenance rules.
ALTER TABLE `#__altacourses_requests` ADD COLUMN `report_timezone` varchar(64) DEFAULT NULL;
