<?php
namespace Advenire\Component\Altacourses\Site\Model;
use Advenire\Component\Altacourses\Administrator\Service\MailchimpEnrollments;
\defined('_JEXEC') or die;
final class MailchimpModel extends RequestrecordsModel
{
    private ?MailchimpEnrollments $enrollments=null;
    public function setMailchimpEnrollments(MailchimpEnrollments $service): void { $this->enrollments=$service; }
    private function service(): MailchimpEnrollments { $this->requireAdministrator();return $this->enrollments??throw new \RuntimeException('Mailchimp service unavailable'); }
    public function settings(): array { return $this->service()->settings(); }
    public function candidates(): array { return $this->service()->candidates(); }
    public function history(): array { return $this->service()->history(); }
    public function retry(int $id,string $revision): void { $this->service()->retry($id,$revision); }
}
