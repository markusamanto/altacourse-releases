<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */
namespace Advenire\Component\Altacourses\Site\View\Deliveries;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
\defined('_JEXEC') or die;
final class HtmlView extends BaseHtmlView
{
    public array $items = [];
    public string $mode = 'off';
    public ?\Joomla\CMS\Pagination\Pagination $pagination = null;
    public function display($tpl = null): void
    {
        $this->mode = $this->getModel()->mode();
        $this->items = $this->getModel()->getItems();
        $this->getDocument()->setTitle(Text::_('COM_ALTACOURSES_DELIVERIES_TITLE'));
        $this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.site');
        parent::display($tpl);
    }
}
