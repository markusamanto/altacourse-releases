<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Model;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\CMS\MVC\Model\BaseModel;
use Joomla\CMS\User\CurrentUserInterface;
use Joomla\CMS\User\User;
use Joomla\Database\DatabaseAwareInterface;
use Joomla\Database\DatabaseAwareTrait;
use Joomla\Database\ParameterType;
use Joomla\Database\QueryInterface;

use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareTrait;

\defined('_JEXEC') or die;

final class ManagecoursesModel extends BaseModel implements CourseScheduleAwareInterface, DatabaseAwareInterface, CurrentUserInterface
{
    use DatabaseAwareTrait;
    use CourseScheduleAwareTrait;

    private ?User $currentUser = null;
    private string $reportingTimezone = 'UTC';
    public function setReportingTimezone(string $timezone): void { new \DateTimeZone($timezone); $this->reportingTimezone = $timezone; }
    public function today(): string { return (new \DateTimeImmutable('now', new \DateTimeZone($this->reportingTimezone)))->format('Y-m-d'); }
    public function isCourseAdministrator(): bool { return $this->currentUser !== null && !$this->currentUser->guest && $this->currentUser->authorise('altacourses.manage', 'com_altacourses'); }

    public function __construct($config = [], ?MVCFactoryInterface $factory = null)
    {
        parent::__construct($config);
    }

    public function setCurrentUser(User $currentUser): void
    {
        $this->currentUser = $currentUser;
    }

    public function getItems(): array
    {
        return $this->getDatabase()->setQuery(
            $this->buildQuery(false),
            (int) $this->getState('list.start', 0),
            (int) $this->getState('list.limit', 20)
        )->loadObjectList();
    }

    public function getTotal(): int
    {
        return (int) $this->getDatabase()->setQuery($this->buildQuery(true))->loadResult();
    }

    /** Lookup choices are derived from the same authorised records as the list. */
    public function getOptions(string $kind): array
    {
        if ($kind === 'suppliers') {
            if (!$this->isCourseAdministrator()) { throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403); }
            $db = $this->getDatabase();
            $query = $db->createQuery()->select(['DISTINCT co.cr AS id', 'owner.name AS account_name', 'sp.company'])
                ->from('#__altacourses_courses AS co')
                ->join('LEFT', '#__users AS owner ON owner.id=co.cr')
                ->join('LEFT', '#__altacourses_suppliers AS sp ON sp.user_id=co.cr')
                ->where('co.cr>0')->order("COALESCE(NULLIF(sp.company,''),owner.name),co.cr");
            $items = $db->setQuery($query)->loadObjectList();
            foreach ($items as $item) {
                $company = trim((string) $item->company);
                $name = $company !== '' ? $company : trim((string) $item->account_name);
                $item->name = $name !== '' ? Text::sprintf('COM_ALTACOURSES_MANAGED_SUPPLIER_CHOICE', $name, (int) $item->id) : Text::sprintf('COM_ALTACOURSES_OWNER_ID', (int) $item->id);
            }
            return $items;
        }
        if (!in_array($kind, ['coursetypes', 'regions'], true)) {
            throw new \InvalidArgumentException('Unsupported lookup');
        }

        $db = $this->getDatabase();
        $query = $db->createQuery()->select('DISTINCT choice.id, choice.name')
            ->from('#__altacourses_courses AS co');
        $this->scopeToCurrentUser($query);

        if ($kind === 'coursetypes') {
            $query->join('INNER', '#__altacourses_coursetypes AS choice ON choice.id = co.course_type');
        } else {
            $query->join('INNER', '#__altacourses_courseplaces AS cp ON cp.id = co.course_place')
                ->join('INNER', '#__altacourses_regions AS choice ON choice.id = cp.region_id');
        }

        return $db->setQuery($query->order('choice.name, choice.id'))->loadObjectList();
    }

    private function buildQuery(bool $count): QueryInterface
    {
        $db = $this->getDatabase();
        $query = $db->createQuery()->from('#__altacourses_courses AS co')
            ->join('LEFT', '#__altacourses_coursetypes AS ct ON ct.id = co.course_type')
            ->join('LEFT', '#__altacourses_courseplaces AS cp ON cp.id = co.course_place')
            ->join('LEFT', '#__altacourses_regions AS re ON re.id = cp.region_id')
            ->join('LEFT', '#__altacourses_seats AS se ON se.seats = co.nr_of_participants')
            ->join('LEFT', '#__users AS owner ON owner.id = co.cr');
        $this->scopeToCurrentUser($query);

        if ($count) {
            $query->select('COUNT(*)');
        } else {
            $query->select(['co.id', 'co.start_date', 'co.stop_date', 'co.state', 'co.cr',
                'co.course_price', 'co.nr_of_participants', 'co.start_date >= CURRENT_TIMESTAMP AS availability_upcoming', 'ct.name AS course_type',
                'cp.name AS course_place', 'se.label AS seats_label', 'owner.name AS owner_name']);
            $query->order(["CASE WHEN co.start_date IS NULL OR CAST(co.start_date AS CHAR) LIKE '0000-%' THEN 1 ELSE 0 END", 'co.start_date ASC', 'co.id ASC']);
        }

        $period = $this->getState('filter.period', 'future');
        if (!is_string($period) || !in_array($period, ['future', 'all'], true)) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_FILTER'), 400);
        }
        if ($period === 'future') {
            $today = $this->today() . ' 00:00:00';
            $query->where('co.start_date>=:managed_today')->bind(':managed_today', $today);
        }
        if ($this->isCourseAdministrator()) {
            $supplier = $this->getState('filter.supplier', 0);
            if (!is_int($supplier) || $supplier < 0 || $supplier > 2147483647) {
                throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_FILTER'), 400);
            }
            if ($supplier > 0) { $query->where('co.cr=:managed_owner')->bind(':managed_owner', $supplier, ParameterType::INTEGER); }
        }

        foreach (['id' => 'co.id', 'type' => 'co.course_type', 'region' => 'cp.region_id'] as $filter => $column) {
            $value = (int) $this->getState('filter.' . $filter, 0);
            if ($value > 0) {
                // bind() retains the value by reference; keep each loop value independently.
                $query->where($column . ' = :' . $filter)->bind(':' . $filter, $value, ParameterType::INTEGER);
                unset($value);
            }
        }
        $from = (string) $this->getState('filter.from', '');
        $to = (string) $this->getState('filter.to', '');
        if ($from !== '') {
            $from .= ' 00:00:00';
            $query->where('co.start_date >= :from_date')->bind(':from_date', $from);
        }
        $this->getCourseSchedule()->applyEndDateFilter($query, $to);

        return $query;
    }

    /** Apply ownership before filters, totals, pagination or lookup choices. */
    private function scopeToCurrentUser(QueryInterface $query): void
    {
        $user = $this->currentUser;
        if ($user === null || $user->guest) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }
        if ($user->authorise('altacourses.manage', 'com_altacourses')) {
            return;
        }
        if (!$user->authorise('altacourses.supplier', 'com_altacourses') || (int) $user->id <= 0) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }

        $ownerId = (int) $user->id;
        $query->where('co.cr = :current_supplier')->bind(':current_supplier', $ownerId, ParameterType::INTEGER);
    }
}
