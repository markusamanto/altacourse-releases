<?php

/** @package Altacourses.Administrator @license GNU General Public License version 2 or later */
\defined('_JEXEC') or die;

use Advenire\Component\Altacourses\Administrator\Service\CommissionReport;
use Advenire\Component\Altacourses\Administrator\Service\CoursePrice;
use Advenire\Component\Altacourses\Administrator\Service\CourseSchedule;
use Advenire\Component\Altacourses\Administrator\Service\NotificationService;
use Advenire\Component\Altacourses\Administrator\Service\MonthlyReport;
use Joomla\CMS\Mail\MailerFactoryInterface;
use Joomla\CMS\Language\LanguageFactoryInterface;
use Joomla\Database\DatabaseInterface;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;

return new class () implements ServiceProviderInterface {
    public function register(Container $container): void
    {
        $container->set(CommissionReport::class, static fn (Container $container): CommissionReport => new CommissionReport($container->get(DatabaseInterface::class), $container->get('config'), $container->get(CourseSchedule::class)));
        $container->set(CoursePrice::class, static fn (): CoursePrice => new CoursePrice());
        $container->set(CourseSchedule::class, static fn (Container $container): CourseSchedule => new CourseSchedule($container->get(DatabaseInterface::class)));
        $container->set(NotificationService::class, static fn (Container $container): NotificationService => new NotificationService(
            $container->get(DatabaseInterface::class), $container->get('config'),
            $container->get(MailerFactoryInterface::class), $container->get(LanguageFactoryInterface::class), $container->get(CoursePrice::class)
        ));
        $container->set(MonthlyReport::class, static fn (Container $container): MonthlyReport => new MonthlyReport(
            $container->get(DatabaseInterface::class), $container->get('config'), $container->get(CommissionReport::class),
            $container->get(NotificationService::class), $container->get(MailerFactoryInterface::class), $container->get(LanguageFactoryInterface::class)
        ));
    }
};
