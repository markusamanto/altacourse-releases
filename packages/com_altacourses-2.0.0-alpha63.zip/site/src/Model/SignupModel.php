<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Model;

use Advenire\Component\Altacourses\Administrator\Service\CoursePriceAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\CoursePriceAwareTrait;
use Advenire\Component\Altacourses\Site\Exception\CourseValidationException;
use Joomla\CMS\Language\Text;

\defined('_JEXEC') or die;

final class SignupModel extends SubmissionModel implements CoursePriceAwareInterface
{
    use CoursePriceAwareTrait;

    protected const FORM = 'signup';
    protected const ASKED_FOR_INFO = 0;
    public const FIELDS = ['firstname', 'lastname', 'company', 'email', 'phone', 'mobile',
        'age', 'profession', 'specialmeal', 'postal_address', 'postal_zip', 'postal_city',
        'invoice_address', 'invoice_zip', 'invoice_city', 'accept_terms', 'newsletter'];

    public function getCourse(int $id, bool $lock = false): object
    {
        $course = parent::getCourse($id, $lock);
        if (trim($course->supplier_terms ?? '') === '' || $this->total($course) === null) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_SIGNUP_UNAVAILABLE'), 404);
        }
        return $course;
    }

    public function agreement(object $course): array
    {
        return $this->summary($course) + ['supplier_id' => (int) $course->supplier_id,
            'supplier_user_id' => (int) $course->supplier_user_id, 'supplier_email' => $course->supplier_email,
            'profile_version' => (int) $course->profile_version, 'course_version' => (int) $course->availability_version,
            'terms' => $course->supplier_terms, 'total_price' => $this->total($course), 'currency' => 'SEK',
            'course_price' => $course->course_price, 'lodging_price' => $course->lodging_price,
            'lodging_included' => $course->lodging_included];
    }

    public function fingerprint(object $course): string
    {
        return hash('sha256', json_encode($this->agreement($course), JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE));
    }

    protected function checkAgreement(object $course, ?string $agreement): void
    {
        if ($agreement === null || !hash_equals($this->fingerprint($course), $agreement)) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_SIGNUP_CONFLICT'), 409);
        }
    }

    protected function submissionSnapshot(object $course, array $snapshot, string $now): array
    {
        return $snapshot + ['booking' => $this->agreement($course) + ['terms_accepted' => true,
            'accepted_at' => $now, 'agreement_hash' => $this->fingerprint($course)]];
    }

    protected function validateData(array $input): array
    {
        if (($input['accept_terms'] ?? null) !== '1') {
            throw new CourseValidationException([Text::_('COM_ALTACOURSES_SIGNUP_ACCEPT_REQUIRED')]);
        }
        $data = parent::validateData($input);
        unset($data['accept_terms']);
        return $data;
    }

    private function total(object $course): ?string
    {
        return $this->getCoursePrice()->formatTotal($course->course_price, $course->lodging_price, $course->lodging_included);
    }
}
