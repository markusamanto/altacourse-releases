-- Alerts retain the original columns and IDs. Existing imported tables are untouched.
CREATE TABLE IF NOT EXISTS `#__altacourses_alerts` (
 `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
 `name` varchar(255) NOT NULL,
 `alert` text NOT NULL,
 `ordering` int NOT NULL DEFAULT 0,
 `state` int NOT NULL DEFAULT 0,
 `checked_out` int NOT NULL DEFAULT 0,
 `checked_out_time` datetime DEFAULT NULL,
 `created_by` int NOT NULL DEFAULT 0,
 `modified_by` int DEFAULT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
