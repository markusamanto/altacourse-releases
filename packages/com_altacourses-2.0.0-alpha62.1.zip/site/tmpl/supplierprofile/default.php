<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;
?>
<section class="altacourses-portal" aria-labelledby="altacourses-supplier-profile-heading">
    <h1 id="altacourses-supplier-profile-heading"><?php echo $this->escape(Text::_('COM_ALTACOURSES_SUPPLIER_PROFILE_TITLE')); ?></h1>
    <p><strong><?php echo $this->escape(Text::_('COM_ALTACOURSES_SUPPLIER_ACCOUNT')); ?>:</strong> <?php echo $this->escape($this->accountName); ?></p>
    <p><strong><?php echo $this->escape(Text::_('COM_ALTACOURSES_SUPPLIER_EMAIL')); ?>:</strong> <?php echo $this->escape($this->accountEmail); ?></p>
    <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_SUPPLIER_ACCOUNT_HELP')); ?></p>
    <?php if (!$this->isCourseAdministrator) : ?><p><a href="<?php echo $this->escape(Route::_('index.php?option=com_users&task=profile.edit&user_id=' . $this->supplierUserId, false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_SUPPLIER_LOGIN_DETAILS')); ?></a></p><?php endif; ?>
    <?php if ($this->accountBlocked) : ?><p><?php echo $this->escape(Text::_('COM_ALTACOURSES_SUPPLIER_BLOCKED')); ?></p><?php endif; ?>
    <form id="altacourses-supplierprofile-form" action="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&task=supplierprofile.save', false)); ?>" method="post">
        <?php foreach (['user_id', 'id', 'version'] as $field) : ?><?php echo $this->form->getInput($field); ?><?php endforeach; ?>
        <?php foreach (['firstname', 'lastname', 'company', 'phone', 'mobile', 'postal_address', 'postal_zip', 'postal_city', 'postal_country', 'invoice_address', 'invoice_zip', 'invoice_city', 'org_name', 'website', 'terms'] as $field) : ?>
            <?php echo $this->form->renderField($field); ?>
        <?php endforeach; ?>
        <?php echo HTMLHelper::_('form.token'); ?>
        <button type="submit" class="btn btn-primary"><?php echo $this->escape(Text::_('JSAVE')); ?></button>
        <a class="btn btn-secondary" href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=' . ($this->isCourseAdministrator ? 'suppliers' : 'dashboard'), false)); ?>"><?php echo $this->escape(Text::_('JCANCEL')); ?></a>
        <a class="btn btn-secondary" href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=supplierprofile&user_id=' . $this->supplierUserId . '&fresh=1', false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_EDIT_RELOAD')); ?></a>
    </form>
</section>
