<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\View\Suppliers;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;

\defined('_JEXEC') or die;

final class HtmlView extends BaseHtmlView
{
    public array $items = [];

    public function display($tpl = null): void
    {
        if (!$this->getModel()->isAdministrator()) { throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403); }
        $this->items = $this->getModel()->getSuppliers();
        $this->getDocument()->setTitle(Text::_('COM_ALTACOURSES_SUPPLIERS_TITLE'));
        $this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.site');
        parent::display($tpl);
    }
}
