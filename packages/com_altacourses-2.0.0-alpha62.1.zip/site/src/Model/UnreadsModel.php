<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Model;

use Advenire\Component\Altacourses\Administrator\Service\RequestReceipt;
use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareTrait;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;

\defined('_JEXEC') or die;

/** Read-only, administrator-only reminder composition; never prepares or sends mail. */
final class UnreadsModel extends RequestrecordsModel implements CourseScheduleAwareInterface
{
    use CourseScheduleAwareTrait;
    private string $receiptSecret = '';
    public function setReceiptSecret(string $secret): void { $this->receiptSecret = $secret; }

    public function getIntroduction(): array
    {
        $this->requireAdministrator();
        $row = $this->getDatabase()->setQuery('SELECT id,message FROM #__altacourses_mailtemplates WHERE type=12 AND COALESCE(course_type,0)=0 AND state=1')->loadObject();
        return ['id' => (int) ($row->id ?? 0), 'message' => (string) ($row->message ?? Text::_('COM_ALTACOURSES_UNREAD_DEFAULT_INTRO'))];
    }

    public function getGroups(): array
    {
        $this->requireAdministrator();
        $query = $this->getDatabase()->createQuery()->select([
            'r.id', 'r.courseid', 'r.asked_for_info', 'r.rebooked', 'r.date_created', 's.created_at AS submitted_at',
            's.contact_json', 'cl.firstname', 'cl.lastname', 'cl.company', 'cl.email', 'cl.phone', 'cl.mobile',
            'cl.invoice_address', 'cl.invoice_zip', 'cl.invoice_city',
            'co.cr AS supplier_user_id', 'sp.company AS supplier_company', 'u.name AS supplier_name', 'u.email AS supplier_email',
            'ct.name AS course_type', 'cp.name AS course_place',
        ])->from('#__altacourses_requests AS r')
            ->join('LEFT', '#__altacourses_courses AS co ON co.id=r.courseid')
            ->join('LEFT', '#__altacourses_request_submissions AS s ON s.request_id=r.id')
            ->join('LEFT', '#__altacourses_clients AS cl ON cl.id=r.clientid')
            ->join('LEFT', '#__altacourses_coursetypes AS ct ON ct.id=co.course_type')
            ->join('LEFT', '#__altacourses_courseplaces AS cp ON cp.id=co.course_place')
            ->join('LEFT', '#__altacourses_suppliers AS sp ON sp.user_id=co.cr')
            ->join('LEFT', '#__users AS u ON u.id=co.cr')
            ->where('(r.received=0 OR r.received IS NULL)')->where('COALESCE(r.canceled,0)=0')
            ->where('COALESCE(r.rebooked,0)<>2')->where('r.asked_for_info IN (0,1)')
            ->order('COALESCE(sp.company,u.name),co.cr,r.date_created,r.id');
        $rows = $this->getDatabase()->setQuery($query)->loadObjectList();
        $sessions = $this->getCourseSchedule()->currentSessions(array_column($rows, 'courseid'));
        $receipts = new RequestReceipt($this->getDatabase(), $this->receiptSecret);
        $groups = [];
        foreach ($rows as $row) {
            $owner = max(0, (int) $row->supplier_user_id);
            if (!isset($groups[$owner])) {
                $label = trim((string) $row->supplier_company) ?: trim((string) $row->supplier_name);
                $groups[$owner] = ['id' => $owner, 'name' => $label ?: ($owner > 0 ? Text::sprintf('COM_ALTACOURSES_OWNER_ID', $owner) : Text::_('COM_ALTACOURSES_UNASSIGNED')),
                    'email' => (string) $row->supplier_email, 'rows' => []];
            }
            // Submitted contact fields remain immutable; legacy/rebooked requests use current client details for display only.
            $row->contact = $row->contact_json !== null ? json_decode($row->contact_json, true, 512, JSON_THROW_ON_ERROR) : [
                'firstname' => $row->firstname, 'lastname' => $row->lastname, 'company' => $row->company, 'email' => $row->email,
                'phone' => $row->phone, 'mobile' => $row->mobile, 'invoice_address' => $row->invoice_address,
                'invoice_zip' => $row->invoice_zip, 'invoice_city' => $row->invoice_city,
            ];
            $row->sessions = $sessions[(int) $row->courseid] ?? [];
            $row->receipt_url = Uri::root() . 'index.php?option=com_altacourses&task=receipt.received&token=' . $receipts->reminderToken((int) $row->id);
            $groups[$owner]['rows'][] = $row;
        }
        return array_values($groups);
    }
}
