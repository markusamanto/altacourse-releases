<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
\defined('_JEXEC') or die;
?>
<section aria-labelledby="altacourses-unreads-heading" class="altacourses-unreads">
    <h1 id="altacourses-unreads-heading"><?php echo $this->escape(Text::_('COM_ALTACOURSES_UNREAD_TITLE')); ?></h1>
    <p><a href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=dashboard', false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_BACK_TO_DASHBOARD')); ?></a></p>
    <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_UNREAD_HELP')); ?></p>
    <p><a href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=' . ($this->introduction['id'] ? 'mailtemplate&id=' . $this->introduction['id'] : 'mailtemplates'), false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_UNREAD_EDIT_INTRO')); ?></a></p>
    <?php if (!$this->introduction['id']) : ?><p role="status"><?php echo $this->escape(Text::_('COM_ALTACOURSES_UNREAD_TEMPLATE_FALLBACK')); ?></p><?php endif; ?>
    <?php if (!$this->groups) : ?><p role="status"><?php echo $this->escape(Text::_('COM_ALTACOURSES_UNREAD_EMPTY')); ?></p><?php endif; ?>
    <?php foreach ($this->groups as $group) : ?>
    <section data-unread-supplier="<?php echo (int) $group['id']; ?>">
        <h2><?php echo $this->escape($group['name']); ?><?php if ($group['id']) : ?> <small>(#<?php echo (int) $group['id']; ?>)</small><?php endif; ?></h2>
        <p><?php echo $this->escape($group['email']); ?></p>
        <div data-reminder-content>
            <p><?php echo nl2br($this->escape($this->introduction['message'])); ?></p>
            <?php foreach ($group['rows'] as $row) : ?>
            <article data-unread-request="<?php echo (int) $row->id; ?>">
                <h3><?php echo $this->escape(Text::_((int) $row->asked_for_info === 1 ? 'COM_ALTACOURSES_ENQUIRY_TITLE' : 'COM_ALTACOURSES_SIGNUP_TITLE')); ?> #<?php echo (int) $row->id; ?><?php if ((int) $row->rebooked === 1) : ?> — <?php echo $this->escape(Text::_('COM_ALTACOURSES_UNREAD_REBOOKING')); ?><?php endif; ?></h3>
                <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_UNREAD_CREATED')); ?>: <?php echo $this->escape($row->submitted_at ?? $row->date_created ?? ''); ?></p>
                <p><?php echo $this->escape(implode(' · ', array_filter([$row->course_type ?? '', $row->course_place ?? ''], static fn ($value): bool => $value !== ''))); ?><br>
                    <?php foreach ($row->sessions as $session) : ?><?php echo $this->escape(substr($session['start_date'] ?? '', 0, 10) . ' – ' . substr($session['stop_date'] ?? '', 0, 10)); ?><br><?php endforeach; ?>
                </p>
                <p>
                <?php foreach (['ENQUIRY_NAME' => trim(($row->contact['firstname'] ?? '') . ' ' . ($row->contact['lastname'] ?? '')), 'ENQUIRY_ORGANISATION' => $row->contact['company'] ?? '', 'SUPPLIER_PHONE' => $row->contact['phone'] ?? '', 'SUPPLIER_MOBILE' => $row->contact['mobile'] ?? '', 'ENQUIRY_EMAIL' => $row->contact['email'] ?? '', 'SIGNUP_INVOICE_ADDRESS' => trim(($row->contact['invoice_address'] ?? '') . ' ' . ($row->contact['invoice_zip'] ?? '') . ' ' . ($row->contact['invoice_city'] ?? ''))] as $label => $value) : ?>
                    <?php if ($value !== '') : ?><strong><?php echo $this->escape(Text::_('COM_ALTACOURSES_' . $label)); ?>:</strong> <?php echo $this->escape($value); ?><br><?php endif; ?>
                <?php endforeach; ?>
                </p>
                <p><a href="<?php echo $this->escape($row->receipt_url); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_UNREAD_MARK')); ?></a></p>
                <hr>
            </article>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endforeach; ?>
</section>
