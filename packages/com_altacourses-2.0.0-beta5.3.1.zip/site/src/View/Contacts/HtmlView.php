<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\View\Contacts;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;

\defined('_JEXEC') or die;

final class HtmlView extends BaseHtmlView
{
    public array $items = [];
    public array $types = [];
    public array $filters = [];
    public ?\Joomla\CMS\Pagination\Pagination $pagination = null;

    public function display($tpl = null): void
    {
        $this->items = $this->getModel()->getItems();
        $this->types = $this->getModel()->getTypeOptions();
        $this->getDocument()->setTitle(Text::_('COM_ALTACOURSES_CONTACTS_TITLE'));
        $this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.site');
        parent::display($tpl);
    }
}
