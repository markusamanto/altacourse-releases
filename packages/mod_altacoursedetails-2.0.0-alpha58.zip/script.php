<?php

/** @package Altacourses.Module @license GNU General Public License version 2 or later */
\defined('_JEXEC') or die;

use Joomla\CMS\Installer\InstallerAdapter;
use Joomla\CMS\Installer\InstallerScriptInterface;
use Joomla\CMS\Language\Text;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;

return new class () implements ServiceProviderInterface {
    public function register(Container $container): void
    {
        $container->set(InstallerScriptInterface::class, static fn (): InstallerScriptInterface => new class () implements InstallerScriptInterface {
            public function preflight(string $type, InstallerAdapter $adapter): bool
            {
                if ($type === 'uninstall') { return true; }
                $file = JPATH_ADMINISTRATOR . '/components/com_altacourses/altacourses.xml';
                $manifest = is_file($file) ? simplexml_load_file($file) : false;
                if (version_compare(JVERSION, '6.2.0', '<') || version_compare(PHP_VERSION, '8.4.0', '<')
                    || !$manifest || (string) $manifest->namespace !== 'Advenire\\Component\\Altacourses'
                    || version_compare((string) $manifest->version, '2.0.0-alpha58', '<')) {
                    throw new \RuntimeException(Text::_('MOD_ALTACOURSEDETAILS_REQUIREMENTS'));
                }
                return true;
            }
            public function install(InstallerAdapter $adapter): bool { return true; }
            public function update(InstallerAdapter $adapter): bool { return true; }
            public function postflight(string $type, InstallerAdapter $adapter): bool { return true; }
            public function uninstall(InstallerAdapter $adapter): bool { return true; }
        });
    }
};
