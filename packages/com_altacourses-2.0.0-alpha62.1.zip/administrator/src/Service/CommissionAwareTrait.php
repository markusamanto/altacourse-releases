<?php

/** @package Altacourses.Administrator @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Administrator\Service;

\defined('_JEXEC') or die;

trait CommissionAwareTrait
{
    private ?CommissionReport $commissionReport = null;
    public function setCommissionReport(CommissionReport $report): void { $this->commissionReport = $report; }
    protected function getCommissionReport(): CommissionReport
    {
        return $this->commissionReport ?? throw new \LogicException('Commission report service has not been injected');
    }
}
