<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\View\Course;

use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareTrait;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;

\defined('_JEXEC') or die;

final class HtmlView extends BaseHtmlView implements CourseScheduleAwareInterface
{
    use CourseScheduleAwareTrait;

    public ?object $item = null;
    public array $sessions = [];
    public array $filters = [];
    public string $heading = '';

    public function display($tpl = null): void
    {
        $this->item = $this->getModel()->getItem();
        $this->sessions = $this->getCourseSchedule()->additionalSessions([(int) $this->item->id])[(int) $this->item->id] ?? [];
        $this->heading = Text::sprintf('COM_ALTACOURSES_COURSE_HEADING', $this->item->course_type ?? '', $this->item->course_place ?? '');
        $this->getDocument()->setTitle($this->heading);
        $this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.site');
        parent::display($tpl);
    }
}
