<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Model;

use Joomla\Database\ParameterType;
use Joomla\Database\QueryInterface;

\defined('_JEXEC') or die;

final class CoursesModel extends PubliccourseModel
{
    public function getItems(): array
    {
        return $this->getDatabase()->setQuery($this->buildQuery(false),
            (int) $this->getState('list.start', 0), (int) $this->getState('list.limit', 20))->loadObjectList();
    }

    public function getTotal(): int
    {
        return (int) $this->getDatabase()->setQuery($this->buildQuery(true))->loadResult();
    }

    public function getOptions(string $kind): array
    {
        if (!in_array($kind, ['coursetypes', 'regions'], true)) {
            throw new \InvalidArgumentException('Unsupported lookup');
        }
        $db = $this->getDatabase();
        return $db->setQuery($db->createQuery()->select(['id', 'name'])
            ->from($db->quoteName('#__altacourses_' . $kind))->where('state = 1')->order('ordering, name, id'))->loadObjectList();
    }

    private function buildQuery(bool $count): QueryInterface
    {
        $query = $this->publicQuery();

        if ($count) {
            $query->select('COUNT(*)');
        } else {
            $query->select(['co.id', 'co.start_date', 'co.stop_date', 'co.course_price', 'co.lodging_price', 'co.lodging_included',
                'ct.name AS course_type', 'cp.name AS course_place', 're.name AS region',
                'l1.name AS leader1', 'l2.name AS leader2', 'se.label AS seats_label']);
            $query->order(['co.start_date', 'ct.name', 'cp.name', 'co.id']);
        }

        $type = (int) $this->getState('filter.type', 0);
        $region = (int) $this->getState('filter.region', 0);
        $from = (string) $this->getState('filter.from', '');
        $to = (string) $this->getState('filter.to', '');
        if ($type > 0) {
            $query->where('co.course_type = :type')->bind(':type', $type, ParameterType::INTEGER);
        }
        if ($region > 0) {
            $query->where('cp.region_id = :region')->bind(':region', $region, ParameterType::INTEGER);
        }
        if ($from !== '') {
            $from .= ' 00:00:00';
            $query->where('co.start_date >= :from_date')->bind(':from_date', $from);
        }
        $this->getCourseSchedule()->applyEndDateFilter($query, $to);
        return $query;
    }
}
