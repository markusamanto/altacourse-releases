<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Model;

use Joomla\CMS\Form\Form;
use Joomla\CMS\Form\FormFactoryAwareInterface;
use Joomla\CMS\Form\FormFactoryAwareTrait;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\CMS\MVC\Model\BaseModel;
use Joomla\CMS\User\CurrentUserInterface;
use Joomla\CMS\User\User;
use Joomla\Database\DatabaseAwareInterface;
use Joomla\Database\DatabaseAwareTrait;
use Joomla\Database\ParameterType;
use Joomla\Database\QueryInterface;

\defined('_JEXEC') or die;

final class AvailabilityModel extends BaseModel implements DatabaseAwareInterface, CurrentUserInterface, FormFactoryAwareInterface
{
    use DatabaseAwareTrait;
    use FormFactoryAwareTrait;

    private ?User $currentUser = null;

    public function __construct($config = [], ?MVCFactoryInterface $factory = null)
    {
        parent::__construct($config);
    }

    public function setCurrentUser(User $currentUser): void
    {
        $this->currentUser = $currentUser;
    }

    public function getCourse(int $id): object
    {
        if ($id <= 0) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_AVAILABILITY'), 400);
        }
        $db = $this->getDatabase();
        $query = $db->createQuery()->select('co.*')->from('#__altacourses_courses AS co')
            ->where('co.id = :course_id')->bind(':course_id', $id, ParameterType::INTEGER);
        $this->scopeToCurrentUser($query, 'co.');
        $course = $db->setQuery($query)->loadObject();
        if ($course === null) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_AVAILABILITY_NOT_FOUND'), 404);
        }
        if ((int) $course->checked_out !== 0 && (int) $course->checked_out !== (int) $this->currentUser->id) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_AVAILABILITY_LOCKED'), 409);
        }

        return $course;
    }

    public function getForm(array $data = []): Form
    {
        $form = $this->getFormFactory()->createForm('com_altacourses.availability', ['control' => 'jform']);
        if (!$form->loadFile(dirname(__DIR__, 2) . '/forms/availability.xml')) {
            throw new \RuntimeException('Availability form could not be loaded');
        }
        $field = new \SimpleXMLElement('<field name="availability" type="list" required="true" filter="integer" validate="options" label="COM_ALTACOURSES_AVAILABILITY" />');
        $placeholder = $field->addChild('option');
        $placeholder->addAttribute('value', '');
        $placeholder[0] = Text::_('COM_ALTACOURSES_CHOOSE_AVAILABILITY');
        foreach ($this->getChoices() as $choice) {
            $option = $field->addChild('option');
            $option->addAttribute('value', (string) $choice->seats);
            $option[0] = (string) $choice->label;
        }
        $form->setField($field);
        $form->bind($data);

        return $form;
    }

    /** The historic numbers are status codes, not seat counts. */
    private function getChoices(): array
    {
        $db = $this->getDatabase();
        return $db->setQuery($db->createQuery()->select(['seats', 'label'])
            ->from('#__altacourses_seats')->where('seats IN (1, 2, 3, 4)')->where('state = 1')
            ->order('ordering, id'))->loadObjectList();
    }

    /** Atomically update only availability and its revision, including ownership in the write. */
    public function saveAvailability(int $id, int $availability, int $expectedVersion): void
    {
        if ($id <= 0 || $expectedVersion < 0 || !in_array($availability, [1, 2, 3, 4], true)
            || !in_array($availability, array_map(static fn ($choice): int => (int) $choice->seats, $this->getChoices()), true)) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_AVAILABILITY'), 400);
        }
        $this->getCourse($id);
        $db = $this->getDatabase();
        $query = $db->createQuery()->update('#__altacourses_courses')
            ->set('nr_of_participants = :availability')->bind(':availability', $availability, ParameterType::INTEGER)
            ->set('availability_version = availability_version + 1')
            ->where('id = :course_id')->bind(':course_id', $id, ParameterType::INTEGER)
            ->where('availability_version = :revision')->bind(':revision', $expectedVersion, ParameterType::INTEGER);
        $this->scopeToCurrentUser($query);
        $editorId = (int) $this->currentUser->id;
        $query->where('(checked_out IS NULL OR checked_out = 0 OR checked_out = :editor_id)')
            ->bind(':editor_id', $editorId, ParameterType::INTEGER);
        $db->setQuery($query)->execute();
        if ($db->getAffectedRows() !== 1) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_AVAILABILITY_CONFLICT'), 409);
        }
    }

    private function scopeToCurrentUser(QueryInterface $query, string $prefix = ''): void
    {
        $user = $this->currentUser;
        if ($user === null || $user->guest) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }
        if ($user->authorise('altacourses.manage', 'com_altacourses')) {
            return;
        }
        if (!$user->authorise('altacourses.supplier', 'com_altacourses') || (int) $user->id <= 0) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }
        $supplierId = (int) $user->id;
        $query->where($prefix . 'cr = :current_supplier')->bind(':current_supplier', $supplierId, ParameterType::INTEGER)
            ->where($prefix . 'start_date >= CURRENT_TIMESTAMP');
    }
}
