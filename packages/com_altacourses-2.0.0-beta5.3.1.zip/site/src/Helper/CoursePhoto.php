<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Helper;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Language\Text;
use Advenire\Component\Altacourses\Site\Exception\CourseValidationException;
\defined('_JEXEC') or die;
/** Existing local raster images only; no upload, external URLs, traversal or symlink escapes. */
final class CoursePhoto
{
    private static function root(): ?string
    {
        $root=ComponentHelper::getParams('com_media')->get('image_path','images');
        return is_string($root)&&preg_match('~^[A-Za-z0-9_-]+(?:/[A-Za-z0-9_-]+)*$~D',$root)?$root:null;
    }
    private static function relative(mixed $value): ?string
    {
        $root=self::root();
        if(!is_string($value)||$root===null||strlen($value)>1024||!mb_check_encoding($value,'UTF-8')||!str_starts_with($value,$root.'/')||preg_match('~[\\\\%?#\x00-\x1f\x7f]~',$value)){return null;}
        foreach(explode('/',$value) as $part){if($part===''||str_starts_with($part,'.')){return null;}}
        return preg_match('/\.(?:jpe?g|png|gif|webp|avif)$/iD',$value)?$value:null;
    }
    public static function url(mixed $value): ?string
    {
        $path=self::relative($value);if($path===null){return null;}$root=realpath(JPATH_ROOT.'/'.self::root());$file=realpath(JPATH_ROOT.'/'.$path);
        if($root===false||$file===false||!str_starts_with($file,$root.DIRECTORY_SEPARATOR)||!is_file($file)||!is_readable($file)){return null;}
        $walk=JPATH_ROOT;foreach(explode('/',$path) as $part){$walk.='/'.$part;if(is_link($walk)){return null;}}
        $size=@getimagesize($file);if($size===false||!in_array($size['mime']??'',['image/jpeg','image/png','image/gif','image/webp','image/avif'],true)){return null;}
        return Uri::root(true).'/'.implode('/',array_map('rawurlencode',explode('/',$path)));
    }
    public static function choices(): array
    {
        $root=self::root();if($root===null||!is_dir(JPATH_ROOT.'/'.$root)||!is_readable(JPATH_ROOT.'/'.$root)||is_link(JPATH_ROOT.'/'.$root)){return [];}$choices=[];
        $files=new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator(JPATH_ROOT.'/'.$root,\FilesystemIterator::SKIP_DOTS),\RecursiveIteratorIterator::LEAVES_ONLY,\RecursiveIteratorIterator::CATCH_GET_CHILD);
        foreach($files as $file){if(!$file->isFile()||$file->isLink()){continue;}$path=substr($file->getPathname(),strlen(JPATH_ROOT)+1);if(self::url($path)!==null){$choices[]=$path;}}
        natcasesort($choices);return array_values($choices);
    }
    public static function selection(mixed $value,?string $current=null): ?string
    {
        if($value===''){return null;}
        if(!is_string($value)||self::relative($value)===null||($value!==$current&&self::url($value)===null)){throw new CourseValidationException([Text::_('COM_ALTACOURSES_PHOTO_INVALID')]);}
        return $value;
    }
}
