<?php
/** @package Altacourses.Module @license GNU General Public License version 2 or later */
namespace Advenire\Module\Altarelatedcourses\Site\Dispatcher;
use Joomla\CMS\Dispatcher\AbstractModuleDispatcher;
use Joomla\CMS\Event\PageCache\IsExcludedEvent;
use Joomla\CMS\Helper\HelperFactoryAwareInterface;
use Joomla\CMS\Helper\HelperFactoryAwareTrait;
use Joomla\CMS\Router\Route;
\defined('_JEXEC') or die;
final class Dispatcher extends AbstractModuleDispatcher implements HelperFactoryAwareInterface
{
    use HelperFactoryAwareTrait;
    protected function getLayoutData(): array|false
    {
        $data=parent::getLayoutData();$helper=$this->getHelperFactory()->getHelper('AltarelatedcoursesHelper');$context=$helper->context($this->app,$data['params']);
        if($context===null){return false;}
        // Also exclude empty eligible articles: new courses/links must become visible immediately.
        $this->app->allowCache(false);$this->app->getDispatcher()->addListener('onPageCacheIsExcluded',static function(IsExcludedEvent $e):void{$e->addResult(true);});
        $rows=$helper->courses($this->app,$context);if(!$rows){return false;}
        $wa=$this->app->getDocument()->getWebAssetManager();$wa->getRegistry()->addRegistryFile('media/mod_altarelatedcourses/joomla.asset.json');$wa->useStyle('mod_altarelatedcourses.site');
        $data['rows']=$rows;$data['mode']=$context['mode'];$data['listing']=Route::_('index.php?option=com_altacourses&view=courses',false);return $data;
    }
}
