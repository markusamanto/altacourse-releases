<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Model;

use Joomla\CMS\Language\Text;
use Joomla\Database\ParameterType;

\defined('_JEXEC') or die;

/** Rebooking belongs to the participation transaction; original submissions are immutable. */
trait RebookingTrait
{
    public function getRebookingOptions(int $requestId): array
    {
        $row = $this->getRecord($requestId); // Independent original-supplier/admin scope check.
        if ($row->date_reported !== null || $row->commission_fee !== null) { return []; }
        $owner = (int) $row->supplier_user_id; $today = $this->today(); $source = (int) $row->courseid;
        $q = $this->getDatabase()->createQuery()->select(['co.id', 'co.availability_version', 'co.start_date', 'co.stop_date', 'ct.name AS course_type', 'cp.name AS course_place'])
            ->from('#__altacourses_courses AS co')
            ->join('INNER', '#__altacourses_coursetypes AS ct ON ct.id=co.course_type')
            ->join('INNER', '#__altacourses_courseplaces AS cp ON cp.id=co.course_place')
            ->join('INNER', '#__users AS u ON u.id=co.cr AND u.block=0')
            ->where('co.cr=:rebook_owner')->bind(':rebook_owner', $owner, ParameterType::INTEGER)
            ->where('co.id<>:rebook_source')->bind(':rebook_source', $source, ParameterType::INTEGER)
            ->where('DATE(co.start_date)>=:rebook_today')->bind(':rebook_today', $today)
            ->where('co.state=1 AND co.nr_of_participants IN (1,3)')->order('co.start_date,co.id');
        $items = $this->getDatabase()->setQuery($q)->loadObjectList();
        $extras = $this->getCourseSchedule()->additionalSessions(array_column($items, 'id'));
        foreach ($items as $item) {
            $item->sessions = array_merge([(object) ['start_date' => $item->start_date, 'stop_date' => $item->stop_date]], $extras[(int) $item->id] ?? []);
        }
        return $items;
    }

    public function getRebookingForm(object $row, string $control): \Joomla\CMS\Form\Form
    {
        $form = $this->getForm(['id' => $row->id, 'version' => $row->participation_version, 'status' => 0, 'note' => $row->note], $control);
        $field = new \SimpleXMLElement('<field name="rebook" type="list" label="COM_ALTACOURSES_REBOOK_TO" filter="string" validate="options"/>');
        $field->addChild('option', 'COM_ALTACOURSES_REBOOK_NONE')->addAttribute('value', '0');
        foreach ($this->getRebookingOptions((int) $row->id) as $target) {
            $dates = array_map(static fn ($s): string => substr($s->start_date, 0, 10) . ' – ' . substr($s->stop_date, 0, 10), $target->sessions);
            $label = '#' . $target->id . ' · ' . $target->course_type . ' · ' . $target->course_place . ' · ' . implode(' / ', $dates);
            $field->addChild('option', htmlspecialchars($label, ENT_XML1 | ENT_QUOTES, 'UTF-8'))
                ->addAttribute('value', $target->id . ':' . $target->availability_version);
        }
        $form->setField($field); $form->setValue('rebook', null, '0');
        return $form;
    }

    private function validateRebooking(string $value): void
    {
        if ($value !== '0' && (!preg_match('/^([1-9][0-9]*):([0-9]+)$/D', $value, $parts)
            || (float) $parts[1] > 2147483647 || (float) $parts[2] > 2147483647)) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_REBOOK_INVALID'), 400);
        }
    }

    /** Called only for an unreported locked source row in saveCourseReports(). */
    private function moveRequest(object $row, array $report, string $now): void
    {
        [$destination, $revision] = array_map('intval', explode(':', $report['rebook']));
        $actor = $this->getActor(); $db = $this->getDatabase();
        if ($report['status'] !== 0 || $row->date_reported !== null || (int) $row->participated !== 0
            || $row->commission_fee !== null || (int) $row->courseid === $destination) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_REBOOK_INVALID'), 409);
        }
        if ((int) $row->participation_version !== $report['version']
            || ((int) $row->checked_out !== 0 && (int) $row->checked_out !== (int) $actor->id)) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_PARTICIPATION_CONFLICT'), 409);
        }
        if (!$row->first_start || substr($row->first_start, 0, 10) > $this->today()) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_PARTICIPATION_NOT_STARTED'), 409);
        }
        // Serialize with SMTP claims; an in-flight original message must finish before a move.
        $outbox = $db->createQuery()->select('o.state')->from('#__altacourses_notification_outbox AS o')
            ->join('INNER', '#__altacourses_request_submissions AS sub ON sub.id=o.submission_id')->where('sub.request_id=' . (int) $row->id);
        $outbox->setQuery((string) $outbox . ' FOR UPDATE');
        if (in_array('sending', $db->setQuery($outbox)->loadColumn(), true)) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_REBOOK_DELIVERY'), 409);
        }
        $target = $this->rebookingCourse($destination, true);
        if (!$target || (int) $target->cr !== (int) $row->supplier_user_id || (int) $target->state !== 1
            || $target->blocked === null || (int) $target->blocked !== 0 || !in_array((int) $target->seats, [1,3], true)
            || !$target->start_date || substr($target->start_date, 0, 10) < $this->today()
            || (int) $target->availability_version !== $revision) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_REBOOK_CHANGED'), 409);
        }
        $duplicate = $db->createQuery()->select('id')->from('#__altacourses_requests')
            ->where('clientid=' . (int) $row->clientid)->where('courseid=' . $destination)
            ->where('id<>' . (int) $row->id)->where('(canceled IS NULL OR canceled=0)');
        $duplicate->setQuery((string) $duplicate . ' FOR UPDATE');
        if ($db->setQuery($duplicate)->loadResult() !== null) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_REBOOK_DUPLICATE'), 409);
        }
        $source = $this->rebookingCourse((int) $row->courseid);
        $audit = (object) ['request_id' => (int) $row->id, 'from_course_id' => (int) $row->courseid, 'to_course_id' => $destination,
            'from_json' => $this->rebookingSnapshot($source), 'to_json' => $this->rebookingSnapshot($target),
            'supplier_user_id' => (int) $row->supplier_user_id, 'created_at' => $now, 'created_by' => (int) $actor->id,
            'request_version' => $report['version'], 'previous_note' => (string) $row->note, 'note' => $report['note']];
        $db->insertObject('#__altacourses_request_rebookings', $audit, 'id');
        $query = $db->createQuery()->update('#__altacourses_requests')->set('courseid=' . $destination)
            ->set('participated=0,canceled=0,date_reported=NULL,reported_by=NULL,participation_version=participation_version+1')
            ->set('note=' . $db->quote($report['note']))->where('id=' . (int) $row->id)
            ->where('participation_version=' . $report['version'])->where('date_reported IS NULL AND commission_fee IS NULL');
        $db->setQuery($query)->execute();
        if ($db->getAffectedRows() !== 1) { throw new \RuntimeException(Text::_('COM_ALTACOURSES_PARTICIPATION_CONFLICT'), 409); }
    }

    private function rebookingCourse(int $id, bool $lock = false): ?object
    {
        $q = $this->getDatabase()->createQuery()->select(['co.*', 'co.nr_of_participants AS seats', 'u.block AS blocked', 'ct.name AS course_type_name', 'cp.name AS course_place_name', 'l1.name AS leader1', 'l2.name AS leader2'])
            ->from('#__altacourses_courses AS co')
            ->join('INNER', '#__altacourses_coursetypes AS ct ON ct.id=co.course_type')
            ->join('INNER', '#__altacourses_courseplaces AS cp ON cp.id=co.course_place')
            ->join('LEFT', '#__users AS u ON u.id=co.cr')
            ->join('LEFT', '#__altacourses_courseleaders AS l1 ON l1.id=co.course_leader_1')
            ->join('LEFT', '#__altacourses_courseleaders AS l2 ON l2.id=co.course_leader_2')
            ->where('co.id=:rebook_course')->bind(':rebook_course', $id, ParameterType::INTEGER);
        if ($lock) { $q->setQuery((string) $q . ' FOR UPDATE'); }
        return $this->getDatabase()->setQuery($q)->loadObject();
    }

    private function rebookingSnapshot(object $course): string
    {
        return json_encode(['id' => (int) $course->id, 'course_type' => $course->course_type_name, 'course_place' => $course->course_place_name,
            'leader1' => $course->leader1, 'leader2' => $course->leader2,
            'sessions' => array_merge([['start_date' => $course->start_date, 'stop_date' => $course->stop_date]],
                array_map(static fn ($s): array => ['start_date' => $s->start_date, 'stop_date' => $s->stop_date], $this->getCourseSchedule()->additionalSessions([(int) $course->id])[(int) $course->id] ?? []))], JSON_THROW_ON_ERROR);
    }
}
