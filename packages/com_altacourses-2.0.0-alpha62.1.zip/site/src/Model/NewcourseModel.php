<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Model;

use Joomla\CMS\Language\Text;
use Advenire\Component\Altacourses\Site\Exception\CourseValidationException;

\defined('_JEXEC') or die;

final class NewcourseModel extends CourseformModel
{
    public function createCourse(array $input, string $submission): int
    {
        $administrator = $this->isAdministrator();
        if (!$administrator && array_key_exists('state', $input)) {
            throw new CourseValidationException([Text::_('COM_ALTACOURSES_NEW_FIELDS_INVALID')]);
        }
        if (!preg_match('/^[a-f0-9]{64}$/D', $submission)) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_NEW_EXPIRED'), 409);
        }
        $token = hash('sha256', $this->currentUser->id . ':' . $submission);
        $existing = $this->existingSubmission($token, $administrator);
        if ($existing !== null) {
            $this->setState('creation.reused', true);
            return $existing;
        }
        $data = $this->validateData($input);
        $db = $this->getDatabase();
        $db->transactionStart();
        try {
            $course = (object) ['start_date' => $data['ranges'][0]['start_date'], 'stop_date' => $data['ranges'][0]['stop_date'],
                'course_type' => (int) $data['course_type'], 'course_place' => (int) $data['course_place'],
                'course_leader_1' => (int) $data['course_leader_1'], 'course_leader_2' => (int) $data['course_leader_2'] ?: null,
                'course_price' => $data['course_price'], 'lodging_price' => $data['lodging_price'],
                'course_notes' => $data['course_notes'], 'lodging_included' => $data['lodging_included'],
                'nr_of_participants' => (int) $data['availability'], 'cr' => $administrator ? (int) $data['supplier'] : (int) $this->currentUser->id,
                'created_by' => (int) $this->currentUser->id, 'state' => (int) $data['state'], 'ordering' => 0, 'checked_out' => 0,
                'availability_version' => 0, 'creation_token' => $token];
            $db->insertObject('#__altacourses_courses', $course, 'id');
            if (isset($data['ranges'][1])) {
                $session = (object) ($data['ranges'][1] + ['course_id' => (int) $course->id, 'ordering' => 2]);
                $db->insertObject('#__altacourses_course_sessions', $session, 'id');
            }
            $db->transactionCommit();
            return (int) $course->id;
        } catch (\Throwable $exception) {
            $db->transactionRollback();
            $existing = $this->existingSubmission($token, $administrator);
            if ($existing !== null) {
                $this->setState('creation.reused', true);
                return $existing;
            }
            throw $exception;
        }
    }

    private function existingSubmission(string $token, bool $administrator): ?int
    {
        $db = $this->getDatabase();
        $query = $db->createQuery()->select(['id', 'created_by', 'cr'])->from('#__altacourses_courses')
            ->where('creation_token=:token')->bind(':token', $token);
        $existing = $db->setQuery($query)->loadObject();
        if ($existing === null) {
            return null;
        }
        if ((int) $existing->created_by !== (int) $this->currentUser->id
            || (!$administrator && (int) $existing->cr !== (int) $this->currentUser->id)) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }
        return (int) $existing->id;
    }
}
