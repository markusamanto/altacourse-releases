<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\View\Courses;

use Advenire\Component\Altacourses\Administrator\Service\CoursePriceAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\CoursePriceAwareTrait;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Pagination\Pagination;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;
use Joomla\Component\Content\Site\Helper\RouteHelper;

use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareTrait;

\defined('_JEXEC') or die;

final class HtmlView extends BaseHtmlView implements CourseScheduleAwareInterface, CoursePriceAwareInterface
{
    use CourseScheduleAwareTrait;
    use CoursePriceAwareTrait;

    public bool $multipleTypes = true;
    public array $articles = [];
    public array $signupAvailable = [];
    public array $sessions = [];
    public array $totalPrices = [];
    public array $items = [];
    public array $types = [];
    public array $regions = [];
    public array $filters = [];
    public ?Pagination $pagination = null;

    public function articleHref(mixed $value,int $courseId): ?string
    {
        if (!is_scalar($value)||!ctype_digit((string)$value)) { return null; }
        $article=$this->articles[(int)$value]??null;if ($article===null) { return null; }
        $uri=new Uri(RouteHelper::getArticleRoute($article->id.':'.$article->alias,(int)$article->catid,$article->language));
        $uri->setVar('coid',$courseId);return Route::_($uri->toString(),false);
    }

    public function display($tpl = null): void
    {
        $model = $this->getModel();
        $this->items = $model->getItems();
        $articleIds=[];
        foreach ($this->items as $item) {
            array_push($articleIds,$item->place_article,$item->leader1_article,$item->leader2_article);
            $this->signupAvailable[(int)$item->id]=$this->getModel('Signup')->canEnquire((int)$item->id);
            $amount = $this->getCoursePrice()->formatTotal($item->course_price, $item->lodging_price, $item->lodging_included);
            $this->totalPrices[(int) $item->id] = $amount === null ? '—' : $amount . ' ' . Text::_('COM_ALTACOURSES_CURRENCY');
        }
        $this->articles=$model->getArticles($articleIds,$this->getDocument()->getLanguage());
        $this->sessions = $this->getCourseSchedule()->additionalSessions(array_map(static fn ($course): int => (int) $course->id, $this->items));
        $this->types = $model->getOptions('coursetypes');
        $this->regions = $model->getOptions('regions');
        $this->getDocument()->setTitle(Text::_('COM_ALTACOURSES_COURSES_TITLE'));
        $this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.site');
        parent::display($tpl);
    }
}
