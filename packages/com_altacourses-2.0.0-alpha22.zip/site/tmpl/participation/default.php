<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;
?>
<section aria-labelledby="participation-title">
    <h1 id="participation-title"><?php echo $this->escape(Text::_('COM_ALTACOURSES_PARTICIPATION_TITLE')); ?></h1>
    <p><a href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=participations', false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_PARTICIPATION_BACK')); ?></a></p>
    <h2><?php echo $this->escape(($this->contact['firstname'] ?? '') . ' ' . ($this->contact['lastname'] ?? '')); ?></h2>
    <p><?php echo $this->escape(($this->contact['company'] ?? '') . ' · ' . ($this->contact['email'] ?? '')); ?></p>
    <dl>
        <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_COURSE_TYPE')); ?></dt><dd><?php echo $this->escape($this->course['course_type'] ?? ''); ?></dd>
        <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_PLACE')); ?></dt><dd><?php echo $this->escape($this->course['course_place'] ?? ''); ?></dd>
        <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_DATES')); ?></dt><dd><?php foreach ($this->course['sessions'] ?? [] as $part) : ?><div><?php echo $this->escape(substr($part['start_date'] ?? '', 0, 10) . ' – ' . substr($part['stop_date'] ?? '', 0, 10)); ?></div><?php endforeach; ?></dd>
        <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_PARTICIPATION_REPORTED_AT')); ?></dt><dd data-reported-at><?php echo $this->escape($this->item->date_reported ?? Text::_('COM_ALTACOURSES_PARTICIPATION_PENDING')); ?></dd>
    </dl>
    <p><a href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=contact&id=' . (int) $this->item->id, false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_PARTICIPATION_HISTORY')); ?></a></p>
    <?php if (!$this->started) : ?><p><?php echo $this->escape(Text::_('COM_ALTACOURSES_PARTICIPATION_NOT_STARTED')); ?></p><?php else : ?>
    <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_PARTICIPATION_REPORT_DATE')); ?></p>
    <form id="participation-form" method="post" action="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&task=participation.save', false)); ?>">
        <?php echo $this->form->renderField('id'), $this->form->renderField('version'), $this->form->renderField('status'), $this->form->renderField('note'); ?>
        <button class="btn btn-primary" type="submit"><?php echo $this->escape(Text::_('JSAVE')); ?></button>
        <?php echo HTMLHelper::_('form.token'); ?>
    </form>
    <?php endif; ?>
</section>
