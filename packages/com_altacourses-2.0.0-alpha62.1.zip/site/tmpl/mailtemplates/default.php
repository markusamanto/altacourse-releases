<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
\defined('_JEXEC') or die;
?>
<section class="altacourses-portal" aria-labelledby="altacourses-mailtemplates-heading">
    <h1 id="altacourses-mailtemplates-heading"><?php echo $this->escape(Text::_('COM_ALTACOURSES_MAILTEMPLATES_TITLE')); ?></h1>
    <p><a href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=dashboard', false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_BACK_TO_DASHBOARD')); ?></a></p>
    <p><a class="btn btn-success" href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=mailtemplate&fresh=1', false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_MAILTEMPLATE_ADD')); ?></a></p>
    <form method="get" action="<?php echo $this->escape(Route::_('index.php', false)); ?>">
        <input type="hidden" name="option" value="com_altacourses">
        <input type="hidden" name="view" value="mailtemplates">
        <label for="mailtemplate-course-type"><?php echo $this->escape(Text::_('COM_ALTACOURSES_COURSE_TYPE')); ?></label>
        <select id="mailtemplate-course-type" name="course_type" class="form-select">
            <option value=""<?php echo $this->filterCourseType === null ? ' selected' : ''; ?>><?php echo $this->escape(Text::_('COM_ALTACOURSES_MAILTEMPLATE_ALL_RECORDS')); ?></option>
            <option value="0"<?php echo $this->filterCourseType === 0 ? ' selected' : ''; ?>><?php echo $this->escape(Text::_('COM_ALTACOURSES_MAILTEMPLATE_ANY_TYPE')); ?></option>
            <?php foreach ($this->courseTypes as $choice) : ?>
                <option value="<?php echo (int) $choice->id; ?>"<?php echo $this->filterCourseType === (int) $choice->id ? ' selected' : ''; ?>><?php echo $this->escape($choice->name . ' (#' . (int) $choice->id . ')'); ?></option>
            <?php endforeach; ?>
        </select>
        <button type="submit" class="btn btn-success"><?php echo $this->escape(Text::_('COM_ALTACOURSES_FILTER')); ?></button>
        <a href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=mailtemplates', false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_CLEAR_FILTERS')); ?></a>
    </form>
    <?php if (!$this->items) : ?><p><?php echo $this->escape(Text::_('COM_ALTACOURSES_MAILTEMPLATES_EMPTY')); ?></p><?php else : ?>
        <div class="table-responsive"><table class="table table-striped">
            <caption><?php echo $this->escape(Text::_('COM_ALTACOURSES_MAILTEMPLATES_TITLE')); ?></caption>
            <thead><tr>
                <?php foreach (['JGRID_HEADING_ID', 'COM_ALTACOURSES_MAILTEMPLATE_TYPE', 'COM_ALTACOURSES_COURSE_TYPE', 'COM_ALTACOURSES_MAILTEMPLATE_SUBJECT', 'COM_ALTACOURSES_MAILTEMPLATE_FROM_NAME', 'COM_ALTACOURSES_MAILTEMPLATE_FROM_EMAIL', 'JSTATUS', 'COM_ALTACOURSES_ACTIONS'] as $heading) : ?>
                    <th scope="col"><?php echo $this->escape(Text::_($heading)); ?></th>
                <?php endforeach; ?>
            </tr></thead>
            <tbody><?php foreach ($this->items as $item) : ?>
                <tr data-mailtemplate-id="<?php echo (int) $item->id; ?>">
                    <td><?php echo (int) $item->id; ?></td><td><?php echo (int) $item->type; ?></td>
                    <td><?php echo $this->escape((int) $item->course_type === 0 ? Text::_('COM_ALTACOURSES_MAILTEMPLATE_ANY_TYPE') : ($item->course_type_name ?? Text::sprintf('COM_ALTACOURSES_MAILTEMPLATE_KEEP_TYPE', (int) $item->course_type))); ?></td>
                    <th scope="row"><?php echo $this->escape($item->subject); ?></th>
                    <td><?php echo $this->escape($item->from_name); ?></td><td><?php echo $this->escape($item->from_email); ?></td>
                    <td><?php echo $this->escape(Text::_(match ((string) $item->state) { '1' => 'JPUBLISHED', '0' => 'JUNPUBLISHED', default => 'COM_ALTACOURSES_MAILTEMPLATE_OTHER_STATE' })); ?></td>
                    <td><a class="btn btn-success" href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=mailtemplate&id=' . (int) $item->id . '&fresh=1', false)); ?>"><?php echo $this->escape(Text::_('JEDIT')); ?></a></td>
                </tr>
            <?php endforeach; ?></tbody>
        </table></div>
    <?php endif; ?>
</section>
