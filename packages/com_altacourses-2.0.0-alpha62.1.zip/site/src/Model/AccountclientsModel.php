<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Model;

use Joomla\CMS\Language\Text;
use Joomla\Database\ParameterType;
use Joomla\Database\QueryInterface;

\defined('_JEXEC') or die;

/** One row per stored client ID, including historical requests without submission snapshots. */
final class AccountclientsModel extends RequestrecordsModel
{
    public function getAccountRecord(int $id): object
    {
        $this->requireAdministrator();
        $db = $this->getDatabase();
        $query = $db->createQuery()->select(['id', 'name', 'invoice_address', 'invoice_address_2', 'invoice_zip',
            'invoice_city', 'invoice_country', 'note', 'state'])->from('#__altacourses_accounts')
            ->where('id=:id')->bind(':id', $id, ParameterType::INTEGER);
        $record = $db->setQuery($query)->loadObject();
        if ($id <= 0 || $record === null) { throw new \RuntimeException(Text::_('COM_ALTACOURSES_ACCOUNT_NOT_FOUND'), 404); }
        // This read-only view remains available while another administrator edits the account.
        return $record;
    }

    public function getItems(): array
    {
        $this->requireAdministrator();
        $query = $this->clientQuery()->select(['c.id', 'c.firstname', 'c.lastname', 'c.company', 'c.email',
            'a.id AS account_id', 'a.name AS account_name', 'activity.latest_activity'])
            ->order('activity.latest_activity DESC, c.id DESC');
        return $this->getDatabase()->setQuery($query, (int) $this->getState('list.start', 0), 20)->loadObjectList();
    }

    public function getTotal(): int
    {
        $this->requireAdministrator();
        return (int) $this->getDatabase()->setQuery($this->clientQuery()->select('COUNT(*)'))->loadResult();
    }

    private function clientQuery(): QueryInterface
    {
        $this->requireAdministrator();
        $db = $this->getDatabase();
        // Cast before testing the legacy zero date so MySQL strict date validation is not relaxed.
        $activity = $db->createQuery()->select(['r.clientid',
            "MAX(COALESCE(NULLIF(CAST(r.date_created AS CHAR), '0000-00-00 00:00:00'), s.created_at)) AS latest_activity"])
            ->from('#__altacourses_requests AS r')
            ->join('LEFT', '#__altacourses_request_submissions AS s ON s.request_id=r.id')
            ->where('r.asked_for_info IN (0, 1)')->group('r.clientid');
        $query = $db->createQuery()->from('#__altacourses_clients AS c')
            // VARCHAR references must not coerce e.g. "1other" or "01" into account ID 1.
            ->join('INNER', '#__altacourses_accounts AS a ON CAST(c.account AS BINARY)=CAST(a.id AS BINARY)')
            ->join('LEFT', '(' . $activity . ') AS activity ON activity.clientid=c.id');
        $accountId = (int) $this->getState('account.id', 0);
        if ($accountId > 0) {
            $query->where('a.id=:account_id')->bind(':account_id', $accountId, ParameterType::INTEGER);
        }
        return $query;
    }
}
