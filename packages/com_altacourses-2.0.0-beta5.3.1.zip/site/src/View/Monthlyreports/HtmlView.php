<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\View\Monthlyreports;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;

\defined('_JEXEC') or die;

final class HtmlView extends BaseHtmlView
{
    public string $month = '';
    public string $mode = 'off';
    public array $messages = [];
    public ?string $blockedReason = null;
    public function display($tpl = null): void
    {
        $this->mode = $this->getModel()->mode();
        $this->messages = $this->getModel()->getMessages($this->month);
        $this->blockedReason = $this->getModel()->blockedReason();
        $this->getDocument()->setTitle(Text::_('COM_ALTACOURSES_MONTHLY_TITLE'));
        $this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.site');
        parent::display($tpl);
    }
}
