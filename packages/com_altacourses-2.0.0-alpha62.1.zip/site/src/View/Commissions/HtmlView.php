<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\View\Commissions;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;

\defined('_JEXEC') or die;

final class HtmlView extends BaseHtmlView
{
    public string $month = '';
    public array $report = [];
    public array $rates = [];

    public function display($tpl = null): void
    {
        $this->report = $this->getModel()->getReport($this->month);
        $this->rates = $this->getModel()->getRates();
        $this->getDocument()->setTitle(Text::_('COM_ALTACOURSES_COMMISSION_TITLE'));
        $this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.site');
        parent::display($tpl);
    }
}
