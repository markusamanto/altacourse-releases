<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */
namespace Advenire\Component\Altacourses\Site\Model;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\CMS\MVC\Model\BaseModel;
use Joomla\CMS\User\CurrentUserInterface;
use Joomla\CMS\User\User;
use Joomla\CMS\User\UserFactoryAwareInterface;
use Joomla\CMS\User\UserFactoryAwareTrait;
use Joomla\Database\DatabaseAwareInterface;
use Joomla\Database\DatabaseAwareTrait;

\defined('_JEXEC') or die;

class EnquiriesModel extends BaseModel implements DatabaseAwareInterface, CurrentUserInterface, UserFactoryAwareInterface
{
    protected const ASKED_FOR_INFO = 1;

    use DatabaseAwareTrait;
    use UserFactoryAwareTrait;
    private ?User $currentUser = null;

    public function __construct($config = [], ?MVCFactoryInterface $factory = null) { parent::__construct($config); }
    public function setCurrentUser(User $currentUser): void { $this->currentUser = $currentUser; }

    public function requireAdministrator(): void
    {
        if ($this->currentUser === null || $this->currentUser->guest) { throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403); }
        $user = $this->getUserFactory()->loadUserById((int) $this->currentUser->id);
        if ($user->guest || $user->block || !$user->authorise('altacourses.manage', 'com_altacourses')) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }
    }

    protected function currentActorId(): int
    {
        $this->requireAdministrator();
        return (int) $this->currentUser->id;
    }

    public function getTotal(): int
    {
        $this->requireAdministrator();
        return (int) $this->getDatabase()->setQuery('SELECT COUNT(*) FROM #__altacourses_request_submissions s JOIN #__altacourses_requests r ON r.id=s.request_id WHERE r.asked_for_info=' . static::ASKED_FOR_INFO)->loadResult();
    }

    public function getItems(): array
    {
        $this->requireAdministrator();
        $query = $this->getDatabase()->createQuery()->select(['s.request_id', 's.created_at', 's.supplier_email', 's.contact_json', 's.course_json', 's.supplier_user_id'])
            ->from('#__altacourses_request_submissions AS s')->join('INNER', '#__altacourses_requests AS r ON r.id=s.request_id')
            ->where('r.asked_for_info=' . static::ASKED_FOR_INFO)->order('s.id DESC');
        return $this->getDatabase()->setQuery($query, (int) $this->getState('list.start', 0), 20)->loadObjectList();
    }
}
