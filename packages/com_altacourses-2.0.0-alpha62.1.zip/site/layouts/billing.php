<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
\defined('_JEXEC') or die;
$v=$displayData['view'];$title=$v->legacy?'COM_ALTACOURSES_BILLING_LEGACY':'COM_ALTACOURSES_KEYACCOUNTS_TITLE';
?>
<section class="altacourses-portal" aria-labelledby="altacourses-billing-heading">
 <h1 id="altacourses-billing-heading"><?php echo $v->escape(Text::_($title)); ?></h1>
 <p><a href="<?php echo $v->escape(Route::_('index.php?option=com_altacourses&view='.($v->legacy?'keyaccounts':'legacykeyaccounts'),false)); ?>"><?php echo $v->escape(Text::_($v->legacy?'COM_ALTACOURSES_KEYACCOUNTS_TITLE':'COM_ALTACOURSES_BILLING_LEGACY')); ?></a></p>
 <p><a href="<?php echo $v->escape(Route::_('index.php?option=com_altacourses&view=dashboard',false)); ?>"><?php echo $v->escape(Text::_('COM_ALTACOURSES_BACK_TO_DASHBOARD')); ?></a></p>
 <?php if ($v->legacy) : ?><p><?php echo $v->escape(Text::_('COM_ALTACOURSES_BILLING_LEGACY_INTRO')); ?></p><?php endif; ?>
 <?php if (!$v->items) : ?><p><?php echo $v->escape(Text::_('COM_ALTACOURSES_BILLING_EMPTY')); ?></p><?php else : ?>
 <div class="table-responsive"><table class="table table-striped altacourses-billing-table">
  <caption><?php echo $v->escape(Text::_($title)); ?></caption>
  <thead><tr><?php foreach (['NAME',$v->legacy?'ORGANISATION':'ACCOUNT','START','INVOICED','RECEIVED','NO_INVOICING','ACTIONS'] as $f) : ?><th scope="col"><?php echo $v->escape(Text::_('COM_ALTACOURSES_BILLING_'.$f)); ?></th><?php endforeach; ?></tr></thead>
  <tbody><?php foreach ($v->items as $row) :
   $id=$v->legacy?(int)$row->record_id:(int)$row->request_id;
   $red=(string)($row->no_invoicing??'0')==='1';$green=(string)($row->invoiced??'0')==='1';
   $url='index.php?option=com_altacourses&view=keyaccount&id='.$id.'&legacy='.(int)$v->legacy.'&fresh=1';
  ?>
   <tr data-billing-id="<?php echo $id; ?>" class="<?php echo $red?'billing-no-invoicing':($green?'billing-invoiced':''); ?>">
    <th scope="row"><?php echo $v->escape(trim((string)($row->firstname??'').' '.(string)($row->lastname??''))); ?></th>
    <td><?php echo $v->escape((string)($row->account_name??'')); ?></td>
    <td><?php echo $v->escape($row->course_start?substr($row->course_start,0,10):Text::_('COM_ALTACOURSES_BILLING_UNKNOWN_DATE')); ?></td>
    <?php foreach (['invoiced','received','no_invoicing'] as $f) : ?><td><input type="checkbox" disabled<?php echo (string)($row->$f??'0')==='1'?' checked':''; ?> aria-label="<?php echo $v->escape(Text::_('COM_ALTACOURSES_BILLING_'.strtoupper($f))); ?>"></td><?php endforeach; ?>
    <td>
     <?php if (!$v->legacy) : ?><a class="btn btn-success btn-sm" data-billing-view href="<?php echo $v->escape(Route::_('index.php?option=com_altacourses&view=client&id='.(int)$row->client_id,false)); ?>"><?php echo $v->escape(Text::_('COM_ALTACOURSES_ACCOUNTCLIENTS_VIEW')); ?></a><?php endif; ?>
     <a class="btn btn-success btn-sm" data-billing-edit href="<?php echo $v->escape(Route::_($url,false)); ?>"><?php echo $v->escape(Text::_('COM_ALTACOURSES_BILLING_EDIT')); ?></a>
    </td>
   </tr>
  <?php endforeach; ?></tbody>
 </table></div>
 <?php echo $v->pagination->getListFooter(); ?>
 <?php endif; ?>
</section>
