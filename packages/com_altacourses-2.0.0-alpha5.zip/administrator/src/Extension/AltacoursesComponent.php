<?php

/**
 * @package     Altacourses.Administrator
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Administrator\Extension;

use Joomla\CMS\Component\Router\RouterServiceInterface;
use Joomla\CMS\Component\Router\RouterServiceTrait;
use Joomla\CMS\Extension\MVCComponent;

\defined('_JEXEC') or die;

final class AltacoursesComponent extends MVCComponent implements RouterServiceInterface
{
    use RouterServiceTrait;
}
