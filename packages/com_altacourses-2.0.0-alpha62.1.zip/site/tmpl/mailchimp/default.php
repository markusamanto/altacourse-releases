<?php
\defined('_JEXEC') or die;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
?>
<h1 id="altacourses-mailchimp-heading"><?php echo Text::_('COM_ALTACOURSES_MC_TITLE'); ?></h1>
<p><?php echo Text::_('COM_ALTACOURSES_MC_INTRO'); ?></p>
<p><?php echo Text::_('COM_ALTACOURSES_MC_MODE'); ?>: <strong><?php echo Text::_('COM_ALTACOURSES_MC_MODE_'.strtoupper($this->settings['mode'])); ?></strong></p>
<?php if(!$this->settings['configured']||($this->settings['mode']==='live'&&!$this->settings['key_configured'])): ?><p class="alert alert-warning"><?php echo Text::_('COM_ALTACOURSES_MC_CONFIGURE'); ?></p><?php endif; ?>
<h2><?php echo Text::_('COM_ALTACOURSES_MC_PREVIEW'); ?></h2>
<p><?php echo Text::_('COM_ALTACOURSES_MC_PREVIEW_HELP'); ?></p>
<?php if(!$this->candidates): ?><p><?php echo Text::_('COM_ALTACOURSES_MC_EMPTY'); ?></p><?php else: ?>
<div class="table-responsive"><table class="table"><thead><tr><?php foreach(['NAME','EMAIL','START','STATUS'] as $key): ?><th><?php echo Text::_('COM_ALTACOURSES_MC_'.$key); ?></th><?php endforeach; ?></tr></thead><tbody>
<?php foreach($this->candidates as $c): ?><tr data-mailchimp-request="<?php echo (int)$c->request_id; ?>"><td><?php echo $this->escape(trim(($c->firstname??'').' '.($c->lastname??''))); ?> (#<?php echo (int)$c->request_id; ?>)</td><td><?php echo $this->escape($c->email); ?></td><td><?php echo $this->escape(substr($c->start_date,0,10)); ?></td><td><?php echo Text::_('COM_ALTACOURSES_MC_STATE_'.strtoupper($c->hash===null?'invalid':($c->record->state??'eligible'))); ?></td></tr><?php endforeach; ?>
</tbody></table></div><?php endif; ?>
<h2><?php echo Text::_('COM_ALTACOURSES_MC_HISTORY'); ?></h2>
<p><?php echo Text::_('COM_ALTACOURSES_MC_HISTORY_HELP'); ?></p>
<div class="table-responsive"><table class="table"><thead><tr><?php foreach(['UPDATED','NAME','STATUS','ERROR','ACTIONS'] as $key): ?><th><?php echo Text::_('COM_ALTACOURSES_MC_'.$key); ?></th><?php endforeach; ?></tr></thead><tbody>
<?php foreach($this->history as $row): ?><tr><td><?php echo $this->escape($row->updated_at); ?></td><td><?php echo $this->escape(trim(($row->firstname??'').' '.($row->lastname??''))); ?> (#<?php echo (int)$row->request_id; ?>)</td><td><?php echo Text::_('COM_ALTACOURSES_MC_STATE_'.strtoupper($row->state)); ?></td><td><?php echo $this->escape($row->last_error??''); ?></td><td><?php if($row->state==='error'): ?><form method="post" action="<?php echo Route::_('index.php?option=com_altacourses&task=mailchimp.retry'); ?>"><input type="hidden" name="jform[id]" value="<?php echo (int)$row->id; ?>"><input type="hidden" name="jform[revision]" value="<?php echo (int)$row->revision; ?>"><label><input type="checkbox" name="jform[review]" value="1" required> <?php echo Text::_('COM_ALTACOURSES_MC_REVIEW'); ?></label><?php echo HTMLHelper::_('form.token'); ?><button type="submit" class="btn btn-warning"><?php echo Text::_('COM_ALTACOURSES_MC_RETRY'); ?></button></form><?php endif; ?></td></tr><?php endforeach; ?>
</tbody></table></div>
