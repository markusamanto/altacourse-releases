<?php

/**
 * @package     Altacourses.Administrator
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Administrator\Factory;

use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareTrait;
use Advenire\Component\Altacourses\Administrator\Service\CoursePriceAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\CoursePriceAwareTrait;
use Advenire\Component\Altacourses\Administrator\Service\NotificationAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\NotificationAwareTrait;
use Joomla\CMS\MVC\Factory\MVCFactory as BaseMVCFactory;

\defined('_JEXEC') or die;

final class MVCFactory extends BaseMVCFactory implements CourseScheduleAwareInterface, CoursePriceAwareInterface, NotificationAwareInterface
{
    use CourseScheduleAwareTrait;
    use CoursePriceAwareTrait;
    use NotificationAwareTrait;

    private string $reportingTimezone = 'UTC';

    public function setReportingTimezone(string $timezone): void { $this->reportingTimezone = $timezone; }

    public function createModel($name, $prefix = '', array $config = [])
    {
        $model = parent::createModel($name, $prefix, $config);
        if ($model instanceof CourseScheduleAwareInterface) {
            $model->setCourseSchedule($this->getCourseSchedule());
        }
        if ($model instanceof CoursePriceAwareInterface) {
            $model->setCoursePrice($this->getCoursePrice());
        }
        if ($model instanceof NotificationAwareInterface) { $model->setNotifications($this->getNotifications()); }
        if ($model instanceof \Advenire\Component\Altacourses\Site\Model\ParticipationModel) {
            $model->setReportingTimezone($this->reportingTimezone);
        }
        return $model;
    }

    public function createView($name, $prefix = '', $type = '', array $config = [])
    {
        $view = parent::createView($name, $prefix, $type, $config);
        if ($view instanceof CourseScheduleAwareInterface) {
            $view->setCourseSchedule($this->getCourseSchedule());
        }
        if ($view instanceof CoursePriceAwareInterface) {
            $view->setCoursePrice($this->getCoursePrice());
        }
        return $view;
    }
}
