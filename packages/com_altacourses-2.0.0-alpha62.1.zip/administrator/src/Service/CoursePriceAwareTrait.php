<?php

/**
 * @package     Altacourses.Administrator
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Administrator\Service;

\defined('_JEXEC') or die;

trait CoursePriceAwareTrait
{
    private ?CoursePrice $coursePrice = null;

    public function setCoursePrice(CoursePrice $price): void
    {
        $this->coursePrice = $price;
    }

    protected function getCoursePrice(): CoursePrice
    {
        return $this->coursePrice ?? throw new \LogicException('Course price service has not been injected');
    }
}
