<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Model;

use Advenire\Component\Altacourses\Site\Exception\CourseValidationException;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Language\Text;
use Joomla\Database\ParameterType;
use Joomla\Database\QueryInterface;

\defined('_JEXEC') or die;

final class EditcourseModel extends CourseformModel
{
    public function getRecord(int $id): array
    {
        $administrator = $this->isAdministrator();
        if ($id <= 0) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_FILTER'), 400);
        }
        $db = $this->getDatabase();
        $query = $db->createQuery()->select('*')->from('#__altacourses_courses')
            ->where('id=:id')->bind(':id', $id, ParameterType::INTEGER);
        $this->scopeToOwner($query, $administrator);
        $course = $db->setQuery($query)->loadObject();
        if ($course === null) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_AVAILABILITY_NOT_FOUND'), 404);
        }
        if ((int) $course->checked_out !== 0 && (int) $course->checked_out !== (int) $this->currentUser->id) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_AVAILABILITY_LOCKED'), 409);
        }
        $query = $db->createQuery()->select('*')->from('#__altacourses_course_sessions')
            ->where('course_id=:course')->bind(':course', $id, ParameterType::INTEGER)->order('ordering, id');
        return ['course' => $course, 'sessions' => $db->setQuery($query)->loadObjectList()];
    }

    public function formData(array $record): array
    {
        $course = $record['course'];
        $data = [];
        foreach (self::FIELDS as $name) {
            $data[$name] = (string) ($course->$name ?? '');
        }
        foreach (['course_type', 'course_place', 'course_leader_1', 'course_leader_2'] as $name) {
            $data[$name] = (string) ($course->$name ?? 0);
        }
        $data['availability'] = (string) ($course->nr_of_participants ?? 0);
        $data['supplier'] = (string) ($course->cr ?? 0);
        $data['lodging_included'] = empty($course->lodging_included) ? '0' : '1';
        $data['id'] = (string) $course->id;
        $data['version'] = (string) $course->availability_version;
        $data['start_date'] = $this->dateValue($course->start_date);
        $data['stop_date'] = $this->dateValue($course->stop_date);
        $second = $record['sessions'][0] ?? null;
        $data['second_start'] = $second ? $this->dateValue($second->start_date) : '';
        $data['second_end'] = $second ? $this->dateValue($second->stop_date) : '';
        unset($data['submission']);
        return $data;
    }

    private function dateValue(?string $value): string
    {
        $value = substr($value ?? '', 0, 10);
        $date = \DateTimeImmutable::createFromFormat('!Y-m-d', $value, new \DateTimeZone('UTC'));
        return $date && $date->format('Y-m-d') === $value && (int) $date->format('Y') >= 1000 ? $value : '';
    }

    public function getEditForm(array $record, array $data): Form
    {
        $form = parent::getForm($data, $this->formData($record));
        $form->removeField('submission');
        foreach (['id', 'version'] as $name) {
            $field = new \SimpleXMLElement('<field type="hidden" required="true" filter="integer" />');
            $field->addAttribute('name', $name);
            $form->setField($field);
        }
        if ($record['sessions']) {
            $form->setFieldAttribute('second_start', 'required', 'true');
            $form->setFieldAttribute('second_end', 'required', 'true');
        }
        $form->bind($data);
        return $form;
    }

    public function saveCourse(int $id, int $version, array $input): void
    {
        $administrator = $this->isAdministrator();
        $record = $this->getRecord($id);
        $course = $record['course'];
        if ($version < 0 || $version !== (int) $course->availability_version) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_EDIT_CONFLICT'), 409);
        }
        if (array_key_exists('submission', $input)) {
            throw new CourseValidationException([Text::_('COM_ALTACOURSES_NEW_FIELDS_INVALID')]);
        }
        $original = $this->formData($record);
        if ($record['sessions'] && (empty($input['second_start']) || empty($input['second_end']))) {
            throw new CourseValidationException([Text::_('COM_ALTACOURSES_EDIT_KEEP_SESSIONS')]);
        }
        $data = $this->validateData($input, $original);
        if ($data['ranges'] !== null && count($record['sessions']) > 1) {
            $pairs = [[$data['start_date'], $data['stop_date']], [$data['second_start'], $data['second_end']]];
            foreach (array_slice($record['sessions'], 1) as $session) {
                $pairs[] = [$this->dateValue($session->start_date), $this->dateValue($session->stop_date)];
            }
            try {
                $this->getCourseSchedule()->validateDatePairs($pairs);
            } catch (\InvalidArgumentException $exception) {
                throw new CourseValidationException([Text::_('COM_ALTACOURSES_NEW_DATES_INVALID')]);
            }
        }
        $db = $this->getDatabase();
        $query = $db->createQuery()->update('#__altacourses_courses')
            ->set('availability_version=availability_version+1')
            ->where('id=:course')->bind(':course', $id, ParameterType::INTEGER)
            ->where('availability_version=:revision')->bind(':revision', $version, ParameterType::INTEGER);
        $this->scopeToOwner($query, $administrator);
        $actor = (int) $this->currentUser->id;
        $query->where('(checked_out IS NULL OR checked_out=0 OR checked_out=:actor)')->bind(':actor', $actor, ParameterType::INTEGER);
        $values = [];
        foreach (['course_type', 'course_place', 'course_leader_1', 'course_leader_2', 'course_price', 'lodging_price', 'lodging_included', 'course_notes', 'availability'] as $field) {
            if ($data[$field] !== $original[$field]) {
                $column = $field === 'availability' ? 'nr_of_participants' : $field;
                $value = in_array($field, ['course_type', 'course_place', 'course_leader_1', 'course_leader_2', 'availability'], true) ? (int) $data[$field] : $data[$field];
                $values[$column] = $field === 'course_leader_2' && $value === 0 ? null : $value;
            }
        }
        if ($administrator && $data['supplier'] !== $original['supplier']) {
            $values['cr'] = (int) $data['supplier'] ?: null;
            if ($values['cr'] !== null) {
                $selectedSupplier = $values['cr'];
                $query->where('EXISTS (SELECT 1 FROM #__users AS active_supplier WHERE active_supplier.id=:selected_supplier AND active_supplier.block=0)')
                    ->bind(':selected_supplier', $selectedSupplier, ParameterType::INTEGER);
            }
        }
        foreach (['start_date', 'stop_date'] as $field) {
            if ($data[$field] !== $original[$field]) {
                $values[$field] = $data['ranges'][0][$field];
            }
        }
        if (!$administrator) {
            $newStart = $values['start_date'] ?? $course->start_date;
            $future = $db->createQuery()->select('CASE WHEN :date >= CURRENT_TIMESTAMP THEN 1 ELSE 0 END')->bind(':date', $newStart);
            if (!(int) $db->setQuery($future)->loadResult()) {
                throw new CourseValidationException([Text::_('COM_ALTACOURSES_EDIT_UPCOMING')]);
            }
            $query->where(':new_start >= CURRENT_TIMESTAMP')->bind(':new_start', $newStart);
        }
        // Only explicit editable columns are updated. Creator, publication and creation token remain intact.
        $bound = [];
        foreach ($values as $column => $value) {
            $parameter = ':edit_' . $column;
            $query->set($db->quoteName($column) . '=' . ($value === null ? 'NULL' : $parameter));
            if ($value !== null) {
                $bound[$parameter] = $value;
                $query->bind($parameter, $bound[$parameter], is_int($value) ? ParameterType::INTEGER : ParameterType::STRING);
            }
        }
        $db->transactionStart();
        try {
            $db->setQuery($query)->execute();
            if ($db->getAffectedRows() !== 1) {
                throw new \RuntimeException(Text::_('COM_ALTACOURSES_EDIT_CONFLICT'), 409);
            }
            if ($data['ranges'] !== null && isset($data['ranges'][1])) {
                $second = $record['sessions'][0] ?? null;
                if ($second === null) {
                    $row = (object) ($data['ranges'][1] + ['course_id' => $id, 'ordering' => 2]);
                    $db->insertObject('#__altacourses_course_sessions', $row, 'id');
                } else {
                    $changes = [];
                    foreach (['start_date' => 'second_start', 'stop_date' => 'second_end'] as $column => $field) {
                        if ($data[$field] !== $original[$field]) {
                            $changes[] = $db->quoteName($column) . '=' . $db->quote($data['ranges'][1][$column]);
                        }
                    }
                    if ($changes) {
                        $sessionId = (int) $second->id;
                        $update = $db->createQuery()->update('#__altacourses_course_sessions')->set($changes)
                            ->where('id=:session')->bind(':session', $sessionId, ParameterType::INTEGER)
                            ->where('course_id=:owner_course')->bind(':owner_course', $id, ParameterType::INTEGER);
                        $db->setQuery($update)->execute();
                    }
                }
            }
            $db->transactionCommit();
        } catch (\Throwable $exception) {
            $db->transactionRollback();
            throw $exception;
        }
    }

    private function scopeToOwner(QueryInterface $query, bool $administrator): void
    {
        if (!$administrator) {
            $owner = (int) $this->currentUser->id;
            $query->where('cr=:owner')->bind(':owner', $owner, ParameterType::INTEGER)->where('start_date >= CURRENT_TIMESTAMP');
        }
    }
}
