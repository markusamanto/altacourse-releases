<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
use Joomla\CMS\Layout\LayoutHelper;
\defined('_JEXEC') or die;
echo LayoutHelper::render('accountclients', ['view' => $this], dirname(__DIR__, 2) . '/layouts');
