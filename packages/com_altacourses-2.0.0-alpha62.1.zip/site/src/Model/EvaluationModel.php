<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Model;
use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareTrait;
use Advenire\Component\Altacourses\Site\Exception\CourseValidationException;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\BaseModel;
use Joomla\CMS\User\UserFactoryAwareInterface;
use Joomla\CMS\User\UserFactoryAwareTrait;
use Joomla\Database\DatabaseAwareInterface;
use Joomla\Database\DatabaseAwareTrait;
use Joomla\Database\ParameterType;
\defined('_JEXEC') or die;

/** Public capabilities authorise one new response; no read/edit/publication access to saved answers. */
final class EvaluationModel extends BaseModel implements DatabaseAwareInterface, UserFactoryAwareInterface, CourseScheduleAwareInterface
{
    use DatabaseAwareTrait;
    use UserFactoryAwareTrait;
    use CourseScheduleAwareTrait;

    private function request(int $id,bool $lock=false): ?object
    {
        if ($id<1||$id>4294967295) { return null; }
        $db=$this->getDatabase();$q=$db->createQuery()->select(['id','courseid','rate_code'])->from('#__altacourses_requests')
            ->where('id=:evaluation_request')->bind(':evaluation_request',$id,ParameterType::INTEGER);
        if ($lock) { $q->setQuery((string)$q.' FOR UPDATE'); }
        return $db->setQuery($q)->loadObject();
    }
    private function answered(int $id): bool
    {
        return $this->getDatabase()->setQuery('SELECT id FROM #__altacourses_evaluations WHERE request_id='.$id,0,1)->loadResult()!==null;
    }
    /** Only an authenticated entry may issue this server-side session proof. */
    public function enter(int $id,mixed $code): array
    {
        if ($code===null||$code==='') { return ['status'=>'missing']; }
        if (!is_string($code)||!preg_match('/^[A-Za-z0-9_-]{1,255}$/D',$code)) { return ['status'=>'invalid']; }
        $r=$this->request($id);$stored=(string)($r->rate_code??'');$valid=false;
        if ($stored!==''&&str_starts_with($stored,'sha256:')) {
            $valid=preg_match('/^[a-f0-9]{64}$/D',$code)===1&&strlen($stored)===71&&hash_equals(substr($stored,7),hash('sha256',$code));
        } elseif ($stored!=='') { $valid=hash_equals($stored,$code); }
        if (!$valid) { return ['status'=>'invalid']; }
        return ['status'=>$this->answered($id)?'answered':'ready','request_id'=>$id,'proof'=>hash('sha256',$stored)];
    }
    public function page(int $id,string $proof): array
    {
        $r=$this->request($id);
        if (!$this->authorised($r,$proof)) { return ['status'=>'invalid']; }
        if ($this->answered($id)) { return ['status'=>'answered']; }
        $db=$this->getDatabase();$co=(int)$r->courseid;
        $details=$db->setQuery($db->createQuery()->select(['co.id','ct.name AS course_type','cp.name AS course_place','l1.name AS leader1','l2.name AS leader2'])
            ->from('#__altacourses_courses AS co')->join('LEFT','#__altacourses_coursetypes AS ct ON ct.id=co.course_type')
            ->join('LEFT','#__altacourses_courseplaces AS cp ON cp.id=co.course_place')
            ->join('LEFT','#__altacourses_courseleaders AS l1 ON l1.id=co.course_leader_1')->join('LEFT','#__altacourses_courseleaders AS l2 ON l2.id=co.course_leader_2')
            ->where('co.id='.$co))->loadObject();
        return ['status'=>'ready','course'=>$details,'sessions'=>$this->getCourseSchedule()->currentSessions([$co])[$co]??[]];
    }
    private function authorised(?object $r,string $proof): bool
    {
        return $r!==null&&(string)($r->rate_code??'')!==''&&preg_match('/^[a-f0-9]{64}$/D',$proof)===1
            &&hash_equals(hash('sha256',(string)$r->rate_code),$proof);
    }
    /** Request-first locks match invitation delivery, and serialize response existence checks/inserts. */
    public function submit(int $id,string $proof,array $input): string
    {
        $db=$this->getDatabase();$db->transactionStart();
        try {
            $r=$this->request($id,true);
            if (!$this->authorised($r,$proof)) { $db->transactionRollback();return 'invalid'; }
            if ($this->answered($id)) { $db->transactionCommit();return 'answered'; }
            $fields=['rating_overall','rating_leaders','rating_place','review','feedback','correction'];
            if (array_diff(array_keys($input),$fields)||array_diff($fields,array_keys($input))) { throw new CourseValidationException([Text::_('COM_ALTACOURSES_EVALUATION_INPUT_INVALID')]); }
            foreach (['rating_overall','rating_leaders','rating_place'] as $f) {
                if (!is_string($input[$f])||!in_array($input[$f],['1','2','3','4','5'],true)) { throw new CourseValidationException([Text::_('COM_ALTACOURSES_EVALUATION_RATINGS_REQUIRED')]); }
            }
            foreach (['review','feedback','correction'] as $f) {
                if (!is_string($input[$f])||!mb_check_encoding($input[$f],'UTF-8')||strlen($input[$f])>65535||preg_match('/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/',$input[$f])) {
                    throw new CourseValidationException([Text::_('COM_ALTACOURSES_EVALUATION_INPUT_INVALID')]);
                }
            }
            $row=(object)($input+['request_id'=>$id,'rating_date'=>gmdate('Y-m-d H:i:s'),'review_published'=>0,'feedback_read'=>0,'ordering'=>0,'state'=>0,'checked_out'=>0,'created_by'=>0]);
            $db->insertObject('#__altacourses_evaluations',$row,'id');
            $db->transactionCommit();return 'thanks';
        } catch (\Throwable $e) { $db->transactionRollback();throw $e; }
    }
    /** Explicit module selection ignores position/menu assignment, but always honours guest visibility. */
    public function thankyouModule(int $id,string $language): ?object
    {
        if ($id<1) { return null; }
        $db=$this->getDatabase();$levels=array_map('intval',$this->getUserFactory()->loadUserById(0)->getAuthorisedViewLevels());$now=gmdate('Y-m-d H:i:s');
        return $db->setQuery($db->createQuery()->select('*')->from('#__modules')->where('id=:thanks_module')->bind(':thanks_module',$id,ParameterType::INTEGER)
            ->where("module='mod_custom' AND client_id=0 AND published=1")->where('access IN ('.implode(',',$levels?:[0]).')')
            ->where("(language='*' OR language=:thanks_language)")->bind(':thanks_language',$language)
            ->where("(publish_up IS NULL OR CAST(publish_up AS CHAR) LIKE '0000-%' OR publish_up<=".$db->quote($now).')')
            ->where("(publish_down IS NULL OR CAST(publish_down AS CHAR) LIKE '0000-%' OR publish_down>=".$db->quote($now).')'))->loadObject();
    }
}
