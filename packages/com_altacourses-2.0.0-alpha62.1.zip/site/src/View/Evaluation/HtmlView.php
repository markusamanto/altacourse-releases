<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\View\Evaluation;
use Joomla\CMS\Language\Text;
\defined('_JEXEC') or die;
class HtmlView extends \Joomla\CMS\MVC\View\HtmlView
{
 public string $status='missing';
 public string $ticket='';
 public array $page=[];
 public array $draft=[];
 public ?object $thanksModule=null;
 public function display($tpl=null):void
 {
  $this->getDocument()->setTitle(Text::_($this->status==='thanks'?'COM_ALTACOURSES_EVALUATION_THANKS_TITLE':'COM_ALTACOURSES_EVALUATION_TITLE'));
  $this->getDocument()->setMetaData('robots','noindex, nofollow');$this->getDocument()->setMetaData('referrer','no-referrer');
  $this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.site');parent::display($tpl);
 }
}
