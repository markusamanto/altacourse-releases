<?php
/** @package Altacourses.Administrator @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Administrator\Service;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
\defined('_JEXEC') or die;

/** Presentation only. CoursePrice remains the sole interpreter of monetary amounts. */
final class PriceDisplay
{
    public static function mode(): string
    {
        return ComponentHelper::getParams('com_altacourses')->get('price_display_mode', 'T') === 'V' ? 'V' : 'T';
    }
    public static function residential(mixed $value): int
    {
        return (string) $value === '2' ? 2 : 1;
    }
    private static function loadLanguage(): void
    {
        Factory::getApplication()->getLanguage()->load('com_altacourses', JPATH_SITE . '/components/com_altacourses');
    }
    public static function label(string $fallback): string
    {
        self::loadLanguage();
        return Text::_(self::mode() === 'V' ? 'COM_ALTACOURSES_VARIABLE_PRICE' : $fallback);
    }
    public static function descriptionKey(mixed $residential): string
    {
        return 'COM_ALTACOURSES_PRICE_DESCRIPTION_' . self::residential($residential);
    }
    public static function description(mixed $residential, string $fallback): string
    {
        self::loadLanguage();
        return Text::_(self::mode() === 'V' ? self::descriptionKey($residential) : $fallback);
    }
    /** Trusted markup; all editable text is escaped and markers are fixed integers. */
    public static function marker(mixed $residential): string
    {
        return self::mode() === 'V' ? '<sup class="altacourses-price-marker">' . self::residential($residential) . '</sup>' : '';
    }
    public static function intro(string $fallback, string $suffix): string
    {
        self::loadLanguage();
        $escape = static fn(string $text): string => htmlspecialchars($text, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        if (self::mode() !== 'V') { return $escape(Text::_($fallback)); }
        return '<sup>1</sup> ' . $escape(Text::_(self::descriptionKey(1))) . '<br><sup>2</sup> '
            . $escape(Text::_(self::descriptionKey(2))) . ' ' . $escape(Text::_($suffix));
    }
}
