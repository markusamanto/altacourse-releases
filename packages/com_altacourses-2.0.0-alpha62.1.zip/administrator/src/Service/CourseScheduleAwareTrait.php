<?php

/**
 * @package     Altacourses.Administrator
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Administrator\Service;

\defined('_JEXEC') or die;

trait CourseScheduleAwareTrait
{
    private ?CourseSchedule $courseSchedule = null;

    public function setCourseSchedule(CourseSchedule $schedule): void
    {
        $this->courseSchedule = $schedule;
    }

    protected function getCourseSchedule(): CourseSchedule
    {
        return $this->courseSchedule ?? throw new \LogicException('Course schedule service has not been injected');
    }
}
