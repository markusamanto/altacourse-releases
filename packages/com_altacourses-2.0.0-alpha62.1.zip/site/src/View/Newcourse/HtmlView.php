<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\View\Newcourse;

use Joomla\CMS\Form\Form;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;

\defined('_JEXEC') or die;

final class HtmlView extends BaseHtmlView
{
    public ?Form $form = null;
    public bool $isCourseAdministrator = false;

    public function display($tpl = null): void
    {
        $this->isCourseAdministrator = $this->getModel()->isAdministrator();
        $this->getDocument()->setTitle(Text::_('COM_ALTACOURSES_NEW_TITLE'));
        $this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.site')->useScript('com_altacourses.newcourse');
        parent::display($tpl);
    }
}
