<?php
/** @package Altacourses.Module @license GNU General Public License version 2 or later */
namespace Advenire\Module\Altaevaluations\Site\Dispatcher;
use Joomla\CMS\Dispatcher\AbstractModuleDispatcher;
use Joomla\CMS\Event\PageCache\IsExcludedEvent;
use Joomla\CMS\Helper\HelperFactoryAwareInterface;
use Joomla\CMS\Helper\HelperFactoryAwareTrait;
\defined('_JEXEC') or die;
final class Dispatcher extends AbstractModuleDispatcher implements HelperFactoryAwareInterface
{
    use HelperFactoryAwareTrait;
    protected function getLayoutData(): array|false
    {
        $data=parent::getLayoutData();
        // Publication changes must immediately affect both populated and previously empty pages.
        $this->app->allowCache(false);$this->app->getDispatcher()->addListener('onPageCacheIsExcluded',static function(IsExcludedEvent $event):void{$event->addResult(true);});
        $result=$this->getHelperFactory()->getHelper('AltaevaluationsHelper')->render($this->app,$data['params']);
        if($result===null){return false;}
        $assets=$this->app->getDocument()->getWebAssetManager();$assets->getRegistry()->addRegistryFile('media/mod_altaevaluations/joomla.asset.json');$assets->useStyle('mod_altaevaluations.site');
        return $data+$result;
    }
}
