<?php
namespace Advenire\Component\Altacourses\Site\Controller;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Language\Text;
\defined('_JEXEC') or die;
final class MailchimpController extends BaseController
{
    public function execute($task)
    {
        if(strtolower((string)$task)!=='retry'||$this->app->getDocument()->getType()!=='html'){throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'),404);}
        $model=$this->getModel('Mailchimp','Site',['ignore_request'=>true]);$model->requireAdministrator();
        if($this->input->getMethod()!=='POST'){throw new \RuntimeException(Text::_('COM_ALTACOURSES_AVAILABILITY_POST_REQUIRED'),405);}
        if(!$this->checkToken('post',false)){throw new \RuntimeException(Text::_('JINVALID_TOKEN'),403);}
        $d=$this->input->post->get('jform',[],'array');
        if(count($d)!==3||array_diff(array_keys($d),['id','revision','review'])||($d['review']??null)!=='1'){throw new \RuntimeException(Text::_('COM_ALTACOURSES_COMMISSION_INVALID'),400);}
        foreach(['id','revision'] as $key){if(!is_string($d[$key])||!ctype_digit($d[$key])||strlen($d[$key])>10||(float)$d[$key]>2147483647||($key==='id'&&(int)$d[$key]<1)){throw new \RuntimeException(Text::_('COM_ALTACOURSES_COMMISSION_INVALID'),400);}}
        $model->retry((int)$d['id'],$d['revision']);$this->setMessage(Text::_('COM_ALTACOURSES_MC_REQUEUED'));
        $this->setRedirect(Route::_('index.php?option=com_altacourses&view=mailchimp',false));return true;
    }
}
