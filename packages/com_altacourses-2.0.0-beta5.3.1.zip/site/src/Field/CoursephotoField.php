<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Field;
use Advenire\Component\Altacourses\Site\Helper\CoursePhoto;
use Joomla\CMS\Factory;
use Joomla\CMS\Form\Field\ListField;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
\defined('_JEXEC') or die;
/** Uses existing frontend component permission, without granting Media Manager/backend access. */
final class CoursephotoField extends ListField
{
    protected $type='Coursephoto';
    protected function getOptions(): array
    {
        $options=[HTMLHelper::_('select.option','',Text::_('COM_ALTACOURSES_PHOTO_NONE'))];$paths=CoursePhoto::choices();
        foreach($paths as $path){$options[]=HTMLHelper::_('select.option',$path,$path);}
        if(is_string($this->value)&&$this->value!==''&&!in_array($this->value,$paths,true)){$options[]=HTMLHelper::_('select.option',$this->value,Text::sprintf('COM_ALTACOURSES_PHOTO_UNAVAILABLE',$this->value));}
        return $options;
    }
    protected function getInput(): string
    {
        $app=Factory::getApplication();if(!$app->getIdentity()->authorise('altacourses.manage','com_altacourses')){throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'),403);}
        $app->getDocument()->getWebAssetManager()->useScript('com_altacourses.coursephoto');$input=parent::getInput();$url=CoursePhoto::url($this->value);$escape=static fn($v)=>htmlspecialchars((string)$v,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');
        return '<div data-course-photo-picker data-photo-root="'.$escape(\Joomla\CMS\Uri\Uri::root(true)).'">'.$input.'<button type="button" class="btn btn-secondary btn-sm mt-2" data-photo-clear hidden>'. $escape(Text::_('COM_ALTACOURSES_PHOTO_CLEAR')).'</button><div><img class="altacourses-entity-photo mt-2" data-photo-preview alt="'.$escape(Text::_('COM_ALTACOURSES_PHOTO_PREVIEW')).'"'.($url===null?' hidden':' src="'.$escape($url).'"').'></div></div>';
    }
}
