<?php
/** @package Altacourses.Task @license GNU General Public License version 2 or later */
namespace Advenire\Plugin\Task\Altacoursesmonthly\Task;
use Joomla\CMS\Language\Language;
use Joomla\Component\Scheduler\Administrator\Task\TaskOption;
\defined('_JEXEC') or die;
final class NewsletterOption extends TaskOption
{
    public function __construct(Language $language)
    {
        $this->id='altacourses.newsletter';$this->langConstPrefix='PLG_TASK_ALTACOURSESMONTHLY_NEWSLETTER';
        $this->title=$language->_($this->langConstPrefix.'_TITLE');$this->desc=$language->_($this->langConstPrefix.'_DESC');
    }
}
