<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\View\Evaluations;
use Joomla\CMS\Language\Text;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
\defined('_JEXEC') or die;
final class HtmlView extends BaseHtmlView
{
    public array $items=[];
    public ?\Joomla\CMS\Pagination\Pagination $pagination=null;
    public function display($tpl=null): void
    {
        $this->getModel()->requireAdministrator();$this->items=$this->getModel()->getItems();
        $this->getDocument()->setTitle(Text::_('COM_ALTACOURSES_EVALADMIN_TITLE'));
        $this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.site')->useStyle('fontawesome');
        HTMLHelper::_('bootstrap.collapse');parent::display($tpl);
    }
}
