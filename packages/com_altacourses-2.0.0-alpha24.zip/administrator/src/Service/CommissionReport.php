<?php

/** @package Altacourses.Administrator @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Administrator\Service;

use Joomla\CMS\Language\Text;
use Joomla\Database\DatabaseInterface;
use Joomla\Database\ParameterType;
use Joomla\Registry\Registry;

\defined('_JEXEC') or die;

/** Shared reporting/export logic; no transport, scheduling or public files. */
final class CommissionReport
{
    public function __construct(private readonly DatabaseInterface $database, private readonly Registry $config, private readonly CourseSchedule $schedule) {}

    private function timezone(): \DateTimeZone
    {
        return new \DateTimeZone((string) $this->config->get('offset', 'UTC'));
    }

    public function previousMonth(): string
    {
        return (new \DateTimeImmutable('first day of this month', $this->timezone()))->modify('-1 month')->format('Y-m');
    }

    public function bounds(string $month): array
    {
        if (!preg_match('/^(?:19|[2-9]\d)\d{2}-(?:0[1-9]|1[0-2])$/D', $month) || $month === '9999-12') {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_COMMISSION_INVALID'), 400);
        }
        $start = new \DateTimeImmutable($month . '-01 00:00:00', $this->timezone());
        $utc = new \DateTimeZone('UTC');
        return [$start->setTimezone($utc)->format('Y-m-d H:i:s'), $start->modify('+1 month')->setTimezone($utc)->format('Y-m-d H:i:s')];
    }

    public function read(string $month, bool $lock = false): array
    {
        [$from, $to] = $this->bounds($month);
        $query = $this->database->createQuery()->select(['r.id', 'r.date_reported', 'r.note', 'r.participation_version',
            'r.commission_fee', 'r.commission_captured_at', 'r.commission_captured_by', 's.supplier_user_id', 's.supplier_id',
            's.supplier_email', 's.contact_json', 's.course_json', 'sp.company AS supplier_company', 'sp.fee AS current_fee', 'sp.profile_version', 'co.id AS actual_course_id', 'co.start_date', 'co.stop_date', 'co.availability_version AS course_version', 'ct.name AS actual_type', 'cp.name AS actual_place'])
            ->from('#__altacourses_requests AS r')
            ->join('INNER', '#__altacourses_request_submissions AS s ON s.request_id=r.id')
            ->join('LEFT', '#__altacourses_suppliers AS sp ON sp.id=s.supplier_id AND sp.user_id=s.supplier_user_id')
            ->join('LEFT', '#__altacourses_courses AS co ON co.id=r.courseid')
            ->join('LEFT', '#__altacourses_coursetypes AS ct ON ct.id=co.course_type')
            ->join('LEFT', '#__altacourses_courseplaces AS cp ON cp.id=co.course_place')
            ->where('r.participated=1 AND r.canceled=0 AND r.date_reported>=:commission_from AND r.date_reported<:commission_to')
            ->bind(':commission_from', $from)->bind(':commission_to', $to)
            ->order('s.supplier_user_id, r.id');
        if ($lock) { $query->setQuery((string) $query . ' FOR UPDATE'); }
        $rows = $this->database->setQuery($query)->loadObjectList();
        $extras = $this->schedule->additionalSessions(array_column($rows, 'actual_course_id'));
        $groups = []; $missing = 0; $total = 0;
        foreach ($rows as $row) {
            $fee = $row->commission_fee ?? $row->current_fee;
            $row->effective_fee = $fee !== null && ctype_digit((string) $fee) && (float) $fee <= 2147483647 ? (int) $fee : null;
            $row->contact = json_decode($row->contact_json, true, 512, JSON_THROW_ON_ERROR);
            $row->course = json_decode($row->course_json, true, 512, JSON_THROW_ON_ERROR);
            if ($row->actual_course_id !== null) {
                $row->course['course_type'] = $row->actual_type ?? '';
                $row->course['course_place'] = $row->actual_place ?? '';
                $row->course['sessions'] = array_merge([['start_date' => $row->start_date, 'stop_date' => $row->stop_date]],
                    array_map(static fn ($s): array => ['start_date' => $s->start_date, 'stop_date' => $s->stop_date], $extras[(int) $row->actual_course_id] ?? []));
            }
            $row->reported_local = (new \DateTimeImmutable($row->date_reported, new \DateTimeZone('UTC')))->setTimezone($this->timezone())->format('Y-m-d H:i:s');
            $supplierId = (int) $row->supplier_user_id;
            if (!isset($groups[$supplierId])) { $groups[$supplierId] = ['name' => $row->supplier_company ?: $row->supplier_email, 'rows' => [], 'total' => 0, 'missing' => 0]; }
            $groups[$supplierId]['rows'][] = $row;
            if ($row->effective_fee === null) { ++$missing; ++$groups[$supplierId]['missing']; }
            else { $total += $row->effective_fee; $groups[$supplierId]['total'] += $row->effective_fee; }
        }
        // Include all amount, profile and submission inputs in the reviewed export fingerprint.
        $fingerprint = hash('sha256', json_encode([$month, (string) $this->config->get('offset', 'UTC'), $rows], JSON_THROW_ON_ERROR));
        return ['rows' => $rows, 'groups' => $groups, 'missing' => $missing, 'total' => $total, 'fingerprint' => $fingerprint];
    }

    /** Explicit reviewed export records only previously unrecorded fees, in one transaction. */
    public function captureCsv(string $month, string $fingerprint, int $actorId, array $headers): string
    {
        $this->database->transactionStart();
        try {
            $report = $this->read($month, true);
            if (!hash_equals($report['fingerprint'], $fingerprint)) { throw new \RuntimeException(Text::_('COM_ALTACOURSES_COMMISSION_CONFLICT'), 409); }
            if (!$report['rows'] || $report['missing']) { throw new \RuntimeException(Text::_('COM_ALTACOURSES_COMMISSION_MISSING'), 409); }
            $csv = $this->csv($report['rows'], $headers);
            $now = (new \DateTimeImmutable('now', new \DateTimeZone('UTC')))->format('Y-m-d H:i:s');
            foreach ($report['rows'] as $row) {
                if ($row->commission_fee !== null) { continue; }
                $id = (int) $row->id; $fee = $row->effective_fee;
                $query = $this->database->createQuery()->update('#__altacourses_requests')
                    ->set('commission_fee=:commission_fee')->bind(':commission_fee', $fee, ParameterType::INTEGER)
                    ->set('commission_captured_at=:commission_time')->bind(':commission_time', $now)
                    ->set('commission_captured_by=:commission_actor')->bind(':commission_actor', $actorId, ParameterType::INTEGER)
                    ->where('id=:commission_id AND commission_fee IS NULL')->bind(':commission_id', $id, ParameterType::INTEGER);
                $this->database->setQuery($query)->execute();
                if ($this->database->getAffectedRows() !== 1) { throw new \RuntimeException(Text::_('COM_ALTACOURSES_COMMISSION_CONFLICT'), 409); }
            }
            $this->database->transactionCommit();
            return $csv;
        } catch (\Throwable $error) { $this->database->transactionRollback(); throw $error; }
    }

    /** Excel-compatible UTF-8 CSV, original seven columns and semicolon delimiter. */
    private function csv(array $rows, array $headers): string
    {
        $stream = fopen('php://temp', 'w+');
        if ($stream === false) { throw new \RuntimeException('Could not prepare commission export'); }
        try {
            fwrite($stream, "\xEF\xBB\xBF");
            fputcsv($stream, $headers, ';', '"', '', "\r\n");
            foreach ($rows as $row) {
                $dates = [];
                foreach ($row->course['sessions'] ?? [] as $session) { $dates[] = substr($session['start_date'] ?? '', 0, 10) . ' – ' . substr($session['stop_date'] ?? '', 0, 10); }
                $values = [$row->supplier_company ?: $row->supplier_email, $row->course['course_type'] ?? '', implode(' / ', $dates),
                    trim(($row->contact['firstname'] ?? '') . ' ' . ($row->contact['lastname'] ?? '')), $row->contact['company'] ?? '',
                    (string) $row->effective_fee, (string) $row->note];
                $values = array_map(static function ($value): string {
                    $value = (string) $value;
                    return preg_match('/^[\s\x{FEFF}]*[=+\-@]/u', $value) ? "'" . $value : $value;
                }, $values);
                if (fputcsv($stream, $values, ';', '"', '', "\r\n") === false) { throw new \RuntimeException('Could not write commission export'); }
            }
            rewind($stream);
            $csv = stream_get_contents($stream);
            if ($csv === false) { throw new \RuntimeException('Could not read commission export'); }
            return $csv;
        } finally { fclose($stream); }
    }
}
