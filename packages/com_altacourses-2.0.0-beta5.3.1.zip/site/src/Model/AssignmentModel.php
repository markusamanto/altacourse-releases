<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Model;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\CMS\MVC\Model\BaseModel;
use Joomla\CMS\User\CurrentUserInterface;
use Joomla\CMS\User\User;
use Joomla\CMS\User\UserFactoryAwareInterface;
use Joomla\CMS\User\UserFactoryAwareTrait;
use Joomla\Database\DatabaseAwareInterface;
use Joomla\Database\DatabaseAwareTrait;

\defined('_JEXEC') or die;

final class AssignmentModel extends BaseModel implements DatabaseAwareInterface, CurrentUserInterface, UserFactoryAwareInterface
{
    use DatabaseAwareTrait;
    use UserFactoryAwareTrait;

    private ?User $currentUser = null;

    public function __construct($config = [], ?MVCFactoryInterface $factory = null)
    {
        parent::__construct($config);
    }

    public function setCurrentUser(User $currentUser): void
    {
        $this->currentUser = $currentUser;
    }

    /** Active Joomla accounts eligible to manage supplier courses; never infer a company ID. */
    public function getChoices(): array
    {
        $this->requireAdministrator();
        $db = $this->getDatabase();
        $accounts = $db->setQuery($db->createQuery()->select(['u.id', 'u.name', 's.company'])->from('#__users AS u')
            ->join('LEFT', '#__altacourses_suppliers AS s ON s.user_id = u.id')
            ->where('u.block = 0')->order("COALESCE(NULLIF(TRIM(s.company), ''), u.name), u.id"))->loadObjectList();
        $choices = [(object) ['id' => 0, 'label' => Text::_('COM_ALTACOURSES_UNASSIGNED')]];
        foreach ($accounts as $account) {
            $user = $this->getUserFactory()->loadUserById((int) $account->id);
            if ($this->isEligible($user)) {
                $choices[] = (object) ['id' => (int) $user->id, 'label' => trim((string) $account->company) ?: $user->name];
            }
        }
        return $choices;
    }

    private function isEligible(User $user): bool
    {
        return !$user->guest && !(bool) $user->block && !$user->authorise('core.admin')
            && $user->authorise('altacourses.supplier', 'com_altacourses');
    }

    private function requireAdministrator(): void
    {
        if ($this->currentUser === null || $this->currentUser->guest
            || !$this->currentUser->authorise('altacourses.manage', 'com_altacourses')) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }
    }
}
