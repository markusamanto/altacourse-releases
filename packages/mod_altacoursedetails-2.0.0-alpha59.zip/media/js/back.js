document.addEventListener('click', (event) => {
    const link = event.target.closest('[data-altacourses-back]');
    if (!link || event.defaultPrevented || event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
    const canGoBack = window.navigation
        ? window.navigation.canGoBack || (Boolean(document.referrer) && window.history.length > 1)
        : window.history.length > 1;
    if (canGoBack) {
        event.preventDefault();
        window.history.back();
    }
});
