<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
\defined('_JEXEC') or die;
$date=static fn(mixed $v):string=>is_string($v)&&preg_match('/^[1-9][0-9]{3}-[0-9]{2}-[0-9]{2}/',$v)?substr($v,0,10):Text::_('COM_ALTACOURSES_EVALUATION_UNKNOWN');
?>
<section class="altacourses-portal altacourses-evaluations" aria-labelledby="evaluations-heading">
 <h1 id="evaluations-heading"><?php echo $this->escape(Text::_('COM_ALTACOURSES_EVALADMIN_TITLE')); ?></h1>
 <p><a href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=dashboard',false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_BACK_TO_DASHBOARD')); ?></a></p>
 <?php if (!$this->items) : ?><p><?php echo $this->escape(Text::_('COM_ALTACOURSES_EVALADMIN_EMPTY')); ?></p><?php else : ?>
 <div class="table-responsive"><table class="table evaluations-table">
  <caption class="visually-hidden"><?php echo $this->escape(Text::_('COM_ALTACOURSES_EVALADMIN_TITLE')); ?></caption>
  <thead><tr><?php foreach (['DATE','NAME','COURSE','LEADERS','PLACE','PUBLISHED_LABEL','DETAILS'] as $f) : ?><th scope="col"><?php echo $this->escape(Text::_('COM_ALTACOURSES_EVALADMIN_'.$f)); ?></th><?php endforeach; ?></tr></thead>
  <tbody><?php foreach ($this->items as $row) : $id=(int)$row->id;$published=(string)$row->state==='1';$name=trim((string)$row->firstname.' '.(string)$row->lastname);$name=$name!==''?$name:Text::_('COM_ALTACOURSES_EVALUATION_UNKNOWN'); ?>
   <tr class="evaluation-summary" data-evaluation-id="<?php echo $id; ?>">
    <td><?php echo $this->escape($date($row->rating_date)); ?>
     <?php foreach (['feedback'=>'flag','correction'=>'exclamation-circle'] as $f=>$icon) : if (trim((string)($row->$f??''))!=='') : $label=Text::_('COM_ALTACOURSES_EVALADMIN_HAS_'.strtoupper($f)); ?>
      <span class="evaluation-indicator" data-evaluation-indicator="<?php echo $f; ?>" title="<?php echo $this->escape($label); ?>"><span class="icon-<?php echo $icon; ?>" aria-hidden="true"></span><span class="visually-hidden"><?php echo $this->escape($label); ?></span></span>
     <?php endif; endforeach; ?>
    </td>
    <th scope="row"><?php echo $this->escape($name); ?></th>
    <?php foreach (['rating_overall'=>'COURSE','rating_leaders'=>'LEADERS','rating_place'=>'PLACE'] as $f=>$label) : $value=(string)($row->$f??''); ?>
     <td><?php if (in_array($value,['1','2','3','4','5'],true)) : ?><div class="progress" role="progressbar" aria-label="<?php echo $this->escape(Text::_('COM_ALTACOURSES_EVALADMIN_'.$label)); ?>" aria-valuenow="<?php echo $value; ?>" aria-valuemin="0" aria-valuemax="5"><div class="progress-bar" style="width:<?php echo (int)$value*20; ?>%" ><?php echo $value; ?></div></div><?php else : ?><span title="<?php echo $this->escape(Text::_('COM_ALTACOURSES_EVALADMIN_NO_RATING')); ?>">—</span><?php endif; ?></td>
    <?php endforeach; ?>
    <td><form class="evaluation-publish" action="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&task=evaluations.publish',false)); ?>" method="post">
     <input type="hidden" name="jform[id]" value="<?php echo $id; ?>"><input type="hidden" name="jform[state]" value="<?php echo $published?'0':'1'; ?>">
     <input type="hidden" name="jform[version]" value="<?php echo $this->escape($this->getModel()->version($row)); ?>"><input type="hidden" name="jform[start]" value="<?php echo (int)$this->pagination->limitstart; ?>">
     <?php echo HTMLHelper::_('form.token'); ?>
     <button type="submit" class="btn <?php echo $published?'btn-outline-success':'btn-outline-secondary'; ?>" data-published="<?php echo $published?'1':'0'; ?>" aria-label="<?php echo $this->escape(Text::sprintf($published?'COM_ALTACOURSES_EVALADMIN_UNPUBLISH':'COM_ALTACOURSES_EVALADMIN_PUBLISH',$name)); ?>"<?php echo $this->getModel()->isLocked($row)?' disabled':''; ?>>
      <span class="icon-<?php echo $published?'check':'times'; ?>" aria-hidden="true"></span><span class="visually-hidden"><?php echo $this->escape(Text::_($published?'JPUBLISHED':'JUNPUBLISHED')); ?></span>
     </button></form></td>
    <td><button type="button" class="btn btn-primary btn-sm" data-bs-toggle="collapse" data-bs-target="#evaluation-details-<?php echo $id; ?>" aria-expanded="false" aria-controls="evaluation-details-<?php echo $id; ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_EVALADMIN_SHOW')); ?></button></td>
   </tr>
   <tr class="evaluation-details-row"><td colspan="7" class="p-0"><div class="collapse" id="evaluation-details-<?php echo $id; ?>"><div class="evaluation-details p-3">
    <h2 class="h4"><?php echo $this->escape(Text::_('COM_ALTACOURSES_EVALADMIN_OCCASION')); ?></h2>
    <dl class="altacourses-account-summary">
     <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_EVALUATION_DATES')); ?></dt><dd><?php foreach ($row->sessions as $session) : ?><div><?php echo $this->escape($date($session['start_date']).' – '.$date($session['stop_date'])); ?></div><?php endforeach; ?><?php if (!$row->sessions) : ?><?php echo $this->escape(Text::_('COM_ALTACOURSES_EVALUATION_UNKNOWN')); ?><?php endif; ?></dd>
     <?php foreach (['course_place'=>'PLACE','leader1'=>'LEADERS','leader2'=>'LEADERS','supplier'=>'SUPPLIER'] as $f=>$label) : if ($f==='leader2'&&trim((string)$row->$f)==='') { continue; } ?>
      <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_EVALADMIN_'.$label)); ?></dt><dd><?php echo $this->escape(trim((string)$row->$f)!==''?(string)$row->$f:Text::_('COM_ALTACOURSES_EVALUATION_UNKNOWN')); ?></dd>
     <?php endforeach; ?>
    </dl>
    <h2 class="h4"><?php echo $this->escape(Text::_('COM_ALTACOURSES_EVALADMIN_REVIEW')); ?></h2>
    <p class="evaluation-text"><?php echo $this->escape(trim((string)$row->review)!==''?(string)$row->review:Text::_('COM_ALTACOURSES_EVALADMIN_NO_REVIEW')); ?></p>
    <?php foreach (['feedback','correction'] as $f) : if (trim((string)($row->$f??''))!=='') : ?><h2 class="h4"><?php echo $this->escape(Text::_('COM_ALTACOURSES_EVALADMIN_'.strtoupper($f))); ?> <span class="small"><?php echo $this->escape(Text::_('COM_ALTACOURSES_EVALADMIN_PRIVATE')); ?></span></h2><p class="evaluation-text" data-private="<?php echo $f; ?>"><?php echo $this->escape((string)$row->$f); ?></p><?php endif; endforeach; ?>
   </div></div></td></tr>
  <?php endforeach; ?></tbody>
 </table></div>
 <?php echo $this->pagination->getListFooter(); ?>
 <?php endif; ?>
</section>
