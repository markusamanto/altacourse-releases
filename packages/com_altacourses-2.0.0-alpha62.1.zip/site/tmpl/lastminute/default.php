<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;
?>
<section class="altacourses-portal" aria-labelledby="altacourses-lastminute-heading">
    <h1 id="altacourses-lastminute-heading"><?php echo $this->escape(Text::_($this->lastminuteId === 0 ? 'COM_ALTACOURSES_LASTMINUTE_ADD' : 'COM_ALTACOURSES_LASTMINUTE_EDIT')); ?></h1>
    <form id="altacourses-lastminute-form" action="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&task=lastminute.save', false)); ?>" method="post">
        <?php foreach (['id', 'version', 'ticket'] as $field) : ?><?php echo $this->form->getInput($field); ?><?php endforeach; ?>
        <?php foreach (['firstname', 'lastname', 'telephone', 'email', 'participated', 'notes'] as $field) : ?><?php echo $this->form->renderField($field); ?><?php endforeach; ?>
        <?php echo HTMLHelper::_('form.token'); ?>
        <button type="submit" class="btn btn-success"><?php echo $this->escape(Text::_('JSAVE')); ?></button>
        <a class="btn btn-secondary" href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=lastminutes', false)); ?>"><?php echo $this->escape(Text::_('JCANCEL')); ?></a>
        <?php if ($this->lastminuteId > 0) : ?>
            <a class="btn btn-secondary" href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=lastminute&id=' . $this->lastminuteId . '&fresh=1', false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_EDIT_RELOAD')); ?></a>
        <?php endif; ?>
    </form>
</section>
