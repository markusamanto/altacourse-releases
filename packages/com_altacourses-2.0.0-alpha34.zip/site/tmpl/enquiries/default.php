<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
\defined('_JEXEC') or die;
?>
<section aria-labelledby="altacourses-enquiries-heading">
    <h1 id="altacourses-enquiries-heading"><?php echo $this->escape(Text::_('COM_ALTACOURSES_ENQUIRIES_TITLE')); ?></h1>
    <p><a href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=dashboard', false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_BACK_TO_DASHBOARD')); ?></a></p>
    <?php if (!$this->items) : ?><p><?php echo $this->escape(Text::_('COM_ALTACOURSES_ENQUIRIES_EMPTY')); ?></p><?php else : ?>
    <div class="table-responsive"><table class="table table-striped"><thead><tr>
        <?php foreach (['ENQUIRY_DATE', 'ENQUIRY_NAME', 'ENQUIRY_ORGANISATION', 'ENQUIRY_EMAIL', 'SUPPLIER_PHONE', 'SUPPLIER_MOBILE', 'ENQUIRY_COURSE', 'ENQUIRY_SUPPLIER'] as $label) : ?><th scope="col"><?php echo $this->escape(Text::_('COM_ALTACOURSES_' . $label)); ?></th><?php endforeach; ?>
    </tr></thead><tbody>
    <?php foreach ($this->items as $item) : ?>
        <?php $contact = json_decode($item->contact_json, true, 512, JSON_THROW_ON_ERROR); $course = json_decode($item->course_json, true, 512, JSON_THROW_ON_ERROR); ?>
        <tr data-enquiry-id="<?php echo (int) $item->request_id; ?>">
            <td><?php echo $this->escape($item->created_at); ?></td>
            <td><?php echo $this->escape(($contact['firstname'] ?? '') . ' ' . ($contact['lastname'] ?? '')); ?></td>
            <?php foreach (['company', 'email', 'phone', 'mobile'] as $field) : ?><td><?php echo $this->escape($contact[$field] ?? ''); ?></td><?php endforeach; ?>
            <td><?php echo $this->escape(($course['course_type'] ?? '') . ' — ' . ($course['course_place'] ?? '')); ?>
                <?php foreach ($course['sessions'] ?? [] as $part) : ?><div><?php echo $this->escape(substr($part['start_date'] ?? '', 0, 10) . ' – ' . substr($part['stop_date'] ?? '', 0, 10)); ?></div><?php endforeach; ?>
            </td>
            <td><?php echo $this->escape($item->supplier_email); ?></td>
        </tr>
    <?php endforeach; ?></tbody></table></div>
    <?php echo $this->pagination->getPagesLinks(); ?>
    <?php endif; ?>
</section>
