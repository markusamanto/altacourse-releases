<?php

/**
 * @package     Altacourses.Administrator
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Administrator\Service;

use Joomla\Database\DatabaseInterface;
use Joomla\Database\ParameterType;
use Joomla\Database\QueryInterface;

\defined('_JEXEC') or die;

/** Shared schedule reading and date-filter semantics for public and protected lists. */
final class CourseSchedule
{
    public function __construct(private readonly DatabaseInterface $database)
    {
    }

    /** New-course date-only ranges, shared across course types. Existing records are untouched. */
    public function validateRanges(string $start, string $end, string $secondStart = '', string $secondEnd = ''): array
    {
        $pairs = [[$start, $end]];
        if ($secondStart !== '' || $secondEnd !== '') {
            $pairs[] = [$secondStart, $secondEnd];
        }
        return $this->validateDatePairs($pairs);
    }

    /** Validate a complete ordered schedule, including preserved read-only later sessions. */
    public function validateDatePairs(array $pairs): array
    {
        $ranges = [];
        $previousEnd = null;
        foreach ($pairs as [$from, $to]) {
            foreach ([$from, $to] as $value) {
                if (!preg_match('/^\d{4}-\d{2}-\d{2}$/D', $value)) {
                    throw new \InvalidArgumentException('Invalid course date');
                }
                $date = \DateTimeImmutable::createFromFormat('!Y-m-d', $value, new \DateTimeZone('UTC'));
                if (!$date || $date->format('Y-m-d') !== $value || (int) $date->format('Y') < 1000) {
                    throw new \InvalidArgumentException('Invalid course date');
                }
            }
            if ($to < $from || ($previousEnd !== null && $from <= $previousEnd)) {
                throw new \InvalidArgumentException('Course sessions must be chronological and non-overlapping');
            }
            $ranges[] = ['start_date' => $from . ' 00:00:00', 'stop_date' => $to . ' 00:00:00'];
            $previousEnd = $to;
        }
        return $ranges;
    }

    /** Caller supplies only IDs already selected by its authorised course query. */
    public function additionalSessions(array $courseIds): array
    {
        $courseIds = array_values(array_unique(array_filter(array_map('intval', $courseIds), static fn (int $id): bool => $id > 0)));
        if (!$courseIds) {
            return [];
        }
        $query = $this->database->createQuery()->select(['course_id', 'start_date', 'stop_date', 'ordering'])
            ->from('#__altacourses_course_sessions')->order(['course_id', 'ordering', 'id']);
        $parameters = [];
        foreach ($courseIds as $index => $courseId) {
            $parameter = ':schedule_' . $index;
            $parameters[] = $parameter;
            $query->bind($parameter, $courseId, ParameterType::INTEGER);
            unset($courseId);
        }
        $query->where('course_id IN (' . implode(',', $parameters) . ')');
        $result = [];
        foreach ($this->database->setQuery($query)->loadObjectList() as $session) {
            $result[(int) $session->course_id][] = $session;
        }
        return $result;
    }

    /** First-session start stays on courses; the final end includes all additional sessions. */
    public function applyEndDateFilter(QueryInterface $query, string $to): void
    {
        if ($to === '') {
            return;
        }
        $end = $to . ' 23:59:59';
        // Static aliases only. Both list models deliberately use co for their course table.
        $latest = '(SELECT MAX(extra.stop_date) FROM #__altacourses_course_sessions AS extra WHERE extra.course_id = co.id)';
        $finalEnd = 'CASE WHEN co.stop_date IS NULL THEN ' . $latest
            . ' ELSE GREATEST(co.stop_date, COALESCE(' . $latest . ', co.stop_date)) END';
        $query->where('(' . $finalEnd . ') <= :schedule_end')->bind(':schedule_end', $end);
    }
}
