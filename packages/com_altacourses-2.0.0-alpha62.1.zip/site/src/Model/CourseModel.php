<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Model;

use Joomla\CMS\Language\Text;
use Advenire\Component\Altacourses\Administrator\Service\CoursePriceAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\CoursePriceAwareTrait;
use Joomla\Database\ParameterType;

\defined('_JEXEC') or die;

final class CourseModel extends PubliccourseModel implements CoursePriceAwareInterface
{
    use CoursePriceAwareTrait;
    public function getPublicDetails(): array
    {
        $course=$this->getItem();
        return ['course'=>$course,'amount'=>$this->getCoursePrice()->formatTotal($course->course_price,$course->lodging_price,$course->lodging_included),
            'sessions'=>$this->getCourseSchedule()->currentSessions([(int)$course->id])[(int)$course->id]??[]];
    }

    public function getItem(): object
    {
        $id = (int) $this->getState('course.id', 0);
        if ($id <= 0) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_COURSE_NOT_FOUND'), 404);
        }
        // Explicit public projection: never expose supplier accounts, alerts or submission tokens.
        $query = $this->publicQuery()->select(['co.id', 'co.start_date', 'co.stop_date', 'co.course_price',
            'co.lodging_price', 'co.lodging_included', 'co.course_notes', 'ct.name AS course_type',
            'cp.name AS course_place', 're.name AS region', 'l1.name AS leader1', 'l2.name AS leader2',
            'se.label AS seats_label', 'cp.url AS place_article', 'l1.url AS leader1_article', 'l2.url AS leader2_article'])->where('co.id=:course')->bind(':course', $id, ParameterType::INTEGER);
        $item = $this->getDatabase()->setQuery($query)->loadObject();
        if ($item === null) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_COURSE_NOT_FOUND'), 404);
        }
        return $item;
    }
}
