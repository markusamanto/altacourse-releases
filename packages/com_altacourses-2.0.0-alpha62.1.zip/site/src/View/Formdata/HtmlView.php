<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\View\Formdata;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;

\defined('_JEXEC') or die;

final class HtmlView extends BaseHtmlView
{
    public ?object $item = null;
    public array $contact = [];
    public array $course = [];
    public int $returnStart = 0;
    public array $returnFilters = [];

    public function display($tpl = null): void
    {
        $this->item = $this->getModel()->getRecord((int) $this->getModel()->getState('request.id'));
        if ($this->item->submission_id !== null) {
            $this->contact = json_decode($this->item->contact_json, true, 512, JSON_THROW_ON_ERROR);
            $this->course = json_decode($this->item->course_json, true, 512, JSON_THROW_ON_ERROR);
        }
        $this->getDocument()->setTitle(Text::_('COM_ALTACOURSES_FORMDATA_TITLE'));
        $this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.site');
        parent::display($tpl);
    }
}
