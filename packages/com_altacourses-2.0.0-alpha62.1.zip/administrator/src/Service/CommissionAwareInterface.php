<?php

/** @package Altacourses.Administrator @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Administrator\Service;

\defined('_JEXEC') or die;

interface CommissionAwareInterface
{
    public function setCommissionReport(CommissionReport $report): void;
}
