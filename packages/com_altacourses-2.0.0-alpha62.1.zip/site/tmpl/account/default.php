<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;
?>
<section class="altacourses-portal" aria-labelledby="altacourses-account-heading">
    <h1 id="altacourses-account-heading"><?php echo $this->escape(Text::_($this->accountId === 0 ? 'COM_ALTACOURSES_ACCOUNT_ADD' : 'COM_ALTACOURSES_ACCOUNT_EDIT')); ?></h1>
    <form id="altacourses-account-form" action="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&task=account.save', false)); ?>" method="post">
        <?php foreach (['id', 'version', 'ticket'] as $field) : ?><?php echo $this->form->getInput($field); ?><?php endforeach; ?>
        <?php foreach (\Advenire\Component\Altacourses\Site\Model\AccountsModel::TEXT_FIELDS as $field) : ?><?php echo $this->form->renderField($field); ?><?php endforeach; ?>
        <?php echo $this->form->renderField('state'); ?>
        <?php echo HTMLHelper::_('form.token'); ?>
        <button type="submit" class="btn btn-success"><?php echo $this->escape(Text::_('JSAVE')); ?></button>
        <a class="btn btn-secondary" href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=accounts', false)); ?>"><?php echo $this->escape(Text::_('JCANCEL')); ?></a>
        <?php if ($this->accountId > 0) : ?>
            <a class="btn btn-secondary" href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=account&id=' . $this->accountId . '&fresh=1', false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_EDIT_RELOAD')); ?></a>
        <?php endif; ?>
    </form>
</section>
