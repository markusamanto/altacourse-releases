<?php

/** @package Altacourses.Administrator @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Administrator\Service;

use Joomla\CMS\Language\Text;
use Joomla\Database\DatabaseInterface;
use Joomla\Database\ParameterType;

\defined('_JEXEC') or die;

/** A request-scoped capability; tokens live in the private supplier message, only hashes on requests. */
final class RequestReceipt
{
    public function __construct(private readonly DatabaseInterface $db, private readonly string $secret = '') {}

    /** Called once while preparing messages inside the submission transaction. */
    public function issue(int $requestId): string
    {
        $token = bin2hex(random_bytes(32));
        $hash = hash('sha256', $token);
        $query = $this->db->createQuery()->update('#__altacourses_requests')
            ->set('receipt_token_hash=:hash')->bind(':hash', $hash)
            ->where('id=:request')->bind(':request', $requestId, ParameterType::INTEGER)
            ->where('receipt_token_hash IS NULL');
        $this->db->setQuery($query)->execute();
        if ($this->db->getAffectedRows() !== 1) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_NOTIFY_CHANGED'), 409);
        }
        return $token;
    }

    /** Stable signed capability for reminders, including records without a saved supplier email. */
    public function reminderToken(int $id): string
    {
        if ($id <= 0 || $id > 2147483647 || strlen($this->secret) < 16) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_UNREAD_SECRET_MISSING'), 409);
        }
        return 'h' . $id . '.' . hash_hmac('sha256', 'altacourses-request-receipt:' . $id, $this->secret);
    }

    /** Atomic first acknowledgement. Repeated/concurrent clicks never replace its date. */
    public function acknowledge(mixed $token): void
    {
        $id = null;
        if (is_string($token) && preg_match('/^h([1-9][0-9]{0,9})\.[a-f0-9]{64}$/D', $token, $match)
            && (float) $match[1] <= 2147483647 && strlen($this->secret) >= 16
            && hash_equals($this->reminderToken((int) $match[1]), $token)) {
            $id = (int) $match[1];
        } elseif (!is_string($token) || !preg_match('/^[a-f0-9]{64}$/D', $token)) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_RECEIPT_INVALID'), 404);
        }
        $value = $id ?? hash('sha256', $token);
        $column = $id !== null ? 'id' : 'receipt_token_hash';
        $type = $id !== null ? ParameterType::INTEGER : ParameterType::STRING;
        $now = (new \DateTimeImmutable('now', new \DateTimeZone('UTC')))->format('Y-m-d H:i:s');
        $query = $this->db->createQuery()->update('#__altacourses_requests')
            ->set('received_at=COALESCE(received_at,:now)')->bind(':now', $now)
            ->set('received=1')->where($column . '=:receipt')->bind(':receipt', $value, $type)
            ->where('(received=0 OR received IS NULL)');
        $this->db->setQuery($query)->execute();
        if ($this->db->getAffectedRows() === 1) { return; }
        $query = $this->db->createQuery()->select('id')->from('#__altacourses_requests')
            ->where($column . '=:receipt')->bind(':receipt', $value, $type);
        if ($this->db->setQuery($query)->loadResult() === null) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_RECEIPT_INVALID'), 404);
        }
        // Historical received=1 / received_at=NULL remains an acknowledgement of unknown date.
    }
}
