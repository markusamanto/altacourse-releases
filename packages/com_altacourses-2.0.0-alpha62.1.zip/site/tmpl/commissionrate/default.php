<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;
?>
<h1><?php echo $this->escape(Text::_('COM_ALTACOURSES_COMMISSION_RATE')); ?></h1>
<h2><?php echo $this->escape($this->company); ?></h2>
<form id="commission-rate-form" method="post" action="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&task=commissions.saverate', false)); ?>">
    <?php foreach (['user_id', 'version', 'month', 'fee'] as $field) : ?><?php echo $this->form->renderField($field); ?><?php endforeach; ?>
    <?php echo HTMLHelper::_('form.token'); ?>
    <button class="btn btn-primary" type="submit"><?php echo $this->escape(Text::_('JSAVE')); ?></button>
    <a class="btn btn-secondary" href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=commissions&month=' . rawurlencode($this->month), false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_COMMISSION_BACK')); ?></a>
</form>
