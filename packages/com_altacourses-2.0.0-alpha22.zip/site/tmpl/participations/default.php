<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;
?>
<section aria-labelledby="participations-title">
    <h1 id="participations-title"><?php echo $this->escape(Text::_('COM_ALTACOURSES_PARTICIPATION_TITLE')); ?></h1>
    <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_PARTICIPATION_INTRO')); ?></p>
    <p><a href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=dashboard', false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_BACK_TO_DASHBOARD')); ?></a></p>
    <form method="get" action="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=participations', false)); ?>">
        <input type="hidden" name="option" value="com_altacourses" /><input type="hidden" name="view" value="participations" />
        <label for="report-filter"><?php echo $this->escape(Text::_('COM_ALTACOURSES_PARTICIPATION_STATUS')); ?></label>
        <select name="status" id="report-filter" class="form-select">
        <?php foreach (['pending' => 'PENDING', 'reported' => 'REPORTED', 'all' => 'ALL'] as $value => $label) : ?>
            <option value="<?php echo $this->escape($value); ?>"<?php if ($this->status === $value) : ?> selected<?php endif; ?>><?php echo $this->escape(Text::_('COM_ALTACOURSES_PARTICIPATION_' . $label)); ?></option>
        <?php endforeach; ?>
        </select><button type="submit" class="btn btn-primary"><?php echo $this->escape(Text::_('COM_ALTACOURSES_CONTACTS_FILTER')); ?></button>
    </form>
    <p data-participation-total="<?php echo (int) $this->pagination->total; ?>"><?php echo $this->escape(Text::sprintf('COM_ALTACOURSES_CONTACTS_TOTAL', (int) $this->pagination->total)); ?></p>
    <?php if (!$this->items) : ?><p><?php echo $this->escape(Text::_('COM_ALTACOURSES_PARTICIPATION_EMPTY')); ?></p><?php else : ?>
    <div class="table-responsive"><table class="table table-striped"><thead><tr>
        <?php foreach (['ENQUIRY_NAME', 'ENQUIRY_ORGANISATION', 'PARTICIPANT_KIND', 'COURSE_TYPE', 'PLACE', 'DATES', 'PARTICIPATION_STATUS', 'SIGNUP_VIEW'] as $label) : ?><th scope="col"><?php echo $this->escape(Text::_('COM_ALTACOURSES_' . $label)); ?></th><?php endforeach; ?>
    </tr></thead><tbody>
    <?php foreach ($this->items as $item) : ?>
        <?php $person = json_decode($item->contact_json, true, 512, JSON_THROW_ON_ERROR); $course = json_decode($item->course_json, true, 512, JSON_THROW_ON_ERROR); ?>
        <tr data-participation-id="<?php echo (int) $item->id; ?>">
            <td><?php echo $this->escape(($person['firstname'] ?? '') . ' ' . ($person['lastname'] ?? '')); ?></td>
            <td><?php echo $this->escape($person['company'] ?? ''); ?></td>
            <td><?php echo $this->escape(Text::_('COM_ALTACOURSES_' . ((int) $item->asked_for_info === 1 ? 'ENQUIRY_TITLE' : 'SIGNUP_TITLE'))); ?></td>
            <td><?php echo $this->escape($course['course_type'] ?? ''); ?></td><td><?php echo $this->escape($course['course_place'] ?? ''); ?></td>
            <td><?php foreach ($course['sessions'] ?? [] as $part) : ?><div><?php echo $this->escape(substr($part['start_date'] ?? '', 0, 10) . ' – ' . substr($part['stop_date'] ?? '', 0, 10)); ?></div><?php endforeach; ?></td>
            <td><?php echo $this->escape(Text::_('COM_ALTACOURSES_PARTICIPATION_' . ($item->date_reported === null ? 'PENDING' : ((int) $item->participated === 1 ? 'YES' : 'NO')))); ?></td>
            <td><a href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=participation&id=' . (int) $item->id, false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_SIGNUP_VIEW')); ?></a></td>
        </tr>
    <?php endforeach; ?></tbody></table></div>
    <?php echo $this->pagination->getPagesLinks(); ?>
    <?php endif; ?>
</section>
