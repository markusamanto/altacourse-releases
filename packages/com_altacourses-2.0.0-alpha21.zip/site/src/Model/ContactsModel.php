<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Model;

use Joomla\CMS\Language\Text;
use Joomla\Database\QueryInterface;

\defined('_JEXEC') or die;

final class ContactsModel extends EnquiriesModel
{
    use ContactScopeTrait;

    public function getItems(): array
    {
        $query = $this->buildQuery()->select(['s.request_id', 's.created_at', 's.contact_json', 's.course_json', 'r.asked_for_info'])
            ->order('s.created_at DESC, s.request_id DESC');
        return $this->getDatabase()->setQuery($query, (int) $this->getState('list.start', 0), 20)->loadObjectList();
    }

    public function getTotal(): int
    {
        return (int) $this->getDatabase()->setQuery($this->buildQuery()->select('COUNT(*)'))->loadResult();
    }

    public function getTypeOptions(): array
    {
        $query = $this->baseQuery()->select("DISTINCT JSON_UNQUOTE(JSON_EXTRACT(s.course_json,'$.course_type')) AS value")->order('value');
        return $this->getDatabase()->setQuery($query)->loadColumn();
    }

    private function baseQuery(): QueryInterface
    {
        $query = $this->getDatabase()->createQuery()->from('#__altacourses_request_submissions AS s')
            ->join('INNER', '#__altacourses_requests AS r ON r.id=s.request_id')->where('r.asked_for_info IN (0, 1)');
        $this->scopeContacts($query);
        return $query;
    }

    private function buildQuery(): QueryInterface
    {
        $query = $this->baseQuery();
        $kind = $this->getState('filter.kind', 'all');
        $search = $this->getState('filter.search', '');
        $type = $this->getState('filter.type', '');
        if (!is_string($kind) || !in_array($kind, ['all', 'enquiry', 'signup'], true)
            || !is_string($search) || mb_strlen($search) > 120 || preg_match('/[\x00-\x1f\x7f]/', $search)
            || !is_string($type) || mb_strlen($type) > 255 || preg_match('/[\x00-\x1f\x7f]/', $type)) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_FILTER'), 400);
        }
        if ($kind !== 'all') { $query->where('r.asked_for_info=' . ($kind === 'enquiry' ? '1' : '0')); }
        if ($search !== '') {
            $needle = '%' . str_replace(['=', '%', '_'], ['==', '=%', '=_'], trim($search)) . '%';
            $query->where("CONCAT_WS(' ', JSON_UNQUOTE(JSON_EXTRACT(s.contact_json,'$.firstname')), JSON_UNQUOTE(JSON_EXTRACT(s.contact_json,'$.lastname')), JSON_UNQUOTE(JSON_EXTRACT(s.contact_json,'$.company')), JSON_UNQUOTE(JSON_EXTRACT(s.contact_json,'$.email'))) COLLATE utf8mb4_unicode_ci LIKE :contact_search ESCAPE '='")
                ->bind(':contact_search', $needle);
        }
        if ($type !== '') {
            $query->where("JSON_UNQUOTE(JSON_EXTRACT(s.course_json,'$.course_type'))=:contact_type")->bind(':contact_type', $type);
        }
        return $query;
    }
}
