<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\View\Accountclients;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Pagination\Pagination;

\defined('_JEXEC') or die;

class HtmlView extends BaseHtmlView
{
    public array $items = [];
    public ?object $account = null;
    public ?Pagination $pagination = null;

    public function display($tpl = null): void
    {
        $model = $this->getModel();
        $model->requireAdministrator();
        if ($this->getName() === 'accountclients') {
            $this->account = $model->getAccountRecord((int) $model->getState('account.id'));
        }
        $this->items = $model->getItems();
        $this->getDocument()->setTitle(Text::_($this->account === null ? 'COM_ALTACOURSES_KEYACCOUNTS_TITLE' : 'COM_ALTACOURSES_ACCOUNTCLIENTS_TITLE'));
        $this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.site');
        parent::display($tpl);
    }
}
