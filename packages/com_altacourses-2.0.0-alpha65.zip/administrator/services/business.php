<?php

/** @package Altacourses.Administrator @license GNU General Public License version 2 or later */
\defined('_JEXEC') or die;

use Advenire\Component\Altacourses\Administrator\Service\CommissionReport;
use Advenire\Component\Altacourses\Administrator\Service\CoursePrice;
use Advenire\Component\Altacourses\Administrator\Service\CourseSchedule;
use Advenire\Component\Altacourses\Administrator\Service\NotificationService;
use Advenire\Component\Altacourses\Administrator\Service\MonthlyReport;
use Advenire\Component\Altacourses\Administrator\Service\SupplierReminders;
use Joomla\CMS\Mail\MailerFactoryInterface;
use Joomla\CMS\Language\LanguageFactoryInterface;
use Joomla\Database\DatabaseInterface;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;

return new class () implements ServiceProviderInterface {
    public function register(Container $container): void
    {
        $container->set(\Advenire\Component\Altacourses\Administrator\Service\Recaptcha::class,static fn(Container $c)=>new \Advenire\Component\Altacourses\Administrator\Service\Recaptcha($c->get(DatabaseInterface::class)));
        $container->set(\Advenire\Component\Altacourses\Administrator\Service\MailchimpEnrollments::class,static fn(Container $c)=>new \Advenire\Component\Altacourses\Administrator\Service\MailchimpEnrollments($c->get(DatabaseInterface::class)));
        $container->set(\Advenire\Component\Altacourses\Administrator\Service\ZenlerNewsletter::class,static fn(Container $c)=>new \Advenire\Component\Altacourses\Administrator\Service\ZenlerNewsletter($c->get(DatabaseInterface::class)));
        $container->set(CommissionReport::class, static fn (Container $container): CommissionReport => new CommissionReport($container->get(DatabaseInterface::class), $container->get('config'), $container->get(CourseSchedule::class)));
        $container->set(CoursePrice::class, static fn (): CoursePrice => new CoursePrice());
        $container->set(CourseSchedule::class, static fn (Container $container): CourseSchedule => new CourseSchedule($container->get(DatabaseInterface::class)));
        $container->set(NotificationService::class, static fn (Container $container): NotificationService => new NotificationService(
            $container->get(DatabaseInterface::class), $container->get('config'),
            $container->get(MailerFactoryInterface::class), $container->get(LanguageFactoryInterface::class), $container->get(CoursePrice::class)
        ));
        $container->set(\Advenire\Component\Altacourses\Administrator\Service\EvaluationInvitations::class,static fn(Container $c)=>new \Advenire\Component\Altacourses\Administrator\Service\EvaluationInvitations($c->get(DatabaseInterface::class),$c->get('config'),$c->get(NotificationService::class),$c->get(MailerFactoryInterface::class)));
        $container->set(SupplierReminders::class, static fn (Container $container): SupplierReminders => new SupplierReminders($container->get(DatabaseInterface::class),$container->get('config'),$container->get(NotificationService::class),$container->get(MailerFactoryInterface::class)));
        $container->set(MonthlyReport::class, static fn (Container $container): MonthlyReport => new MonthlyReport(
            $container->get(DatabaseInterface::class), $container->get('config'), $container->get(CommissionReport::class),
            $container->get(NotificationService::class), $container->get(MailerFactoryInterface::class), $container->get(LanguageFactoryInterface::class)
        ));
    }
};
