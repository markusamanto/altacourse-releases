-- Independent last-minute list; preserve imported rows/IDs and other tables.
-- Existing imports receive a primary/automatic ID conditionally in script.php.
CREATE TABLE IF NOT EXISTS `#__altacourses_lastminute` (
 `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
 `firstname` varchar(255) DEFAULT NULL,
 `lastname` varchar(255) DEFAULT NULL,
 `telephone` varchar(255) DEFAULT NULL,
 `email` varchar(255) DEFAULT NULL,
 `participated` varchar(11) DEFAULT '0',
 `notes` text DEFAULT NULL,
 `ordering` int DEFAULT '0',
 `state` tinyint(1) DEFAULT '0',
 `checked_out` int DEFAULT '0',
 `checked_out_time` datetime DEFAULT NULL,
 `created_by` int DEFAULT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
