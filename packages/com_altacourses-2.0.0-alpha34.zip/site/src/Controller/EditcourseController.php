<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Controller;

use Advenire\Component\Altacourses\Site\Exception\CourseValidationException;
use Advenire\Component\Altacourses\Site\Model\CourseformModel;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;

final class EditcourseController extends BaseController
{
    public function execute($task)
    {
        if (strtolower((string) $task) !== 'save') {
            throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'), 404);
        }
        return parent::execute($task);
    }

    public function save(): void
    {
        $model = $this->getModel('Editcourse', 'Site', ['ignore_request' => true]);
        $model->isAdministrator();
        if ($this->input->getMethod() !== 'POST') {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_SAMPLE_POST_REQUIRED'), 405);
        }
        if (!$this->checkToken('post', false)) {
            throw new \RuntimeException(Text::_('JINVALID_TOKEN'), 403);
        }
        $raw = $this->input->post->get('jform', [], 'array');
        foreach (['id', 'version'] as $name) {
            if (!isset($raw[$name]) || !is_scalar($raw[$name]) || !ctype_digit((string) $raw[$name]) || (float) $raw[$name] > 2147483647) {
                throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_FILTER'), 400);
            }
        }
        $id = (int) $raw['id'];
        $version = (int) $raw['version'];
        $record = $model->getRecord($id);
        $original = $model->formData($record);
        $key = 'com_altacourses.editcourse.' . (int) $this->app->getIdentity()->id . '.' . $id;
        $draft = ['id' => (string) $id, 'version' => (string) $version];
        foreach (array_diff(CourseformModel::FIELDS, ['submission']) as $name) {
            if (isset($raw[$name]) && is_scalar($raw[$name])) {
                $value = (string) $raw[$name];
                if (mb_strlen($value) <= ($name === 'course_notes' ? 10000 : 255)) {
                    $draft[$name] = $value;
                } elseif ($value !== ($original[$name] ?? null)) {
                    $draft[$name] = mb_substr($value, 0, $name === 'course_notes' ? 10000 : 255);
                }
            }
        }
        // Unchecked checkboxes are absent from browser POSTs; do not repopulate an older checked value.
        $draft['lodging_included'] ??= '0';
        $this->app->setUserState($key, $draft);
        unset($raw['id'], $raw['version']);
        try {
            $model->saveCourse($id, $version, $raw);
        } catch (CourseValidationException $exception) {
            foreach ($exception->messages as $message) {
                $this->app->enqueueMessage($message, 'warning');
            }
            $this->setRedirect(Route::_('index.php?option=com_altacourses&view=editcourse&id=' . $id, false));
            return;
        } catch (\Throwable $exception) {
            if (in_array($exception->getCode(), [403, 404, 409], true)
                && in_array($exception->getMessage(), [Text::_('JERROR_ALERTNOAUTHOR'), Text::_('COM_ALTACOURSES_AVAILABILITY_NOT_FOUND'),
                    Text::_('COM_ALTACOURSES_AVAILABILITY_LOCKED'), Text::_('COM_ALTACOURSES_EDIT_CONFLICT')], true)) {
                throw $exception;
            }
            $this->app->getLogger()->error('Altacourses course editing failed', ['exception' => $exception]);
            $this->setMessage(Text::_('COM_ALTACOURSES_EDIT_FAILED'), 'warning');
            $this->setRedirect(Route::_('index.php?option=com_altacourses&view=editcourse&id=' . $id, false));
            return;
        }
        $this->app->setUserState($key, null);
        $this->setMessage(Text::_('COM_ALTACOURSES_EDIT_SAVED'));
        $this->setRedirect(Route::_('index.php?option=com_altacourses&view=managecourses&id=' . $id, false));
    }
}
