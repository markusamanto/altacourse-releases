<?php
/** @package Altacourses.Module @license GNU General Public License version 2 or later */
\defined('_JEXEC') or die;
// HTML is maintained through Joomla's filtered module editor; replacements are scalar/escaped.
?>
<div class="altacourses-letter card" data-altacourses-letter><div class="card-body"><?php echo $body; ?></div></div>
