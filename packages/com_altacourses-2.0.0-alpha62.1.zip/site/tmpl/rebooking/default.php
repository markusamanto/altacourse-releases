<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
use Joomla\CMS\Language\Text;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Router\Route;
\defined('_JEXEC') or die;
?>
<section aria-labelledby="rebooking-heading">
<h1 id="rebooking-heading"><?php echo $this->escape(Text::_('COM_ALTACOURSES_REBOOK_ACTION')); ?> #<?php echo (int) $this->record->id; ?></h1>
<h2><?php echo $this->escape($this->context['name']); ?></h2>
<p><?php echo $this->escape(Text::_('COM_ALTACOURSES_REBOOK_SOURCE') . ' #' . $this->context['course_id'] . ' · ' . substr($this->context['start_date'], 0, 10)); ?></p>
<p><?php echo $this->escape(Text::_('COM_ALTACOURSES_REBOOK_INDIVIDUAL_HELP')); ?></p>
<p><a href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=client&id=' . (int) $this->record->clientid, false)); ?>"><?php echo $this->escape(Text::_('JCANCEL')); ?></a></p>
<?php if (!$this->options) : ?><p><?php echo $this->escape(Text::_('COM_ALTACOURSES_REBOOK_NO_OPTIONS')); ?></p><?php else : ?>
<form method="post" id="altacourses-rebooking-form" action="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&task=rebooking.save', false)); ?>">
<input type="hidden" name="jform[id]" value="<?php echo (int) $this->record->id; ?>" />
<input type="hidden" name="jform[version]" value="<?php echo $this->escape($this->getModel()->revision($this->record)); ?>" />
<label for="rebooking-destination"><?php echo $this->escape(Text::_('COM_ALTACOURSES_REBOOK_TO')); ?></label>
<select id="rebooking-destination" class="form-select" name="jform[destination]" required>
<option value=""><?php echo $this->escape(Text::_('JSELECT')); ?></option>
<?php foreach ($this->options as $target) : ?>
<?php $dates = array_map(static fn ($part): string => substr($part->start_date, 0, 10) . ' – ' . substr($part->stop_date, 0, 10), $target->sessions); ?>
<option value="<?php echo (int) $target->id . ':' . $this->escape($target->target_version); ?>"><?php echo $this->escape('#' . $target->id . ' · ' . $target->type_name . ' · ' . $target->place_name . ' · ' . implode(' / ', $dates)); ?></option>
<?php endforeach; ?>
</select>
<label for="rebooking-note"><?php echo $this->escape(Text::_('COM_ALTACOURSES_PARTICIPATION_NOTE')); ?></label>
<textarea id="rebooking-note" class="form-control" name="jform[note]" maxlength="4000"></textarea>
<?php echo HTMLHelper::_('form.token'); ?>
<button type="submit" class="btn btn-success"><?php echo $this->escape(Text::_('COM_ALTACOURSES_REBOOK_ACTION')); ?></button>
</form>
<?php endif; ?>
</section>
