<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\View\Mailtemplate;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;

\defined('_JEXEC') or die;

final class HtmlView extends BaseHtmlView
{
    public ?\Joomla\CMS\Form\Form $form = null;
    public int $mailtemplateId = 0;

    public function display($tpl = null): void
    {
        $this->getModel()->requireAdministrator();

        $this->getDocument()->setTitle(Text::_(($this->mailtemplateId === 0 ? 'COM_ALTACOURSES_MAILTEMPLATE_ADD' : 'COM_ALTACOURSES_MAILTEMPLATE_EDIT')));
        $this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.site');
        parent::display($tpl);
    }
}
