-- Existing imported rows and course_type NULL values are retained.
-- Conditional adoption of an existing table/column and the unique published key
-- is completed by the install/update lifecycle in script.php.
CREATE TABLE IF NOT EXISTS `#__altacourses_mailtemplates` (
 `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
 `type` int NOT NULL,
 `course_type` int DEFAULT NULL,
 `name` varchar(255) NOT NULL,
 `subject` varchar(255) NOT NULL,
 `from_name` varchar(255) NOT NULL,
 `from_email` varchar(255) NOT NULL,
 `message` text NOT NULL,
 `ordering` int NOT NULL DEFAULT 0,
 `state` int DEFAULT NULL,
 `checked_out` int NOT NULL DEFAULT 0,
 `checked_out_time` datetime DEFAULT NULL,
 `created_by` int NOT NULL DEFAULT 0,
 `published_course_type` int GENERATED ALWAYS AS (CASE WHEN `state` = 1 THEN COALESCE(`course_type`, 0) ELSE NULL END) STORED,
 PRIMARY KEY (`id`),
 UNIQUE KEY `idx_mailtemplate_published` (`type`, `published_course_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
