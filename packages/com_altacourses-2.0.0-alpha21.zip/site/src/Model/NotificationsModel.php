<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Model;

use Advenire\Component\Altacourses\Administrator\Service\NotificationAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\NotificationAwareTrait;
use Joomla\CMS\Language\Text;

\defined('_JEXEC') or die;

final class NotificationsModel extends EnquiriesModel implements NotificationAwareInterface
{
    use NotificationAwareTrait;

    public function getRecord(int $id): array
    {
        $this->requireAdministrator();
        $row = $this->getDatabase()->setQuery('SELECT request_id FROM #__altacourses_request_submissions WHERE request_id=' . $id)->loadObject();
        if ($id <= 0 || $row === null) { throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'), 404); }
        return ['id' => $id, 'messages' => $this->getNotifications()->getMessages($id),
            'blocked' => $this->getNotifications()->blockedReason(), 'mode' => $this->getNotifications()->settings()['mode']];
    }

    public function prepare(int $id): void
    {
        $this->getRecord($id);
        $db = $this->getDatabase();
        $db->transactionStart();
        try { $this->getNotifications()->prepare($id); $db->transactionCommit(); }
        catch (\Throwable $error) { $db->transactionRollback(); throw $error; }
    }

    public function send(int $id): void
    {
        $this->getRecord($id);
        $this->requireEnabled();
        $this->getNotifications()->deliver($id);
    }

    public function retry(int $id, int $messageId, bool $reviewed): void
    {
        $this->getRecord($id);
        $this->requireEnabled();
        if (!$reviewed) { throw new \RuntimeException(Text::_('COM_ALTACOURSES_NOTIFY_REVIEW_REQUIRED'), 409); }
        $this->getNotifications()->retry($id, $messageId, (int) $this->currentActorId());
    }

    private function requireEnabled(): void
    {
        if ($this->getNotifications()->blockedReason() !== null) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_NOTIFY_BLOCKED'), 409);
        }
    }

    public function confirm(int $id, int $messageId, bool $reviewed): void
    {
        $this->getRecord($id);
        if (!$reviewed) { throw new \RuntimeException(Text::_('COM_ALTACOURSES_NOTIFY_REVIEW_REQUIRED'), 409); }
        $this->getNotifications()->confirm($id, $messageId, $this->currentActorId());
    }
}
