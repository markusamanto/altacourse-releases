<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Controller;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;
use Joomla\CMS\MVC\View\ViewInterface;
use Joomla\CMS\Pagination\Pagination;

\defined('_JEXEC') or die;

final class DisplayController extends BaseController
{
    protected $default_view = 'dashboard';

    public function execute($task)
    {
        if (!in_array(strtolower((string) $task), ['', 'display'], true)) {
            throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'), 404);
        }

        return parent::execute($task);
    }

    public function display($cachable = false, $urlparams = [])
    {
        $viewName = $this->input->getCmd('view', 'dashboard');
        if (!in_array($viewName, ['dashboard', 'courses', 'managecourses', 'availability', 'assignment', 'newcourse'], true)
            || $this->input->getCmd('layout', 'default') !== 'default'
            || $this->app->getDocument()->getType() !== 'html') {
            throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'), 404);
        }

        if ($viewName === 'courses') {
            return parent::display(false, []);
        }

        $user = $this->app->getIdentity();

        if ($user->guest) {
            $return = 'index.php?option=com_altacourses&view=' . $viewName;
            if (in_array($viewName, ['availability', 'assignment'], true)) {
                $return .= '&id=' . $this->readInteger('id');
            }
            $itemId = $this->input->getInt('Itemid');

            if ($itemId > 0) {
                $return .= '&Itemid=' . $itemId;
            }

            // Joomla validates index.php-relative returns; format the SEF URL after login.
            // Never accept a return URL supplied by the visitor.
            $this->setRedirect(Route::_('index.php?option=com_users&view=login&return=' . rawurlencode(base64_encode($return)), false));

            return $this;
        }

        if (!$user->authorise('altacourses.manage', 'com_altacourses')
            && !$user->authorise('altacourses.supplier', 'com_altacourses')) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }

        // Never cache a page whose content depends on the current user's role.
        return parent::display(false, []);
    }

    protected function prepareViewModel(ViewInterface $view)
    {
        if ($view->getName() === 'newcourse') {
            $model = $this->getModel('Newcourse', 'Site', ['ignore_request' => true]);
            $model->isAdministrator();
            $key = 'com_altacourses.newcourse.' . (int) $this->app->getIdentity()->id;
            if ($this->input->getBool('fresh')) {
                $this->app->setUserState($key . '.draft', null);
            }
            $data = $this->app->getUserState($key . '.draft', []) ?: [];
            $tickets = array_filter($this->app->getUserState($key . '.tickets', []), static fn ($time): bool => $time >= time() - 14400);
            if (!isset($data['submission']) || !isset($tickets[$data['submission']])) {
                $data['submission'] = bin2hex(random_bytes(32));
                $tickets = array_slice($tickets, -19, null, true);
                $tickets[$data['submission']] = time();
            }
            $this->app->setUserState($key . '.tickets', $tickets);
            $view->form = $model->getForm($data);
            $view->setModel($model, true);
            return;
        }
        if (in_array($view->getName(), ['availability', 'assignment'], true)) {
            $model = $this->getModel(ucfirst($view->getName()), 'Site', ['ignore_request' => true]);
            $view->course = $model->getCourse($this->readInteger('id'));
            $view->form = $model->getForm([
                'id' => (int) $view->course->id,
                'version' => (int) $view->course->availability_version,
                ($view->getName() === 'assignment' ? 'supplier' : 'availability') => $view->getName() === 'assignment'
                    ? (int) $view->course->cr : $view->course->nr_of_participants,
            ]);
            $view->setModel($model, true);
            return;
        }
        $managed = $view->getName() === 'managecourses';
        if (!$managed && $view->getName() !== 'courses') {
            parent::prepareViewModel($view);
            $view->allowTestData = (bool) $this->app->getParams('com_altacourses')->get('allow_test_data', false);
            return;
        }

        $model = $this->getModel($managed ? 'Managecourses' : 'Courses', 'Site', ['ignore_request' => true]);
        $filters = [
            'type' => $this->readInteger('type'),
            'region' => $this->readInteger('region'),
            'from' => $this->readDate('from'),
            'to' => $this->readDate('to'),
        ];
        if ($managed) {
            $filters['id'] = $this->readInteger('id');
        }
        if ($filters['from'] !== '' && $filters['to'] !== '' && $filters['from'] > $filters['to']) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_FILTER'), 400);
        }
        foreach ($filters as $key => $value) {
            $model->setState('filter.' . $key, $value);
        }

        $pagination = new Pagination($model->getTotal(), $this->readInteger('limitstart'), 20, '', $this->app);
        foreach (['option' => 'com_altacourses', 'view' => $view->getName()] + $filters as $key => $value) {
            $pagination->setAdditionalUrlParam($key, $value);
        }
        $itemId = $this->input->getInt('Itemid');
        if ($itemId > 0) {
            $pagination->setAdditionalUrlParam('Itemid', $itemId);
        }
        $model->setState('list.start', $pagination->limitstart);
        $model->setState('list.limit', 20);
        $view->setModel($model, true);
        $view->pagination = $pagination;
        $view->filters = $filters;
    }

    private function readInteger(string $name): int
    {
        $raw = $this->input->get($name, '0', 'raw');
        if (!is_scalar($raw) || !ctype_digit((string) $raw) || (float) $raw > 2147483647) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_FILTER'), 400);
        }
        return (int) $raw;
    }

    private function readDate(string $name): string
    {
        $raw = $this->input->get($name, '', 'raw');
        if (!is_string($raw)) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_FILTER'), 400);
        }
        if ($raw === '') {
            return '';
        }
        $date = \DateTimeImmutable::createFromFormat('!Y-m-d', $raw, new \DateTimeZone('UTC'));
        if (!$date || $date->format('Y-m-d') !== $raw || (int) $date->format('Y') < 1000) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_FILTER'), 400);
        }
        return $raw;
    }
}
