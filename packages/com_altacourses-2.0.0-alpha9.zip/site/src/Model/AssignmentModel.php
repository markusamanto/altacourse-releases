<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Model;

use Joomla\CMS\Form\Form;
use Joomla\CMS\Form\FormFactoryAwareInterface;
use Joomla\CMS\Form\FormFactoryAwareTrait;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\CMS\MVC\Model\BaseModel;
use Joomla\CMS\User\CurrentUserInterface;
use Joomla\CMS\User\User;
use Joomla\CMS\User\UserFactoryAwareInterface;
use Joomla\CMS\User\UserFactoryAwareTrait;
use Joomla\Database\DatabaseAwareInterface;
use Joomla\Database\DatabaseAwareTrait;
use Joomla\Database\ParameterType;

\defined('_JEXEC') or die;

final class AssignmentModel extends BaseModel implements DatabaseAwareInterface, CurrentUserInterface, FormFactoryAwareInterface, UserFactoryAwareInterface
{
    use DatabaseAwareTrait;
    use FormFactoryAwareTrait;
    use UserFactoryAwareTrait;

    private ?User $currentUser = null;

    public function __construct($config = [], ?MVCFactoryInterface $factory = null)
    {
        parent::__construct($config);
    }

    public function setCurrentUser(User $currentUser): void
    {
        $this->currentUser = $currentUser;
    }

    public function getCourse(int $id): object
    {
        if ($id <= 0) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_ASSIGNMENT'), 400);
        }
        $db = $this->getDatabase();
        $query = $db->createQuery()->select('co.*')->from('#__altacourses_courses AS co')
            ->where('co.id = :course_id')->bind(':course_id', $id, ParameterType::INTEGER);
        $this->requireAdministrator();
        $course = $db->setQuery($query)->loadObject();
        if ($course === null) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_AVAILABILITY_NOT_FOUND'), 404);
        }
        if ((int) $course->checked_out !== 0 && (int) $course->checked_out !== (int) $this->currentUser->id) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_AVAILABILITY_LOCKED'), 409);
        }

        return $course;
    }

    public function getForm(array $data = []): Form
    {
        $form = $this->getFormFactory()->createForm('com_altacourses.assignment', ['control' => 'jform']);
        if (!$form->loadFile(dirname(__DIR__, 2) . '/forms/assignment.xml')) {
            throw new \RuntimeException('Assignment form could not be loaded');
        }
        $field = new \SimpleXMLElement('<field name="supplier" type="list" required="true" filter="integer" validate="options" label="COM_ALTACOURSES_ASSIGNMENT_SUPPLIER" />');
        $placeholder = $field->addChild('option');
        $placeholder->addAttribute('value', '');
        $placeholder[0] = Text::_('COM_ALTACOURSES_CHOOSE_SUPPLIER');
        foreach ($this->getChoices() as $choice) {
            $option = $field->addChild('option');
            $option->addAttribute('value', (string) $choice->id);
            $option[0] = (string) $choice->label;
        }
        $form->setField($field);
        $form->bind($data);

        return $form;
    }

    /** Active Joomla accounts eligible to manage supplier courses; never infer a company ID. */
    public function getChoices(): array
    {
        $this->requireAdministrator();
        $db = $this->getDatabase();
        $ids = $db->setQuery($db->createQuery()->select('id')->from('#__users')
            ->where('block = 0')->order('name, id'))->loadColumn();
        $choices = [(object) ['id' => 0, 'label' => Text::_('COM_ALTACOURSES_UNASSIGNED')]];
        foreach ($ids as $id) {
            $user = $this->getUserFactory()->loadUserById((int) $id);
            if ($this->isEligible($user)) {
                $choices[] = (object) ['id' => (int) $user->id, 'label' => $user->name . ' (' . $user->username . ')'];
            }
        }
        return $choices;
    }

    private function isEligible(User $user): bool
    {
        return !$user->guest && !(bool) $user->block
            && $user->authorise('altacourses.supplier', 'com_altacourses');
    }

    /** Assign or unassign only an administrator-selected eligible account, with a revision check. */
    public function saveAssignment(int $id, int $supplier, int $expectedVersion): void
    {
        $this->requireAdministrator();
        if ($id <= 0 || $expectedVersion < 0 || $supplier < 0
            || ($supplier > 0 && !$this->isEligible($this->getUserFactory()->loadUserById($supplier)))) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_ASSIGNMENT'), 400);
        }
        $this->getCourse($id);
        $db = $this->getDatabase();
        $query = $db->createQuery()->update('#__altacourses_courses')
            ->set('availability_version = availability_version + 1')
            ->where('id = :course_id')->bind(':course_id', $id, ParameterType::INTEGER)
            ->where('availability_version = :revision')->bind(':revision', $expectedVersion, ParameterType::INTEGER);
        if ($supplier === 0) {
            $query->set('cr = NULL');
        } else {
            $query->set('cr = :supplier')->bind(':supplier', $supplier, ParameterType::INTEGER)
                ->where('EXISTS (SELECT 1 FROM #__users AS active_supplier WHERE active_supplier.id = :active_id AND active_supplier.block = 0)')
                ->bind(':active_id', $supplier, ParameterType::INTEGER);
        }
        $editor = (int) $this->currentUser->id;
        $query->where('(checked_out IS NULL OR checked_out = 0 OR checked_out = :editor)')->bind(':editor', $editor, ParameterType::INTEGER);
        $db->setQuery($query)->execute();
        if ($db->getAffectedRows() !== 1) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_AVAILABILITY_CONFLICT'), 409);
        }
    }

    private function requireAdministrator(): void
    {
        if ($this->currentUser === null || $this->currentUser->guest
            || !$this->currentUser->authorise('altacourses.manage', 'com_altacourses')) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }
    }
}
