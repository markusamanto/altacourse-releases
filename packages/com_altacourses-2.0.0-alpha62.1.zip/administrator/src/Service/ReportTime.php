<?php
/** @package Altacourses.Administrator @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Administrator\Service;
use Joomla\CMS\Language\Text;
\defined('_JEXEC') or die;
/** Legacy server clocks are Stockholm; rebuild reports explicitly use UTC. Values are never rewritten on read. */
final class ReportTime
{
    public static function pending(?string $value): bool { return $value === null || str_starts_with($value, '0000-'); }
    public static function zone(object $row): \DateTimeZone
    {
        $zone = $row->report_timezone ?? null;
        if ($zone !== null && $zone !== 'UTC') { throw new \RuntimeException(Text::_('COM_ALTACOURSES_REPORT_TIME_INVALID'), 409); }
        return new \DateTimeZone($zone ?? (($row->submission_id ?? null) !== null || ($row->reported_by ?? null) !== null ? 'UTC' : 'Europe/Stockholm'));
    }
    public static function local(object $row, string $timezone): ?string
    {
        if (self::pending($row->date_reported)) { return null; }
        return (new \DateTimeImmutable($row->date_reported, self::zone($row)))->setTimezone(new \DateTimeZone($timezone))->format('Y-m-d H:i:s');
    }
}
