<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Model;

use Joomla\CMS\Form\Form;
use Joomla\CMS\Form\FormFactoryAwareInterface;
use Joomla\CMS\Form\FormFactoryAwareTrait;
use Joomla\CMS\Language\Text;
use Joomla\Database\ParameterType;
use Joomla\Database\QueryInterface;

\defined('_JEXEC') or die;

/** Reporting uses the original recipient; it never modifies the binding agreement. */
final class ParticipationModel extends EnquiriesModel implements FormFactoryAwareInterface
{
    use ContactScopeTrait;
    use FormFactoryAwareTrait;

    private string $reportingTimezone = 'UTC';

    public function setReportingTimezone(string $timezone): void
    {
        new \DateTimeZone($timezone);
        $this->reportingTimezone = $timezone;
    }

    public function today(): string
    {
        return (new \DateTimeImmutable('now', new \DateTimeZone($this->reportingTimezone)))->format('Y-m-d');
    }

    private function baseQuery(): QueryInterface
    {
        $query = $this->getDatabase()->createQuery()->from('#__altacourses_requests AS r')
            ->join('INNER', '#__altacourses_request_submissions AS s ON s.request_id=r.id')
            ->join('INNER', '#__altacourses_courses AS co ON co.id=r.courseid')
            ->where('r.asked_for_info IN (0, 1)');
        $this->scopeContacts($query);
        return $query;
    }

    private function listQuery(): QueryInterface
    {
        $query = $this->baseQuery();
        $today = $this->today();
        $query->where('co.start_date IS NOT NULL AND DATE(co.start_date)<=:report_today')->bind(':report_today', $today);
        $status = $this->getState('filter.status', 'pending');
        if (!is_string($status) || !in_array($status, ['pending', 'reported', 'all'], true)) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_FILTER'), 400);
        }
        if ($status !== 'all') { $query->where('r.date_reported IS ' . ($status === 'reported' ? 'NOT ' : '') . 'NULL'); }
        return $query;
    }

    public function getTotal(): int
    {
        return (int) $this->getDatabase()->setQuery($this->listQuery()->select('COUNT(*)'))->loadResult();
    }

    public function getItems(): array
    {
        $query = $this->listQuery()->select(['r.id', 'r.asked_for_info', 'r.participated', 'r.canceled', 'r.date_reported', 's.contact_json', 's.course_json'])
            ->order('co.start_date DESC, r.id DESC');
        return $this->getDatabase()->setQuery($query, (int) $this->getState('list.start', 0), 20)->loadObjectList();
    }

    public function getRecord(int $id, bool $lock = false): object
    {
        $query = $this->baseQuery()->select(['r.*', 's.contact_json', 's.course_json', 'co.start_date AS first_start'])
            ->where('r.id=:report_id')->bind(':report_id', $id, ParameterType::INTEGER);
        // setQuery() retains this query object's bound values (verified Joomla 6.2 source).
        if ($lock) { $query->setQuery((string) $query . ' FOR UPDATE'); }
        $row = $this->getDatabase()->setQuery($query)->loadObject();
        if ($row === null) { throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'), 404); }
        return $row;
    }

    public function getForm(array $data = []): Form
    {
        $form = $this->getFormFactory()->createForm('com_altacourses.participation', ['control' => 'jform']);
        if (!$form->loadFile(dirname(__DIR__, 2) . '/forms/participation.xml')) {
            throw new \RuntimeException('Participation form could not be loaded');
        }
        $form->bind($data);
        return $form;
    }

    /** Status 0 is unreported, 1 participated, 2 did not participate (legacy flags). */
    public function saveReport(int $id, int $version, int $status, string $note): void
    {
        $this->requireContactAccess();
        if ($id <= 0 || $version < 0 || !in_array($status, [0, 1, 2], true)
            || mb_strlen($note) > 4000 || preg_match('/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/', $note)) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_PARTICIPATION_INVALID'), 400);
        }
        $actor = $this->getActor();
        $db = $this->getDatabase();
        $db->transactionStart();
        try {
            $row = $this->getRecord($id, true);
            if (!$row->first_start || substr($row->first_start, 0, 10) > $this->today()) {
                throw new \RuntimeException(Text::_('COM_ALTACOURSES_PARTICIPATION_NOT_STARTED'), 409);
            }
            if ((int) $row->participation_version !== $version) {
                throw new \RuntimeException(Text::_('COM_ALTACOURSES_PARTICIPATION_CONFLICT'), 409);
            }
            if ((int) $row->checked_out !== 0 && (int) $row->checked_out !== (int) $actor->id) {
                throw new \RuntimeException(Text::_('COM_ALTACOURSES_PARTICIPATION_LOCKED'), 409);
            }
            if ($row->date_reported !== null && $status === 0) {
                throw new \RuntimeException(Text::_('COM_ALTACOURSES_PARTICIPATION_NO_RESET'), 409);
            }
            $participated = $status === 1 ? 1 : 0;
            $canceled = $status === 2 ? 1 : 0;
            $editor = (int) $actor->id;
            $query = $db->createQuery()->update('#__altacourses_requests')
                ->set('participated=:report_participated')->bind(':report_participated', $participated, ParameterType::INTEGER)
                ->set('canceled=:report_canceled')->bind(':report_canceled', $canceled, ParameterType::INTEGER)
                ->set('note=:report_note')->bind(':report_note', $note)
                ->set('participation_version=participation_version+1')
                ->where('id=:report_id')->bind(':report_id', $id, ParameterType::INTEGER)
                ->where('participation_version=:report_version')->bind(':report_version', $version, ParameterType::INTEGER);
            // Note-only edits retain the reporting month; a changed outcome is a new report.
            if ($status !== 0 && ($row->date_reported === null || (int) $row->participated !== $participated || (int) $row->canceled !== $canceled)) {
                $now = (new \DateTimeImmutable('now', new \DateTimeZone('UTC')))->format('Y-m-d H:i:s');
                $query->set('date_reported=:report_time')->bind(':report_time', $now)
                    ->set('reported_by=:report_actor')->bind(':report_actor', $editor, ParameterType::INTEGER);
            }
            $db->setQuery($query)->execute();
            if ($db->getAffectedRows() !== 1) { throw new \RuntimeException(Text::_('COM_ALTACOURSES_PARTICIPATION_CONFLICT'), 409); }
            $db->transactionCommit();
        } catch (\Throwable $error) {
            $db->transactionRollback();
            throw $error;
        }
    }
}
