<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
\defined('_JEXEC') or die;
$navigation=['return_start'=>$this->returnStart]+$this->returnFilters;
$back=Route::_('index.php?'.http_build_query(['option'=>'com_altacourses','view'=>'client','id'=>$this->clientId]+$navigation),false);
?>
<section aria-labelledby="altacourses-editclient-heading">
<h1 id="altacourses-editclient-heading"><?php echo $this->escape(Text::_('COM_ALTACOURSES_CLIENT_EDIT')); ?></h1>
<p><?php echo $this->escape(Text::_('COM_ALTACOURSES_CLIENT_EDIT_HELP')); ?></p>
<form id="altacourses-editclient-form" action="<?php echo $this->escape(Route::_('index.php?'.http_build_query(['option'=>'com_altacourses','task'=>'editclient.save']+$navigation),false)); ?>" method="post">
<?php foreach(['id','version'] as $f){echo $this->form->getInput($f);} ?>
<?php foreach(\Advenire\Component\Altacourses\Site\Model\EditclientModel::FIELDS as $f){echo $this->form->renderField($f);} ?>
<?php echo HTMLHelper::_('form.token'); ?>
<button type="submit" class="btn btn-success"><?php echo $this->escape(Text::_('JSAVE')); ?></button>
<a class="btn btn-secondary" data-editclient-cancel href="<?php echo $this->escape($back); ?>"><?php echo $this->escape(Text::_('JCANCEL')); ?></a>
<a class="btn btn-secondary" data-editclient-reload href="<?php echo $this->escape(Route::_('index.php?'.http_build_query(['option'=>'com_altacourses','view'=>'editclient','id'=>$this->clientId,'fresh'=>1]+$navigation),false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_EDIT_RELOAD')); ?></a>
</form></section>
