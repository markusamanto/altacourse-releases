<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Controller;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;
\defined('_JEXEC') or die;
final class EvaluationsController extends BaseController
{
    public function execute($task)
    {
        $this->app->allowCache(false);$this->app->setHeader('Cache-Control','private, no-store, no-cache, must-revalidate',true);
        if (strtolower((string)$task)!=='publish'||$this->app->getDocument()->getType()!=='html') { throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'),404); }
        return parent::execute($task);
    }
    public function publish(): void
    {
        $model=$this->getModel('Evaluations','Site',['ignore_request'=>true]);$model->requireAdministrator();
        if ($this->input->getMethod()!=='POST') { throw new \RuntimeException(Text::_('COM_ALTACOURSES_SAMPLE_POST_REQUIRED'),405); }
        if (!$this->checkToken('post',false)) { throw new \RuntimeException(Text::_('JINVALID_TOKEN'),403); }
        $raw=$this->input->post->get('jform',[],'array');
        if (array_diff(array_keys($raw),['id','state','version','start'])||count($raw)!==4
            ||!is_string($raw['id']??null)||!ctype_digit($raw['id'])||(float)$raw['id']>4294967295
            ||!is_string($raw['state']??null)||!in_array($raw['state'],['0','1'],true)
            ||!is_string($raw['version']??null)||!preg_match('/^[a-f0-9]{64}$/D',$raw['version'])
            ||!is_string($raw['start']??null)||!ctype_digit($raw['start'])||(float)$raw['start']>2147483647) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_EVALADMIN_INVALID'),400);
        }
        $model->publish((int)$raw['id'],(int)$raw['state'],$raw['version']);
        $this->setMessage(Text::_($raw['state']==='1'?'COM_ALTACOURSES_EVALADMIN_PUBLISHED':'COM_ALTACOURSES_EVALADMIN_UNPUBLISHED'));
        $this->setRedirect(Route::_('index.php?option=com_altacourses&view=evaluations&limitstart='.(int)$raw['start'],false));
    }
}
