<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\View\Courses;

use Advenire\Component\Altacourses\Administrator\Service\CoursePriceAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\CoursePriceAwareTrait;
use Joomla\CMS\Language\Text;
use Advenire\Component\Altacourses\Administrator\Service\PriceDisplay;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Pagination\Pagination;
use Advenire\Component\Altacourses\Site\Helper\CourseArticle;

use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareTrait;

\defined('_JEXEC') or die;

final class HtmlView extends BaseHtmlView implements CourseScheduleAwareInterface, CoursePriceAwareInterface
{
    use CourseScheduleAwareTrait;
    use CoursePriceAwareTrait;

    public int $menuItemId = 0;
    public bool $showPageHeading = true;
    public string $pageHeading = '';
    public bool $multipleTypes = true;
    public array $articles = [];
    public array $signupAvailable = [];
    public array $sessions = [];
    public array $totalPrices = [];
    public array $items = [];
    public array $types = [];
    public array $regions = [];
    public array $filters = [];
    public ?Pagination $pagination = null;

    public function articleHref(mixed $value,int $courseId): ?string
    {
        return CourseArticle::href($this->articles,$value,$courseId);
    }

    private function prepareDocument(): void
    {
        $app = \Joomla\CMS\Factory::getApplication();
        $menu = \Advenire\Component\Altacourses\Site\Helper\ListingMenu::active($app);
        $fallback = Text::_('COM_ALTACOURSES_COURSES_TITLE');
        $this->pageHeading = $fallback;
        $this->showPageHeading = true;
        $title = $fallback;
        if ($menu !== null) {
            $params = $menu->getParams();
            $this->pageHeading = (string)($params->get('page_heading') ?: $menu->title);
            $this->showPageHeading = (bool)$params->get('show_page_heading', true);
            $title = (string)($params->get('page_title') ?: $menu->title);
            foreach (['menu-meta_description' => 'description', 'robots' => 'robots'] as $setting => $meta) {
                if ($params->get($setting)) { $this->getDocument()->setMetadata($meta, (string)$params->get($setting)); }
            }
            $site = (string)$app->get('sitename', '');
            if ((int)$app->get('sitename_pagetitles', 0) === 1) { $title = Text::sprintf('JPAGETITLE', $site, $title); }
            elseif ((int)$app->get('sitename_pagetitles', 0) === 2) { $title = Text::sprintf('JPAGETITLE', $title, $site); }
        }
        $this->getDocument()->setTitle($title);
    }

    public function display($tpl = null): void
    {
        $model = $this->getModel();
        $this->items = $model->getItems();
        $articleIds=[];
        foreach ($this->items as $item) {
            array_push($articleIds,$item->place_article,$item->leader1_article,$item->leader2_article);
            $this->signupAvailable[(int)$item->id]=$this->getModel('Signup')->canEnquire((int)$item->id);
            $amount = $this->getCoursePrice()->formatTotal($item->course_price, $item->lodging_price, $item->lodging_included);
            $this->totalPrices[(int) $item->id] = $amount === null ? '—' : $amount . ' ' . PriceDisplay::currency();
        }
        $this->articles=$model->getArticles($articleIds,$this->getDocument()->getLanguage());
        $this->sessions = $this->getCourseSchedule()->additionalSessions(array_map(static fn ($course): int => (int) $course->id, $this->items));
        $this->types = $model->getOptions('coursetypes');
        $this->regions = $model->getOptions('regions');
        $this->prepareDocument();
        $this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.site');
        parent::display($tpl);
    }
}
