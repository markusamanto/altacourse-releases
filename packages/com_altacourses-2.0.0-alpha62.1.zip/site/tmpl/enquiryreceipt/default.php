<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
\defined('_JEXEC') or die;
?>
<section class="altacourses-portal" aria-labelledby="altacourses-enquiry-receipt-heading">
    <h1 id="altacourses-enquiry-receipt-heading"><?php echo $this->escape(Text::_('COM_ALTACOURSES_ENQUIRY_RECEIPT_TITLE')); ?></h1>
    <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_ENQUIRY_RECEIPT')); ?></p>
    <a href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=courses', false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_BACK_TO_COURSES')); ?></a>
</section>
