<?php
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
\defined('_JEXEC') or die;
$r=$this->record;
?>
<section class="altacourses-portal" aria-labelledby="altacourses-billing-edit-heading">
 <h1 id="altacourses-billing-edit-heading"><?php echo $this->escape(Text::_('COM_ALTACOURSES_BILLING_EDIT')); ?></h1>
 <?php if ($this->legacy) : ?><p><?php echo $this->escape(Text::_('COM_ALTACOURSES_BILLING_LEGACY_INTRO')); ?></p><?php endif; ?>
 <dl class="altacourses-details">
  <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_BILLING_NAME')); ?></dt><dd><?php echo $this->escape(trim((string)($r->firstname??'').' '.(string)($r->lastname??''))); ?></dd>
  <dt><?php echo $this->escape(Text::_($this->legacy?'COM_ALTACOURSES_BILLING_ORGANISATION':'COM_ALTACOURSES_BILLING_ACCOUNT')); ?></dt><dd><?php echo $this->escape((string)($r->account_name??'')); ?></dd>
  <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_BILLING_START')); ?></dt><dd><?php echo $this->escape($r->course_start?substr($r->course_start,0,10):Text::_('COM_ALTACOURSES_BILLING_UNKNOWN_DATE')); ?></dd>
 </dl>
 <form id="altacourses-billing-form" action="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&task=keyaccount.save',false)); ?>" method="post">
  <input type="hidden" name="jform[id]" value="<?php echo $this->recordId; ?>">
  <input type="hidden" name="jform[legacy]" value="<?php echo (int)$this->legacy; ?>">
  <input type="hidden" name="jform[version]" value="<?php echo $this->escape($this->data['version']); ?>">
  <?php foreach (['invoiced','received','no_invoicing'] as $f) : ?>
   <div class="form-check my-3"><input type="hidden" name="jform[<?php echo $f; ?>]" value="0">
    <input class="form-check-input" type="checkbox" id="billing-<?php echo $f; ?>" name="jform[<?php echo $f; ?>]" value="1"<?php echo $this->data[$f]==='1'?' checked':''; ?>>
    <label class="form-check-label" for="billing-<?php echo $f; ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_BILLING_'.strtoupper($f))); ?></label>
   </div>
  <?php endforeach; ?>
  <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_BILLING_RECEIVED_HELP')); ?></p>
  <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_BILLING_EXCLUSIVE_HELP')); ?></p>
  <label for="billing-notes"><?php echo $this->escape(Text::_('COM_ALTACOURSES_BILLING_NOTES')); ?></label>
  <textarea class="form-control mb-3" id="billing-notes" name="jform[notes]" rows="6"><?php echo $this->escape($this->data['notes']); ?></textarea>
  <?php echo HTMLHelper::_('form.token'); ?>
  <button class="btn btn-success" type="submit"><?php echo $this->escape(Text::_('JSAVE')); ?></button>
  <a class="btn btn-secondary" href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view='.($this->legacy?'legacykeyaccounts':'keyaccounts'),false)); ?>"><?php echo $this->escape(Text::_('JCANCEL')); ?></a>
  <a class="btn btn-secondary" href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=keyaccount&id='.$this->recordId.'&legacy='.(int)$this->legacy.'&fresh=1',false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_EDIT_RELOAD')); ?></a>
 </form>
</section>
