-- Accounts retain legacy IDs/columns; new country and note fields are additive.
CREATE TABLE IF NOT EXISTS `#__altacourses_accounts` (
 `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
 `asset_id` int UNSIGNED NOT NULL DEFAULT 0,
 `name` varchar(255) NOT NULL,
 `invoice_address` varchar(255) NOT NULL DEFAULT '',
 `invoice_address_2` varchar(255) NOT NULL DEFAULT '',
 `invoice_zip` varchar(255) NOT NULL DEFAULT '',
 `invoice_city` varchar(255) NOT NULL DEFAULT '',
 `invoice_country` varchar(255) NOT NULL DEFAULT '',
 `note` text NOT NULL,
 `ordering` int NOT NULL DEFAULT 0,
 `state` tinyint NOT NULL DEFAULT 0,
 `checked_out` int NOT NULL DEFAULT 0,
 `checked_out_time` datetime DEFAULT NULL,
 `created_by` int NOT NULL DEFAULT 0,
 `modified_by` int DEFAULT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
