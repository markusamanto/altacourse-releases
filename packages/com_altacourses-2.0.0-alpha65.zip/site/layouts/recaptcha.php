<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
use Joomla\CMS\Language\Text;
\defined('_JEXEC') or die;
$view=$displayData['view'];$settings=$view->captcha;
?>
<?php if($settings['enabled']): ?>
<div class="my-3" data-recaptcha-field>
<?php if($settings['configured']): ?>
<div class="overflow-auto"><div class="g-recaptcha" data-sitekey="<?php echo $view->escape($settings['site_key']); ?>" data-theme="light" data-size="normal"></div></div>
<p class="mt-2"><?php echo $view->escape(Text::_('COM_ALTACOURSES_RECAPTCHA_HELP')); ?></p>
<noscript><p class="alert alert-warning"><?php echo $view->escape(Text::_('COM_ALTACOURSES_RECAPTCHA_JAVASCRIPT')); ?></p></noscript>
<?php else: ?><p class="alert alert-warning"><?php echo $view->escape(Text::_('COM_ALTACOURSES_RECAPTCHA_UNAVAILABLE')); ?></p><?php endif; ?>
</div>
<?php endif; ?>
