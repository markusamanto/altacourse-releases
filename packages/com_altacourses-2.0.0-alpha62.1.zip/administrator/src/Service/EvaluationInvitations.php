<?php
/** @package Altacourses.Administrator @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Administrator\Service;

use Joomla\CMS\Mail\Mail;
use Joomla\CMS\Mail\MailerFactoryInterface;
use Joomla\CMS\String\PunycodeHelper;
use Joomla\Database\DatabaseInterface;
use Joomla\Registry\Registry;

\defined('_JEXEC') or die;

/** One invitation per request, frozen capabilities and explicit recovery of uncertain delivery. */
final class EvaluationInvitations
{
    public function __construct(private readonly DatabaseInterface $db, private readonly Registry $config,
        private readonly NotificationService $notifications, private readonly MailerFactoryInterface $mailers,
        private readonly ?\Closure $clock = null) {}

    private function now(): \DateTimeImmutable { return $this->clock !== null ? ($this->clock)() : new \DateTimeImmutable('now', new \DateTimeZone('UTC')); }
    private function timestamp(): string { return $this->now()->setTimezone(new \DateTimeZone('UTC'))->format('Y-m-d H:i:s'); }
    private function localNow(): \DateTimeImmutable { return $this->now()->setTimezone(new \DateTimeZone('Europe/Stockholm')); }
    public function currentPeriod(): string { return $this->localNow()->format('Y-m'); }
    public function validatePeriod(string $period): void
    {
        if (!preg_match('/^(?:19|[2-9]\d)\d{2}-(?:0[1-9]|1[0-2])$/D', $period)) { throw new \RuntimeException('Invalid reminder month', 400); }
    }
    public function blockedReason(): ?string
    {
        $params = json_decode($this->db->setQuery("SELECT params FROM #__extensions WHERE element='com_altacourses' AND type='component' AND enabled=1")->loadResult() ?: '{}', true, flags: JSON_THROW_ON_ERROR);
        return $this->notifications->sandboxReason(($params['evaluation_mode'] ?? 'off') === 'sandbox');
    }
    public function messages(string $period): array
    {
        $this->validatePeriod($period);
        return $this->db->setQuery('SELECT * FROM #__altacourses_evaluation_invitations WHERE period=' . $this->db->quote($period) . ' ORDER BY client_name,request_id,id')->loadObjectList();
    }
    private function publicRoot(): ?string
    {
        $p=json_decode($this->db->setQuery("SELECT params FROM #__extensions WHERE element='com_altacourses' AND type='component'")->loadResult()?:'{}',true,flags:JSON_THROW_ON_ERROR);
        $root=$p['evaluation_public_url']??$this->config->get('live_site','');
        if (!is_string($root)||!filter_var($root,FILTER_VALIDATE_URL)||preg_match('/[\x00-\x20\x7f\\\\]/',$root)) { return null; }
        $url=parse_url($root);
        if (($url['scheme']??'')!=='https'||empty($url['host'])||isset($url['user'],$url['pass'])||isset($url['query'])||isset($url['fragment'])||isset($url['user'])||isset($url['pass'])) { return null; }
        return rtrim($root,'/').'/';
    }
    public function earliestEnd(): string
    {
        $params=json_decode($this->db->setQuery("SELECT params FROM #__extensions WHERE element='com_altacourses' AND type='component'")->loadResult()?:'{}',true,flags:JSON_THROW_ON_ERROR);
        $date=$params['evaluation_earliest_end']??'';
        if (!is_string($date)) { throw new \RuntimeException('Invalid earliest evaluation course date',400); }
        if ($date==='') { return ''; }
        $parsed=\DateTimeImmutable::createFromFormat('!Y-m-d',$date,new \DateTimeZone('Europe/Stockholm'));
        if (!$parsed||$parsed->format('Y-m-d')!==$date||(int)$parsed->format('Y')<1000) { throw new \RuntimeException('Invalid earliest evaluation course date',400); }
        return $date;
    }
    private function eligible(): array
    {
        $cutoff=$this->earliestEnd();
        $final="CASE WHEN co.stop_date IS NULL OR CAST(co.stop_date AS CHAR) LIKE '0000-%' THEN (SELECT MAX(ex.stop_date) FROM #__altacourses_course_sessions AS ex WHERE ex.course_id=co.id AND CAST(ex.stop_date AS CHAR) NOT LIKE '0000-%') ELSE GREATEST(co.stop_date,COALESCE((SELECT MAX(ex.stop_date) FROM #__altacourses_course_sessions AS ex WHERE ex.course_id=co.id AND CAST(ex.stop_date AS CHAR) NOT LIKE '0000-%'),co.stop_date)) END";
        $rows=$this->db->setQuery($this->db->createQuery()->select(['r.id AS request_id','r.rate_code','cl.firstname','cl.email','cl.lastname','co.start_date', $final.' AS final_end','ct.name AS course_type','cp.name AS course_place'])
            ->from('#__altacourses_requests AS r')->join('INNER','#__altacourses_courses AS co ON co.id=r.courseid')
            ->join('INNER','#__altacourses_clients AS cl ON cl.id=r.clientid')
            ->join('LEFT','#__altacourses_coursetypes AS ct ON ct.id=co.course_type')->join('LEFT','#__altacourses_courseplaces AS cp ON cp.id=co.course_place')
            ->where('r.asked_for_info IN (0,1) AND r.participated=1 AND COALESCE(r.canceled,0)=0 AND COALESCE(r.rebooked,0) IN (0,1) AND COALESCE(r.quality_control_email,0)=0')
            ->where('NOT EXISTS (SELECT 1 FROM #__altacourses_evaluations AS ev WHERE ev.request_id=r.id)')->order('r.id'))->loadObjectList();
        $eligible=[];$today=$this->localNow()->format('Y-m-d');
        foreach ($rows as $row) {
            if (!$row->final_end) { continue; }
            $end=substr($row->final_end,0,10);
            if (($cutoff!==''&&$end<$cutoff)||(new \DateTimeImmutable($end,new \DateTimeZone('Europe/Stockholm')))->modify('+14 days')->format('Y-m-d')>$today) { continue; }
            $row->client_name=trim(($row->firstname??'').' '.($row->lastname??''));$eligible[(int)$row->request_id]=$row;
        }
        return $eligible;
    }
    private function context(object $r): string
    {
        return hash('sha256',json_encode([$r->firstname,$r->lastname,$r->email,$r->start_date,$r->final_end,$r->course_type,$r->course_place],JSON_THROW_ON_ERROR));
    }
    public function runDue(): string
    {
        if ($this->blockedReason()!==null) { return 'blocked'; }
        return $this->runPeriod($this->currentPeriod());
    }
    /** Explicit administrator test/recovery run; may prepare previews while delivery is disabled. */
    public function runPeriod(string $period): string
    {
        $this->validatePeriod($period);
        if ($period !== $this->currentPeriod()) { throw new \RuntimeException('Only the current reminder month can be prepared', 409); }
        $eligible = $this->eligible();
        $template = $this->db->setQuery('SELECT * FROM #__altacourses_mailtemplates WHERE type=5 AND COALESCE(course_type,0)=0 AND state=1')->loadObject();
        foreach ($eligible as $id => $supplier) { $this->prepare($period, $id, $supplier, $template); }
        if ($this->blockedReason() !== null) { return 'blocked'; }
        foreach ($this->db->setQuery('SELECT * FROM #__altacourses_evaluation_invitations ORDER BY id')->loadObjectList() as $row) {
            if (!isset($eligible[(int) $row->request_id]) && in_array($row->state, ['pending','blocked'], true) && (int) $row->attempts === 0) {
                $this->db->setQuery("UPDATE #__altacourses_evaluation_invitations SET state='skipped',last_error='request_no_longer_eligible' WHERE id=" . (int) $row->id . " AND state IN ('pending','blocked') AND attempts=0")->execute();
            } elseif ($row->state === 'pending') { $this->deliver($row); }
        }
        foreach ($this->db->setQuery('SELECT * FROM #__altacourses_evaluation_invitations ORDER BY id')->loadObjectList() as $row) { if (!in_array($row->state, ['sent','skipped'], true)) { return 'review'; } }
        return 'complete';
    }
    private function templateError(?object $template): ?string
    {
        if ($template === null) { return 'missing_template_5'; }
        if (!$this->notifications->validAddress((string) $template->from_email)) { return 'invalid_template_sender'; }
        foreach (['subject','from_name'] as $field) {
            if (trim((string) $template->$field) === '' || mb_strlen($template->$field) > 255 || preg_match('/[\r\n\x00]/', $template->$field)) { return 'invalid_template_headers'; }
        }
        if (trim((string) $template->message) === '' || !mb_check_encoding($template->message, 'UTF-8') || preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', $template->message)) { return 'invalid_template_body'; }
        return null;
    }
    private function prepare(string $period,int $id,object $participant,?object $template): void
    {
        $old=$this->db->setQuery('SELECT * FROM #__altacourses_evaluation_invitations WHERE request_id='.$id)->loadObject();
        if ($old && ((int)$old->attempts!==0||!in_array($old->state,['blocked','skipped'],true))) { return; }
        $error=trim((string)($participant->rate_code??''))!==''?'existing_rate_code':(!$this->notifications->validAddress((string)$participant->email)?'invalid_participant_email':$this->templateError($template));
        $raw=bin2hex(random_bytes(32));$code='sha256:'.hash('sha256',$raw);
        $base=$this->publicRoot();
        if ($base===null) { $error='invalid_public_url';$base=''; }
        $link=$base.'index.php?option=com_altacourses&task=evaluation.edit&requestid='.$id.'&code='.$raw;
        if ($error===null&&!str_contains((string)$template->message,'[Link]')) { $error='missing_link_placeholder'; }
        if ($old&&$error!==null&&$old->period===$period&&$old->last_error===$error&&hash_equals($old->context_hash,$this->context($participant))&&(int)$old->template_id===(int)($template?->id)) { return; }
        $date=static fn(?string $v):string=>$v?substr($v,0,10):'';
        $values=[$participant->firstname??'',$participant->course_type??'',$date($participant->start_date).' - '.$date($participant->final_end),$participant->course_place??'',$link];
        $body=$error===null?strtr($template->message,array_combine(['[Firstname]','[Coursetype]','[Coursedate]','[Courseplace]','[Link]'],$values)):'';
        $row=(object)['period'=>$period,'request_id'=>$id,'client_name'=>mb_substr($participant->client_name,0,255),
            'recipient'=>$error===null?PunycodeHelper::emailToPunycode($participant->email):'',
            'from_email'=>$error===null?PunycodeHelper::emailToPunycode($template->from_email):'',
            'from_name'=>$error===null?$template->from_name:'','subject'=>$error===null?'[TEST] '.mb_substr($template->subject,0,248):'',
            'body'=>$body,'template_id'=>$template?->id,'token_hash'=>$code,'context_hash'=>$this->context($participant),
            'message_id'=>'<'.bin2hex(random_bytes(24)).'@altacourses.invalid>','state'=>$error===null?'pending':'blocked','last_error'=>$error,'created_at'=>$this->timestamp()];
        $row->payload_hash=$this->digest($row);
        try { $this->db->insertObject('#__altacourses_evaluation_invitations',$row,'id'); }
        catch (\Throwable $e) {
            $existing=$this->db->setQuery('SELECT * FROM #__altacourses_evaluation_invitations WHERE request_id='.$id)->loadObject();
            if ($existing===null) { throw $e; }
            if ((int)$existing->attempts!==0||!in_array($existing->state,['blocked','skipped'],true)) { return; }
            $q=$this->db->createQuery()->update('#__altacourses_evaluation_invitations');
            foreach (get_object_vars($row) as $k=>$v) { $q->set($this->db->quoteName($k).'='.($v===null?'NULL':$this->db->quote((string)$v))); }
            $q->where('id='.(int)$existing->id)->where("state IN ('blocked','skipped') AND attempts=0");$this->db->setQuery($q)->execute();
        }
    }
    private function digest(object $r): string
    {
        return hash('sha256', json_encode([$r->period,(int)$r->request_id,$r->recipient,$r->from_email,$r->from_name,$r->subject,$r->body,$r->template_id === null ? null : (int)$r->template_id,$r->message_id,$r->token_hash,$r->context_hash],JSON_THROW_ON_ERROR));
    }
    private function deliver(object $row): void
    {
        if ($this->blockedReason() !== null) { return; }
        if (!hash_equals($row->payload_hash, $this->digest($row)) || !$this->notifications->validAddress($row->recipient)) { throw new \RuntimeException('Evaluation invitation archive integrity check failed'); }
        $activeTemplate = $this->db->setQuery('SELECT * FROM #__altacourses_mailtemplates WHERE type=5 AND COALESCE(course_type,0)=0 AND state=1')->loadObject();
        $templateIssue = $this->templateError($activeTemplate) ?? ((int)$activeTemplate->id !== (int)$row->template_id ? 'template_changed' : null);
        if ($templateIssue !== null) {
            $state = (int)$row->attempts > 0 ? 'uncertain' : 'blocked';
            $this->db->setQuery('UPDATE #__altacourses_evaluation_invitations SET state=' . $this->db->quote($state) . ',last_error=' . $this->db->quote($templateIssue) . ' WHERE id=' . (int)$row->id . " AND state='pending'")->execute();return;
        }
        $current = $this->eligible()[(int)$row->request_id] ?? null;
        $reason=$current===null?'request_no_longer_eligible':(!$this->notifications->validAddress((string)$current->email)?'participant_unavailable':
            (!hash_equals($row->context_hash,$this->context($current))?'request_details_changed':
            (trim((string)($current->rate_code??''))!==''&&!hash_equals($row->token_hash,(string)$current->rate_code)?'existing_rate_code':null)));
        if ($reason!==null) {
            $this->db->setQuery('UPDATE #__altacourses_evaluation_invitations SET state='.$this->db->quote($current===null?'skipped':'blocked').',last_error='.$this->db->quote($reason).' WHERE id='.(int)$row->id." AND state='pending'")->execute();return;
        }
        $token = bin2hex(random_bytes(32));
        $this->db->transactionStart();
        try {
            $request=$this->db->setQuery('SELECT * FROM #__altacourses_requests WHERE id='.(int)$row->request_id.' FOR UPDATE')->loadObject();
            $current=$this->eligible()[(int)$row->request_id]??null;
            if (!$request||!$current||!hash_equals($row->context_hash,$this->context($current))
                ||(trim((string)($request->rate_code??''))!==''&&!hash_equals($row->token_hash,(string)$request->rate_code))) { $this->db->transactionRollback();return; }
            $this->db->setQuery("UPDATE #__altacourses_evaluation_invitations SET state='sending',attempts=attempts+1,attempt_token=".$this->db->quote($token).',claimed_at='.$this->db->quote($this->timestamp()).' WHERE id='.(int)$row->id." AND state='pending'")->execute();
            if ($this->db->getAffectedRows()!==1) { $this->db->transactionRollback();return; }
            $this->db->setQuery('UPDATE #__altacourses_requests SET rate_code='.$this->db->quote($row->token_hash).' WHERE id='.(int)$row->request_id)->execute();
            $this->db->transactionCommit();
        } catch (\Throwable $e) { $this->db->transactionRollback();throw $e; }
        $mailer = null; $accepted = false;
        try {
            $mailer = $this->mailers->createMailer(new Registry(['throw_exceptions'=>true]));
            if (!$mailer instanceof Mail) { throw new \RuntimeException('Unsupported mailer'); }
            $mailer->SMTPAutoTLS=false;$mailer->Timeout=10;$mailer->getSMTPInstance()->Timelimit=10;$mailer->SMTPDebug=0;
            $mailer->MessageID=$row->message_id;$mailer->setSender($row->from_email,$row->from_name);$mailer->addRecipient($row->recipient);$mailer->setSubject($row->subject);$mailer->setBody($row->body);
            if ($mailer->send() !== true) { throw new \RuntimeException('No SMTP acceptance'); }
            $accepted=true;$this->finish((int)$row->id,$token,'sent',null);
        } catch (\Throwable $e) { $this->finish((int)$row->id,$token,'uncertain',$this->notifications->failureDiagnostic($mailer instanceof Mail ? $mailer : null,$e,$accepted)); }
    }
    private function markInvited(object $row): void
    {
        $request=$this->db->setQuery('SELECT rate_code FROM #__altacourses_requests WHERE id='.(int)$row->request_id.' FOR UPDATE')->loadObject();
        if (!$request||!hash_equals($row->token_hash,(string)$request->rate_code)) { throw new \RuntimeException('Invitation request code changed',409); }
        $this->db->setQuery('UPDATE #__altacourses_requests SET quality_control_email=1 WHERE id='.(int)$row->request_id)->execute();
    }
    private function finish(int $id,string $token,string $state,?string $error): void
    {
        $this->db->transactionStart();
        try {
            $identity=$this->db->setQuery('SELECT request_id FROM #__altacourses_evaluation_invitations WHERE id='.$id)->loadObject();
            if (!$identity) { throw new \RuntimeException('Invitation delivery record missing'); }
            $this->db->setQuery('SELECT id FROM #__altacourses_requests WHERE id='.(int)$identity->request_id.' FOR UPDATE')->loadResult();
            $row=$this->db->setQuery('SELECT * FROM #__altacourses_evaluation_invitations WHERE id='.$id.' FOR UPDATE')->loadObject();
            if (!$row||$row->state!=='sending'||!hash_equals((string)$row->attempt_token,$token)) { throw new \RuntimeException('Invitation delivery state changed'); }
            if ($state==='sent') { $this->markInvited($row); }
            $this->db->setQuery('UPDATE #__altacourses_evaluation_invitations SET state='.$this->db->quote($state).',last_error='.($error===null?'NULL':$this->db->quote($error)).($state==='sent'?',sent_at='.$this->db->quote($this->timestamp()):'').' WHERE id='.$id)->execute();
            $this->db->transactionCommit();
        } catch (\Throwable $e) { $this->db->transactionRollback();throw $e; }
    }
    public function review(string $period,int $id,string $token,int $actor,bool $captured): void
    {
        $this->validatePeriod($period);$rows=array_filter($this->messages($period),static fn($r)=>(int)$r->id===$id);$row=reset($rows);
        if (!$row || $actor<=0 || !hash_equals((string)$row->attempt_token,$token)
            || !($row->state==='uncertain'||($row->state==='sending'&&strtotime($row->claimed_at.' UTC')<$this->now()->getTimestamp()-300))) { throw new \RuntimeException('Evaluation invitation changed; reload and review Mailtrap',409); }
        if (!$captured && ($this->blockedReason()!==null)) { throw new \RuntimeException('Evaluation invitation retry blocked',409); }
        if (!hash_equals($row->payload_hash,$this->digest($row))) { throw new \RuntimeException('Evaluation invitation archive integrity check failed',409); }
        $this->db->transactionStart();
        try {
        $this->db->setQuery('SELECT id FROM #__altacourses_requests WHERE id='.(int)$row->request_id.' FOR UPDATE')->loadResult();
        $this->db->setQuery('UPDATE #__altacourses_evaluation_invitations SET state=' . $this->db->quote($captured?'sent':'pending') . ',reviewed_by=' . $actor . ',reviewed_at=' . $this->db->quote($this->timestamp()) . ',last_error=' . $this->db->quote($captured?'operator_confirmed':'operator_retry') . ($captured?',sent_at='.$this->db->quote($this->timestamp()):'') . ' WHERE id=' . $id . ' AND state=' . $this->db->quote($row->state) . ' AND attempt_token=' . $this->db->quote($token))->execute();
        if ($this->db->getAffectedRows()!==1) { throw new \RuntimeException('Evaluation invitation review changed',409); }
        if ($captured) { $this->markInvited($row); }
        $this->db->transactionCommit();
        } catch (\Throwable $e) { $this->db->transactionRollback();throw $e; }
        if (!$captured) { $row->state='pending';$this->deliver($row); }
    }
}
