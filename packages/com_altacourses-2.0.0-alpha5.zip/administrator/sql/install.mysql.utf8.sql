-- Initial course-list schema. No production records or sample data.

CREATE TABLE IF NOT EXISTS `#__altacourses_courses` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `asset_id` int DEFAULT NULL COMMENT 'FK to the #__assets table.',
  `start_date` datetime DEFAULT NULL,
  `stop_date` datetime DEFAULT NULL,
  `course_type` int DEFAULT NULL,
  `course_place` int DEFAULT NULL,
  `course_leader_1` int DEFAULT NULL,
  `course_leader_2` int DEFAULT NULL,
  `nr_of_participants` int DEFAULT NULL,
  `course_price` varchar(255) DEFAULT NULL,
  `lodging_price` varchar(225) DEFAULT NULL,
  `course_notes` text,
  `lodging_included` varchar(255) DEFAULT NULL,
  `alert` text,
  `reminder_sent` datetime DEFAULT NULL,
  `cr` int DEFAULT NULL,
  `ordering` int DEFAULT NULL,
  `state` tinyint(1) DEFAULT NULL,
  `checked_out` int DEFAULT NULL,
  `checked_out_time` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_course_listing` (`state`, `start_date`),
  KEY `idx_course_type` (`course_type`),
  KEY `idx_course_place` (`course_place`),
  KEY `idx_supplier_user` (`cr`),
  KEY `idx_availability` (`nr_of_participants`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__altacourses_coursetypes` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `url` text,
  `params` text,
  `ordering` int DEFAULT '0',
  `state` tinyint(1) DEFAULT '0',
  `checked_out` int NOT NULL DEFAULT '0',
  `checked_out_time` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__altacourses_courseplaces` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `region_id` int DEFAULT '0',
  `url` varchar(255) DEFAULT NULL,
  `params` text,
  `ordering` int NOT NULL DEFAULT '0',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int NOT NULL DEFAULT '0',
  `checked_out_time` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_region` (`region_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__altacourses_courseleaders` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `params` text,
  `ordering` int NOT NULL DEFAULT '0',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int NOT NULL DEFAULT '0',
  `checked_out_time` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__altacourses_regions` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `params` text,
  `ordering` int NOT NULL DEFAULT '0',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int NOT NULL DEFAULT '0',
  `checked_out_time` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__altacourses_seats` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `seats` int NOT NULL,
  `label` varchar(255) NOT NULL,
  `ordering` int NOT NULL,
  `state` tinyint(1) NOT NULL,
  `checked_out` int NOT NULL,
  `checked_out_time` datetime DEFAULT NULL,
  `created_by` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_seat_code` (`seats`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
