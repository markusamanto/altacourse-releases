<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Model;

use Joomla\Database\QueryInterface;

\defined('_JEXEC') or die;

final class ContactModel extends ParticipantModel
{
    use ContactScopeTrait;

    protected function scopeHistory(QueryInterface $query): void
    {
        $this->scopeContacts($query);
    }
}
