<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Model;
use Advenire\Component\Altacourses\Administrator\Service\EvaluationInvitations;
\defined('_JEXEC') or die;
final class InvitationsModel extends RequestrecordsModel
{
    private ?EvaluationInvitations $invitations = null;
    public function setEvaluationInvitations(EvaluationInvitations $service): void { $this->invitations=$service; }
    private function service(): EvaluationInvitations { $this->requireAdministrator();if($this->invitations===null){throw new \RuntimeException('Evaluation invitation service unavailable');}return $this->invitations; }
    public function currentPeriod(): string { return $this->service()->currentPeriod(); }
    public function validateMonth(string $period): void { $this->service()->validatePeriod($period); }
    public function getMessages(string $period): array { return $this->service()->messages($period); }
    public function blockedReason(): ?string { return $this->service()->blockedReason(); }
    public function runPeriod(string $period): string { return $this->service()->runPeriod($period); }
    public function review(string $period,int $id,string $token,bool $captured): void { $this->service()->review($period,$id,$token,$this->currentActorId(),$captured); }
}
