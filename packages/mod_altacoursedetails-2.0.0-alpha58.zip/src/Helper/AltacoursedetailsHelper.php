<?php
/** @package Altacourses.Module @license GNU General Public License version 2 or later */
namespace Advenire\Module\Altacoursedetails\Site\Helper;
use Advenire\Component\Altacourses\Site\Helper\CourseArticle;
use Joomla\CMS\Application\SiteApplication;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
\defined('_JEXEC') or die;
final class AltacoursedetailsHelper
{
    public function details(SiteApplication $app): ?array
    {
        $input=$app->getInput();$raw=$input->get('coid',null,'raw');
        if (!is_scalar($raw)||!ctype_digit((string)$raw)||(int)$raw<1||(float)$raw>2147483647
            ||$input->getCmd('option')!=='com_content'||$input->getCmd('view')!=='article'
            ||$app->getDocument()->getType()!=='html'||!ComponentHelper::isEnabled('com_altacourses')) { return null; }
        $article=$input->get('id','','raw');
        if (!is_scalar($article)||!preg_match('/^([1-9][0-9]*)(?::[^\r\n]*)?$/D',(string)$article,$match)||(float)$match[1]>2147483647) { return null; }
        $file=JPATH_ADMINISTRATOR.'/components/com_altacourses/altacourses.xml';
        $manifest=is_file($file)?simplexml_load_file($file):false;
        if (!$manifest||(string)$manifest->namespace!=='Advenire\\Component\\Altacourses'||version_compare((string)$manifest->version,'2.0.0-alpha58','<')) { return null; }
        $mvc=$app->bootComponent('com_altacourses')->getMVCFactory();$courseModel=$mvc->createModel('Course','Site',['ignore_request'=>true]);$id=(int)$raw;$courseModel->setState('course.id',$id);
        try { $context=$courseModel->getPublicDetails();$course=$context['course']; } catch (\RuntimeException $e) { if ($e->getCode()===404) { return null; }throw $e; }
        $refs=$mvc->createModel('Courses','Site',['ignore_request'=>true]);
        $articles=$refs->getArticles([$course->place_article,$course->leader1_article,$course->leader2_article],$app->getLanguage()->getTag());
        // Exact selected article IDs, not every article sharing a configured category.
        if (!isset($articles[(int)$match[1]])) { return null; }
        $amount=$context['amount'];
        $sessions=$context['sessions'];
        return ['course'=>$course,'sessions'=>$sessions,'price'=>$amount===null?'—':$amount.' '.Text::_('MOD_ALTACOURSEDETAILS_CURRENCY'),
            'placeLink'=>CourseArticle::href($articles,$course->place_article,$id),
            'leader1Link'=>CourseArticle::href($articles,$course->leader1_article,$id),'leader2Link'=>CourseArticle::href($articles,$course->leader2_article,$id),
            'signup'=>$mvc->createModel('Signup','Site',['ignore_request'=>true])->canEnquire($id)?Route::_('index.php?option=com_altacourses&view=signup&coid='.$id,false):null,
            'back'=>Route::_('index.php?option=com_altacourses&view=courses',false)];
    }
}
