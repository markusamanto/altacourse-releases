<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
\defined('_JEXEC') or die;
?>
<section aria-labelledby="altacourses-unconfirmed-heading">
    <h1 id="altacourses-unconfirmed-heading"><?php echo $this->escape(Text::_('COM_ALTACOURSES_UNCONFIRMED_TITLE')); ?></h1>
    <p><a href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=dashboard', false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_BACK_TO_DASHBOARD')); ?></a></p>
    <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_UNCONFIRMED_INTRO')); ?></p>
    <?php if (!$this->items) : ?>
        <p role="status"><?php echo $this->escape(Text::_('COM_ALTACOURSES_UNCONFIRMED_EMPTY')); ?></p>
    <?php else : ?>
        <div class="table-responsive"><table class="table table-striped">
            <thead><tr>
                <?php foreach (['COMMISSION_SUPPLIER', 'UNCONFIRMED_START', 'ENQUIRY_NAME', 'UNCONFIRMED_TYPE'] as $label) : ?>
                <th scope="col"><?php echo $this->escape(Text::_('COM_ALTACOURSES_' . $label)); ?></th>
                <?php endforeach; ?>
            </tr></thead>
            <tbody>
            <?php foreach ($this->items as $item) : ?>
                <tr data-unconfirmed-request="<?php echo (int) $item->id; ?>">
                    <td><?php echo $this->escape($item->supplier_name); ?></td>
                    <td><time datetime="<?php echo $this->escape(substr($item->start_date, 0, 10)); ?>"><?php echo $this->escape(substr($item->start_date, 0, 10)); ?></time></td>
                    <td><?php echo $this->escape($item->client_name); ?></td>
                    <td><?php echo $this->escape(Text::_((int) $item->rebooked === 1 ? 'COM_ALTACOURSES_UNREAD_REBOOKING' : ((int) $item->asked_for_info === 1 ? 'COM_ALTACOURSES_ENQUIRY_TITLE' : 'COM_ALTACOURSES_SIGNUP_TITLE'))); ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table></div>
    <?php endif; ?>
</section>
