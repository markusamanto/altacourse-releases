<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Model;

use Joomla\CMS\Language\Text;

\defined('_JEXEC') or die;

/** Administrator overview only; no participation, receipt or mail actions. */
final class UnconfirmedModel extends RequestrecordsModel
{
    private string $reportingTimezone = 'UTC';

    public function setReportingTimezone(string $timezone): void
    {
        new \DateTimeZone($timezone);
        $this->reportingTimezone = $timezone;
    }

    public function today(): string
    {
        return (new \DateTimeImmutable('now', new \DateTimeZone($this->reportingTimezone)))->format('Y-m-d');
    }

    public function getItems(): array
    {
        $this->requireAdministrator();
        $today = $this->today();
        $supplier = "COALESCE(NULLIF(TRIM(sp.company),''),NULLIF(TRIM(u.name),''),'')";
        $query = $this->getDatabase()->createQuery()->select([
            'r.id', 'r.asked_for_info', 'r.rebooked', 'co.start_date', 'co.cr AS supplier_user_id',
            $supplier . ' AS supplier_name', 'cl.firstname', 'cl.lastname', 'cl.id AS linked_client_id',
        ])->from('#__altacourses_requests AS r')
            ->join('INNER', '#__altacourses_courses AS co ON co.id=r.courseid')
            ->join('LEFT', '#__altacourses_clients AS cl ON cl.id=r.clientid')
            ->join('LEFT', '#__altacourses_suppliers AS sp ON sp.user_id=co.cr')
            ->join('LEFT', '#__users AS u ON u.id=co.cr')
            ->where('r.asked_for_info IN (0,1)')
            ->where('COALESCE(r.participated,0)=0')->where('COALESCE(r.canceled,0)=0')
            ->where('COALESCE(r.rebooked,0) IN (0,1)')
            ->where("(r.date_reported IS NULL OR CAST(r.date_reported AS CHAR) LIKE '0000-%')")
            ->where("co.start_date IS NOT NULL AND CAST(co.start_date AS CHAR) NOT LIKE '0000-%' AND DATE(co.start_date)<=:unconfirmed_today")
            ->bind(':unconfirmed_today', $today)
            ->order(['supplier_name ASC', 'DATE(co.start_date) ASC', 'cl.firstname ASC', 'cl.lastname ASC', 'r.id ASC']);
        $rows = $this->getDatabase()->setQuery($query)->loadObjectList();
        foreach ($rows as $row) {
            if ($row->supplier_name === '') {
                $row->supplier_name = (int) $row->supplier_user_id > 0 ? Text::sprintf('COM_ALTACOURSES_OWNER_ID', (int) $row->supplier_user_id) : Text::_('COM_ALTACOURSES_UNASSIGNED');
            }
            $row->client_name = trim(($row->firstname ?? '') . ' ' . ($row->lastname ?? ''));
            if ($row->client_name === '') { $row->client_name = Text::_('COM_ALTACOURSES_UNCONFIRMED_UNKNOWN_CLIENT'); }
        }
        return $rows;
    }
}
