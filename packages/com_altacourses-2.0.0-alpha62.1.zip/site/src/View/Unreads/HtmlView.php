<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\View\Unreads;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;

\defined('_JEXEC') or die;

final class HtmlView extends BaseHtmlView
{
    public array $groups = [];
    public array $introduction = [];
    public function display($tpl = null): void
    {
        $this->groups = $this->getModel()->getGroups();
        $this->introduction = $this->getModel()->getIntroduction();
        $this->getDocument()->setTitle(Text::_('COM_ALTACOURSES_UNREAD_TITLE'));
        $this->getDocument()->setMetaData('robots', 'noindex, nofollow');
        $this->getDocument()->setMetaData('referrer', 'no-referrer');
        $this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.site');
        parent::display($tpl);
    }
}
