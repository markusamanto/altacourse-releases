-- Initial course-list schema. No production records or sample data.

CREATE TABLE IF NOT EXISTS `#__altacourses_courses` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `asset_id` int DEFAULT NULL COMMENT 'FK to the #__assets table.',
  `start_date` datetime DEFAULT NULL,
  `stop_date` datetime DEFAULT NULL,
  `course_type` int DEFAULT NULL,
  `course_place` int DEFAULT NULL,
  `course_leader_1` int DEFAULT NULL,
  `course_leader_2` int DEFAULT NULL,
  `nr_of_participants` int DEFAULT NULL,
  `availability_version` int UNSIGNED NOT NULL DEFAULT 0,
  `creation_token` char(64) DEFAULT NULL,
  `course_price` varchar(255) DEFAULT NULL,
  `lodging_price` varchar(225) DEFAULT NULL,
  `course_notes` text,
  `lodging_included` varchar(255) DEFAULT NULL,
  `alert` text,
  `reminder_sent` datetime DEFAULT NULL,
  `cr` int DEFAULT NULL,
  `ordering` int DEFAULT NULL,
  `state` tinyint(1) DEFAULT NULL,
  `checked_out` int DEFAULT NULL,
  `checked_out_time` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_course_listing` (`state`, `start_date`),
  KEY `idx_course_type` (`course_type`),
  KEY `idx_course_place` (`course_place`),
  KEY `idx_supplier_user` (`cr`),
  KEY `idx_availability` (`nr_of_participants`),
  UNIQUE KEY `idx_creation_token` (`creation_token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__altacourses_coursetypes` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `url` text,
  `params` text,
  `ordering` int DEFAULT '0',
  `state` tinyint(1) DEFAULT '0',
  `checked_out` int NOT NULL DEFAULT '0',
  `checked_out_time` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__altacourses_courseplaces` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `region_id` int DEFAULT '0',
  `url` varchar(255) DEFAULT NULL,
  `params` text,
  `ordering` int NOT NULL DEFAULT '0',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int NOT NULL DEFAULT '0',
  `checked_out_time` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_region` (`region_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__altacourses_courseleaders` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `params` text,
  `ordering` int NOT NULL DEFAULT '0',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int NOT NULL DEFAULT '0',
  `checked_out_time` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__altacourses_regions` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `params` text,
  `ordering` int NOT NULL DEFAULT '0',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int NOT NULL DEFAULT '0',
  `checked_out_time` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__altacourses_seats` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `seats` int NOT NULL,
  `label` varchar(255) NOT NULL,
  `ordering` int NOT NULL,
  `state` tinyint(1) NOT NULL,
  `checked_out` int NOT NULL,
  `checked_out_time` datetime DEFAULT NULL,
  `created_by` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_seat_code` (`seats`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Only additional sessions; the first session remains in the original courses columns.
CREATE TABLE IF NOT EXISTS `#__altacourses_course_sessions` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `course_id` int UNSIGNED NOT NULL,
  `start_date` datetime NOT NULL,
  `stop_date` datetime NOT NULL,
  `ordering` smallint UNSIGNED NOT NULL DEFAULT 2,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_course_session_order` (`course_id`, `ordering`),
  CONSTRAINT CHECK (`stop_date` >= `start_date`),
  CONSTRAINT CHECK (`ordering` >= 2),
  FOREIGN KEY (`course_id`) REFERENCES `#__altacourses_courses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Supplier profiles retain the legacy business columns and user-account link.
CREATE TABLE IF NOT EXISTS `#__altacourses_suppliers` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `company` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `postal_address` varchar(255) DEFAULT NULL,
  `postal_zip` varchar(255) DEFAULT NULL,
  `postal_city` varchar(255) DEFAULT NULL,
  `postal_state` varchar(255) DEFAULT NULL,
  `postal_country` varchar(255) DEFAULT NULL,
  `invoice_address` varchar(255) DEFAULT NULL,
  `invoice_city` varchar(255) DEFAULT NULL,
  `invoice_zip` varchar(255) DEFAULT NULL,
  `org_name` varchar(255) DEFAULT NULL,
  `newsletter` varchar(255) DEFAULT NULL,
  `terms` text,
  `notes` text,
  `bookingsurl` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `fee` int DEFAULT NULL,
  `ordering` int DEFAULT NULL,
  `state` tinyint(1) DEFAULT NULL,
  `checked_out` int DEFAULT NULL,
  `checked_out_time` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `profile_version` int UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_supplier_account` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Adds participant/request storage without importing production data.
CREATE TABLE IF NOT EXISTS `#__altacourses_clients` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `userid` int DEFAULT NULL,
  `account` varchar(255) DEFAULT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `newsletter` bigint NOT NULL DEFAULT '0',
  `age` varchar(255) DEFAULT NULL,
  `company` varchar(255) DEFAULT NULL,
  `specialmeal` varchar(255) DEFAULT NULL,
  `profession` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `postal_address` varchar(255) DEFAULT NULL,
  `postal_zip` varchar(255) DEFAULT NULL,
  `postal_city` varchar(255) DEFAULT NULL,
  `postal_state` varchar(255) DEFAULT NULL,
  `postal_country` varchar(255) DEFAULT NULL,
  `invoice_address` varchar(255) DEFAULT NULL,
  `invoice_city` varchar(255) DEFAULT NULL,
  `invoice_zip` varchar(255) DEFAULT NULL,
  `notes` text,
  `ordering` int NOT NULL DEFAULT '0',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int NOT NULL DEFAULT '0',
  `checked_out_time` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `modified_by` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_client_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__altacourses_requests` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `courseid` int DEFAULT NULL,
  `clientid` int DEFAULT NULL,
  `userid` int DEFAULT NULL,
  `participated` tinyint NOT NULL DEFAULT '0',
  `canceled` tinyint NOT NULL DEFAULT '0',
  `other_occasion` int NOT NULL DEFAULT '0',
  `note` text,
  `asked_for_info` tinyint NOT NULL DEFAULT '0',
  `date_reported` timestamp NULL DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_upgraded` timestamp NULL DEFAULT NULL,
  `rebooked` tinyint NOT NULL DEFAULT '0',
  `quality_control_email` tinyint(1) NOT NULL DEFAULT '0',
  `rate_code` varchar(255) DEFAULT NULL,
  `thesource` varchar(255) DEFAULT NULL,
  `received` tinyint(1) NOT NULL DEFAULT '0',
  `ordering` int NOT NULL DEFAULT '0',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int NOT NULL DEFAULT '0',
  `checked_out_time` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_request_course` (`courseid`),
  KEY `idx_request_client` (`clientid`),
  KEY `idx_request_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Immutable submitted details and intended supplier, independent of mutable client/profile rows.
CREATE TABLE IF NOT EXISTS `#__altacourses_request_submissions` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `request_id` int UNSIGNED NOT NULL,
  `supplier_id` int UNSIGNED NOT NULL,
  `supplier_user_id` int NOT NULL,
  `supplier_email` varchar(255) NOT NULL,
  `token_hash` char(64) NOT NULL,
  `contact_json` text NOT NULL,
  `course_json` mediumtext NOT NULL,
  `created_at` datetime NOT NULL,
  `delivery_state` varchar(20) NOT NULL DEFAULT 'not_sent',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_submission_token` (`token_hash`),
  UNIQUE KEY `idx_submission_request` (`request_id`),
  KEY `idx_submission_supplier` (`supplier_user_id`),
  CONSTRAINT CHECK (JSON_VALID(`contact_json`)),
  CONSTRAINT CHECK (JSON_VALID(`course_json`)),
  FOREIGN KEY (`request_id`) REFERENCES `#__altacourses_requests` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  FOREIGN KEY (`supplier_id`) REFERENCES `#__altacourses_suppliers` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
