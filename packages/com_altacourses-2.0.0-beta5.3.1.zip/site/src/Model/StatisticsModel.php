<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Model;
use Joomla\CMS\Language\Text;
use Joomla\Registry\Registry;
\defined('_JEXEC') or die;
/** Read-only operational request counts; no submission snapshots or distinct-client deduplication. */
final class StatisticsModel extends RequestrecordsModel
{
    public function courseTypes(): array
    {
        $this->requireAdministrator();
        return $this->getDatabase()->setQuery('SELECT id,name FROM #__altacourses_coursetypes ORDER BY name,id')->loadObjectList();
    }
    public function sections(Registry $options): array
    {
        $this->requireAdministrator();$sections=[];
        foreach(['activity','forecast','analysis'] as $section){$sections[$section]=(bool)$options->get('statistics_show_'.$section,true);}
        return $sections;
    }
    public function overview(Registry $options,int $type=0,?int $year=null,string $timezone='UTC',?\DateTimeImmutable $now=null): array
    {
        $this->requireAdministrator();$sections=$this->sections($options);$utc=new \DateTimeZone('UTC');$zone=new \DateTimeZone($timezone);
        $now=($now??new \DateTimeImmutable('now',$utc))->setTimezone($utc);$local=$now->setTimezone($zone);$currentYear=(int)$local->format('Y');
        if($type<0||$type>2147483647||($year!==null&&($year<2009||$year>$currentYear))){throw new \RuntimeException(Text::_('COM_ALTACOURSES_STATS_INVALID'),400);}
        $db=$this->getDatabase();if($type>0&&!$db->setQuery('SELECT id FROM #__altacourses_coursetypes WHERE id='.$type)->loadResult()){throw new \RuntimeException(Text::_('COM_ALTACOURSES_STATS_INVALID'),400);}
        $date=static fn(\DateTimeImmutable $value)=>$value->setTimezone($utc)->format('Y-m-d H:i:s');
        $start=$local->setDate($currentYear,1,1)->setTime(0,0,0);$days=(int)$local->format('z')+1;$yearDays=(int)$local->format('L')===1?366:365;
        $signup='r.asked_for_info=0 AND COALESCE(r.canceled,0)<>1 AND COALESCE(r.rebooked,0)<>2';$enquiry='r.asked_for_info=1';
        $base=static function()use($db,$type,$now,$date){$q=$db->createQuery()->from('#__altacourses_requests AS r')->where('r.date_created<='.$db->quote($date($now)));if($type>0){$q->join('INNER','#__altacourses_courses AS co ON co.id=r.courseid')->where('co.course_type='.$type);}return $q;};
        $counts=['signups24'=>0,'enquiries24'=>0,'signups7'=>0,'enquiries7'=>0,'signupsYear'=>0];
        if($sections['activity']||$sections['forecast']){
            $seven=$now->sub(new \DateInterval('P7D'));$day=$now->sub(new \DateInterval('PT24H'));$q=$base();$lower=$sections['activity']&&$seven<$start?$seven:$start;$q->where('r.date_created>='.$db->quote($date($lower)));
            $expressions=['signupsYear'=>[$signup,$date($start)]];
            if($sections['activity']){$expressions+=['signups24'=>[$signup,$date($day)],'enquiries24'=>[$enquiry,$date($day)],'signups7'=>[$signup,$date($seven)],'enquiries7'=>[$enquiry,$date($seven)]];}
            foreach($expressions as $key=>[$condition,$from]){$q->select('COALESCE(SUM(CASE WHEN '.$condition.' AND r.date_created>='.$db->quote($from).' THEN 1 ELSE 0 END),0) AS '.$db->quoteName($key));}
            foreach($db->setQuery($q)->loadAssoc() as $key=>$value){$counts[$key]=(int)$value;}
        }
        $analysis=null;
        if($sections['analysis']&&$year!==null){$from=$start->setDate($year,1,1);$to=$from->modify('+1 year');$q=$base()->where('r.date_created>='.$db->quote($date($from)))->where('r.date_created<'.$db->quote($date($to)))->select(['COALESCE(SUM(CASE WHEN '.$signup.' THEN 1 ELSE 0 END),0) AS signups','COALESCE(SUM(CASE WHEN '.$enquiry.' THEN 1 ELSE 0 END),0) AS enquiries']);$row=$db->setQuery($q)->loadAssoc();$analysis=['year'=>$year,'signups'=>(int)$row['signups'],'enquiries'=>(int)$row['enquiries']];}
        $money=static function(mixed $raw): float{if(!is_scalar($raw)||!preg_match('/^\d{1,9}(?:[.,]\d{1,2})?$/D',(string)$raw)){throw new \RuntimeException(Text::_('COM_ALTACOURSES_STATS_MONEY_INVALID'),400);}return (float)str_replace(',','.',(string)$raw);};
        $average=$counts['signupsYear']/$days;$predicted=(int)round($average*$yearDays);$commission=$sections['forecast']?$money($options->get('statistics_average_commission','0')):0.0;$goal=$sections['forecast']?$money($options->get('statistics_income_goal','0')):0.0;
        return compact('sections','counts','analysis','currentYear','days','yearDays','average','predicted','commission','goal')+['income'=>round($predicted*$commission,2),'type'=>$type,'year'=>$year];
    }
}
