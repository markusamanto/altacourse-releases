<?php

/**
 * @package     Altacourses.Installer
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Installer;

use Joomla\CMS\Installer\InstallerAdapter;
use Joomla\CMS\Installer\InstallerScriptInterface;
use Joomla\CMS\Language\Text;
use Joomla\Database\DatabaseInterface;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;

\defined('_JEXEC') or die;

return new class () implements ServiceProviderInterface {
    public function register(Container $container): void
    {
        $container->set(
            InstallerScriptInterface::class,
            static fn (Container $container): InstallerScriptInterface => new class ($container->get(DatabaseInterface::class)) implements InstallerScriptInterface {
                public function __construct(private readonly DatabaseInterface $database)
                {
                }

                public function preflight(string $type, InstallerAdapter $adapter): bool
                {
                    if ($type === 'uninstall') {
                        return true;
                    }

                    if (version_compare(JVERSION, '6.2.0', '<') || version_compare(PHP_VERSION, '8.4.0', '<')) {
                        throw new \RuntimeException(Text::_('COM_ALTACOURSES_INSTALL_REQUIREMENTS'));
                    }

                    if ($this->database->getServerType() !== 'mysql') {
                        throw new \RuntimeException(Text::_('COM_ALTACOURSES_INSTALL_DATABASE'));
                    }

                    $manifest = JPATH_ADMINISTRATOR . '/components/com_altacourses/altacourses.xml';
                    $installed = null;

                    if (is_file($manifest)) {
                        $installed = simplexml_load_file($manifest);

                        if ($installed === false || (string) $installed->namespace !== 'Advenire\\Component\\Altacourses') {
                            throw new \RuntimeException(Text::_('COM_ALTACOURSES_INSTALL_LEGACY'));
                        }
                    }

                    $prefix = $this->database->getPrefix() . 'altacourses_';
                    $owned = array_map(static fn (string $name): string => $prefix . $name,
                        ['courses', 'coursetypes', 'courseplaces', 'courseleaders', 'regions', 'seats']);
                    $mayHaveSchema = $installed !== null
                        && version_compare((string) $installed->version, '2.0.0-alpha4', '>=');
                    $mayHaveSessions = $mayHaveSchema && version_compare((string) $installed->version, '2.0.0-alpha8', '>=');
                    if ($mayHaveSessions) {
                        $owned[] = $prefix . 'course_sessions';
                    }
                    $schema = null;

                    if ($mayHaveSchema) {
                        $schema = $this->database->setQuery(
                            "SELECT s.version_id FROM #__schemas AS s INNER JOIN #__extensions AS e ON e.extension_id = s.extension_id WHERE e.element = 'com_altacourses' AND e.type = 'component'"
                        )->loadResult();
                    }

                    $expectedSchema = $mayHaveSchema && version_compare((string) $installed->version, '2.0.0-alpha9', '>=')
                        ? '2.0.3' : ($mayHaveSessions
                        ? '2.0.2' : ($mayHaveSchema && version_compare((string) $installed->version, '2.0.0-alpha6', '>=')
                        ? '2.0.1' : '2.0.0'));

                    foreach ($this->database->getTableList() as $table) {
                        if (str_starts_with($table, $prefix)
                            && (!$mayHaveSchema || $schema !== $expectedSchema || !in_array($table, $owned, true))) {
                            throw new \RuntimeException(Text::_('COM_ALTACOURSES_INSTALL_EXISTING_DATA'));
                        }
                    }

                    return true;
                }

                public function install(InstallerAdapter $adapter): bool
                {
                    return true;
                }

                public function update(InstallerAdapter $adapter): bool
                {
                    return true;
                }

                public function uninstall(InstallerAdapter $adapter): bool
                {
                    return true;
                }

                public function postflight(string $type, InstallerAdapter $adapter): bool
                {
                    if ($type !== 'uninstall') {
                        foreach (['src/View/Assignment/HtmlView.php', 'tmpl/assignment/default.php', 'forms/assignment.xml'] as $file) {
                            $path = JPATH_SITE . '/components/com_altacourses/' . $file;
                            if (is_file($path) && !\Joomla\Filesystem\File::delete($path)) {
                                throw new \RuntimeException('Retired assignment screen could not be removed');
                            }
                        }
                    }
                    return true;
                }
            }
        );
    }
};
