<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;
$view = $displayData['view'];
?>
<section aria-labelledby="altacourses-participant-heading">
    <h1 id="altacourses-participant-heading"><?php echo $view->escape(Text::_('COM_ALTACOURSES_PARTICIPANT_TITLE')); ?></h1>
    <p><a data-back-<?php echo $view->escape($view->backView); ?> href="<?php echo $view->escape(Route::_('index.php?' . http_build_query(['option' => 'com_altacourses', 'view' => $view->backView, 'limitstart' => $view->returnStart] + $view->returnFilters), false)); ?>"><?php echo $view->escape(Text::_($view->scopedContact ? 'COM_ALTACOURSES_CONTACTS_BACK' : 'COM_ALTACOURSES_PARTICIPANT_BACK')); ?></a></p>
    <p><?php echo $view->escape(Text::_('COM_ALTACOURSES_PARTICIPANT_SNAPSHOT')); ?></p>
    <dl data-participant-contact>
        <?php foreach (['firstname' => 'SUPPLIER_FIRSTNAME', 'lastname' => 'SUPPLIER_LASTNAME', 'company' => 'ENQUIRY_ORGANISATION', 'email' => 'ENQUIRY_EMAIL', 'phone' => 'SUPPLIER_PHONE', 'mobile' => 'SUPPLIER_MOBILE', 'age' => 'SIGNUP_AGE', 'profession' => 'SIGNUP_PROFESSION', 'specialmeal' => 'SIGNUP_SPECIALMEAL', 'postal_address' => 'SIGNUP_POSTAL_ADDRESS', 'postal_zip' => 'SIGNUP_POSTAL_ZIP', 'postal_city' => 'SIGNUP_POSTAL_CITY', 'invoice_address' => 'SIGNUP_INVOICE_ADDRESS', 'invoice_zip' => 'SIGNUP_INVOICE_ZIP', 'invoice_city' => 'SIGNUP_INVOICE_CITY'] as $field => $label) : ?>
            <dt><?php echo $view->escape(Text::_('COM_ALTACOURSES_' . $label)); ?></dt><dd><?php echo $view->escape($view->contact[$field] ?? ''); ?></dd>
        <?php endforeach; ?>
    </dl>

    <?php if ($view->accountForm !== null) : ?>
    <form id="altacourses-clientaccount-form" action="<?php echo $view->escape(Route::_('index.php?option=com_altacourses&task=clientaccount.save', false)); ?>" method="post">
        <?php foreach (['request_id', 'version'] as $field) : ?><?php echo $view->accountForm->getInput($field); ?><?php endforeach; ?>
        <?php echo $view->accountForm->renderField('account'); ?>
        <?php echo HTMLHelper::_('form.token'); ?>
        <button type="submit" class="btn btn-success"><?php echo $view->escape(Text::_('JSAVE')); ?></button>
    </form>
    <?php endif; ?>

    <?php if ($view->scopedContact) : ?><p><?php echo $view->escape(Text::_('COM_ALTACOURSES_CONTACTS_HISTORY_SCOPE')); ?></p><?php endif; ?>
    <p><a data-participation-link href="<?php echo $view->escape(Route::_('index.php?option=com_altacourses&view=participation&id=' . (int) $view->item->request_id, false)); ?>"><?php echo $view->escape(Text::_('COM_ALTACOURSES_PARTICIPATION_TITLE')); ?></a></p>
    <h2><?php echo $view->escape(Text::_('COM_ALTACOURSES_PARTICIPANT_HISTORY')); ?></h2>
    <div class="table-responsive"><table class="table table-striped"><thead><tr>
        <?php foreach (['SIGNUP_CREATED', 'PARTICIPANT_KIND', 'COURSE_TYPE', 'PLACE', 'DATES', 'SIGNUP_VIEW'] as $label) : ?>
            <th scope="col"><?php echo $view->escape(Text::_('COM_ALTACOURSES_' . $label)); ?></th>
        <?php endforeach; ?>
    </tr></thead><tbody>
    <?php foreach ($view->history as $entry) : ?>
        <?php $course = json_decode($entry->course_json, true, 512, JSON_THROW_ON_ERROR); ?>
        <tr data-history-id="<?php echo (int) $entry->request_id; ?>"<?php if ((int) $entry->request_id === (int) $view->item->request_id) : ?> class="table-active"<?php endif; ?>>
            <td><?php echo $view->escape($entry->created_at); ?></td>
            <td><?php echo $view->escape(Text::_((int) $entry->asked_for_info === 1 ? 'COM_ALTACOURSES_ENQUIRY_TITLE' : 'COM_ALTACOURSES_SIGNUP_TITLE')); ?></td>
            <td><?php echo $view->escape($course['course_type'] ?? ''); ?></td>
            <td><?php echo $view->escape($course['course_place'] ?? ''); ?></td>
            <td><?php foreach ($course['sessions'] ?? [] as $part) : ?><div><?php echo $view->escape(substr($part['start_date'] ?? '', 0, 10) . ' – ' . substr($part['stop_date'] ?? '', 0, 10)); ?></div><?php endforeach; ?></td>
            <td><a data-history-view href="<?php echo $view->escape(Route::_('index.php?' . http_build_query(['option' => 'com_altacourses', 'view' => $view->detailView, 'id' => (int) $entry->request_id, 'return_start' => $view->returnStart] + $view->returnFilters), false)); ?>"><?php echo $view->escape(Text::_('COM_ALTACOURSES_SIGNUP_VIEW')); ?></a></td>
        </tr>
    <?php endforeach; ?>
    </tbody></table></div>

    <?php if ($view->showMailActions) : ?>
    <p><a href="<?php echo $view->escape(Route::_('index.php?option=com_altacourses&view=notifications&id=' . (int) $view->item->request_id, false)); ?>"><?php echo $view->escape(Text::_('COM_ALTACOURSES_NOTIFY_TITLE')); ?></a></p>
    <?php endif; ?>
    <h2><?php echo $view->escape(Text::_('COM_ALTACOURSES_PARTICIPANT_SELECTED')); ?></h2>
    <dl data-selected-submission>
        <dt><?php echo $view->escape(Text::_('COM_ALTACOURSES_PARTICIPANT_KIND')); ?></dt><dd><?php echo $view->escape(Text::_((int) $view->item->asked_for_info === 1 ? 'COM_ALTACOURSES_ENQUIRY_TITLE' : 'COM_ALTACOURSES_SIGNUP_TITLE')); ?></dd>
        <dt><?php echo $view->escape(Text::_('COM_ALTACOURSES_SIGNUP_CREATED')); ?></dt><dd><?php echo $view->escape($view->item->created_at); ?></dd>
        <dt><?php echo $view->escape(Text::_('COM_ALTACOURSES_LEADERS')); ?></dt><dd><?php echo $view->escape(implode(', ', array_filter([$view->course['leader1'] ?? '', $view->course['leader2'] ?? '']))); ?></dd>
        <dt><?php echo $view->escape(Text::_('COM_ALTACOURSES_ENQUIRY_SUPPLIER')); ?></dt><dd><?php echo $view->escape($view->item->supplier_email); ?></dd>
        <?php if ((int) $view->item->asked_for_info === 0) : ?>
            <?php $booking = $view->course['booking'] ?? []; ?>
            <dt><?php echo $view->escape(Text::_('COM_ALTACOURSES_TOTAL_PRICE')); ?></dt><dd><?php echo $view->escape(($booking['total_price'] ?? '') . ' ' . Text::_('COM_ALTACOURSES_CURRENCY')); ?></dd>
            <dt><?php echo $view->escape(Text::_('COM_ALTACOURSES_SUPPLIER_TERMS')); ?></dt><dd><?php echo nl2br($view->escape($booking['terms'] ?? '')); ?></dd>
            <dt><?php echo $view->escape(Text::_('COM_ALTACOURSES_SIGNUP_ACCEPTED_AT')); ?></dt><dd><?php echo $view->escape($booking['accepted_at'] ?? ''); ?></dd>
        <?php endif; ?>
    </dl>
</section>
<?php if ($view->rebookings) : ?>
<section aria-labelledby="rebooking-history-title">
<h2 id="rebooking-history-title"><?php echo $view->escape(Text::_('COM_ALTACOURSES_REBOOK_HISTORY')); ?></h2>
<p><?php echo $view->escape(Text::_('COM_ALTACOURSES_REBOOK_HISTORY_HELP')); ?></p>
<?php foreach ($view->rebookings as $event) : ?>
<article data-rebooking-id="<?php echo (int) $event->id; ?>">
<p><?php echo $view->escape($event->created_at . ' UTC'); ?> · #<?php echo (int) $event->request_id; ?></p>
<?php foreach (['from_json' => 'REBOOK_FROM', 'to_json' => 'REBOOK_TO'] as $field => $label) : ?>
<?php $occasion = json_decode($event->$field, true, 512, JSON_THROW_ON_ERROR); ?>
<p><strong><?php echo $view->escape(Text::_('COM_ALTACOURSES_' . $label)); ?>:</strong>
<?php echo $view->escape('#' . $occasion['id'] . ' · ' . ($occasion['course_type'] ?? '') . ' · ' . ($occasion['course_place'] ?? '')); ?>
<?php foreach ($occasion['sessions'] ?? [] as $part) : ?><span><?php echo $view->escape(substr($part['start_date'] ?? '', 0, 10) . ' – ' . substr($part['stop_date'] ?? '', 0, 10)); ?></span> <?php endforeach; ?>
</p>
<?php endforeach; ?>
<p><?php echo nl2br($view->escape($event->note)); ?></p>
</article>
<?php endforeach; ?>
</section>
<?php endif; ?>
