<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
\defined('_JEXEC') or die;
$link = static fn(string $query): string => Route::_('index.php?option=com_altacourses&' . $query, false);
?>
<section class="altacourses-portal altacourses-lastminutes" aria-labelledby="altacourses-lastminutes-heading">
 <h1 id="altacourses-lastminutes-heading"><?php echo $this->escape(Text::_('COM_ALTACOURSES_LASTMINUTES_TITLE')); ?></h1>
 <p><a href="<?php echo $this->escape($link('view=dashboard')); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_BACK_TO_DASHBOARD')); ?></a></p>
 <p><a class="btn btn-success" href="<?php echo $this->escape($link('view=lastminute&fresh=1')); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_LASTMINUTE_ADD')); ?></a></p>
 <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_LASTMINUTE_COPY_HELP')); ?></p>
 <button type="button" class="btn btn-primary" id="lastminute-copy" data-success="<?php echo $this->escape(Text::_('COM_ALTACOURSES_LASTMINUTE_COPIED')); ?>" data-failure="<?php echo $this->escape(Text::_('COM_ALTACOURSES_LASTMINUTE_COPY_FAILED')); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_LASTMINUTE_COPY')); ?> (<?php echo count($this->emails); ?>)</button>
 <p id="lastminute-copy-status" role="status" aria-live="polite"></p>
 <details id="lastminute-copy-fallback"><summary><?php echo $this->escape(Text::_('COM_ALTACOURSES_LASTMINUTE_COPY_MANUAL')); ?></summary>
 <textarea id="lastminute-copy-addresses" rows="4" readonly aria-label="<?php echo $this->escape(Text::_('COM_ALTACOURSES_LASTMINUTE_EMAIL')); ?>"><?php echo $this->escape(implode(', ', $this->emails)); ?></textarea></details>
 <form method="get" action="<?php echo $this->escape(Route::_('index.php', false)); ?>" class="my-3" id="lastminute-filters">
  <input type="hidden" name="option" value="com_altacourses"><input type="hidden" name="view" value="lastminutes">
  <label for="lastminute-search"><?php echo $this->escape(Text::_('JSEARCH_FILTER')); ?></label>
  <input type="search" name="search" id="lastminute-search" maxlength="120" value="<?php echo $this->escape($this->filters['search']); ?>">
  <label for="lastminute-participated"><?php echo $this->escape(Text::_('COM_ALTACOURSES_LASTMINUTE_PARTICIPATED')); ?></label>
  <select name="participated" id="lastminute-participated">
   <?php foreach (['0' => 'COM_ALTACOURSES_LASTMINUTE_PENDING', '1' => 'COM_ALTACOURSES_LASTMINUTE_DONE', 'all' => 'JALL'] as $value => $label) : ?>
    <option value="<?php echo $this->escape((string) $value); ?>"<?php echo $this->filters['participated'] === (string) $value ? ' selected' : ''; ?>><?php echo $this->escape(Text::_($label)); ?></option>
   <?php endforeach; ?>
  </select>
  <button class="btn btn-primary" type="submit"><?php echo $this->escape(Text::_('JSEARCH_FILTER_SUBMIT')); ?></button>
  <a class="btn btn-secondary" href="<?php echo $this->escape($link('view=lastminutes')); ?>"><?php echo $this->escape(Text::_('JSEARCH_FILTER_CLEAR')); ?></a>
 </form>
 <?php if (!$this->items) : ?><p><?php echo $this->escape(Text::_('COM_ALTACOURSES_LASTMINUTES_EMPTY')); ?></p><?php else : ?>
 <div class="table-responsive"><table class="table table-striped">
 <caption><?php echo $this->escape(Text::_('COM_ALTACOURSES_LASTMINUTES_TITLE')); ?></caption>
 <thead><tr><?php foreach (['FIRSTNAME', 'LASTNAME', 'TELEPHONE', 'EMAIL', 'PARTICIPATED', 'ACTIONS'] as $label) : ?><th scope="col"><?php echo $this->escape(Text::_('COM_ALTACOURSES_LASTMINUTE_' . $label)); ?></th><?php endforeach; ?></tr></thead>
 <tbody><?php foreach ($this->items as $item) : ?>
 <tr data-lastminute-id="<?php echo (int) $item->id; ?>">
  <th scope="row"><a href="<?php echo $this->escape($link('view=lastminute&id=' . (int) $item->id . '&fresh=1')); ?>"><?php echo $this->escape((string) ($item->firstname ?? '')); ?></a></th>
  <?php foreach (['lastname', 'telephone', 'email'] as $field) : ?><td><?php echo $this->escape((string) ($item->$field ?? '')); ?></td><?php endforeach; ?>
  <td><?php echo $this->escape(Text::_(trim((string) $item->participated) === '1' ? 'JYES' : 'JNO')); ?></td>
  <td>
   <a class="btn btn-success btn-sm" href="<?php echo $this->escape($link('view=lastminute&id=' . (int) $item->id . '&fresh=1')); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_LASTMINUTE_EDIT_ACTION')); ?></a>
   <details class="lastminute-delete"><summary class="btn btn-danger btn-sm"><?php echo $this->escape(Text::_('COM_ALTACOURSES_LASTMINUTE_DELETE')); ?></summary>
    <p><?php echo $this->escape(Text::sprintf('COM_ALTACOURSES_LASTMINUTE_DELETE_CONFIRM', trim((string) $item->firstname . ' ' . (string) $item->lastname))); ?></p>
    <form action="<?php echo $this->escape($link('task=lastminute.delete')); ?>" method="post">
     <input type="hidden" name="jform[id]" value="<?php echo (int) $item->id; ?>">
     <input type="hidden" name="jform[version]" value="<?php echo $this->escape($this->getModel()->formData($item)['version']); ?>">
     <input type="hidden" name="jform[confirm]" value="1">
     <?php echo HTMLHelper::_('form.token'); ?>
     <button type="submit" class="btn btn-danger"><?php echo $this->escape(Text::_('COM_ALTACOURSES_LASTMINUTE_DELETE_YES')); ?></button>
     <button type="button" class="btn btn-secondary" data-cancel-delete><?php echo $this->escape(Text::_('JCANCEL')); ?></button>
    </form>
   </details>
  </td>
 </tr>
 <?php endforeach; ?></tbody></table></div>
 <?php echo $this->pagination->getPagesLinks(); ?>
 <?php endif; ?>
</section>
