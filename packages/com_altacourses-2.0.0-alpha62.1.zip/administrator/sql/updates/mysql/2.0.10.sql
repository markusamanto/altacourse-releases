-- Append-only movement history. Request identity and original accepted submission stay intact.
CREATE TABLE IF NOT EXISTS `#__altacourses_request_rebookings` (
 `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
 `request_id` int UNSIGNED NOT NULL,
 `from_course_id` int UNSIGNED NOT NULL,
 `to_course_id` int UNSIGNED NOT NULL,
 `from_json` text NOT NULL,
 `to_json` text NOT NULL,
 `supplier_user_id` int NOT NULL,
 `created_at` datetime NOT NULL,
 `created_by` int NOT NULL,
 `request_version` int UNSIGNED NOT NULL,
 `previous_note` text NOT NULL,
 `note` text NOT NULL,
 PRIMARY KEY (`id`),
 UNIQUE KEY `idx_rebooking_revision` (`request_id`,`request_version`),
 KEY `idx_rebooking_request` (`request_id`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
