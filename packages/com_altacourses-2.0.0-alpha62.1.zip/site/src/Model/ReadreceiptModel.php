<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Model;

use Advenire\Component\Altacourses\Administrator\Service\RequestReceipt;
use Joomla\CMS\MVC\Model\BaseModel;
use Joomla\Database\DatabaseAwareInterface;
use Joomla\Database\DatabaseAwareTrait;

\defined('_JEXEC') or die;

final class ReadreceiptModel extends BaseModel implements DatabaseAwareInterface
{
    use DatabaseAwareTrait;

    private string $receiptSecret = '';
    public function setReceiptSecret(string $secret): void { $this->receiptSecret = $secret; }

    public function acknowledge(mixed $token): void
    {
        (new RequestReceipt($this->getDatabase(), $this->receiptSecret))->acknowledge($token);
    }
}
