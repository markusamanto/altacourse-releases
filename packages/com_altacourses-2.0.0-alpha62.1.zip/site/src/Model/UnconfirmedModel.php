<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Model;

use Joomla\CMS\Language\Text;

\defined('_JEXEC') or die;

/** Administrator overview only; no participation, receipt or mail actions. */
final class UnconfirmedModel extends RequestrecordsModel
{
    private string $reportingTimezone = 'UTC';

    public function setReportingTimezone(string $timezone): void
    {
        new \DateTimeZone($timezone);
        $this->reportingTimezone = $timezone;
    }

    public function today(): string
    {
        return (new \DateTimeImmutable('now', new \DateTimeZone($this->reportingTimezone)))->format('Y-m-d');
    }

    public function getItems(): array
    {
        $this->requireAdministrator();
        $today = $this->today();
        $rows = (new \Advenire\Component\Altacourses\Administrator\Service\PendingParticipation($this->getDatabase()))->items($today);
        foreach ($rows as $row) {
            if ($row->supplier_name === '') { $row->supplier_name = (int)$row->supplier_user_id > 0 ? Text::sprintf('COM_ALTACOURSES_OWNER_ID',(int)$row->supplier_user_id) : Text::_('COM_ALTACOURSES_UNASSIGNED'); }
            if ($row->client_name === '') { $row->client_name = Text::_('COM_ALTACOURSES_UNCONFIRMED_UNKNOWN_CLIENT'); }
        }
        return $rows;
    }
}
