<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Model;
use Joomla\CMS\Language\Text;
\defined('_JEXEC') or die;
/** Participation uses the same two-request writer inside its complete course transaction. */
trait RebookingTrait
{
    private RebookingModel $rebookingModel;
    public function setRebookingModel(RebookingModel $model): void { $model->setParticipationContext(true); $this->rebookingModel = $model; }
    private function rebooking(): RebookingModel
    {
        $this->rebookingModel->setCurrentUser($this->getActor());
        $this->rebookingModel->setReportingTimezone($this->reportingTimezone);
        return $this->rebookingModel;
    }
    public function getRebookingOptions(int $requestId): array
    {
        $row = $this->getRecord($requestId);
        if ($row->date_reported !== null || $row->commission_fee !== null || (int) $row->participated !== 0 || (int) $row->canceled !== 0) { return []; }
        try { return $this->rebooking()->getOptions($requestId); }
        catch (\RuntimeException $error) { if ($error->getCode() === 409) { return []; } throw $error; }
    }
    public function getRebookingForm(object $row, string $control): \Joomla\CMS\Form\Form
    {
        $form = $this->getForm(['id' => $row->id, 'version' => $row->participation_version, 'status' => 0, 'note' => $row->note], $control);
        $field = new \SimpleXMLElement('<field name="rebook" type="list" label="COM_ALTACOURSES_REBOOK_TO" filter="string" validate="options"/>');
        $field->addChild('option', 'COM_ALTACOURSES_REBOOK_NONE')->addAttribute('value', '0');
        foreach ($this->getRebookingOptions((int) $row->id) as $target) {
            $dates = array_map(static fn ($part): string => substr($part->start_date, 0, 10) . ' – ' . substr($part->stop_date, 0, 10), $target->sessions);
            $label = '#' . $target->id . ' · ' . $target->type_name . ' · ' . $target->place_name . ' · ' . implode(' / ', $dates);
            $field->addChild('option', htmlspecialchars($label, ENT_QUOTES | ENT_XML1, 'UTF-8'))->addAttribute('value', $target->id . ':' . $target->target_version);
        }
        $form->setField($field); $form->setValue('rebook', null, '0'); return $form;
    }
    private function validateRebooking(string $value): void
    {
        if ($value !== '0' && (!preg_match('/^([1-9][0-9]*):([a-f0-9]{64})$/D', $value, $parts) || (float) $parts[1] > 2147483647)) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_REBOOK_INVALID'), 400);
        }
    }
    private function moveRequest(object $row, array $report, string $now): void
    {
        if ($report['status'] !== 0 || (int) $row->participation_version !== $report['version']) { throw new \RuntimeException(Text::_('COM_ALTACOURSES_REBOOK_INVALID'), 409); }
        [$destination, $targetVersion] = explode(':', $report['rebook']);
        $model = $this->rebooking(); $source = $model->getRecord((int) $row->id, true);
        $model->rebook((int) $row->id, $model->revision($source), (int) $destination, $targetVersion, $report['note'], true, $now);
    }
}
