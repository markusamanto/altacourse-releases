<?php

/**
 * @package     Altacourses.Administrator
 * @license     GNU General Public License version 2 or later
 * @var         \Advenire\Component\Altacourses\Administrator\View\Dashboard\HtmlView $this
 */

use Joomla\CMS\Language\Text;

\defined('_JEXEC') or die;
?>
<section class="altacourses-dashboard" aria-labelledby="altacourses-heading">
    <div class="card">
        <div class="card-body">
            <h2 id="altacourses-heading" class="card-title">
                <?php echo $this->escape(Text::_('COM_ALTACOURSES_FOUNDATION_HEADING')); ?>
            </h2>
            <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_FOUNDATION_DESCRIPTION')); ?></p>
            <p class="mb-0"><?php echo $this->escape(Text::_('COM_ALTACOURSES_FOUNDATION_NEXT')); ?></p>
        </div>
    </div>
</section>

<?php if ($this->migrationReport !== null): $report=$this->migrationReport; ?>
<section class="card mt-4"><div class="card-body">
<h2><?php echo $this->escape(Text::_('COM_ALTACOURSES_MIGRATION_REPORT')); ?></h2>
<p><?php echo $this->escape(Text::_('COM_ALTACOURSES_MIGRATION_COMPLETE')); ?></p>
<p><?php echo $this->escape(Text::_('JSTATUS').': '.$report['status']); ?></p>
<table class="table table-striped"><caption><?php echo $this->escape(Text::_('COM_ALTACOURSES_MIGRATION_COUNTS')); ?></caption><tbody>
<?php foreach ($report['counts'] as $table=>$count): ?><tr><th scope="row"><?php echo $this->escape($table); ?></th><td><?php echo (int)$count; ?></td></tr><?php endforeach; ?>
</tbody></table>
<p><?php echo $this->escape(Text::_('COM_ALTACOURSES_MIGRATION_MENUS').': '.$report['menu_count']); ?></p>
<p><?php echo $this->escape(Text::_('COM_ALTACOURSES_MIGRATION_MANUAL').': '.implode(', ',$report['unmapped'])); ?></p>
<p><?php echo $this->escape(Text::_('COM_ALTACOURSES_MIGRATION_INCOMPLETE').': '.implode(', ',$report['incomplete_requests'])); ?></p>
<ul><?php foreach ($report['modules'] as $module): ?><li><?php echo $this->escape('#'.$module['id'].' '.$module['target'].($module['pending']?' — '.Text::_('COM_ALTACOURSES_MIGRATION_PENDING'):'')); ?></li><?php endforeach; ?></ul>
<details><summary><?php echo $this->escape(Text::_('COM_ALTACOURSES_MIGRATION_CONVERSIONS')); ?></summary><ul>
<?php foreach ($report['conversions'] as $field=>$count): ?><li><?php echo $this->escape($field.': '.$count); ?></li><?php endforeach; ?>
</ul></details>
</div></section>
<?php endif; ?>
