<?php

/**
 * @package     Altacourses.Administrator
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Administrator\Service;

use Joomla\CMS\Language\LanguageFactoryInterface;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Mail\Mail;
use Joomla\CMS\String\PunycodeHelper;
use Joomla\CMS\Mail\MailerFactoryInterface;
use Joomla\Database\DatabaseInterface;
use Joomla\Database\ParameterType;
use Joomla\Registry\Registry;

\defined('_JEXEC') or die;

/** Immutable per-recipient messages; SMTP acceptance is not proof of inbox delivery. */
final class NotificationService
{
    public function __construct(
        private readonly DatabaseInterface $db,
        private readonly Registry $config,
        private readonly MailerFactoryInterface $mailers,
        private readonly LanguageFactoryInterface $languages,
        private readonly CoursePrice $prices
    ) {
    }

    public function settings(): array
    {
        $params = json_decode($this->db->setQuery("SELECT params FROM #__extensions WHERE element='com_altacourses' AND type='component'")->loadResult() ?: '{}', true, flags: JSON_THROW_ON_ERROR);
        return ['mode' => $params['notification_mode'] ?? 'off', 'language' => ($params['notification_language'] ?? 'sv-SE') === 'en-GB' ? 'en-GB' : 'sv-SE'];
    }

    /** Fail closed: alpha19 has no production transport or arbitrary SMTP destination. */
    public function blockedReason(): ?string
    {
        return $this->sandboxReason($this->settings()['mode'] === 'sandbox');
    }

    /** Shared fail-closed transport gate for independent controlled mail features. */
    public function sandboxReason(bool $enabled): ?string
    {
        if (!$enabled) { return 'disabled'; }
        if (!(bool) $this->config->get('mailonline', false)) { return 'mail_disabled'; }
        if ($this->config->get('mailer') !== 'smtp'
            || $this->config->get('smtphost') !== 'sandbox.smtp.mailtrap.io'
            || !in_array((int) $this->config->get('smtpport'), [587, 2525], true)
            || $this->config->get('smtpsecure') !== 'tls'
            || (int) $this->config->get('smtpauth') !== 1
            || (string) $this->config->get('smtpuser', '') === ''
            || (string) $this->config->get('smtppass', '') === '') {
            return 'unsafe_transport';
        }
        if (!$this->validAddress((string) $this->config->get('mailfrom', ''))
            || preg_match('/[\r\n\x00]/', (string) $this->config->get('fromname', ''))) {
            return 'invalid_sender';
        }
        return null;
    }

    /** Called inside the submission transaction; never performs external actions. */
    public function prepare(int $requestId): void
    {
        $query = $this->db->createQuery()->select(['s.*', 'r.asked_for_info'])
            ->from('#__altacourses_request_submissions AS s')
            ->join('INNER', '#__altacourses_requests AS r ON r.id=s.request_id')
            ->where('s.request_id=:request')->bind(':request', $requestId, ParameterType::INTEGER);
        $query->setQuery((string) $query . ' FOR UPDATE');
        $submission = $this->db->setQuery($query)->loadObject();
        if ($submission === null) { throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'), 404); }
        $submissionId = (int) $submission->id;
        $existing = (int) $this->db->setQuery('SELECT COUNT(*) FROM #__altacourses_notification_outbox WHERE submission_id=' . $submissionId)->loadResult();
        if ($existing !== 0) { return; }
        $contact = json_decode($submission->contact_json, true, 512, JSON_THROW_ON_ERROR);
        $course = json_decode($submission->course_json, true, 512, JSON_THROW_ON_ERROR);
        $signup = (int) $submission->asked_for_info === 0;
        if (!in_array((int) $submission->asked_for_info, [0, 1], true)
            || !$this->validAddress($submission->supplier_email) || !$this->validAddress($contact['email'] ?? '')
            || ($signup && (empty($course['booking']['terms_accepted']) || !isset($course['booking']['terms'], $course['booking']['total_price'])))) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_NOTIFY_SNAPSHOT_INVALID'), 409);
        }
        $language = $this->languages->createLanguage($this->settings()['language'], false);
        $language->load('com_altacourses', JPATH_SITE . '/components/com_altacourses', null, true, false);
        $text = static fn (string $key): string => $language->_('COM_ALTACOURSES_' . $key);
        $kind = $text($signup ? 'SIGNUP_TITLE' : 'ENQUIRY_TITLE');
        $details = $kind . ' #' . $requestId . "\n\n";
        foreach (['course_type' => 'COURSE_TYPE', 'course_place' => 'PLACE'] as $field => $label) {
            $details .= $text($label) . ': ' . ($course[$field] ?? '') . "\n";
        }
        foreach ($course['sessions'] ?? [] as $index => $session) {
            $details .= $text('DATES') . ' ' . ($index + 1) . ': ' . substr($session['start_date'] ?? '', 0, 10)
                . ' – ' . substr($session['stop_date'] ?? '', 0, 10) . "\n";
        }
        $details .= $text('LEADERS') . ': ' . implode(', ', array_filter([$course['leader1'] ?? '', $course['leader2'] ?? ''])) . "\n";
        $total = $signup ? $course['booking']['total_price'] : $this->prices->formatTotal($course['course_price'] ?? null, $course['lodging_price'] ?? null, $course['lodging_included'] ?? null);
        if ($total !== null) { $details .= $text('TOTAL_PRICE') . ': ' . $total . ' ' . $text('CURRENCY') . "\n"; }
        $details .= "\n";
        $fields = ['firstname' => 'SUPPLIER_FIRSTNAME', 'lastname' => 'SUPPLIER_LASTNAME', 'company' => 'ENQUIRY_ORGANISATION', 'email' => 'ENQUIRY_EMAIL', 'phone' => 'SUPPLIER_PHONE', 'mobile' => 'SUPPLIER_MOBILE'];
        if ($signup) {
            $fields += ['age' => 'SIGNUP_AGE', 'profession' => 'SIGNUP_PROFESSION', 'specialmeal' => 'SIGNUP_SPECIALMEAL', 'postal_address' => 'SIGNUP_POSTAL_ADDRESS', 'postal_zip' => 'SIGNUP_POSTAL_ZIP', 'postal_city' => 'SIGNUP_POSTAL_CITY', 'invoice_address' => 'SIGNUP_INVOICE_ADDRESS', 'invoice_zip' => 'SIGNUP_INVOICE_ZIP', 'invoice_city' => 'SIGNUP_INVOICE_CITY'];
        }
        foreach ($fields as $field => $label) { $details .= $text($label) . ': ' . ($contact[$field] ?? '') . "\n"; }
        if ($signup) {
            $details .= "\n" . $text('SUPPLIER_TERMS') . ":\n" . $course['booking']['terms'] . "\n\n"
                . $text('SIGNUP_ACCEPTED_AT') . ': ' . ($course['booking']['accepted_at'] ?? '') . "\n";
        }
        foreach (['supplier', 'participant'] as $role) {
            $subject = '[TEST] ' . $text($role === 'supplier' ? 'NOTIFY_SUPPLIER_SUBJECT' : 'NOTIFY_PARTICIPANT_SUBJECT') . ' – ' . $kind;
            $subject = mb_substr(str_replace(["\r", "\n", "\0"], ' ', $subject), 0, 255);
            $body = $text($role === 'supplier' ? 'NOTIFY_SUPPLIER_INTRO' : ($signup ? 'NOTIFY_SIGNUP_INTRO' : 'NOTIFY_ENQUIRY_INTRO')) . "\n\n" . $details;
            $row = (object) ['submission_id' => $submissionId, 'role' => $role,
                'recipient' => PunycodeHelper::emailToPunycode($role === 'supplier' ? $submission->supplier_email : $contact['email']),
                'reply_to' => $role === 'supplier' ? PunycodeHelper::emailToPunycode($contact['email']) : null,
                'subject' => $subject, 'body' => $body,
                'message_id' => '<altacourses-' . bin2hex(random_bytes(16)) . '@notifications.invalid>',
                'state' => 'pending', 'created_at' => $this->now()];
            $this->db->insertObject('#__altacourses_notification_outbox', $row, 'id');
        }
    }

    public function getMessages(int $requestId): array
    {
        $query = $this->db->createQuery()->select('o.*')->from('#__altacourses_notification_outbox AS o')
            ->join('INNER', '#__altacourses_request_submissions AS s ON s.id=o.submission_id')
            ->where('s.request_id=:request')->bind(':request', $requestId, ParameterType::INTEGER)
            ->order("CASE WHEN o.role='supplier' THEN 0 ELSE 1 END");
        return $this->db->setQuery($query)->loadObjectList();
    }

    /** Claims are committed before SMTP; sending/uncertain rows are never automatically retried. */
    public function deliver(int $requestId): void
    {
        if ($this->blockedReason() !== null) { return; }
        foreach ($this->getMessages($requestId) as $row) {
            if ($row->role === 'participant') {
                $supplier = array_filter($this->getMessages($requestId), static fn ($entry): bool => $entry->role === 'supplier' && $entry->state === 'sent');
                if (!$supplier) { break; }
            }
            if ($row->state !== 'pending') { continue; }
            $token = bin2hex(random_bytes(32));
            $query = $this->db->createQuery()->update('#__altacourses_notification_outbox')
                ->set("state='sending', attempts=attempts+1")
                ->set('attempt_token=:token')->bind(':token', $token)
                ->set('claimed_at=' . $this->db->quote($this->now()))
                ->where('id=' . (int) $row->id)->where("state='pending'");
            $this->db->setQuery($query)->execute();
            if ($this->db->getAffectedRows() !== 1) { continue; }
            $mailer = null;
            $accepted = false;
            try {
                $mailer = $this->mailers->createMailer(new Registry(['throw_exceptions' => true]));
                if (!$mailer instanceof Mail) { throw new \RuntimeException('Unsupported mailer'); }
                // Mail::Send otherwise retries automatically when opportunistic TLS is enabled.
                // Explicit SMTP TLS remains required; automatic resend/fallback is disabled.
                $mailer->SMTPAutoTLS = false;
                $mailer->Timeout = 10;
                $mailer->getSMTPInstance()->Timelimit = 10;
                $mailer->SMTPDebug = 0;
                $mailer->MessageID = $row->message_id;
                $mailer->setSender(PunycodeHelper::emailToPunycode((string) $this->config->get('mailfrom')), (string) $this->config->get('fromname'));
                $mailer->addRecipient($row->recipient);
                if ($row->reply_to !== null) { $mailer->addReplyTo($row->reply_to); }
                $mailer->setSubject($row->subject);
                $mailer->setBody($row->body);
                if ($mailer->send() !== true) { throw new \RuntimeException('No SMTP acceptance'); }
                $accepted = true;
                $this->finish((int) $row->id, $token, 'sent');
            } catch (\Throwable $error) {
                // SMTP may have accepted the message before a connection/status-write failure.
                // Do not expose raw SMTP exceptions, credentials or contact data.
                $this->finish((int) $row->id, $token, 'uncertain', $this->failureDiagnostic($mailer instanceof Mail ? $mailer : null, $error, $accepted));
                break;
            }
        }
        $this->refreshState($requestId);
    }

    public function retry(int $requestId, int $messageId, int $actorId): void
    {
        $rows = array_filter($this->getMessages($requestId), static fn ($row): bool => (int) $row->id === $messageId);
        $row = reset($rows);
        if (!$row || !($row->state === 'uncertain' || ($row->state === 'sending' && strtotime($row->claimed_at . ' UTC') < time() - 300))) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_NOTIFY_RETRY_CONFLICT'), 409);
        }
        $query = $this->db->createQuery()->update('#__altacourses_notification_outbox')
            ->set("state='pending', attempt_token=NULL, last_error='operator_retry'")
            ->set('reviewed_by=' . $actorId)->set('reviewed_at=' . $this->db->quote($this->now()))
            ->where('id=' . $messageId)->where('state=' . $this->db->quote($row->state))
            ->where('attempt_token=' . $this->db->quote($row->attempt_token));
        $this->db->setQuery($query)->execute();
        if ($this->db->getAffectedRows() !== 1) { throw new \RuntimeException(Text::_('COM_ALTACOURSES_NOTIFY_CHANGED'), 409); }
        $this->deliver($requestId);
    }

    /** Operator verified the message exists in Mailtrap; this never resends it. */
    public function confirm(int $requestId, int $messageId, int $actorId): void
    {
        $rows = array_filter($this->getMessages($requestId), static fn ($row): bool => (int) $row->id === $messageId);
        $row = reset($rows);
        if (!$row || !($row->state === 'uncertain' || ($row->state === 'sending' && strtotime($row->claimed_at . ' UTC') < time() - 300))) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_NOTIFY_CONFIRM_CONFLICT'), 409);
        }
        $query = $this->db->createQuery()->update('#__altacourses_notification_outbox')
            ->set("state='sent', last_error='operator_confirmed'")
            ->set('sent_at=' . $this->db->quote($this->now()))
            ->set('reviewed_by=' . $actorId)->set('reviewed_at=' . $this->db->quote($this->now()))
            ->where('id=' . $messageId)->where('state=' . $this->db->quote($row->state))
            ->where('attempt_token=' . $this->db->quote($row->attempt_token));
        $this->db->setQuery($query)->execute();
        if ($this->db->getAffectedRows() !== 1) { throw new \RuntimeException(Text::_('COM_ALTACOURSES_NOTIFY_CHANGED'), 409); }
        $this->refreshState($requestId);
    }

    private function finish(int $id, string $token, string $state, string $diagnostic = 'smtp_unconfirmed'): void
    {
        $query = $this->db->createQuery()->update('#__altacourses_notification_outbox')
            ->set('state=' . $this->db->quote($state))
            ->set('last_error=' . ($state === 'sent' ? 'NULL' : $this->db->quote($diagnostic)))
            ->set('sent_at=' . ($state === 'sent' ? $this->db->quote($this->now()) : 'NULL'))
            ->where('id=' . $id)->where('attempt_token=:token')->bind(':token', $token)->where("state='sending'");
        $this->db->setQuery($query)->execute();
    }

    /** Persist only a fixed category and numeric codes, never response text or credentials. */
    public function failureDiagnostic(?Mail $mailer, \Throwable $error, bool $accepted): string
    {
        if ($accepted) { return 'status_unconfirmed'; }
        if ($mailer === null) { return 'smtp_unconfirmed'; }
        $failure = $mailer->getSMTPInstance()->getError();
        $text = substr(($failure['error'] ?? '') . ' ' . ($failure['detail'] ?? '') . ' ' . $error->getMessage() . ' ' . $mailer->ErrorInfo, 0, 8192);
        $code = (string) ($failure['smtp_code'] ?? '');
        $extended = (string) ($failure['smtp_code_ex'] ?? '');
        if (!preg_match('/^[45][0-9]{2}$/D', $code)) {
            $code = preg_match('/SMTP code:\s*([45][0-9]{2})\b/i', $text, $match) ? $match[1] : '';
        }
        if (!preg_match('/^[45]\.[0-9]{1,3}\.[0-9]{1,3}$/D', $extended)) {
            $extended = preg_match('/Additional SMTP info:\s*([45]\.[0-9]{1,3}\.[0-9]{1,3})\b/i', $text, $match) ? $match[1] : '';
        }
        $category = 'smtp_unconfirmed';
        if (preg_match('/too many (?:emails|messages)|(?:sending|rate|throughput) limit|(?:emails|messages) per second/i', $text)) {
            $category = 'rate_limit';
        } elseif (in_array($code, ['530', '534', '535'], true) || preg_match('/authenticat(?:ion|e|ing).*fail|could not authenticate/i', $text)) {
            $category = 'authentication';
        } elseif (preg_match('/connect|certificate|TLS negotiation/i', $text)) {
            $category = 'connection';
        } elseif (preg_match('/recipient|RCPT/i', $failure['error'] ?? '')) {
            $category = 'recipient_rejected';
        } elseif ($code !== '') {
            $category = 'smtp_rejected';
        }
        return $category . ($code !== '' ? '|' . $code . ($extended !== '' ? '|' . $extended : '') : '');
    }

    private function refreshState(int $requestId): void
    {
        $states = array_column($this->getMessages($requestId), 'state');
        $state = in_array('uncertain', $states, true) || in_array('sending', $states, true) ? 'uncertain'
            : (count($states) === 2 && count(array_filter($states, static fn ($value): bool => $value === 'sent')) === 2 ? 'sent'
                : (in_array('sent', $states, true) ? 'partial' : 'not_sent'));
        $this->db->setQuery('UPDATE #__altacourses_request_submissions SET delivery_state=' . $this->db->quote($state) . ' WHERE request_id=' . $requestId)->execute();
    }

    public function validAddress(string $email): bool
    {
        try {
            $normalised = PunycodeHelper::emailToPunycode($email);
            return strlen($normalised) <= 254 && !preg_match('/[\r\n\x00]/', $normalised) && filter_var($normalised, FILTER_VALIDATE_EMAIL) !== false;
        } catch (\Throwable) { return false; }
    }

    private function now(): string
    {
        return (new \DateTimeImmutable('now', new \DateTimeZone('UTC')))->format('Y-m-d H:i:s');
    }
}
