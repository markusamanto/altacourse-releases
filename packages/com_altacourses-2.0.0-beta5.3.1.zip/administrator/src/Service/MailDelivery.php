<?php
/** @package Altacourses.Administrator @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Administrator\Service;
use Joomla\Database\DatabaseInterface;
\defined('_JEXEC') or die;
/** Transport provenance is separate from immutable payloads and SMTP acceptance. */
final class MailDelivery
{
    public const TABLES = ['notification_outbox', 'monthly_reports', 'supplier_reminders', 'evaluation_invitations'];
    public function __construct(private readonly DatabaseInterface $db) {}
    public static function fingerprint(object $row): string { return hash('sha256', json_encode($row, JSON_THROW_ON_ERROR)); }
    public static function canSend(object $row, string $mode): bool
    {
        $origin = $row->delivery_mode ?? 'legacy';
        $approved = (int)($row->production_approved_by ?? 0) > 0 && !empty($row->production_approved_at);
        return $mode === 'production' ? ($origin === 'production' || $approved)
            : ($mode === 'sandbox' && in_array($origin, ['legacy', 'off', 'sandbox'], true) && !$approved);
    }
    public static function claimCondition(string $mode): string
    {
        return $mode === 'production'
            ? "(delivery_mode='production' OR (production_approved_by>0 AND production_approved_at IS NOT NULL))"
            : "(delivery_mode IN ('legacy','off','sandbox') AND production_approved_at IS NULL)";
    }
    public static function reviewable(object $row): bool
    {
        return $row->state === 'pending' || $row->state === 'uncertain'
            || ($row->state === 'sending' && strtotime($row->claimed_at . ' UTC') < time() - 300);
    }
    public static function decorate(object $row, string $mode): object
    {
        $row->approval_token = self::fingerprint($row);
        $row->production_review = $mode === 'production' && !self::canSend($row, $mode) && self::reviewable($row);
        $row->mode_blocked = $row->state === 'pending' && !self::canSend($row, $mode) && $mode !== 'off';
        return $row;
    }
    /** Per-message approval, with a fresh preview fingerprint, never an automatic/bulk conversion. */
    public function approve(string $table, int $id, string $fingerprint, int $actor): object
    {
        if (!in_array($table, self::TABLES, true) || $id < 1 || $actor < 1 || !preg_match('/^[a-f0-9]{64}$/D', $fingerprint)) {
            throw new \RuntimeException('Invalid production review', 409);
        }
        $table = '#__altacourses_' . $table;
        $this->db->transactionStart();
        try {
            $row = $this->db->setQuery('SELECT * FROM ' . $table . ' WHERE id=' . $id . ' FOR UPDATE')->loadObject();
            if (!$row || !self::reviewable($row) || self::canSend($row, 'production') || !hash_equals(self::fingerprint($row), $fingerprint)) {
                throw new \RuntimeException('Delivery changed; reload the preview before approving', 409);
            }
            $now = $this->db->quote(gmdate('Y-m-d H:i:s'));
            $this->db->setQuery('UPDATE ' . $table . " SET state='pending',attempt_token=NULL,last_error='operator_production_approved',production_approved_by=" . $actor . ',production_approved_at=' . $now . ',reviewed_by=' . $actor . ',reviewed_at=' . $now . ' WHERE id=' . $id)->execute();
            $row = $this->db->setQuery('SELECT * FROM ' . $table . ' WHERE id=' . $id)->loadObject();
            $this->db->transactionCommit();
            return $row;
        } catch (\Throwable $error) { $this->db->transactionRollback(); throw $error; }
    }
}
