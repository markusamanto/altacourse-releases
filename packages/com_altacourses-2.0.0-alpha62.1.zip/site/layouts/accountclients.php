<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;
$view = $displayData['view'];
?>
<section aria-labelledby="altacourses-accountclients-heading">
    <h1 id="altacourses-accountclients-heading"><?php echo $view->escape(Text::_($view->account === null ? 'COM_ALTACOURSES_KEYACCOUNTS_TITLE' : 'COM_ALTACOURSES_ACCOUNTCLIENTS_TITLE')); ?></h1>
    <p><a href="<?php echo $view->escape(Route::_('index.php?option=com_altacourses&view=' . ($view->account === null ? 'dashboard' : 'accounts'), false)); ?>"><?php echo $view->escape(Text::_($view->account === null ? 'COM_ALTACOURSES_BACK_TO_DASHBOARD' : 'COM_ALTACOURSES_ACCOUNTCLIENTS_BACK')); ?></a></p>
    <?php if ($view->account !== null) : ?>
        <dl class="altacourses-account-summary" data-account-summary="<?php echo (int) $view->account->id; ?>">
            <?php foreach (\Advenire\Component\Altacourses\Site\Model\AccountsModel::TEXT_FIELDS as $field) : ?>
                <?php if (trim((string) $view->account->$field) === '') { continue; } ?>
                <dt><?php echo $view->escape(Text::_('COM_ALTACOURSES_ACCOUNT_' . strtoupper($field))); ?></dt>
                <dd><?php echo $view->escape((string) $view->account->$field); ?></dd>
            <?php endforeach; ?>
            <dt><?php echo $view->escape(Text::_('JSTATUS')); ?></dt>
            <dd><?php echo $view->escape(Text::_(match ((string) $view->account->state) { '1' => 'JPUBLISHED', '0' => 'JUNPUBLISHED', default => 'COM_ALTACOURSES_ACCOUNT_OTHER_STATE' })); ?></dd>
        </dl>
    <?php endif; ?>
    <p><?php echo $view->escape(Text::_('COM_ALTACOURSES_ACCOUNTCLIENTS_ORDER')); ?></p>
    <?php if (!$view->items) : ?>
        <p><?php echo $view->escape(Text::_('COM_ALTACOURSES_ACCOUNTCLIENTS_EMPTY')); ?></p>
    <?php else : ?>
        <div class="table-responsive"><table class="table table-striped" data-account-clients>
            <caption><?php echo $view->escape(Text::_('COM_ALTACOURSES_ACCOUNTCLIENTS_TITLE')); ?></caption>
            <thead><tr>
                <?php foreach (['COM_ALTACOURSES_ACCOUNTCLIENTS_LATEST', 'JGRID_HEADING_ID', 'COM_ALTACOURSES_ACCOUNT_NAME', 'COM_ALTACOURSES_ENQUIRY_ORGANISATION', 'COM_ALTACOURSES_ENQUIRY_EMAIL', 'COM_ALTACOURSES_ACCOUNT_LABEL', 'COM_ALTACOURSES_ACTIONS'] as $key) : ?>
                    <th scope="col"><?php echo $view->escape(Text::_($key)); ?></th>
                <?php endforeach; ?>
            </tr></thead><tbody>
                <?php foreach ($view->items as $client) : ?>
                    <tr data-client-id="<?php echo (int) $client->id; ?>">
                        <td><?php echo $view->escape($client->latest_activity ?? Text::_('COM_ALTACOURSES_ACCOUNTCLIENTS_NO_DATE')); ?></td>
                        <td><?php echo (int) $client->id; ?></td>
                        <th scope="row"><?php echo $view->escape(trim((string) $client->firstname . ' ' . (string) $client->lastname)); ?></th>
                        <td><?php echo $view->escape((string) $client->company); ?></td>
                        <td><?php echo $view->escape((string) $client->email); ?></td>
                        <td><?php echo $view->escape((string) $client->account_name); ?></td>
                        <td><a class="btn btn-success" data-account-client-view href="<?php echo $view->escape(Route::_('index.php?option=com_altacourses&view=client&id=' . (int) $client->id, false)); ?>"><?php echo $view->escape(Text::_('COM_ALTACOURSES_ACCOUNTCLIENTS_VIEW')); ?></a></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table></div>
        <?php echo $view->pagination->getListFooter(); ?>
    <?php endif; ?>
</section>
