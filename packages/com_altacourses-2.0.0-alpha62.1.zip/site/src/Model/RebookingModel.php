<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Model;
use Joomla\CMS\Language\Text;
use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareTrait;
use Joomla\Database\ParameterType;
\defined('_JEXEC') or die;

/** Two requests per rebooking; imported originals never require a submission snapshot. */
final class RebookingModel extends RequestrecordsModel implements CourseScheduleAwareInterface
{
    use ContactScopeTrait;
    use CourseScheduleAwareTrait;
    private string $reportingTimezone = 'UTC';
    private bool $participationContext = false;
    public function setParticipationContext(bool $value): void { $this->participationContext = $value; }
    public function setReportingTimezone(string $timezone): void { new \DateTimeZone($timezone); $this->reportingTimezone = $timezone; }
    public function today(): string { return (new \DateTimeImmutable('now', new \DateTimeZone($this->reportingTimezone)))->format('Y-m-d'); }
    public function revision(object $row): string { return hash('sha256', json_encode($row, JSON_THROW_ON_ERROR)); }
    private function fail(string $key = 'COM_ALTACOURSES_REBOOK_INVALID', int $code = 409): never { throw new \RuntimeException(Text::_($key), $code); }
    public function getRecord(int $id, bool $lock = false): object
    {
        $this->requireContactAccess();
        $db = $this->getDatabase();
        $q = $db->createQuery()->select('r.*')->from('#__altacourses_requests AS r')->where('r.id=:id')->bind(':id', $id, ParameterType::INTEGER);
        if ($lock) { $q->setQuery((string) $q . ' FOR UPDATE'); }
        $row = $db->setQuery($q)->loadObject();
        if (!$row) { $this->fail('JERROR_LAYOUT_PAGE_NOT_FOUND', 404); }
        $course = $this->course((int) $row->courseid, $lock);
        if (!$this->isContactAdministrator() && (!$course || ((!$this->participationContext && (int) $course->cr !== (int) $this->getActor()->id) || $this->receivingSupplier($row, $course) !== (int) $this->getActor()->id))) { $this->fail('JERROR_LAYOUT_PAGE_NOT_FOUND', 404); }
        if (!$course || !$course->start_date || str_starts_with($course->start_date, '0000-')
            || (!$this->participationContext && !$this->isContactAdministrator() && substr($course->start_date, 0, 10) <= $this->today())
            || ($this->participationContext && substr($course->start_date, 0, 10) > $this->today())
            || !in_array((int) $row->asked_for_info, [0,1], true) || (int) $row->rebooked === 2 || (int) $row->canceled !== 0 || (int) $row->participated !== 0
            || ($row->date_reported !== null && !str_starts_with($row->date_reported, '0000-')) || $row->commission_fee !== null
            || ((int) $row->checked_out !== 0 && (int) $row->checked_out !== (int) $this->getActor()->id)) { $this->fail(); }
        $client = $db->setQuery($db->createQuery()->select('id')->from('#__altacourses_clients')->where('id=' . (int) $row->clientid))->loadResult();
        if ($client === null) { $this->fail(); }
        // Old movement records must be restored deliberately, not silently mixed with this model.
        if ($db->setQuery('SELECT id FROM #__altacourses_request_rebookings WHERE request_id=' . $id . ' AND destination_request_id IS NULL')->loadResult() !== null) { $this->fail('COM_ALTACOURSES_REBOOK_RESTORE'); }
        return $row;
    }
    /** Native agreements retain their original recipient; imported rows use linked course ownership. */
    private function receivingSupplier(object $row, object $source): int
    {
        $owner = $this->getDatabase()->setQuery('SELECT supplier_user_id FROM #__altacourses_request_submissions WHERE request_id=' . (int) $row->id)->loadResult();
        if ($owner === null) {
            $owner = $this->getDatabase()->setQuery('SELECT supplier_user_id FROM #__altacourses_request_rebookings WHERE destination_request_id=' . (int) $row->id)->loadResult();
        }
        return $owner === null ? (int) $source->cr : (int) $owner;
    }
    private function course(int $id, bool $lock = false): ?object
    {
        $q = $this->getDatabase()->createQuery()->select('co.*')->from('#__altacourses_courses AS co')->where('co.id=' . $id);
        if ($lock) { $q->setQuery((string) $q . ' FOR UPDATE'); }
        return $this->getDatabase()->setQuery($q)->loadObject();
    }
    public function getOptions(int $id): array
    {
        $row = $this->getRecord($id); $source = $this->course((int) $row->courseid); $db = $this->getDatabase(); $owner = $this->receivingSupplier($row, $source);
        $items = $db->setQuery($db->createQuery()->select(['co.*', 'ct.name AS type_name', 'cp.name AS place_name'])
            ->from('#__altacourses_courses AS co')->join('INNER', '#__users AS u ON u.id=co.cr AND u.block=0')
            ->join('INNER', '#__altacourses_coursetypes AS ct ON ct.id=co.course_type')
            ->join('INNER', '#__altacourses_courseplaces AS cp ON cp.id=co.course_place')
            ->where('co.cr=' . $owner)->where('co.id<>' . (int) $row->courseid)
            ->where('co.state=1 AND co.nr_of_participants IN (1,3)')->where('DATE(co.start_date)>=' . $db->quote($this->today()))
            ->order('co.start_date,co.id'))->loadObjectList();
        $extras = $this->getCourseSchedule()->additionalSessions(array_column($items, 'id'));
        foreach ($items as $item) {
            $values = clone $item; unset($values->type_name, $values->place_name);
            $item->target_version = $this->revision($values);
            $item->sessions = array_merge([(object) ['start_date' => $item->start_date, 'stop_date' => $item->stop_date]], $extras[(int) $item->id] ?? []);
        }
        return $items;
    }
    public function getContext(int $id): array
    {
        $row = $this->getRecord($id); $db = $this->getDatabase();
        $person = $db->setQuery('SELECT firstname,lastname FROM #__altacourses_clients WHERE id=' . (int) $row->clientid)->loadObject();
        $course = $this->course((int) $row->courseid);
        return ['name' => trim($person->firstname . ' ' . $person->lastname), 'course_id' => (int) $course->id, 'start_date' => $course->start_date];
    }
    /** Source, target, client and outbox are locked inside a single transaction. */
    public function rebook(int $id, string $version, int $destination, string $targetVersion, string $note, bool $inTransaction = false, ?string $reportedAt = null): int
    {
        $this->requireContactAccess();
        if ($id <= 0 || $destination <= 0 || !preg_match('/^[a-f0-9]{64}$/D', $version) || !preg_match('/^[a-f0-9]{64}$/D', $targetVersion)
            || mb_strlen($note) > 4000 || preg_match('/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/', $note)) { $this->fail('COM_ALTACOURSES_REBOOK_INVALID', 400); }
        $db = $this->getDatabase(); if (!$inTransaction) { $db->transactionStart(); }
        try {
            // Require transactional tables: never pretend rollback protects an imported MyISAM table.
            foreach (['requests', 'clients', 'courses', 'request_rebookings', 'notification_outbox'] as $table) {
                $status = $db->setQuery('SHOW TABLE STATUS WHERE Name=' . $db->quote($db->replacePrefix('#__altacourses_' . $table)))->loadObject();
                if (!$status || strcasecmp($status->Engine, 'InnoDB') !== 0) { $this->fail('COM_ALTACOURSES_REBOOK_ENGINE'); }
            }
            $row = $this->getRecord($id, true);
            if (!hash_equals($this->revision($row), $version)) { $this->fail(); }
            $db->setQuery('SELECT id FROM #__altacourses_clients WHERE id=' . (int) $row->clientid . ' FOR UPDATE')->loadResult();
            $source = $this->course((int) $row->courseid, true); $target = $this->course($destination, true);
            $owner = $this->receivingSupplier($row, $source);
            $blocked = $db->setQuery('SELECT block FROM #__users WHERE id=' . $owner . ' FOR UPDATE')->loadResult();
            if (!$target || $destination === (int) $row->courseid || (int) $target->cr !== $owner || $blocked === null || (int) $blocked !== 0
                || (int) $target->state !== 1 || !in_array((int) $target->nr_of_participants, [1,3], true)
                || !$target->start_date || substr($target->start_date, 0, 10) < $this->today()
                || !hash_equals($this->revision($target), $targetVersion)) { $this->fail('COM_ALTACOURSES_REBOOK_CHANGED'); }
            $duplicate = $db->setQuery('SELECT id FROM #__altacourses_requests WHERE clientid=' . (int) $row->clientid . ' AND courseid=' . $destination . ' AND (canceled IS NULL OR canceled=0) FOR UPDATE')->loadResult();
            if ($duplicate !== null) { $this->fail('COM_ALTACOURSES_REBOOK_DUPLICATE'); }
            $states = $db->setQuery('SELECT o.state FROM #__altacourses_notification_outbox o INNER JOIN #__altacourses_request_submissions s ON s.id=o.submission_id WHERE s.request_id=' . $id . ' FOR UPDATE')->loadColumn();
            if (in_array('sending', $states, true)) { $this->fail('COM_ALTACOURSES_REBOOK_DELIVERY'); }
            $now = $reportedAt ?? (new \DateTimeImmutable('now', new \DateTimeZone('UTC')))->format('Y-m-d H:i:s'); $actor = (int) $this->getActor()->id;
            $new = (object) ['courseid' => $destination, 'clientid' => (int) $row->clientid, 'asked_for_info' => (int) $row->asked_for_info,
                'rebooked' => 1, 'participated' => 0, 'canceled' => 0, 'other_occasion' => 0, 'date_reported' => null,
                'date_created' => $now, 'created_by' => $actor, 'note' => $note];
            $db->insertObject('#__altacourses_requests', $new, 'id');
            $audit = (object) ['request_id' => $id, 'destination_request_id' => (int) $new->id, 'from_course_id' => (int) $row->courseid,
                'to_course_id' => $destination, 'from_json' => json_encode($source, JSON_THROW_ON_ERROR), 'to_json' => json_encode($target, JSON_THROW_ON_ERROR),
                'supplier_user_id' => $owner, 'created_at' => $now, 'created_by' => $actor, 'request_version' => (int) $row->participation_version,
                'previous_note' => (string) $row->note, 'note' => $note];
            $db->insertObject('#__altacourses_request_rebookings', $audit, 'id');
            $db->setQuery($db->createQuery()->update('#__altacourses_requests')->set('rebooked=2,canceled=1,participated=0')
                ->set("report_timezone='UTC'")->set('other_occasion=' . $destination)->set('date_reported=' . $db->quote($now))->set('reported_by=' . $actor)
                ->set('participation_version=participation_version+1')->where('id=' . $id))->execute();
            if (!$inTransaction) { $db->transactionCommit(); } return (int) $new->id;
        } catch (\Throwable $error) { if (!$inTransaction) { $db->transactionRollback(); } throw $error; }
    }
}
