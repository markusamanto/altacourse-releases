<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Model;

use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareTrait;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\CMS\MVC\Model\BaseModel;
use Joomla\Database\DatabaseAwareInterface;
use Joomla\Database\DatabaseAwareTrait;
use Joomla\Database\QueryInterface;

\defined('_JEXEC') or die;

/** Shared visibility rules for public listings and direct course URLs. */
abstract class PubliccourseModel extends BaseModel implements CourseScheduleAwareInterface, DatabaseAwareInterface
{
    use DatabaseAwareTrait;
    use CourseScheduleAwareTrait;

    public function __construct($config = [], ?MVCFactoryInterface $factory = null)
    {
        parent::__construct($config);
    }

    protected function publicQuery(): QueryInterface
    {
        $db = $this->getDatabase();
        $query = $db->createQuery()->from('#__altacourses_courses AS co')
            ->join('INNER', '#__altacourses_coursetypes AS ct ON ct.id = co.course_type')
            ->join('INNER', '#__altacourses_courseplaces AS cp ON cp.id = co.course_place')
            ->join('LEFT', '#__altacourses_regions AS re ON re.id = cp.region_id')
            ->join('LEFT', '#__altacourses_courseleaders AS l1 ON l1.id = co.course_leader_1')
            ->join('LEFT', '#__altacourses_courseleaders AS l2 ON l2.id = co.course_leader_2')
            ->join('LEFT', '#__altacourses_seats AS se ON se.seats = co.nr_of_participants')
            ->where('co.state = 1')->where('co.start_date >= CURRENT_TIMESTAMP')
            ->where('co.nr_of_participants NOT IN (2, 4)');
        return $query;
    }
}
