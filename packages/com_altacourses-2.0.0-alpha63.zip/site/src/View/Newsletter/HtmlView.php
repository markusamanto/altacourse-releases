<?php
namespace Advenire\Component\Altacourses\Site\View\Newsletter;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Language\Text;
\defined('_JEXEC') or die;
final class HtmlView extends BaseHtmlView
{
    public array $settings=[];
    public array $history=[];
    public function display($tpl=null):void
    {
        $m=$this->getModel();$this->settings=$m->settings();$this->history=$m->history();
        $this->getDocument()->setTitle(Text::_('COM_ALTACOURSES_NL_TITLE'));$this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.site');parent::display($tpl);
    }
}
