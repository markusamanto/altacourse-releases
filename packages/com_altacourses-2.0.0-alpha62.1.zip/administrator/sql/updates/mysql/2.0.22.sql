-- Conditional correction-column adoption and transactional/Unicode conversion are in script.php.
-- No response values are rewritten or published by this migration.
SELECT 1;
