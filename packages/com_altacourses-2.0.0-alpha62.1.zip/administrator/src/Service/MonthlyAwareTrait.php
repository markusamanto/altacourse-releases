<?php

/** @package Altacourses.Administrator @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Administrator\Service;

\defined('_JEXEC') or die;

trait MonthlyAwareTrait
{
    private ?MonthlyReport $monthlyReport = null;
    public function setMonthlyReport(MonthlyReport $report): void { $this->monthlyReport = $report; }
    protected function getMonthlyReport(): MonthlyReport
    {
        return $this->monthlyReport ?? throw new \LogicException('Monthly report service has not been injected');
    }
}
