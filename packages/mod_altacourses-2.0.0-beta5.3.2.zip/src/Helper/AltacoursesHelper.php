<?php
/** @package Altacourses.Module @license GNU General Public License version 2 or later */
namespace Advenire\Module\Altacourses\Site\Helper;
use Advenire\Component\Altacourses\Site\Helper\CourseArticle;
use Advenire\Component\Altacourses\Site\Helper\CourseTypes;
use Joomla\CMS\Application\SiteApplication;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Language\Text;
use Advenire\Component\Altacourses\Administrator\Service\PriceDisplay;
use Joomla\CMS\Router\Route;
use Joomla\Registry\Registry;
\defined('_JEXEC') or die;
final class AltacoursesHelper
{
    public function render(SiteApplication $app, Registry $params): ?array
    {
        if ($app->getDocument()->getType() !== 'html' || !ComponentHelper::isEnabled('com_altacourses')) { return null; }
        $file = JPATH_ADMINISTRATOR . '/components/com_altacourses/altacourses.xml';
        $manifest = is_file($file) ? simplexml_load_file($file) : false;
        if (!$manifest || (string) $manifest->namespace !== 'Advenire\\Component\\Altacourses' || version_compare((string) $manifest->version, '2.0.0-beta5.3.2', '<')) { return null; }
        $limit = $params->get('limit', 5);
        if (!is_scalar($limit) || !ctype_digit((string) $limit) || (float) $limit < 1 || (float) $limit > 100) { return null; }
        try { $types = CourseTypes::normalise($params->get('course_types', [])); }
        catch (\InvalidArgumentException) { return null; }
        $mvc = $app->bootComponent('com_altacourses')->getMVCFactory();
        $model = $mvc->createModel('Courses', 'Site', ['ignore_request' => true]);
        foreach (['types' => $types, 'type' => 0, 'regions' => [], 'region' => 0, 'from' => '', 'to' => ''] as $key => $value) {
            $model->setState('filter.' . $key, $value);
        }
        $model->setState('list.start', 0);
        $model->setState('list.limit', (int) $limit);
        $number = $model->getTotal();
        $rows = $model->getCompactItems();
        $articles = $model->getArticles(array_column($rows, 'place_article'), $app->getLanguage()->getTag());
        foreach ($rows as $row) {
            $id = (int) $row->id;
            $row->placeLink = CourseArticle::href($articles, $row->place_article, $id);
            $row->readMore = $row->placeLink ?? Route::_('index.php?option=com_altacourses&view=course&id=' . $id . '&coid=' . $id, false);
            $row->price = $row->amount === null ? '—' : $row->amount . ' ' . PriceDisplay::currency();
        }
        $listing = Route::_('index.php?' . http_build_query(['option' => 'com_altacourses', 'view' => 'courses'] + ($types ? ['types' => $types] : [])), false);
        return compact('rows', 'number', 'listing');
    }
}
