<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\View\Editclient;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
\defined('_JEXEC') or die;
final class HtmlView extends BaseHtmlView
{
    public ?\Joomla\CMS\Form\Form $form=null;
    public int $clientId=0;
    public int $returnStart=0;
    public array $returnFilters=[];
    public function display($tpl=null): void
    {
        $this->getModel()->requireAdministrator();
        $this->getDocument()->setTitle(Text::_('COM_ALTACOURSES_CLIENT_EDIT'));
        $this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.site');
        parent::display($tpl);
    }
}
