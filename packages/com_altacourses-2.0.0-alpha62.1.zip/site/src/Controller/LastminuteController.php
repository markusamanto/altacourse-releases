<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Controller;

use Advenire\Component\Altacourses\Site\Exception\CourseValidationException;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;

final class LastminuteController extends BaseController
{
    public function execute($task)
    {
        if (!in_array(strtolower((string) $task), ['save', 'delete'], true)) {
            throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'), 404);
        }
        return parent::execute($task);
    }

    public function delete(): void
    {
        $model = $this->getModel('Lastminutes', 'Site', ['ignore_request' => true]);
        $model->requireAdministrator();
        if ($this->input->getMethod() !== 'POST') {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_SAMPLE_POST_REQUIRED'), 405);
        }
        if (!$this->checkToken('post', false)) { throw new \RuntimeException(Text::_('JINVALID_TOKEN'), 403); }
        $raw = $this->input->post->get('jform', [], 'array');
        if (array_diff(array_keys($raw), ['id', 'version', 'confirm']) || !isset($raw['id'], $raw['version'], $raw['confirm'])
            || !is_string($raw['id']) || !ctype_digit($raw['id']) || (float) $raw['id'] > 4294967295
            || !is_string($raw['version']) || !preg_match('/^[a-f0-9]{64}$/D', $raw['version']) || $raw['confirm'] !== '1') {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_LASTMINUTE_INVALID'), 400);
        }
        $model->deleteLastminute((int) $raw['id'], $raw['version']);
        $this->setMessage(Text::_('COM_ALTACOURSES_LASTMINUTE_DELETED'));
        $this->setRedirect(Route::_('index.php?option=com_altacourses&view=lastminutes', false));
    }

    public function save(): void
    {
        $model = $this->getModel('Lastminutes', 'Site', ['ignore_request' => true]);
        $model->requireAdministrator();
        if ($this->input->getMethod() !== 'POST') {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_SAMPLE_POST_REQUIRED'), 405);
        }
        if (!$this->checkToken('post', false)) {
            throw new \RuntimeException(Text::_('JINVALID_TOKEN'), 403);
        }
        $raw = $this->input->post->get('jform', [], 'array');
        if (!isset($raw['id'], $raw['version']) || !is_string($raw['id']) || !ctype_digit($raw['id'])
            || (float) $raw['id'] > 4294967295 || !is_string($raw['version'])
            || ($raw['version'] !== '' && !preg_match('/^[a-f0-9]{64}$/D', $raw['version']))) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_LASTMINUTE_INVALID'), 400);
        }
        $id = (int) $raw['id'];
        $key = 'com_altacourses.lastminute.' . (int) $this->app->getIdentity()->id;
        $tickets = $this->app->getUserState($key . '.tickets', []);
        $ticket = $raw['ticket'] ?? '';
        if ($id === 0) {
            if (!is_string($ticket) || !isset($tickets[$ticket]) || $tickets[$ticket]['time'] < time() - 14400) {
                throw new \RuntimeException(Text::_('JINVALID_TOKEN'), 403);
            }
            if ($tickets[$ticket]['id'] > 0) {
                $this->setRedirect(Route::_('index.php?option=com_altacourses&view=lastminutes', false));
                return;
            }
        }
        $draft = array_intersect_key($raw, array_flip(['id', 'version', 'ticket', 'firstname', 'lastname', 'telephone', 'email', 'participated', 'notes']));
        foreach ($draft as $field => $value) {
            if (!is_string($value) || strlen($value) > 65535) { unset($draft[$field]); }
        }
        $this->app->setUserState($key . '.draft.' . $id, $draft);
        $version = $raw['version'];
        unset($raw['id'], $raw['version'], $raw['ticket']);
        try {
            $savedId = $model->saveLastminute($id, $version, $raw);
        } catch (CourseValidationException $exception) {
            foreach ($exception->messages as $message) { $this->app->enqueueMessage($message, 'warning'); }
            $this->setRedirect(Route::_('index.php?option=com_altacourses&view=lastminute&id=' . $id, false));
            return;
        } catch (\Throwable $exception) {
            if (in_array($exception->getCode(), [403, 404, 409], true)) { throw $exception; }
            $this->app->getLogger()->error('Altacourses last-minute save failed', ['exception' => $exception]);
            $this->setMessage(Text::_('COM_ALTACOURSES_LASTMINUTE_FAILED'), 'warning');
            $this->setRedirect(Route::_('index.php?option=com_altacourses&view=lastminute&id=' . $id, false));
            return;
        }
        if ($id === 0) {
            $tickets[$ticket]['id'] = $savedId;
            $this->app->setUserState($key . '.tickets', $tickets);
        }
        $this->app->setUserState($key . '.draft.' . $id, null);
        $this->setMessage(Text::_('COM_ALTACOURSES_LASTMINUTE_SAVED'));
        $this->setRedirect(Route::_('index.php?option=com_altacourses&view=lastminutes', false));
    }
}
