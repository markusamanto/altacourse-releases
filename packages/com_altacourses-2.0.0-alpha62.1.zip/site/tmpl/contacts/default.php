<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;
?>
<section aria-labelledby="altacourses-contacts-heading">
    <h1 id="altacourses-contacts-heading"><?php echo $this->escape(Text::_('COM_ALTACOURSES_CONTACTS_TITLE')); ?></h1>
    <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_CONTACTS_INTRO')); ?></p>
    <p><a href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=dashboard', false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_BACK_TO_DASHBOARD')); ?></a></p>
    <form action="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=contacts', false)); ?>" method="get">
        <input type="hidden" name="option" value="com_altacourses" /><input type="hidden" name="view" value="contacts" />
        <div class="row g-3 mb-3">
            <div class="col-md-5"><label for="contact-search"><?php echo $this->escape(Text::_('COM_ALTACOURSES_CONTACTS_SEARCH')); ?></label>
                <input id="contact-search" class="form-control" name="search" maxlength="120" value="<?php echo $this->escape($this->filters['search']); ?>" />
            </div>
            <div class="col-md-3"><label for="contact-kind"><?php echo $this->escape(Text::_('COM_ALTACOURSES_PARTICIPANT_KIND')); ?></label>
                <select id="contact-kind" class="form-select" name="kind">
                    <?php foreach (['all' => 'CONTACTS_ALL_KINDS', 'enquiry' => 'ENQUIRY_TITLE', 'signup' => 'SIGNUP_TITLE'] as $value => $label) : ?>
                        <option value="<?php echo $this->escape($value); ?>"<?php if ($value === $this->filters['kind']) : ?> selected<?php endif; ?>><?php echo $this->escape(Text::_('COM_ALTACOURSES_' . $label)); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4"><label for="contact-type"><?php echo $this->escape(Text::_('COM_ALTACOURSES_COURSE_TYPE')); ?></label>
                <select id="contact-type" class="form-select" name="type">
                    <option value=""><?php echo $this->escape(Text::_('COM_ALTACOURSES_CONTACTS_ALL_TYPES')); ?></option>
                    <?php foreach ($this->types as $value) : ?>
                        <?php if (!is_string($value) || $value === '') { continue; } ?>
                        <option value="<?php echo $this->escape($value); ?>"<?php if ($value === $this->filters['type']) : ?> selected<?php endif; ?>><?php echo $this->escape($value); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <button class="btn btn-primary" type="submit"><?php echo $this->escape(Text::_('COM_ALTACOURSES_CONTACTS_FILTER')); ?></button>
        <a class="btn btn-secondary" href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=contacts', false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_CONTACTS_RESET')); ?></a>
    </form>
    <p data-contact-total="<?php echo (int) $this->pagination->total; ?>"><?php echo $this->escape(Text::sprintf('COM_ALTACOURSES_CONTACTS_TOTAL', (int) $this->pagination->total)); ?></p>
    <?php if (!$this->items) : ?><p><?php echo $this->escape(Text::_('COM_ALTACOURSES_CONTACTS_EMPTY')); ?></p><?php else : ?>
        <div class="table-responsive"><table class="table table-striped"><thead><tr>
            <?php foreach (['SIGNUP_CREATED', 'ENQUIRY_NAME', 'ENQUIRY_ORGANISATION', 'PARTICIPANT_KIND', 'COURSE_TYPE', 'PLACE', 'DATES', 'SIGNUP_VIEW'] as $label) : ?>
                <th scope="col"><?php echo $this->escape(Text::_('COM_ALTACOURSES_' . $label)); ?></th>
            <?php endforeach; ?>
        </tr></thead><tbody>
        <?php foreach ($this->items as $item) : ?>
            <?php $contact = json_decode($item->contact_json, true, 512, JSON_THROW_ON_ERROR); $course = json_decode($item->course_json, true, 512, JSON_THROW_ON_ERROR); ?>
            <tr data-contact-request="<?php echo (int) $item->request_id; ?>">
                <td><?php echo $this->escape($item->created_at ?? Text::_('COM_ALTACOURSES_ACCOUNTCLIENTS_NO_DATE')); ?></td>
                <td><?php echo $this->escape(($contact['firstname'] ?? '') . ' ' . ($contact['lastname'] ?? '')); ?></td>
                <td><?php echo $this->escape($contact['company'] ?? ''); ?></td>
                <td><?php echo $this->escape(Text::_((int) $item->asked_for_info === 1 ? 'COM_ALTACOURSES_ENQUIRY_TITLE' : 'COM_ALTACOURSES_SIGNUP_TITLE')); ?></td>
                <td><?php echo $this->escape($course['course_type'] ?? ''); ?></td><td><?php echo $this->escape($course['course_place'] ?? ''); ?></td>
                <td><?php foreach ($course['sessions'] ?? [] as $part) : ?><div><?php echo $this->escape(substr($part['start_date'] ?? '', 0, 10) . ' – ' . substr($part['stop_date'] ?? '', 0, 10)); ?></div><?php endforeach; ?></td>
                <td><?php if ($item->linked_client_id !== null) : ?><a data-contact-view href="<?php echo $this->escape(Route::_('index.php?' . http_build_query(['option' => 'com_altacourses', 'view' => 'client', 'id' => (int) $item->clientid, 'return_start' => (int) $this->pagination->limitstart] + $this->filters), false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_SIGNUP_VIEW')); ?></a><?php else : ?><span><?php echo $this->escape(Text::_('COM_ALTACOURSES_CONTACTS_CLIENT_MISSING')); ?></span><?php endif; ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody></table></div><?php echo $this->pagination->getPagesLinks(); ?>
    <?php endif; ?>
</section>
