<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\View\Dashboard;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;

\defined('_JEXEC') or die;

final class HtmlView extends BaseHtmlView
{
    public bool $isCourseAdministrator = false;

    public string $displayName = '';

    public function display($tpl = null): void
    {
        $user = $this->getCurrentUser();
        $this->isCourseAdministrator = $user->authorise('altacourses.manage', 'com_altacourses');

        if ($user->guest || (!$this->isCourseAdministrator && !$user->authorise('altacourses.supplier', 'com_altacourses'))) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }

        $this->displayName = $user->name;
        $this->getDocument()->setTitle(Text::_($this->isCourseAdministrator ? 'COM_ALTACOURSES_PORTAL_ADMIN_TITLE' : 'COM_ALTACOURSES_PORTAL_SUPPLIER_TITLE'));
        $this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.site');

        parent::display($tpl);
    }
}
