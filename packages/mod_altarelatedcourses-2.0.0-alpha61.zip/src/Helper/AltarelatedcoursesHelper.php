<?php
/** @package Altacourses.Module @license GNU General Public License version 2 or later */
namespace Advenire\Module\Altarelatedcourses\Site\Helper;
use Advenire\Component\Altacourses\Site\Helper\CourseArticle;
use Joomla\CMS\Application\SiteApplication;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\Registry\Registry;
\defined('_JEXEC') or die;
final class AltarelatedcoursesHelper
{
    /** Context uses the actual guest-visible article/category, never a supplied catid or coid. */
    public function context(SiteApplication $app,Registry $params): ?array
    {
        $input=$app->getInput();
        $mode=$params->get('mode','leader');
        if (!in_array($mode,['leader','place'],true)||$input->getCmd('option')!=='com_content'||$input->getCmd('view')!=='article'
            ||$app->getDocument()->getType()!=='html'||!ComponentHelper::isEnabled('com_altacourses')) { return null; }
        $raw=$input->get('id','','raw');
        if (!is_scalar($raw)||!preg_match('/^([1-9][0-9]*)(?::[^\r\n]*)?$/D',(string)$raw,$match)||(float)$match[1]>2147483647) { return null; }
        $category=(int)ComponentHelper::getParams('com_altacourses')->get($mode==='leader'?'courseleadercategory':'courseplacecategory',0);
        if ($category<1||$category>2147483647) { return null; }
        $file=JPATH_ADMINISTRATOR.'/components/com_altacourses/altacourses.xml';$manifest=is_file($file)?simplexml_load_file($file):false;
        if (!$manifest||(string)$manifest->namespace!=='Advenire\\Component\\Altacourses'||version_compare((string)$manifest->version,'2.0.0-alpha61','<')) { return null; }
        $mvc=$app->bootComponent('com_altacourses')->getMVCFactory();$articles=$mvc->createModel('Courses','Site',['ignore_request'=>true])->getArticles([(int)$match[1]],$app->getLanguage()->getTag());
        $article=$articles[(int)$match[1]]??null;
        return $article!==null&&(int)$article->catid===$category?['articleId'=>(int)$article->id,'mode'=>$mode]:null;
    }
    public function courses(SiteApplication $app,array $context): array
    {
        $mvc=$app->bootComponent('com_altacourses')->getMVCFactory();$model=$mvc->createModel('Relatedcourses','Site',['ignore_request'=>true]);
        $rows=$context['mode']==='place'?$model->forPlaceArticle($context['articleId']):$model->forLeaderArticle($context['articleId']);
        $values=[];foreach($rows as $row){$values[]=$row->place_article;$values[]=$row->leader1_article;$values[]=$row->leader2_article;}
        $articles=$mvc->createModel('Courses','Site',['ignore_request'=>true])->getArticles($values,$app->getLanguage()->getTag());$signup=$mvc->createModel('Signup','Site',['ignore_request'=>true]);
        foreach($rows as $row){$id=(int)$row->id;$row->price=$row->amount===null?'—':$row->amount.' '.Text::_('MOD_ALTARELATEDCOURSES_CURRENCY');
            $row->placeLink=CourseArticle::href($articles,$row->place_article,$id);$row->leader1Link=CourseArticle::href($articles,$row->leader1_article,$id);$row->leader2Link=CourseArticle::href($articles,$row->leader2_article,$id);$row->signup=$signup->canEnquire($id)?Route::_('index.php?option=com_altacourses&view=signup&coid='.$id,false):null;
            $row->information=Route::_('index.php?option=com_altacourses&view=course&id='.$id,false);
        }
        return $rows;
    }
}
