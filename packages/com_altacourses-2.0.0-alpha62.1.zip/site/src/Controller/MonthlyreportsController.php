<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Controller;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;

final class MonthlyreportsController extends BaseController
{
    public function execute($task)
    {
        if (!in_array(strtolower((string) $task), ['send', 'retry', 'confirm', 'download'], true) || $this->app->getDocument()->getType() !== 'html') {
            throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'), 404);
        }
        $model = $this->getModel('Monthlyreports', 'Site', ['ignore_request' => true]);
        $model->requireAdministrator();
        if ($this->input->getMethod() !== 'POST') { throw new \RuntimeException(Text::_('COM_ALTACOURSES_AVAILABILITY_POST_REQUIRED'), 405); }
        if (!$this->checkToken('post', false)) { throw new \RuntimeException(Text::_('JINVALID_TOKEN'), 403); }
        $data = $this->input->post->get('jform', [], 'array');
        $allowed = strtolower($task) === 'send' ? ['month'] : (strtolower($task) === 'download' ? ['month', 'id'] : ['month', 'id', 'token', 'review']);
        if (count($data) !== count($allowed) || array_diff(array_keys($data), $allowed) || !is_string($data['month'] ?? null)) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_COMMISSION_INVALID'), 400);
        }
        $model->validateMonth($data['month']);
        if (isset($data['id']) && (!is_string($data['id']) || !ctype_digit($data['id']) || (float) $data['id'] > 2147483647 || (int) $data['id'] < 1)) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_COMMISSION_INVALID'), 400);
        }
        if (in_array(strtolower($task), ['retry', 'confirm'], true)
            && (($data['review'] ?? null) !== '1' || !is_string($data['token'] ?? null) || !preg_match('/^[a-f0-9]{64}$/D', $data['token']))) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_COMMISSION_INVALID'), 400);
        }
        try {
            if (strtolower($task) === 'send') {
                $result = $model->runPeriod($data['month']);
                $this->setMessage(Text::_('COM_ALTACOURSES_MONTHLY_RESULT_' . strtoupper($result)), $result === 'complete' ? 'message' : 'warning');
            } elseif (strtolower($task) === 'download') {
                $csv = $model->download($data['month'], (int) $data['id']);
                $this->app->allowCache(false);
                $this->app->setHeader('Cache-Control', 'private, no-store, no-cache, must-revalidate', true);
                $this->app->setHeader('Content-Type', 'text/csv; charset=UTF-8', true);
                $this->app->setHeader('Content-Disposition', 'attachment; filename="altacourses-' . $data['month'] . '.csv"', true);
                $this->app->setHeader('X-Content-Type-Options', 'nosniff', true);
                $this->app->sendHeaders(); echo $csv; $this->app->close(); return true;
            } else {
                $model->review($data['month'], (int) $data['id'], $data['token'], strtolower($task) === 'confirm');
                $this->setMessage(Text::_('COM_ALTACOURSES_MONTHLY_REVIEW_SAVED'));
            }
        } catch (\Throwable $error) {
            if (in_array($error->getCode(), [400, 403, 404, 409], true)) { throw $error; }
            $this->app->getLogger()->error('Altacourses monthly report failed; inspect private archive');
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_COMMISSION_FAILED'), 500);
        }
        $this->setRedirect(Route::_('index.php?option=com_altacourses&view=monthlyreports&month=' . rawurlencode($data['month']), false));
        return true;
    }
}
