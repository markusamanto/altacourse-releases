<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Controller;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;

final class ParticipationController extends BaseController
{
    public function execute($task)
    {
        if (!in_array(strtolower((string) $task), ['save', 'savecourse'], true)) { throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'), 404); }
        return parent::execute($task);
    }

    public function savecourse(): void
    {
        $model = $this->getModel('Participation', 'Site', ['ignore_request' => true]);
        $model->requireContactAccess();
        if ($this->input->getMethod() !== 'POST') { throw new \RuntimeException(Text::_('COM_ALTACOURSES_AVAILABILITY_POST_REQUIRED'), 405); }
        if (!$this->checkToken('post', false)) { throw new \RuntimeException(Text::_('JINVALID_TOKEN'), 403); }
        $data = $this->input->post->get('jform', [], 'array');
        if (count($data) !== 3 || array_diff(array_keys($data), ['course_id', 'course_version', 'reports'])
            || !is_array($data['reports'] ?? null) || !$data['reports'] || count($data['reports']) > 200) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_PARTICIPATION_INVALID'), 400);
        }
        foreach (['course_id', 'course_version'] as $key) { $data[$key] = $this->integer($data[$key]); }
        foreach ($data['reports'] as $id => &$report) {
            if (!is_int($id) || $id <= 0 || $id > 2147483647 || !is_array($report) || !in_array(count($report), [3,4], true)
                || array_diff(array_keys($report), ['version', 'status', 'note', 'rebook']) || !is_string($report['note'] ?? null)) {
                throw new \RuntimeException(Text::_('COM_ALTACOURSES_PARTICIPATION_INVALID'), 400);
            }
            if (isset($report['rebook']) && !is_string($report['rebook'])) { throw new \RuntimeException(Text::_('COM_ALTACOURSES_REBOOK_INVALID'), 400); }
            foreach (['version', 'status'] as $key) { $report[$key] = $this->integer($report[$key] ?? null); }
            if (!$model->getForm()->validate(['id' => $id] + $report)) {
                throw new \RuntimeException(Text::_('COM_ALTACOURSES_PARTICIPATION_INVALID'), 400);
            }
        }
        unset($report);
        try {
            $model->saveCourseReports($data['course_id'], $data['course_version'], $data['reports']);
        } catch (\RuntimeException $error) {
            if (in_array($error->getCode(), [400, 403, 404, 409], true)) { throw $error; }
            $this->app->getLogger()->error('Altacourses course participation update failed', ['exception' => $error]);
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_PARTICIPATION_FAILED'), 500);
        }
        $this->setMessage(Text::_('COM_ALTACOURSES_PARTICIPATION_SAVED'));
        $this->setRedirect(Route::_('index.php?option=com_altacourses&view=participations', false));
    }

    private function integer($value): int
    {
        if (!is_scalar($value) || !ctype_digit((string) $value) || (float) $value > 2147483647) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_PARTICIPATION_INVALID'), 400);
        }
        return (int) $value;
    }

    public function save(): void
    {
        $model = $this->getModel('Participation', 'Site', ['ignore_request' => true]);
        $model->requireContactAccess();
        if ($this->input->getMethod() !== 'POST') { throw new \RuntimeException(Text::_('COM_ALTACOURSES_AVAILABILITY_POST_REQUIRED'), 405); }
        if (!$this->checkToken('post', false)) { throw new \RuntimeException(Text::_('JINVALID_TOKEN'), 403); }
        $data = $this->input->post->get('jform', [], 'array');
        if (count($data) !== 4 || array_diff(array_keys($data), ['id', 'version', 'status', 'note']) || !is_string($data['note'] ?? null)) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_PARTICIPATION_INVALID'), 400);
        }
        foreach (['id', 'version', 'status'] as $key) {
            if (!is_scalar($data[$key]) || !ctype_digit((string) $data[$key]) || (float) $data[$key] > 2147483647) {
                throw new \RuntimeException(Text::_('COM_ALTACOURSES_PARTICIPATION_INVALID'), 400);
            }
            $data[$key] = (int) $data[$key];
        }
        try {
            if (!$model->getForm()->validate($data)) { throw new \RuntimeException(Text::_('COM_ALTACOURSES_PARTICIPATION_INVALID'), 400); }
            $model->saveReport($data['id'], $data['version'], $data['status'], $data['note']);
        } catch (\RuntimeException $error) {
            if (in_array($error->getCode(), [400, 403, 404, 409], true)) { throw $error; }
            $this->app->getLogger()->error('Altacourses participation update failed', ['exception' => $error]);
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_PARTICIPATION_FAILED'), 500);
        }
        $this->setMessage(Text::_('COM_ALTACOURSES_PARTICIPATION_SAVED'));
        $this->setRedirect(Route::_('index.php?option=com_altacourses&view=participation&id=' . $data['id'], false));
    }
}
