<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\View\Participation;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;

\defined('_JEXEC') or die;

final class HtmlView extends BaseHtmlView
{
    public ?object $item = null;
    public ?\Joomla\CMS\Form\Form $form = null;
    public array $contact = [];
    public array $course = [];
    public bool $started = false;
    public bool $batch = false;
    public ?object $occasion = null;
    public array $rows = [];
    public array $forms = [];

    public function display($tpl = null): void
    {
        $model = $this->getModel();
        $courseId = (int) $model->getState('course.id', 0);
        if ($courseId > 0) {
            $this->batch = true;
            $batch = $model->getCourseBatch($courseId);
            $this->occasion = $batch['course']; $this->rows = $batch['rows'];
            foreach ($this->rows as $row) {
                $this->forms[(int) $row->id] = $model->getForm(['id' => $row->id, 'version' => $row->participation_version,
                    'status' => 0, 'note' => $row->note], 'jform[reports][' . (int) $row->id . ']');
            }
            $this->getDocument()->setTitle(Text::_('COM_ALTACOURSES_PARTICIPATION_TITLE'));
            $this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.site');
            parent::display($tpl); return;
        }
        $this->item = $model->getRecord((int) $model->getState('request.id'));
        $this->contact = json_decode($this->item->contact_json, true, 512, JSON_THROW_ON_ERROR);
        $this->course = json_decode($this->item->course_json, true, 512, JSON_THROW_ON_ERROR);
        $this->started = $this->item->first_start && substr($this->item->first_start, 0, 10) <= $model->today();
        $status = (int) $this->item->participated === 1 ? 1 : ((int) $this->item->canceled === 1 ? 2 : 0);
        $this->form = $model->getForm(['id' => $this->item->id, 'version' => $this->item->participation_version, 'status' => $status, 'note' => $this->item->note]);
        if ($this->item->date_reported !== null) { $this->form->removeField('status');
            $this->form->setField(new \SimpleXMLElement('<field name="status" type="list" label="COM_ALTACOURSES_PARTICIPATION_STATUS" required="true"><option value="1">COM_ALTACOURSES_PARTICIPATION_YES</option><option value="2">COM_ALTACOURSES_PARTICIPATION_NO</option></field>'));
            $this->form->setValue('status', null, $status);
        }
        $this->getDocument()->setTitle(Text::_('COM_ALTACOURSES_PARTICIPATION_TITLE'));
        $this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.site');
        parent::display($tpl);
    }
}
