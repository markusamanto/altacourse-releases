-- Preserve existing evaluations verbatim; new installations use transactional Unicode storage.
CREATE TABLE IF NOT EXISTS `#__altacourses_evaluations` (
 `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
 `request_id` int NOT NULL,
 `rating_overall` tinyint(1) DEFAULT NULL,
 `rating_leaders` tinyint(1) DEFAULT NULL,
 `rating_place` tinyint(1) DEFAULT NULL,
 `review` text, `feedback` text, `response` text,
 `review_published` tinyint(1) DEFAULT NULL,
 `rating_date` datetime DEFAULT CURRENT_TIMESTAMP,
 `feedback_read` tinyint(1) NOT NULL DEFAULT 0,
 `rating_moderate_code` varchar(255) DEFAULT NULL,
 `ordering` int NOT NULL DEFAULT 0,
 `state` tinyint(1) NOT NULL DEFAULT 0,
 `checked_out` int NOT NULL DEFAULT 0,
 `checked_out_time` datetime DEFAULT NULL,
 `created_by` int DEFAULT NULL,
 PRIMARY KEY (`id`), KEY `idx_evaluation_request` (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Private delivery archive. No change to request outcomes, reporting dates or old mail.
CREATE TABLE IF NOT EXISTS `#__altacourses_evaluation_invitations` (
 `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
 `period` char(7) NOT NULL,
 `request_id` int UNSIGNED NOT NULL,
 `client_name` varchar(255) NOT NULL,
 `recipient` varchar(254) NOT NULL,
 `from_email` varchar(254) NOT NULL,
 `from_name` varchar(255) NOT NULL,
 `subject` varchar(255) NOT NULL,
 `body` mediumtext NOT NULL,
 `template_id` int UNSIGNED DEFAULT NULL,
 `message_id` varchar(255) NOT NULL,
 `token_hash` varchar(71) NOT NULL,
 `context_hash` char(64) NOT NULL,
 `payload_hash` char(64) NOT NULL,
 `state` varchar(16) NOT NULL DEFAULT 'pending',
 `attempts` int UNSIGNED NOT NULL DEFAULT 0,
 `attempt_token` char(64) DEFAULT NULL,
 `created_at` datetime NOT NULL,
 `claimed_at` datetime DEFAULT NULL,
 `sent_at` datetime DEFAULT NULL,
 `last_error` varchar(80) DEFAULT NULL,
 `reviewed_by` int DEFAULT NULL,
 `reviewed_at` datetime DEFAULT NULL,
 PRIMARY KEY (`id`),
 UNIQUE KEY `idx_evaluation_invitation_request` (`request_id`),
 KEY `idx_evaluation_invitation_state` (`state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
