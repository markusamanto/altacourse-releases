<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\View\Notifications;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;

\defined('_JEXEC') or die;

final class HtmlView extends BaseHtmlView
{
    public array $record = [];

    public function display($tpl = null): void
    {
        $this->record = $this->getModel()->getRecord((int) $this->getModel()->getState('request.id'));
        $this->getDocument()->setTitle(Text::_('COM_ALTACOURSES_NOTIFY_TITLE'));
        $this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.site');
        parent::display($tpl);
    }
}
