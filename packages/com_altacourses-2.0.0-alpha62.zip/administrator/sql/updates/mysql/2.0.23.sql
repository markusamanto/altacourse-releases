CREATE TABLE IF NOT EXISTS `#__altacourses_mailchimp_enrollments` (
 `id` int unsigned NOT NULL AUTO_INCREMENT,
 `audience_id` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `email_hash` char(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 `request_id` int NOT NULL,
 `client_id` int NOT NULL,
 `state` varchar(16) NOT NULL DEFAULT 'retry',
 `attempts` int unsigned NOT NULL DEFAULT 0,
 `revision` int unsigned NOT NULL DEFAULT 0,
 `http_status` smallint unsigned NOT NULL DEFAULT 0,
 `last_error` varchar(64) DEFAULT NULL,
 `next_attempt_at` datetime DEFAULT NULL,
 `created_at` datetime NOT NULL,
 `updated_at` datetime NOT NULL,
 PRIMARY KEY (`id`),
 UNIQUE KEY `audience_email` (`audience_id`,`email_hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
