<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;
?>
<section class="altacourses-portal" aria-labelledby="altacourses-suppliers-heading">
    <h1 id="altacourses-suppliers-heading"><?php echo $this->escape(Text::_('COM_ALTACOURSES_SUPPLIERS_TITLE')); ?></h1>
    <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_SUPPLIERS_HELP')); ?></p>
    <p><a href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=dashboard', false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_BACK_TO_DASHBOARD')); ?></a></p>
    <?php if (!$this->items) : ?><p><?php echo $this->escape(Text::_('COM_ALTACOURSES_SUPPLIERS_EMPTY')); ?></p><?php else : ?>
    <div class="table-responsive"><table class="table table-striped">
        <thead><tr><?php foreach (['COMPANY', 'ACCOUNT', 'EMAIL', 'TERMS', 'ACTION'] as $column) : ?><th scope="col"><?php echo $this->escape(Text::_('COM_ALTACOURSES_SUPPLIER_' . $column)); ?></th><?php endforeach; ?></tr></thead>
        <tbody><?php foreach ($this->items as $item) : ?>
            <tr data-supplier-user-id="<?php echo (int) $item->user_id; ?>">
                <td><?php echo $this->escape($item->company ?: Text::_('COM_ALTACOURSES_UNSPECIFIED')); ?></td>
                <td><?php echo $this->escape($item->name . ' (' . $item->username . ')'); ?><?php if ($item->block) : ?> — <?php echo $this->escape(Text::_('COM_ALTACOURSES_SUPPLIER_BLOCKED')); ?><?php endif; ?></td>
                <td><?php echo $this->escape($item->email); ?></td>
                <td><?php echo $this->escape(Text::_(trim($item->terms ?? '') === '' ? 'COM_ALTACOURSES_SUPPLIER_TERMS_MISSING' : 'COM_ALTACOURSES_SUPPLIER_TERMS_SAVED')); ?></td>
                <td><a href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=supplierprofile&user_id=' . (int) $item->user_id, false)); ?>"><?php echo $this->escape(Text::_($item->profile_id ? 'COM_ALTACOURSES_SUPPLIER_EDIT' : 'COM_ALTACOURSES_SUPPLIER_CREATE')); ?></a></td>
            </tr>
        <?php endforeach; ?></tbody>
    </table></div>
    <?php endif; ?>
</section>
