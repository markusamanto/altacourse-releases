<?php
/** @package Altacourses.Module @license GNU General Public License version 2 or later */
\defined('_JEXEC') or die;
use Joomla\CMS\Language\Text;
$escape=static fn($text)=>htmlspecialchars((string)$text,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');
?>
<div class="altaevaluations" data-altaevaluations="<?php echo (int)$module->id; ?>">
 <?php foreach($evaluations as $evaluation):$rating=(int)$evaluation->rating_overall;$year=substr((string)$evaluation->start_date,0,4); ?>
 <div class="card altaevaluations-review" data-evaluation-id="<?php echo (int)$evaluation->id; ?>"><div class="card-body">
  <div class="altaevaluations-stars" role="img" aria-label="<?php echo $escape(Text::sprintf('MOD_ALTAEVALUATIONS_STARS',$rating)); ?>">
   <?php for($star=1;$star<=5;$star++): ?><span aria-hidden="true" class="<?php echo $star<=$rating?'is-filled':'is-empty'; ?>"><?php echo $star<=$rating?'★':'☆'; ?></span><?php endfor; ?>
  </div>
  <p class="altaevaluations-text">&quot;<?php echo nl2br($escape($evaluation->review),false); ?>&quot;</p>
  <p class="altaevaluations-reviewer"><?php echo $escape(trim((string)$evaluation->firstname.' '.(string)$evaluation->lastname)); ?> (<?php echo $escape($year); ?>)</p>
 </div></div>
 <?php endforeach; ?>
 <?php if($readMore!==null): ?><p class="altaevaluations-more"><a data-evaluations-more href="<?php echo $escape($readMore); ?>"><?php echo $escape(Text::_('MOD_ALTAEVALUATIONS_READ_MORE_EVALUATIONS')); ?></a></p><?php endif; ?>
</div>
