<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
\defined('_JEXEC') or die;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
$message = $displayData['message'];
$escape = static fn($v) => htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
?>
<div data-mail-provenance>
 <p><?php echo $escape(Text::_('COM_ALTACOURSES_MAIL_PREPARED_MODE')); ?>: <strong><?php echo $escape(Text::_('COM_ALTACOURSES_MAIL_MODE_' . strtoupper($message->delivery_mode ?? 'legacy'))); ?></strong></p>
 <?php if (!empty($message->attempt_mode)) : ?><p><?php echo $escape(Text::_('COM_ALTACOURSES_MAIL_ATTEMPT_MODE')); ?>: <?php echo $escape(Text::_('COM_ALTACOURSES_MAIL_MODE_' . strtoupper($message->attempt_mode))); ?></p><?php endif; ?>
 <?php if (!empty($message->production_approved_at)) : ?><p><?php echo $escape(Text::_('COM_ALTACOURSES_MAIL_APPROVAL_AUDIT') . ' #' . $message->production_approved_by . ' / ' . $message->production_approved_at . ' UTC'); ?></p><?php endif; ?>
 <?php if (!empty($message->sequence_blocked)) : ?><p class="alert alert-warning" data-mail-sequence-blocked><?php echo $escape(Text::_('COM_ALTACOURSES_MAIL_SEQUENCE_BLOCKED')); ?></p><?php endif; ?>
 <?php if (!empty($message->mode_blocked)) : ?><p class="alert alert-warning" data-mail-mode-blocked><?php echo $escape(Text::_('COM_ALTACOURSES_MAIL_MODE_BLOCKED')); ?></p><?php endif; ?>
 <?php if (!empty($message->production_review) && $displayData['enabled']) : ?>
 <form method="post" action="<?php echo $escape(Route::_('index.php?option=com_altacourses&task=' . $displayData['task'] . '.approve', false)); ?>" data-production-approval>
  <?php foreach ($displayData['identity'] as $key => $value) : ?><input type="hidden" name="<?php echo $escape($key); ?>" value="<?php echo $escape($value); ?>"><?php endforeach; ?>
  <input type="hidden" name="<?php echo $displayData['task'] === 'notification' ? 'review_token' : 'jform[token]'; ?>" value="<?php echo $escape($message->approval_token); ?>">
  <label><input type="checkbox" required name="<?php echo $displayData['task'] === 'notification' ? 'reviewed' : 'jform[review]'; ?>" value="1"> <?php echo $escape(Text::_('COM_ALTACOURSES_MAIL_APPROVE_REVIEW')); ?></label>
  <?php echo HTMLHelper::_('form.token'); ?><button type="submit" class="btn btn-warning"><?php echo $escape(Text::_('COM_ALTACOURSES_MAIL_APPROVE_SEND')); ?></button>
 </form>
 <?php endif; ?>
</div>
