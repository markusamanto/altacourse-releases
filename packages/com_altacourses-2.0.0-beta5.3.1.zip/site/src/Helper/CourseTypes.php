<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Helper;
\defined('_JEXEC') or die;
/** Empty selection or explicit zero means All. Invalid values never broaden a selection. */
final class CourseTypes
{
    public static function normalise(mixed $values): array
    {
        if (!is_array($values) || count($values) > 100) { throw new \InvalidArgumentException('Invalid course types'); }
        $ids = [];
        foreach ($values as $value) {
            if (!is_scalar($value) || !ctype_digit((string) $value) || strlen((string) $value) > 10 || (float) $value > 2147483647) {
                throw new \InvalidArgumentException('Invalid course types');
            }
            $ids[] = (int) $value;
        }
        if (in_array(0, $ids, true)) { return []; }
        $ids = array_values(array_unique($ids));
        sort($ids, SORT_NUMERIC);
        return $ids;
    }
}
