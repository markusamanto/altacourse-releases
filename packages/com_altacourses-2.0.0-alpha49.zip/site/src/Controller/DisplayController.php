<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Controller;

use Joomla\CMS\Language\Text;
use Joomla\CMS\Event\PageCache\IsExcludedEvent;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;
use Joomla\CMS\MVC\View\ViewInterface;
use Joomla\CMS\Pagination\Pagination;

\defined('_JEXEC') or die;

final class DisplayController extends BaseController
{
    protected $default_view = 'dashboard';

    public function execute($task)
    {
        if (!in_array(strtolower((string) $task), ['', 'display'], true)) {
            throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'), 404);
        }

        return parent::execute($task);
    }

    public function display($cachable = false, $urlparams = [])
    {
        $viewName = $this->input->getCmd('view', 'dashboard');
        if (!in_array($viewName, ['dashboard', 'rebooking', 'client', 'formdata', 'accountclients', 'keyaccounts', 'accounts', 'account', 'mailtemplates', 'mailtemplate', 'alerts', 'alert', 'seats', 'seat', 'courseplaces', 'courseplace', 'courseleaders', 'courseleader', 'regions', 'region', 'coursetypes', 'coursetype', 'courses', 'managecourses', 'availability', 'assignment', 'newcourse', 'editcourse', 'course', 'suppliers', 'supplierprofile', 'readreceipt', 'enquiry', 'enquiryreceipt', 'enquiries', 'signup', 'signupreceipt', 'signups', 'participant', 'unreads', 'deliveries', 'notifications', 'contacts', 'contact', 'participations', 'participation', 'commissions', 'commissionrate', 'monthlyreports'], true)
            || $this->input->getCmd('layout', 'default') !== 'default'
            || $this->app->getDocument()->getType() !== 'html') {
            throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'), 404);
        }

        if (in_array($viewName, ['rebooking', 'client', 'formdata', 'accountclients', 'keyaccounts', 'accounts', 'account', 'mailtemplates', 'mailtemplate', 'alerts', 'alert', 'seats', 'seat', 'courseplaces', 'courseplace', 'courseleaders', 'courseleader', 'regions', 'region', 'coursetypes', 'coursetype', 'readreceipt', 'enquiry', 'enquiryreceipt', 'enquiries', 'signup', 'signupreceipt', 'signups', 'participant', 'unreads', 'deliveries', 'notifications', 'contacts', 'contact', 'participations', 'participation', 'commissions', 'commissionrate', 'monthlyreports'], true)) {
            $this->app->allowCache(false);
            $this->app->setHeader('Cache-Control', 'private, no-store, no-cache, must-revalidate', true);
            $this->app->getDispatcher()->addListener('onPageCacheIsExcluded', static function (IsExcludedEvent $event): void {
                $event->addResult(true);
            });
        }
        if (in_array($viewName, ['courses', 'course', 'readreceipt', 'enquiry', 'enquiryreceipt', 'signup', 'signupreceipt'], true)) {
            return parent::display(false, []);
        }

        $user = $this->app->getIdentity();

        if ($user->guest) {
            $return = 'index.php?option=com_altacourses&view=' . $viewName;
            if (in_array($viewName, ['rebooking', 'client', 'formdata', 'accountclients', 'account', 'mailtemplate', 'alert', 'seat', 'courseplace', 'courseleader', 'region', 'coursetype', 'availability', 'assignment', 'editcourse', 'participant', 'notifications', 'contact', 'participation'], true)) {
                if ($viewName === 'participation' && $this->input->get('course_id', null, 'raw') !== null) {
                    $return .= '&course_id=' . $this->readInteger('course_id');
                } else { $return .= '&id=' . $this->readInteger('id'); }
            }
            if (in_array($viewName, ['commissions', 'commissionrate', 'monthlyreports'], true)) {
                $month = $this->input->get('month', '', 'raw');
                if (!is_string($month) || ($month !== '' && !preg_match('/^\d{4}-(?:0[1-9]|1[0-2])$/D', $month))) { throw new \RuntimeException(Text::_('COM_ALTACOURSES_COMMISSION_INVALID'), 400); }
                if ($month !== '') { $return .= '&month=' . rawurlencode($month); }
                if ($viewName === 'commissionrate') { $return .= '&user_id=' . $this->readInteger('user_id'); }
            }
            if ($viewName === 'supplierprofile' && $this->input->get('user_id', null, 'raw') !== null) {
                $return .= '&user_id=' . $this->readInteger('user_id');
            }
            if (in_array($viewName, ['participant', 'contact', 'client', 'formdata'], true)) { $return .= '&return_start=' . $this->readInteger('return_start'); }
            if (in_array($viewName, ['contacts', 'contact', 'participant', 'client', 'formdata'], true)) {
                $contactFilters = $this->readContactFilters();
                $return .= '&' . http_build_query($contactFilters);
            }
            $itemId = $this->input->getInt('Itemid');

            if ($itemId > 0) {
                $return .= '&Itemid=' . $itemId;
            }

            // Joomla validates index.php-relative returns; format the SEF URL after login.
            // Never accept a return URL supplied by the visitor.
            $this->setRedirect(Route::_('index.php?option=com_users&view=login&return=' . rawurlencode(base64_encode($return)), false));

            return $this;
        }

        if (!$user->authorise('altacourses.manage', 'com_altacourses')
            && !$user->authorise('altacourses.supplier', 'com_altacourses')) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }

        if (in_array($viewName, ['signups', 'enquiries'], true)) {
            $this->getModel('Contacts', 'Site', ['ignore_request' => true])->requireAdministrator();
            $filters = $this->readContactFilters();
            $filters['kind'] = $viewName === 'signups' ? 'signup' : 'enquiry';
            $this->setRedirect(Route::_('index.php?' . http_build_query(['option' => 'com_altacourses', 'view' => 'contacts', 'limitstart' => $this->readInteger('limitstart')] + $filters), false));
            return $this;
        }
        if (in_array($viewName, ['contact', 'participant'], true)) {
            $model = $this->getModel('Formdata', 'Site', ['ignore_request' => true]);
            if ($viewName === 'participant') { $model->requireAdministrator(); }
            $record = $model->getRecord($this->readInteger('id'));
            $this->setRedirect(Route::_('index.php?' . http_build_query(['option' => 'com_altacourses', 'view' => 'client', 'id' => (int) $record->clientid, 'return_start' => $this->readInteger('return_start')] + $this->readContactFilters()), false));
            return $this;
        }

        if ($viewName === 'assignment') {
            if (!$user->authorise('altacourses.manage', 'com_altacourses')) {
                throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
            }
            $this->setRedirect(Route::_('index.php?option=com_altacourses&view=editcourse&id=' . $this->readInteger('id'), false));
            return $this;
        }

        // Never cache a page whose content depends on the current user's role.
        return parent::display(false, []);
    }

    protected function prepareViewModel(ViewInterface $view)
    {
        if ($view->getName() === 'readreceipt') {
            parent::prepareViewModel($view);
            return;
        }
        if ($view->getName() === 'rebooking') {
            $model = $this->getModel('Rebooking', 'Site', ['ignore_request' => true]);
            $model->setState('request.id', $this->readInteger('id'));
            $model->requireContactAccess(); $view->setModel($model, true); return;
        }
        if (in_array($view->getName(), ['courseplaces', 'courseplace'], true)) {
            $model = $this->getModel('Courseplaces', 'Site', ['ignore_request' => true]);
            $model->setArticleCategory((int) $this->app->getParams('com_altacourses')->get('courseplacecategory', 0));
            $model->requireAdministrator();
            $view->setModel($model, true);
            if ($view->getName() === 'courseplaces') { return; }
            $id = $this->readInteger('id');
            $original = $model->formData($model->getRecord($id));
            $key = 'com_altacourses.courseplace.' . (int) $this->app->getIdentity()->id;
            if ($this->input->getBool('fresh')) { $this->app->setUserState($key . '.draft.' . $id, null); }
            $draft = $this->app->getUserState($key . '.draft.' . $id, []) ?: [];
            if ($id > 0 && isset($draft['version']) && $draft['version'] !== $original['version']) {
                $this->app->enqueueMessage(Text::_('COM_ALTACOURSES_COURSEPLACE_CONFLICT'), 'warning');
            }
            $data = $draft + $original;
            if ($id === 0) {
                $tickets = array_filter($this->app->getUserState($key . '.tickets', []), static fn ($ticket): bool => $ticket['time'] >= time() - 14400);
                if (!isset($data['ticket'], $tickets[$data['ticket']]) || $tickets[$data['ticket']]['id'] > 0) {
                    $data['ticket'] = bin2hex(random_bytes(32));
                    $tickets = array_slice($tickets, -19, null, true);
                    $tickets[$data['ticket']] = ['time' => time(), 'id' => 0];
                }
                $this->app->setUserState($key . '.tickets', $tickets);
            }
            $view->courseplaceId = $id;
            $view->form = $model->getForm($data);
            return;
        }
        if (in_array($view->getName(), ['courseleaders', 'courseleader'], true)) {
            $model = $this->getModel('Courseleaders', 'Site', ['ignore_request' => true]);
            $model->setArticleCategory((int) $this->app->getParams('com_altacourses')->get('courseleadercategory', 0));
            $model->requireAdministrator();
            $view->setModel($model, true);
            if ($view->getName() === 'courseleaders') { return; }
            $id = $this->readInteger('id');
            $original = $model->formData($model->getRecord($id));
            $key = 'com_altacourses.courseleader.' . (int) $this->app->getIdentity()->id;
            if ($this->input->getBool('fresh')) { $this->app->setUserState($key . '.draft.' . $id, null); }
            $draft = $this->app->getUserState($key . '.draft.' . $id, []) ?: [];
            if ($id > 0 && isset($draft['version']) && $draft['version'] !== $original['version']) {
                $this->app->enqueueMessage(Text::_('COM_ALTACOURSES_COURSELEADER_CONFLICT'), 'warning');
            }
            $data = $draft + $original;
            if ($id === 0) {
                $tickets = array_filter($this->app->getUserState($key . '.tickets', []), static fn ($ticket): bool => $ticket['time'] >= time() - 14400);
                if (!isset($data['ticket'], $tickets[$data['ticket']]) || $tickets[$data['ticket']]['id'] > 0) {
                    $data['ticket'] = bin2hex(random_bytes(32));
                    $tickets = array_slice($tickets, -19, null, true);
                    $tickets[$data['ticket']] = ['time' => time(), 'id' => 0];
                }
                $this->app->setUserState($key . '.tickets', $tickets);
            }
            $view->courseleaderId = $id;
            $view->form = $model->getForm($data);
            return;
        }
        if (in_array($view->getName(), ['seats', 'seat'], true)) {
            $model = $this->getModel('Seats', 'Site', ['ignore_request' => true]);
            $model->requireAdministrator();
            $view->setModel($model, true);
            if ($view->getName() === 'seats') { return; }
            $id = $this->readInteger('id');
            $original = $model->formData($model->getRecord($id));
            $key = 'com_altacourses.seat.' . (int) $this->app->getIdentity()->id;
            if ($this->input->getBool('fresh')) { $this->app->setUserState($key . '.draft.' . $id, null); }
            $draft = $this->app->getUserState($key . '.draft.' . $id, []) ?: [];
            if ($id > 0 && isset($draft['version']) && $draft['version'] !== $original['version']) {
                $this->app->enqueueMessage(Text::_('COM_ALTACOURSES_SEAT_CONFLICT'), 'warning');
            }
            $data = $draft + $original;
            if ($id === 0) {
                $tickets = array_filter($this->app->getUserState($key . '.tickets', []), static fn ($ticket): bool => $ticket['time'] >= time() - 14400);
                if (!isset($data['ticket'], $tickets[$data['ticket']]) || $tickets[$data['ticket']]['id'] > 0) {
                    $data['ticket'] = bin2hex(random_bytes(32));
                    $tickets = array_slice($tickets, -19, null, true);
                    $tickets[$data['ticket']] = ['time' => time(), 'id' => 0];
                }
                $this->app->setUserState($key . '.tickets', $tickets);
            }
            $view->seatId = $id;
            $view->form = $model->getForm($data);
            return;
        }
        if (in_array($view->getName(), ['mailtemplates', 'mailtemplate'], true)) {
            $model = $this->getModel('Mailtemplates', 'Site', ['ignore_request' => true]);
            $model->requireAdministrator();
            $view->setModel($model, true);
            if ($view->getName() === 'mailtemplates') {
                $raw = $this->input->get('course_type', '', 'raw');
                if (!is_string($raw) || ($raw !== '' && (!ctype_digit($raw) || (float) $raw > 2147483647))) {
                    throw new \RuntimeException(Text::_('COM_ALTACOURSES_MAILTEMPLATE_INVALID'), 400);
                }
                $view->filterCourseType = $raw === '' ? null : (int) $raw;
                return;
            }
            $id = $this->readInteger('id');
            $original = $model->formData($model->getRecord($id));
            $key = 'com_altacourses.mailtemplate.' . (int) $this->app->getIdentity()->id;
            if ($this->input->getBool('fresh')) { $this->app->setUserState($key . '.draft.' . $id, null); }
            $draft = $this->app->getUserState($key . '.draft.' . $id, []) ?: [];
            if ($id > 0 && isset($draft['version']) && $draft['version'] !== $original['version']) {
                $this->app->enqueueMessage(Text::_('COM_ALTACOURSES_MAILTEMPLATE_CONFLICT'), 'warning');
            }
            $data = $draft + $original;
            if ($id === 0) {
                $tickets = array_filter($this->app->getUserState($key . '.tickets', []), static fn ($ticket): bool => $ticket['time'] >= time() - 14400);
                if (!isset($data['ticket'], $tickets[$data['ticket']]) || $tickets[$data['ticket']]['id'] > 0) {
                    $data['ticket'] = bin2hex(random_bytes(32));
                    $tickets = array_slice($tickets, -19, null, true);
                    $tickets[$data['ticket']] = ['time' => time(), 'id' => 0];
                }
                $this->app->setUserState($key . '.tickets', $tickets);
            }
            $view->mailtemplateId = $id;
            $view->form = $model->getForm($data);
            return;
        }
        if (in_array($view->getName(), ['accountclients', 'keyaccounts'], true)) {
            $model = $this->getModel('Accountclients', 'Site', ['ignore_request' => true]);
            $model->requireAdministrator();
            $parameters = ['option' => 'com_altacourses', 'view' => $view->getName()];
            if ($view->getName() === 'accountclients') {
                $id = $this->readInteger('id');
                $model->getAccountRecord($id);
                $model->setState('account.id', $id);
                $parameters['id'] = $id;
            }
            $view->pagination = new Pagination($model->getTotal(), $this->readInteger('limitstart'), 20, '', $this->app);
            foreach ($parameters as $key => $value) { $view->pagination->setAdditionalUrlParam($key, $value); }
            $model->setState('list.start', $view->pagination->limitstart);
            $view->setModel($model, true);
            return;
        }
        if (in_array($view->getName(), ['accounts', 'account'], true)) {
            $model = $this->getModel('Accounts', 'Site', ['ignore_request' => true]);
            $model->requireAdministrator();
            $view->setModel($model, true);
            if ($view->getName() === 'accounts') { return; }
            $id = $this->readInteger('id');
            $original = $model->formData($model->getRecord($id));
            $key = 'com_altacourses.account.' . (int) $this->app->getIdentity()->id;
            if ($this->input->getBool('fresh')) { $this->app->setUserState($key . '.draft.' . $id, null); }
            $draft = $this->app->getUserState($key . '.draft.' . $id, []) ?: [];
            if ($id > 0 && isset($draft['version']) && $draft['version'] !== $original['version']) {
                $this->app->enqueueMessage(Text::_('COM_ALTACOURSES_ACCOUNT_CONFLICT'), 'warning');
            }
            $data = $draft + $original;
            if ($id === 0) {
                $tickets = array_filter($this->app->getUserState($key . '.tickets', []), static fn ($ticket): bool => $ticket['time'] >= time() - 14400);
                if (!isset($data['ticket'], $tickets[$data['ticket']]) || $tickets[$data['ticket']]['id'] > 0) {
                    $data['ticket'] = bin2hex(random_bytes(32));
                    $tickets = array_slice($tickets, -19, null, true);
                    $tickets[$data['ticket']] = ['time' => time(), 'id' => 0];
                }
                $this->app->setUserState($key . '.tickets', $tickets);
            }
            $view->accountId = $id;
            $view->form = $model->getForm($data);
            return;
        }
        if (in_array($view->getName(), ['alerts', 'alert'], true)) {
            $model = $this->getModel('Alerts', 'Site', ['ignore_request' => true]);
            $model->requireAdministrator();
            $view->setModel($model, true);
            if ($view->getName() === 'alerts') { return; }
            $id = $this->readInteger('id');
            $original = $model->formData($model->getRecord($id));
            $key = 'com_altacourses.alert.' . (int) $this->app->getIdentity()->id;
            if ($this->input->getBool('fresh')) { $this->app->setUserState($key . '.draft.' . $id, null); }
            $draft = $this->app->getUserState($key . '.draft.' . $id, []) ?: [];
            if ($id > 0 && isset($draft['version']) && $draft['version'] !== $original['version']) {
                $this->app->enqueueMessage(Text::_('COM_ALTACOURSES_ALERT_CONFLICT'), 'warning');
            }
            $data = $draft + $original;
            if ($id === 0) {
                $tickets = array_filter($this->app->getUserState($key . '.tickets', []), static fn ($ticket): bool => $ticket['time'] >= time() - 14400);
                if (!isset($data['ticket'], $tickets[$data['ticket']]) || $tickets[$data['ticket']]['id'] > 0) {
                    $data['ticket'] = bin2hex(random_bytes(32));
                    $tickets = array_slice($tickets, -19, null, true);
                    $tickets[$data['ticket']] = ['time' => time(), 'id' => 0];
                }
                $this->app->setUserState($key . '.tickets', $tickets);
            }
            $view->alertId = $id;
            $view->form = $model->getForm($data);
            return;
        }
        if (in_array($view->getName(), ['regions', 'region'], true)) {
            $model = $this->getModel('Regions', 'Site', ['ignore_request' => true]);
            $model->requireAdministrator();
            $view->setModel($model, true);
            if ($view->getName() === 'regions') { return; }
            $id = $this->readInteger('id');
            $original = $model->formData($model->getRecord($id));
            $key = 'com_altacourses.region.' . (int) $this->app->getIdentity()->id;
            if ($this->input->getBool('fresh')) { $this->app->setUserState($key . '.draft.' . $id, null); }
            $draft = $this->app->getUserState($key . '.draft.' . $id, []) ?: [];
            if ($id > 0 && isset($draft['version']) && $draft['version'] !== $original['version']) {
                $this->app->enqueueMessage(Text::_('COM_ALTACOURSES_REGION_CONFLICT'), 'warning');
            }
            $data = $draft + $original;
            if ($id === 0) {
                $tickets = array_filter($this->app->getUserState($key . '.tickets', []), static fn ($ticket): bool => $ticket['time'] >= time() - 14400);
                if (!isset($data['ticket'], $tickets[$data['ticket']]) || $tickets[$data['ticket']]['id'] > 0) {
                    $data['ticket'] = bin2hex(random_bytes(32));
                    $tickets = array_slice($tickets, -19, null, true);
                    $tickets[$data['ticket']] = ['time' => time(), 'id' => 0];
                }
                $this->app->setUserState($key . '.tickets', $tickets);
            }
            $view->regionId = $id;
            $view->form = $model->getForm($data);
            return;
        }
        if (in_array($view->getName(), ['coursetypes', 'coursetype'], true)) {
            $model = $this->getModel('Coursetypes', 'Site', ['ignore_request' => true]);
            $model->requireAdministrator();
            $view->setModel($model, true);
            if ($view->getName() === 'coursetypes') { return; }
            $id = $this->readInteger('id');
            $original = $model->formData($model->getRecord($id));
            $key = 'com_altacourses.coursetype.' . (int) $this->app->getIdentity()->id;
            if ($this->input->getBool('fresh')) { $this->app->setUserState($key . '.draft.' . $id, null); }
            $draft = $this->app->getUserState($key . '.draft.' . $id, []) ?: [];
            if ($id > 0 && isset($draft['version']) && $draft['version'] !== $original['version']) {
                $this->app->enqueueMessage(Text::_('COM_ALTACOURSES_COURSETYPE_CONFLICT'), 'warning');
            }
            $data = $draft + $original;
            if ($id === 0) {
                $tickets = array_filter($this->app->getUserState($key . '.tickets', []), static fn ($ticket): bool => $ticket['time'] >= time() - 14400);
                if (!isset($data['ticket'], $tickets[$data['ticket']]) || $tickets[$data['ticket']]['id'] > 0) {
                    $data['ticket'] = bin2hex(random_bytes(32));
                    $tickets = array_slice($tickets, -19, null, true);
                    $tickets[$data['ticket']] = ['time' => time(), 'id' => 0];
                }
                $this->app->setUserState($key . '.tickets', $tickets);
            }
            $view->courseTypeId = $id;
            $view->form = $model->getForm($data);
            return;
        }
        if (in_array($view->getName(), ['enquiryreceipt', 'signupreceipt'], true)) {
            $mode = $view->getName() === 'signupreceipt' ? 'signup' : 'enquiry';
            $id = $this->readInteger('coid');
            $receipt = $this->app->getUserState('com_altacourses.' . $mode . '.' . $id . '.receipt', []);
            if (!$id || ($receipt['course_id'] ?? 0) !== $id || empty($receipt['request_id'])) { throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'), 404); }
            $view->courseId = $id;
            return;
        }
        if (in_array($view->getName(), ['enquiry', 'signup'], true)) {
            $mode = $view->getName();
            $id = $this->readInteger('coid');
            $model = $this->getModel(ucfirst($mode), 'Site', ['ignore_request' => true]);
            $course = $model->getCourse($id);
            $key = 'com_altacourses.' . $mode . '.' . $id;
            $data = $this->app->getUserState($key . '.draft', []) ?: [];
            $tickets = array_filter($this->app->getUserState('com_altacourses.' . $mode . '.tickets', []), static fn ($ticket): bool => $ticket['time'] >= time() - 14400);
            $ticket = isset($data['submission']) ? ($tickets[$data['submission']] ?? null) : null;
            $agreement = $mode === 'signup' ? $model->fingerprint($course) : null;
            if ($ticket === null || $ticket['course_id'] !== $id || $ticket['revision'] !== (int) $course->availability_version
                || ($ticket['agreement'] ?? null) !== $agreement) {
                if ($ticket !== null) { $this->app->enqueueMessage(Text::_($mode === 'signup' ? 'COM_ALTACOURSES_SIGNUP_CONFLICT' : 'COM_ALTACOURSES_ENQUIRY_CONFLICT'), 'warning'); }
                if ($mode === 'signup') { unset($data['accept_terms']); }
                $data['submission'] = bin2hex(random_bytes(32));
                $tickets = array_slice($tickets, -19, null, true);
                $tickets[$data['submission']] = ['time' => time(), 'course_id' => $id, 'revision' => (int) $course->availability_version, 'agreement' => $agreement];
            }
            $data['coid'] = $id;
            $this->app->setUserState('com_altacourses.' . $mode . '.tickets', $tickets);
            $view->summary = $model->summary($course);
            if ($mode === 'signup') {
                $view->terms = $course->supplier_terms;
                $view->totalPrice = $model->agreement($course)['total_price'];
            }
            $view->form = $model->getForm($data);
            $view->setModel($model, true);
            return;
        }
        if (in_array($view->getName(), ['commissions', 'commissionrate', 'monthlyreports'], true)) {
            $model = $this->getModel($view->getName() === 'monthlyreports' ? 'Monthlyreports' : 'Commissions', 'Site', ['ignore_request' => true]);
            $model->requireAdministrator();
            $month = $this->input->get('month', $model->previousMonth(), 'raw');
            if (!is_string($month)) { throw new \RuntimeException(Text::_('COM_ALTACOURSES_COMMISSION_INVALID'), 400); }
            $model->validateMonth($month);
            $view->month = $month;
            if ($view->getName() === 'commissionrate') { $view->supplierId = $this->readInteger('user_id'); }
            $view->setModel($model, true);
            return;
        }
        if ($view->getName() === 'notifications') {
            $model = $this->getModel('Notifications', 'Site', ['ignore_request' => true]);
            $model->requireAdministrator();
            $model->setState('request.id', $this->readInteger('id'));
            $view->setModel($model, true);
            return;
        }
        if (in_array($view->getName(), ['participations', 'participation'], true)) {
            $model = $this->getModel('Participation', 'Site', ['ignore_request' => true]);
            $model->requireContactAccess();
            if ($view->getName() === 'participation') {
                if ($this->input->get('course_id', null, 'raw') !== null) {
                    if ($this->input->get('id', null, 'raw') !== null) { throw new \RuntimeException(Text::_('COM_ALTACOURSES_PARTICIPATION_INVALID'), 400); }
                    $model->setState('course.id', $this->readInteger('course_id'));
                } else { $model->setState('request.id', $this->readInteger('id')); }
            } else {
                $view->pagination = new Pagination($model->getTotal(), $this->readInteger('limitstart'), 20, '', $this->app);
                foreach (['option' => 'com_altacourses', 'view' => 'participations'] as $key => $value) {
                    $view->pagination->setAdditionalUrlParam($key, $value);
                }
                $model->setState('list.start', $view->pagination->limitstart);
            }
            $view->setModel($model, true);
            return;
        }
        if (in_array($view->getName(), ['client', 'formdata'], true)) {
            $model = $this->getModel(ucfirst($view->getName()), 'Site', ['ignore_request' => true]);
            $model->requireContactAccess();
            $model->setState($view->getName() === 'client' ? 'client.id' : 'request.id', $this->readInteger('id'));
            $view->returnStart = $this->readInteger('return_start');
            $view->returnFilters = $this->readContactFilters();
            if ($view->getName() === 'client') { $view->setModel($this->getModel('Accounts', 'Site', ['ignore_request' => true])); $view->setModel($this->getModel('Rebooking', 'Site', ['ignore_request' => true])); }
            $view->setModel($model, true);
            return;
        }
        if ($view->getName() === 'contacts') {
            $model = $this->getModel('Contacts', 'Site', ['ignore_request' => true]);
            $model->requireContactAccess();
            $filters = $this->readContactFilters();
            foreach ($filters as $key => $value) { $model->setState('filter.' . $key, $value); }
            $pagination = new Pagination($model->getTotal(), $this->readInteger('limitstart'), 20, '', $this->app);
            foreach (['option' => 'com_altacourses', 'view' => 'contacts'] + $filters as $key => $value) { $pagination->setAdditionalUrlParam($key, $value); }
            $model->setState('list.start', $pagination->limitstart);
            $view->filters = $filters;
            $view->pagination = $pagination;
            $view->setModel($model, true);
            return;
        }
        if ($view->getName() === 'unreads') {
            $model = $this->getModel('Unreads', 'Site', ['ignore_request' => true]);
            $model->requireAdministrator();
            $view->setModel($model, true);
            return;
        }
        if ($view->getName() === 'deliveries') {
            $model = $this->getModel(ucfirst($view->getName()), 'Site', ['ignore_request' => true]);
            $model->requireAdministrator();
            $pagination = new Pagination($model->getTotal(), $this->readInteger('limitstart'), 20, '', $this->app);
            $pagination->setAdditionalUrlParam('option', 'com_altacourses'); $pagination->setAdditionalUrlParam('view', $view->getName());
            $model->setState('list.start', $pagination->limitstart);
            $view->pagination = $pagination;
            $view->setModel($model, true);
            return;
        }
        if (in_array($view->getName(), ['suppliers', 'supplierprofile'], true)) {
            $model = $this->getModel('Supplierprofile', 'Site', ['ignore_request' => true]);
            $administrator = $model->isAdministrator();
            if ($view->getName() === 'suppliers') {
                if (!$administrator) { throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403); }
                $view->setModel($model, true);
                return;
            }
            $userId = $this->readInteger('user_id');
            if ($userId === 0 && !$administrator) { $userId = (int) $this->app->getIdentity()->id; }
            $record = $model->getRecord($userId);
            $key = 'com_altacourses.supplierprofile.' . (int) $this->app->getIdentity()->id . '.' . $userId;
            if ($this->input->getBool('fresh')) { $this->app->setUserState($key, null); }
            $original = $model->formData($record);
            $draft = $this->app->getUserState($key, []) ?: [];
            if (isset($draft['version']) && ($draft['version'] !== $original['version'] || ($draft['id'] ?? '') !== $original['id'])) {
                $this->app->enqueueMessage(Text::_('COM_ALTACOURSES_SUPPLIER_DRAFT_STALE'), 'warning');
            }
            $view->form = $model->getForm($record, $draft + $original);
            $view->accountName = $record['account']->name . ' (' . $record['account']->username . ')';
            $view->accountEmail = $record['account']->email;
            $view->accountBlocked = (bool) $record['account']->block;
            $view->supplierUserId = $userId;
            $view->setModel($model, true);
            return;
        }
        if ($view->getName() === 'course') {
            $model = $this->getModel('Course', 'Site', ['ignore_request' => true]);
            $id = $this->readInteger('id');
            $model->setState('course.id', $id);
            $view->canSignup = $this->getModel('Signup', 'Site', ['ignore_request' => true])->canEnquire($this->readInteger('id'));
            $view->canEnquire = $this->getModel('Enquiry', 'Site', ['ignore_request' => true])->canEnquire($id);
            $view->filters = $this->readCourseFilters();
            $view->setModel($model, true);
            return;
        }
        if ($view->getName() === 'editcourse') {
            $model = $this->getModel('Editcourse', 'Site', ['ignore_request' => true]);
            $id = $this->readInteger('id');
            $record = $model->getRecord($id);
            $key = 'com_altacourses.editcourse.' . (int) $this->app->getIdentity()->id . '.' . $id;
            if ($this->input->getBool('fresh')) {
                $this->app->setUserState($key, null);
            }
            $original = $model->formData($record);
            $draft = $this->app->getUserState($key, []) ?: [];
            if (isset($draft['version']) && $draft['version'] !== $original['version']) {
                $this->app->enqueueMessage(Text::_('COM_ALTACOURSES_EDIT_DRAFT_STALE'), 'warning');
            }
            $view->form = $model->getEditForm($record, $draft + $original);
            $view->courseId = $id;
            $view->hasStoredSecond = (bool) $record['sessions'];
            $view->laterSessions = array_slice($record['sessions'], 1);
            $view->setModel($model, true);
            return;
        }
        if ($view->getName() === 'newcourse') {
            $model = $this->getModel('Newcourse', 'Site', ['ignore_request' => true]);
            $model->isAdministrator();
            $key = 'com_altacourses.newcourse.' . (int) $this->app->getIdentity()->id;
            if ($this->input->getBool('fresh')) {
                $this->app->setUserState($key . '.draft', null);
            }
            $data = $this->app->getUserState($key . '.draft', []) ?: [];
            $tickets = array_filter($this->app->getUserState($key . '.tickets', []), static fn ($time): bool => $time >= time() - 14400);
            if (!isset($data['submission']) || !isset($tickets[$data['submission']])) {
                $data['submission'] = bin2hex(random_bytes(32));
                $tickets = array_slice($tickets, -19, null, true);
                $tickets[$data['submission']] = time();
            }
            $this->app->setUserState($key . '.tickets', $tickets);
            $view->form = $model->getForm($data);
            $view->setModel($model, true);
            return;
        }
        if ($view->getName() === 'availability') {
            $model = $this->getModel(ucfirst($view->getName()), 'Site', ['ignore_request' => true]);
            $view->course = $model->getCourse($this->readInteger('id'));
            $view->form = $model->getForm([
                'id' => (int) $view->course->id,
                'version' => (int) $view->course->availability_version,
                'availability' => $view->course->nr_of_participants,
            ]);
            $view->setModel($model, true);
            return;
        }
        $managed = $view->getName() === 'managecourses';
        if (!$managed && $view->getName() !== 'courses') {
            parent::prepareViewModel($view);
            $view->allowTestData = (bool) $this->app->getParams('com_altacourses')->get('allow_test_data', false);
            return;
        }

        $model = $this->getModel($managed ? 'Managecourses' : 'Courses', 'Site', ['ignore_request' => true]);
        $filters = $this->readCourseFilters();
        if ($managed) {
            $filters['id'] = $this->readInteger('id');
            if ($this->app->getIdentity()->authorise('altacourses.manage', 'com_altacourses')) {
                $filters['supplier'] = $this->readInteger('supplier');
            }
            $period = $this->input->get('period', 'future', 'raw');
            if (!is_string($period) || !in_array($period, ['future', 'all'], true)) { throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_FILTER'), 400); }
            $filters['period'] = $period;
        }
        unset($filters['limitstart']);
        foreach ($filters as $key => $value) {
            $model->setState('filter.' . $key, $value);
        }

        $pagination = new Pagination($model->getTotal(), $this->readInteger('limitstart'), 20, '', $this->app);
        foreach (['option' => 'com_altacourses', 'view' => $view->getName()] + $filters as $key => $value) {
            $pagination->setAdditionalUrlParam($key, $value);
        }
        $itemId = $this->input->getInt('Itemid');
        if ($itemId > 0) {
            $pagination->setAdditionalUrlParam('Itemid', $itemId);
        }
        $model->setState('list.start', $pagination->limitstart);
        $model->setState('list.limit', 20);
        $view->setModel($model, true);
        $view->pagination = $pagination;
        $view->filters = $filters;
    }

    private function readContactFilters(): array
    {
        $filters = [];
        foreach (['kind' => 10, 'search' => 120, 'type' => 255] as $key => $length) {
            $value = $this->input->get($key, $key === 'kind' ? 'all' : '', 'raw');
            if (!is_string($value) || mb_strlen($value) > $length || preg_match('/[\x00-\x1f\x7f]/', $value)) {
                throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_FILTER'), 400);
            }
            $filters[$key] = trim($value);
        }
        if (!in_array($filters['kind'], ['all', 'enquiry', 'signup'], true)) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_FILTER'), 400);
        }
        return $filters;
    }

    private function readCourseFilters(): array
    {
        $filters = [
            'type' => $this->readInteger('type'),
            'region' => $this->readInteger('region'),
            'from' => $this->readDate('from'),
            'to' => $this->readDate('to'),
        ];
        if ($filters['from'] !== '' && $filters['to'] !== '' && $filters['from'] > $filters['to']) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_FILTER'), 400);
        }
        $filters['limitstart'] = $this->readInteger('limitstart');
        return $filters;
    }

    private function readInteger(string $name): int
    {
        $raw = $this->input->get($name, '0', 'raw');
        if (!is_scalar($raw) || !ctype_digit((string) $raw) || (float) $raw > 2147483647) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_FILTER'), 400);
        }
        return (int) $raw;
    }

    private function readDate(string $name): string
    {
        $raw = $this->input->get($name, '', 'raw');
        if (!is_string($raw)) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_FILTER'), 400);
        }
        if ($raw === '') {
            return '';
        }
        $date = \DateTimeImmutable::createFromFormat('!Y-m-d', $raw, new \DateTimeZone('UTC'));
        if (!$date || $date->format('Y-m-d') !== $raw || (int) $date->format('Y') < 1000) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_FILTER'), 400);
        }
        return $raw;
    }
}
