<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\View\Courseavailability;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareTrait;
\defined('_JEXEC') or die;
final class HtmlView extends BaseHtmlView implements CourseScheduleAwareInterface
{
    use CourseScheduleAwareTrait;
    public array $items=[],$sessions=[],$suppliers=[],$choices=[],$filters=[];
    public ?\Joomla\CMS\Pagination\Pagination $pagination=null;
    public bool $administrator=false;
    public function display($tpl=null): void
    {
        $model=$this->getModel();$model->requireContactAccess();$this->administrator=$model->isContactAdministrator();
        $this->items=$model->getItems();$this->choices=$model->getChoices();if($this->administrator){$this->suppliers=$model->getSuppliers();}
        $this->sessions=$this->getCourseSchedule()->additionalSessions(array_map(static fn($r)=>(int)$r->id,$this->items));
        $this->getDocument()->setTitle(Text::_('COM_ALTACOURSES_INLINE_TITLE'));
        $this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.site')->useStyle('com_altacourses.courseavailability')->useScript('com_altacourses.courseavailability');
        foreach(['SAVING','SAVED','ERROR','REFRESHING','REFRESHED','UNKNOWN','READONLY','SESSION'] as $key){Text::script('COM_ALTACOURSES_INLINE_'.$key);}
        parent::display($tpl);
    }
}
