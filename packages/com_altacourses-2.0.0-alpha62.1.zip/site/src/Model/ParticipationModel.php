<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Model;

use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareTrait;
use Joomla\CMS\Form\Form;
use Advenire\Component\Altacourses\Administrator\Service\ReportTime;
use Joomla\CMS\Form\FormFactoryAwareInterface;
use Joomla\CMS\Form\FormFactoryAwareTrait;
use Joomla\CMS\Language\Text;
use Joomla\Database\ParameterType;
use Joomla\Database\QueryInterface;

\defined('_JEXEC') or die;

/** Reporting uses the original recipient; it never modifies the binding agreement. */
final class ParticipationModel extends RequestrecordsModel implements FormFactoryAwareInterface, CourseScheduleAwareInterface
{
    use ContactScopeTrait;
    use RebookingTrait;
    use CourseScheduleAwareTrait;
    use FormFactoryAwareTrait;

    private string $reportingTimezone = 'UTC';

    public function setReportingTimezone(string $timezone): void
    {
        new \DateTimeZone($timezone);
        $this->reportingTimezone = $timezone;
    }

    public function today(): string
    {
        return (new \DateTimeImmutable('now', new \DateTimeZone($this->reportingTimezone)))->format('Y-m-d');
    }

    private function baseQuery(): QueryInterface
    {
        $query = $this->getDatabase()->createQuery()->from('#__altacourses_requests AS r')
            ->join('INNER', '#__altacourses_courses AS co ON co.id=r.courseid')
            ->join('LEFT', '#__altacourses_request_submissions AS s ON s.request_id=r.id')
            ->join('LEFT', '#__altacourses_request_rebookings AS incoming ON incoming.destination_request_id=r.id')
            ->join('LEFT', '#__altacourses_clients AS cl ON cl.id=r.clientid')
            ->join('LEFT', '#__altacourses_coursetypes AS ct ON ct.id=co.course_type')
            ->join('LEFT', '#__altacourses_courseplaces AS cp ON cp.id=co.course_place')
            ->where('(s.id IS NOT NULL OR cl.id IS NOT NULL)')->where('r.asked_for_info IN (0, 1)')->where('COALESCE(r.rebooked,0)<>2');
        $actor = $this->contactActor();
        if (!$this->isContactAdministrator()) {
            $owner = (int) $actor->id;
            $query->where('COALESCE(s.supplier_user_id,incoming.supplier_user_id,co.cr)=:participation_owner')->bind(':participation_owner', $owner, ParameterType::INTEGER);
        }
        return $query;
    }

    private function listQuery(): QueryInterface
    {
        $query = $this->baseQuery();
        $today = $this->today();
        $query->where("co.start_date IS NOT NULL AND CAST(co.start_date AS CHAR) NOT LIKE '0000-%' AND DATE(co.start_date)<=:report_today")->bind(':report_today', $today);
        $query->where("(r.date_reported IS NULL OR CAST(r.date_reported AS CHAR) LIKE '0000-%')");
        return $query;
    }

    public function getTotal(): int
    {
        return (int) $this->getDatabase()->setQuery($this->listQuery()->select('COUNT(DISTINCT co.id)'))->loadResult();
    }

    public function getItems(): array
    {
        // Select course data only: no submitted names, organisations or email on the queue.
        $query = $this->listQuery()->select(['DISTINCT co.id', 'co.start_date', 'co.stop_date', 'ct.name AS course_type', 'cp.name AS course_place'])
            ->order('co.start_date, co.id');
        $items = $this->getDatabase()->setQuery($query, (int) $this->getState('list.start', 0), 20)->loadObjectList();
        $extras = $this->getCourseSchedule()->additionalSessions(array_column($items, 'id'));
        foreach ($items as $item) {
            $item->sessions = array_merge([(object) ['start_date' => $item->start_date, 'stop_date' => $item->stop_date]], $extras[(int) $item->id] ?? []);
        }
        return $items;
    }

    private function pendingRows(int $courseId, bool $lock = false): array
    {
        $query = $this->baseQuery()->select(['r.*', 's.id AS submission_id', "COALESCE(s.contact_json,JSON_OBJECT('firstname',cl.firstname,'lastname',cl.lastname,'company',cl.company,'email',cl.email)) AS contact_json", $this->currentCourseExpression() . ' AS course_json', 'COALESCE(s.supplier_user_id,incoming.supplier_user_id,co.cr) AS supplier_user_id', 'ct.name AS actual_type', 'cp.name AS actual_place', 'co.start_date AS first_start', 'co.availability_version AS course_version'])
            ->where('co.id=:batch_course')->bind(':batch_course', $courseId, ParameterType::INTEGER)
            ->where("(r.date_reported IS NULL OR CAST(r.date_reported AS CHAR) LIKE '0000-%')")->order('r.id');
        if ($lock) { $query->setQuery((string) $query . ' FOR UPDATE'); }
        return $this->projectRows($this->getDatabase()->setQuery($query)->loadObjectList());
    }

    public function getCourseBatch(int $courseId): array
    {
        $rows = $this->pendingRows($courseId);
        if (!$rows) { throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'), 404); }
        if (!$rows[0]->first_start || str_starts_with($rows[0]->first_start, '0000-') || substr($rows[0]->first_start, 0, 10) > $this->today()) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_PARTICIPATION_NOT_STARTED'), 409);
        }
        if (count($rows) > 200) { throw new \RuntimeException(Text::_('COM_ALTACOURSES_PARTICIPATION_BATCH_LIMIT'), 422); }
        $query = $this->getDatabase()->createQuery()->select(['co.id', 'co.start_date', 'co.stop_date', 'ct.name AS course_type', 'cp.name AS course_place', 'cl1.name AS leader1', 'cl2.name AS leader2'])
            ->from('#__altacourses_courses AS co')
            ->join('LEFT', '#__altacourses_coursetypes AS ct ON ct.id=co.course_type')
            ->join('LEFT', '#__altacourses_courseplaces AS cp ON cp.id=co.course_place')
            ->join('LEFT', '#__altacourses_courseleaders AS cl1 ON cl1.id=co.course_leader_1')
            ->join('LEFT', '#__altacourses_courseleaders AS cl2 ON cl2.id=co.course_leader_2')
            ->where('co.id=:batch_summary')->bind(':batch_summary', $courseId, ParameterType::INTEGER);
        $course = $this->getDatabase()->setQuery($query)->loadObject();
        $course->sessions = array_merge([(object) ['start_date' => $course->start_date, 'stop_date' => $course->stop_date]], $this->getCourseSchedule()->additionalSessions([$courseId])[$courseId] ?? []);
        return ['course' => $course, 'rows' => $rows];
    }

    /** One complete scoped course form, including pending notes, saves atomically. */
    public function saveCourseReports(int $courseId, int $courseVersion, array $reports): void
    {
        $this->requireContactAccess();
        if ($courseId <= 0 || $courseVersion < 0 || !$reports || count($reports) > 200) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_PARTICIPATION_INVALID'), 400);
        }
        foreach ($reports as $id => $report) {
            if (!is_int($id) || $id <= 0 || $id > 2147483647 || !is_array($report) || !in_array(count($report), [3,4], true)
                || array_diff(array_keys($report), ['version', 'status', 'note', 'rebook']) || !is_int($report['version'] ?? null)
                || !is_int($report['status'] ?? null) || !is_string($report['note'] ?? null)) {
                throw new \RuntimeException(Text::_('COM_ALTACOURSES_PARTICIPATION_INVALID'), 400);
            }
            if (isset($report['rebook']) && !is_string($report['rebook'])) { throw new \RuntimeException(Text::_('COM_ALTACOURSES_REBOOK_INVALID'), 400); }
            $this->validateRebooking($report['rebook'] ?? '0');
            $this->validateReport($id, $report['version'], $report['status'], $report['note']);
        }
        $db = $this->getDatabase();
        $this->requireTransactional();
        $db->transactionStart();
        try {
            $rows = $this->pendingRows($courseId, true);
            $actualIds = array_map(static fn ($row): int => (int) $row->id, $rows);
            $postedIds = array_keys($reports); sort($postedIds);
            if ($actualIds !== $postedIds) {
                throw new \RuntimeException(Text::_('COM_ALTACOURSES_PARTICIPATION_BATCH_CONFLICT'), 409);
            }
            if ((int) $rows[0]->course_version !== $courseVersion) {
                throw new \RuntimeException(Text::_('COM_ALTACOURSES_PARTICIPATION_BATCH_CONFLICT'), 409);
            }
            $reportTime = (new \DateTimeImmutable('now', new \DateTimeZone('UTC')))->format('Y-m-d H:i:s');
            foreach ($rows as $row) {
                $report = $reports[(int) $row->id];
                if (($report['rebook'] ?? '0') !== '0') { $this->moveRequest($row, $report, $reportTime); }
                else { $this->writeReport($row, $report['version'], $report['status'], $report['note'], $reportTime); }
            }
            $db->transactionCommit();
        } catch (\Throwable $error) {
            $db->transactionRollback(); throw $error;
        }
    }

    public function getRecord(int $id, bool $lock = false): object
    {
        $query = $this->baseQuery()->select(['r.*', 's.id AS submission_id', "COALESCE(s.contact_json,JSON_OBJECT('firstname',cl.firstname,'lastname',cl.lastname,'company',cl.company,'email',cl.email)) AS contact_json", $this->currentCourseExpression() . ' AS course_json', 'COALESCE(s.supplier_user_id,incoming.supplier_user_id,co.cr) AS supplier_user_id', 'ct.name AS actual_type', 'cp.name AS actual_place', 'co.start_date AS first_start'])
            ->where('r.id=:report_id')->bind(':report_id', $id, ParameterType::INTEGER);
        // setQuery() retains this query object's bound values (verified Joomla 6.2 source).
        if ($lock) { $query->setQuery((string) $query . ' FOR UPDATE'); }
        $row = $this->getDatabase()->setQuery($query)->loadObject();
        if ($row === null) { throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'), 404); }
        return $this->projectRows([$row])[0];
    }

    private function projectRows(array $rows): array
    {
        $sessions = $this->getCourseSchedule()->currentSessions(array_column($rows, 'courseid'));
        foreach ($rows as $row) {
            if (ReportTime::pending($row->date_reported)) { $row->date_reported = null; }
            $row->reported_local = ReportTime::local($row, $this->reportingTimezone);
            if ($row->course_json === null) {
                $row->course_json = json_encode(['course_type' => $row->actual_type, 'course_place' => $row->actual_place,
                    'sessions' => $sessions[(int) $row->courseid] ?? []], JSON_THROW_ON_ERROR);
            }
        }
        return $rows;
    }

    private function requireTransactional(): void
    {
        $db = $this->getDatabase();
        foreach (['requests', 'clients', 'courses'] as $name) {
            $status = $db->setQuery('SHOW TABLE STATUS WHERE Name=' . $db->quote($db->replacePrefix('#__altacourses_' . $name)))->loadObject();
            if (!$status || strcasecmp($status->Engine, 'InnoDB') !== 0) { throw new \RuntimeException(Text::_('COM_ALTACOURSES_REPORT_ENGINE'), 409); }
        }
    }

    public function getForm(array $data = [], string $control = 'jform'): Form
    {
        $form = $this->getFormFactory()->createForm('com_altacourses.participation', ['control' => $control]);
        if (!$form->loadFile(dirname(__DIR__, 2) . '/forms/participation.xml')) {
            throw new \RuntimeException('Participation form could not be loaded');
        }
        $form->bind($data);
        return $form;
    }

    /** Status 0 is unreported, 1 participated, 2 did not participate (legacy flags). */
    public function saveReport(int $id, int $version, int $status, string $note): void
    {
        $this->requireContactAccess();
        $this->validateReport($id, $version, $status, $note);
        $db = $this->getDatabase();
        $this->requireTransactional();
        $db->transactionStart();
        try {
            $this->writeReport($this->getRecord($id, true), $version, $status, $note);
            $db->transactionCommit();
        } catch (\Throwable $error) {
            $db->transactionRollback(); throw $error;
        }
    }

    private function validateReport(int $id, int $version, int $status, string $note): void
    {
        if ($id <= 0 || $version < 0 || !in_array($status, [0, 1, 2], true)
            || mb_strlen($note) > 4000 || preg_match('/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/', $note)) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_PARTICIPATION_INVALID'), 400);
        }
    }

    private function writeReport(object $row, int $version, int $status, string $note, ?string $reportTime = null): void
    {
        $actor = $this->getActor();
        $db = $this->getDatabase();
        $id = (int) $row->id;
        if (!$row->first_start || str_starts_with($row->first_start, '0000-') || substr($row->first_start, 0, 10) > $this->today()) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_PARTICIPATION_NOT_STARTED'), 409);
        }
        if ((int) $row->participation_version !== $version) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_PARTICIPATION_CONFLICT'), 409);
        }
        if ((int) $row->checked_out !== 0 && (int) $row->checked_out !== (int) $actor->id) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_PARTICIPATION_LOCKED'), 409);
        }
        if ($row->date_reported !== null && $status === 0) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_PARTICIPATION_NO_RESET'), 409);
        }
        if ($row->date_reported === null && $status === 0 && (string) $row->note === $note) { return; }
        $participated = $status === 1 ? 1 : 0;
        $canceled = $status === 2 ? 1 : 0;
        $editor = (int) $actor->id;
        $query = $db->createQuery()->update('#__altacourses_requests')
            ->set('note=:report_note')->bind(':report_note', $note)
            ->set('participation_version=participation_version+1')
            ->where('id=:report_id')->bind(':report_id', $id, ParameterType::INTEGER)
            ->where('participation_version=:report_version')->bind(':report_version', $version, ParameterType::INTEGER);
        // Note-only edits retain the reporting month; a changed outcome is a new report.
        if ($status !== 0 && ($row->date_reported === null || (int) $row->participated !== $participated || (int) $row->canceled !== $canceled)) {
            $now = $reportTime ?? (new \DateTimeImmutable('now', new \DateTimeZone('UTC')))->format('Y-m-d H:i:s');
            $query->set('participated=:report_participated')->bind(':report_participated', $participated, ParameterType::INTEGER)
                ->set('canceled=:report_canceled')->bind(':report_canceled', $canceled, ParameterType::INTEGER)
                ->set('date_reported=:report_time')->bind(':report_time', $now)
                ->set('reported_by=:report_actor')->bind(':report_actor', $editor, ParameterType::INTEGER)->set("report_timezone='UTC'");
        }
        $db->setQuery($query)->execute();
        if ($db->getAffectedRows() !== 1) { throw new \RuntimeException(Text::_('COM_ALTACOURSES_PARTICIPATION_CONFLICT'), 409); }
    }
}
