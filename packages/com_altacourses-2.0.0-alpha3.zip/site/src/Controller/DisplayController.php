<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Controller;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;

final class DisplayController extends BaseController
{
    protected $default_view = 'dashboard';

    public function display($cachable = false, $urlparams = [])
    {
        if ($this->input->getCmd('view', 'dashboard') !== 'dashboard'
            || $this->input->getCmd('layout', 'default') !== 'default'
            || $this->app->getDocument()->getType() !== 'html') {
            throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'), 404);
        }

        $user = $this->app->getIdentity();

        if ($user->guest) {
            $return = 'index.php?option=com_altacourses&view=dashboard';
            $itemId = $this->input->getInt('Itemid');

            if ($itemId > 0) {
                $return .= '&Itemid=' . $itemId;
            }

            // Joomla validates index.php-relative returns; format the SEF URL after login.
            // Never accept a return URL supplied by the visitor.
            $this->setRedirect(Route::_('index.php?option=com_users&view=login&return=' . rawurlencode(base64_encode($return)), false));

            return $this;
        }

        if (!$user->authorise('altacourses.manage', 'com_altacourses')
            && !$user->authorise('altacourses.supplier', 'com_altacourses')) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }

        // Never cache a page whose content depends on the current user's role.
        return parent::display(false, []);
    }
}
