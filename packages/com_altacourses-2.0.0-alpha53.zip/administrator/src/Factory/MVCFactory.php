<?php

/**
 * @package     Altacourses.Administrator
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Administrator\Factory;

use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareTrait;
use Advenire\Component\Altacourses\Administrator\Service\CoursePriceAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\CoursePriceAwareTrait;
use Advenire\Component\Altacourses\Administrator\Service\NotificationAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\NotificationAwareTrait;
use Advenire\Component\Altacourses\Administrator\Service\CommissionAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\CommissionAwareTrait;
use Advenire\Component\Altacourses\Administrator\Service\MonthlyAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\MonthlyAwareTrait;
use Joomla\CMS\MVC\Factory\MVCFactory as BaseMVCFactory;

\defined('_JEXEC') or die;

final class MVCFactory extends BaseMVCFactory implements CourseScheduleAwareInterface, CoursePriceAwareInterface, NotificationAwareInterface, CommissionAwareInterface, MonthlyAwareInterface
{
    use CourseScheduleAwareTrait;
    use CoursePriceAwareTrait;
    use NotificationAwareTrait;
    use CommissionAwareTrait;
    use MonthlyAwareTrait;

    private ?\Advenire\Component\Altacourses\Administrator\Service\SupplierReminders $supplierReminders = null;
    public function setSupplierReminders(\Advenire\Component\Altacourses\Administrator\Service\SupplierReminders $service): void { $this->supplierReminders = $service; }
    private string $receiptSecret = '';
    public function setReceiptSecret(string $secret): void { $this->receiptSecret = $secret; }
    private string $reportingTimezone = 'UTC';

    public function setReportingTimezone(string $timezone): void { $this->reportingTimezone = $timezone; }

    public function createModel($name, $prefix = '', array $config = [])
    {
        $model = parent::createModel($name, $prefix, $config);
        if ($model instanceof CourseScheduleAwareInterface) {
            $model->setCourseSchedule($this->getCourseSchedule());
        }
        if ($model instanceof CoursePriceAwareInterface) {
            $model->setCoursePrice($this->getCoursePrice());
        }
        if ($model instanceof \Advenire\Component\Altacourses\Site\Model\ReadreceiptModel || $model instanceof \Advenire\Component\Altacourses\Site\Model\UnreadsModel) { $model->setReceiptSecret($this->receiptSecret); }
        if ($model instanceof \Advenire\Component\Altacourses\Site\Model\RemindersModel && $this->supplierReminders !== null) { $model->setSupplierReminders($this->supplierReminders); }
        if ($model instanceof NotificationAwareInterface) { $model->setNotifications($this->getNotifications()); }
        if ($model instanceof \Advenire\Component\Altacourses\Site\Model\ParticipationModel || $model instanceof \Advenire\Component\Altacourses\Site\Model\RebookingModel || $model instanceof \Advenire\Component\Altacourses\Site\Model\ManagecoursesModel || $model instanceof \Advenire\Component\Altacourses\Site\Model\UnconfirmedModel) {
            $model->setReportingTimezone($this->reportingTimezone);
        }
        if ($model instanceof \Advenire\Component\Altacourses\Site\Model\ParticipationModel) {
            $model->setRebookingModel($this->createModel('Rebooking', 'Site', ['ignore_request' => true]));
        }
        if ($model instanceof CommissionAwareInterface) { $model->setCommissionReport($this->getCommissionReport()); }
        if ($model instanceof MonthlyAwareInterface) { $model->setMonthlyReport($this->getMonthlyReport()); }
        return $model;
    }

    public function createView($name, $prefix = '', $type = '', array $config = [])
    {
        $view = parent::createView($name, $prefix, $type, $config);
        if ($view instanceof CourseScheduleAwareInterface) {
            $view->setCourseSchedule($this->getCourseSchedule());
        }
        if ($view instanceof CoursePriceAwareInterface) {
            $view->setCoursePrice($this->getCoursePrice());
        }
        return $view;
    }
}
