<?php
/** @package Altacourses.Module @license GNU General Public License version 2 or later */
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use \Advenire\Component\Altacourses\Administrator\Service\PriceDisplay as PriceDisplay;
\defined('_JEXEC') or die;
$escape = static fn (mixed $value): string => htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
$date = static fn (string $value): string => HTMLHelper::_('date', substr($value, 0, 10) . ' 12:00:00', Text::_('MOD_ALTACOURSES_DATE_FORMAT'), false);
?>
<div class="altacourses-compact" data-altacourses-compact>
 <?php if ($rows) : ?>
 <div class="table-responsive"><table class="table table-striped">
  <caption class="visually-hidden"><?php echo $escape(Text::_('MOD_ALTACOURSES_CAPTION')); ?></caption>
  <thead><tr><?php foreach (['DATES', 'PLACE', 'TOTAL', 'MORE'] as $column) : ?><th scope="col"><?php echo $escape(($column==='TOTAL' ? PriceDisplay::label('MOD_ALTACOURSES_TOTAL') : Text::_('MOD_ALTACOURSES_' . $column))); ?></th><?php endforeach; ?></tr></thead>
  <tbody><?php foreach ($rows as $row) : ?><tr data-compact-course-id="<?php echo (int) $row->id; ?>">
   <td><?php foreach ($row->sessions as $part) : ?><div class="altacourses-compact-session"><time datetime="<?php echo $escape(substr($part['start_date'], 0, 10)); ?>"><?php echo $escape($date($part['start_date'])); ?></time><?php if ($part['stop_date'] && substr($part['stop_date'], 0, 10) !== substr($part['start_date'], 0, 10)) : ?> – <time datetime="<?php echo $escape(substr($part['stop_date'], 0, 10)); ?>"><?php echo $escape($date($part['stop_date'])); ?></time><?php endif; ?></div><?php endforeach; ?></td>
   <td><?php if ($row->placeLink !== null) : ?><a data-compact-place href="<?php echo $escape($row->placeLink); ?>"><?php echo $escape($row->course_place); ?></a><?php else : ?><?php echo $escape($row->course_place); ?><?php endif; ?></td>
   <td class="text-nowrap" data-compact-price><?php echo $escape($row->price); ?><?php echo PriceDisplay::marker($row->residential); ?></td>
   <td><a data-compact-more href="<?php echo $escape($row->readMore); ?>"><?php echo $escape(Text::_('MOD_ALTACOURSES_MORE')); ?><span class="visually-hidden">: <?php echo $escape($row->course_place . ' ' . substr($row->start_date, 0, 10)); ?></span></a></td>
  </tr><?php endforeach; ?></tbody>
 </table></div>
 <?php else : ?><p role="status"><?php echo $escape(Text::_('MOD_ALTACOURSES_EMPTY')); ?></p><?php endif; ?>
 <?php if ((bool)$params->get('show_listing', 1)): ?><p><a class="btn btn-primary" data-compact-listing href="<?php echo $escape($listing); ?>"><?php echo $escape(Text::sprintf('MOD_ALTACOURSES_LISTING', $number)); ?></a></p><?php endif; ?>
 <p class="altacourses-compact-pricing"><?php echo PriceDisplay::intro('MOD_ALTACOURSES_PRICING', 'COM_ALTACOURSES_COURSE_VAT'); ?></p>
</div>
