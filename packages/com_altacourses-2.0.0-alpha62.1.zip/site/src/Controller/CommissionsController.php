<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Controller;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;

final class CommissionsController extends BaseController
{
    public function execute($task)
    {
        if (!in_array(strtolower((string) $task), ['export', 'saverate'], true) || $this->app->getDocument()->getType() !== 'html') {
            throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'), 404);
        }
        return parent::execute($task);
    }

    private function posted(): array
    {
        $model = $this->getModel('Commissions', 'Site', ['ignore_request' => true]);
        $model->requireAdministrator();
        if ($this->input->getMethod() !== 'POST') { throw new \RuntimeException(Text::_('COM_ALTACOURSES_AVAILABILITY_POST_REQUIRED'), 405); }
        if (!$this->checkToken('post', false)) { throw new \RuntimeException(Text::_('JINVALID_TOKEN'), 403); }
        return $this->input->post->get('jform', [], 'array');
    }

    public function export(): void
    {
        $data = $this->posted();
        if (count($data) !== 3 || array_diff(array_keys($data), ['month', 'fingerprint', 'confirm'])
            || !is_string($data['month'] ?? null) || !is_string($data['fingerprint'] ?? null)
            || !preg_match('/^[a-f0-9]{64}$/D', $data['fingerprint']) || ($data['confirm'] ?? null) !== '1') {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_COMMISSION_INVALID'), 400);
        }
        $model = $this->getModel('Commissions', 'Site', ['ignore_request' => true]);
        try { $csv = $model->download($data['month'], $data['fingerprint']); }
        catch (\RuntimeException $error) {
            if (in_array($error->getCode(), [400, 403, 404, 409], true)) { throw $error; }
            $this->app->getLogger()->error('Altacourses commission export failed', ['exception' => $error]);
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_COMMISSION_FAILED'), 500);
        }
        $this->app->allowCache(false);
        $this->app->setHeader('Cache-Control', 'private, no-store, no-cache, must-revalidate', true);
        $this->app->setHeader('Content-Type', 'text/csv; charset=UTF-8', true);
        $this->app->setHeader('Content-Disposition', 'attachment; filename="altacourses-' . $data['month'] . '.csv"', true);
        $this->app->setHeader('X-Content-Type-Options', 'nosniff', true);
        $this->app->sendHeaders();
        echo $csv;
        $this->app->close();
    }

    public function saverate(): void
    {
        $data = $this->posted();
        if (count($data) !== 4 || array_diff(array_keys($data), ['user_id', 'version', 'month', 'fee'])
            || !is_string($data['month'] ?? null) || !is_string($data['fee'] ?? null)) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_COMMISSION_INVALID'), 400);
        }
        foreach (['user_id', 'version'] as $key) {
            if (!is_string($data[$key] ?? null) || !ctype_digit($data[$key]) || (float) $data[$key] > 2147483647) {
                throw new \RuntimeException(Text::_('COM_ALTACOURSES_COMMISSION_INVALID'), 400);
            }
        }
        $model = $this->getModel('Commissions', 'Site', ['ignore_request' => true]);
        $model->validateMonth($data['month']); // Validate period before changing a rate or redirecting.
        $model->saveRate((int) $data['user_id'], (int) $data['version'], $data['fee']);
        $this->setMessage(Text::_('COM_ALTACOURSES_COMMISSION_RATE_SAVED'));
        $this->setRedirect(Route::_('index.php?option=com_altacourses&view=commissions&month=' . rawurlencode($data['month']), false));
    }
}
