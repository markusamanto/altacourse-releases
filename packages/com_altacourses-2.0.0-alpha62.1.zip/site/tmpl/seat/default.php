<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;
?>
<section class="altacourses-portal" aria-labelledby="altacourses-seat-heading">
    <h1 id="altacourses-seat-heading"><?php echo $this->escape(Text::_($this->seatId === 0 ? 'COM_ALTACOURSES_SEAT_ADD' : 'COM_ALTACOURSES_SEAT_EDIT')); ?></h1>
    <form id="altacourses-seat-form" action="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&task=seat.save', false)); ?>" method="post">
        <?php foreach (['id', 'version', 'ticket'] as $field) : ?><?php echo $this->form->getInput($field); ?><?php endforeach; ?>
        <?php echo $this->form->renderField('seats'); ?>
        <?php echo $this->form->renderField('label'); ?>
        <?php echo $this->form->renderField('state'); ?>
        <?php echo HTMLHelper::_('form.token'); ?>
        <button type="submit" class="btn btn-success"><?php echo $this->escape(Text::_('JSAVE')); ?></button>
        <a class="btn btn-secondary" href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=seats', false)); ?>"><?php echo $this->escape(Text::_('JCANCEL')); ?></a>
        <?php if ($this->seatId > 0) : ?>
            <a class="btn btn-secondary" href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=seat&id=' . $this->seatId . '&fresh=1', false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_EDIT_RELOAD')); ?></a>
        <?php endif; ?>
    </form>
</section>
