<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Model;

use Advenire\Component\Altacourses\Site\Exception\CourseValidationException;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Form\FormFactoryAwareInterface;
use Joomla\CMS\Form\FormFactoryAwareTrait;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\BaseModel;
use Joomla\CMS\User\CurrentUserInterface;
use Joomla\CMS\User\User;
use Joomla\CMS\User\UserFactoryAwareInterface;
use Joomla\CMS\User\UserFactoryAwareTrait;
use Joomla\Database\DatabaseAwareInterface;
use Joomla\Database\DatabaseAwareTrait;
use Joomla\Database\ParameterType;

\defined('_JEXEC') or die;

/** Seat management uses the original table and IDs; no delete operation. */
final class SeatsModel extends BaseModel implements DatabaseAwareInterface, CurrentUserInterface, UserFactoryAwareInterface, FormFactoryAwareInterface
{
    use DatabaseAwareTrait;
    use UserFactoryAwareTrait;
    use FormFactoryAwareTrait;

    private ?User $currentUser = null;

    public function setCurrentUser(User $currentUser): void
    {
        $this->currentUser = $currentUser;
    }

    public function requireAdministrator(): void
    {
        $user = $this->currentUser;
        if ($user === null || $user->guest || $user->block
            || !$user->authorise('altacourses.manage', 'com_altacourses')) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }
        $fresh = $this->getUserFactory()->loadUserById((int) $user->id);
        if ($fresh->guest || $fresh->block || !$fresh->authorise('altacourses.manage', 'com_altacourses')) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }
    }

    public function getItems(): array
    {
        $this->requireAdministrator();
        $db = $this->getDatabase();
        return $db->setQuery($db->createQuery()->select(['id', 'seats', 'label', 'state'])
            ->from($db->quoteName('#__altacourses_seats'))->order($db->quoteName('seats') . ', ' . $db->quoteName('id')))->loadObjectList();
    }

    public function getRecord(int $id): ?object
    {
        $this->requireAdministrator();
        if ($id === 0) {
            return null;
        }
        $db = $this->getDatabase();
        $query = $db->createQuery()->select('*')->from($db->quoteName('#__altacourses_seats'))
            ->where($db->quoteName('id') . ' = :id')->bind(':id', $id, ParameterType::INTEGER);
        $record = $db->setQuery($query)->loadObject();
        if ($record === null) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_SEAT_NOT_FOUND'), 404);
        }
        $this->requireUnlocked($record);
        return $record;
    }

    /** A fingerprint avoids adding a migration-only revision column to the legacy table. */
    public function formData(?object $record): array
    {
        return [
            'id' => (string) ($record->id ?? 0),
            'label' => (string) ($record->label ?? ''),
            'seats' => $record === null ? '' : (string) $record->seats,
            'state' => $record === null ? '1' : (string) $record->state,
            'version' => $record === null ? '' : hash('sha256', json_encode($record, JSON_THROW_ON_ERROR)),
        ];
    }

    public function getForm(array $data): Form
    {
        $this->requireAdministrator();
        $form = $this->getFormFactory()->createForm('com_altacourses.seat', ['control' => 'jform']);
        if (!$form->loadFile(dirname(__DIR__, 2) . '/forms/seat.xml')) {
            throw new \RuntimeException('Seat form could not be loaded');
        }
        $record = $this->getRecord((int) ($data['id'] ?? 0));
        if ($record !== null && $this->valueLocked($record)) {
            $form->setFieldAttribute('seats', 'readonly', 'true');
            $form->setFieldAttribute('seats', 'description', 'COM_ALTACOURSES_SEAT_VALUE_LOCKED_HELP');
        }
        $form->bind($data);
        return $form;
    }

    public function saveLabel(int $id, string $version, array $input): int
    {
        $this->requireAdministrator();
        $label = $input['label'] ?? null;
        $rawValue = $input['seats'] ?? null;
        $state = $input['state'] ?? null;
        if (array_diff(array_keys($input), ['label', 'seats', 'state']) || !is_string($label) || !is_string($state)
            || !in_array($state, ['0', '1'], true) || !is_string($rawValue)
            || !preg_match('/^-?[0-9]+$/D', $rawValue) || (float) $rawValue < -2147483648 || (float) $rawValue > 2147483647) {
            throw new CourseValidationException([Text::_('COM_ALTACOURSES_SEAT_INVALID')]);
        }
        $label = trim($label);
        $value = (int) $rawValue;
        if ($label === '' || mb_strlen($label) > 255 || preg_match('/[\x00-\x1F\x7F]/u', $label)) {
            throw new CourseValidationException([Text::_('COM_ALTACOURSES_SEAT_INVALID')]);
        }
        $form = $this->getForm([]);
        if (!$form->validate(['id' => $id, 'label' => $label, 'seats' => (string) $value, 'state' => $state])) {
            throw new CourseValidationException([Text::_('COM_ALTACOURSES_SEAT_INVALID')]);
        }
        $db = $this->getDatabase();
        if ($this->valueExists($value, $id)) {
            throw new CourseValidationException([Text::_('COM_ALTACOURSES_SEAT_DUPLICATE')]);
        }
        if ($id === 0) {
            if ($version !== '') {
                throw new \RuntimeException(Text::_('COM_ALTACOURSES_SEAT_CONFLICT'), 409);
            }
            $row = (object) ['seats' => $value, 'label' => $label, 'state' => (int) $state,
                'ordering' => 0, 'checked_out' => 0, 'created_by' => (int) $this->currentUser->id];
            try { $db->insertObject('#__altacourses_seats', $row, 'id'); }
            catch (\Throwable $exception) {
                if ($this->valueExists($value, 0)) { throw new CourseValidationException([Text::_('COM_ALTACOURSES_SEAT_DUPLICATE')]); }
                throw $exception;
            }
            return (int) $row->id;
        }
        $db->transactionStart();
        try {
            $query = $db->createQuery()->select('*')->from($db->quoteName('#__altacourses_seats'))
                ->where($db->quoteName('id') . ' = :id')->bind(':id', $id, ParameterType::INTEGER);
            $query->setQuery((string) $query . ' FOR UPDATE');
            $record = $db->setQuery($query)->loadObject();
            if ($record === null) {
                throw new \RuntimeException(Text::_('COM_ALTACOURSES_SEAT_NOT_FOUND'), 404);
            }
            $this->requireUnlocked($record);
            if (!hash_equals($this->formData($record)['version'], $version)) {
                throw new \RuntimeException(Text::_('COM_ALTACOURSES_SEAT_CONFLICT'), 409);
            }
            if ($value !== (int) $record->seats && $this->valueLocked($record)) {
                throw new \RuntimeException(Text::_('COM_ALTACOURSES_SEAT_VALUE_LOCKED'), 409);
            }
            $published = (int) $state;
            $query = $db->createQuery()->update($db->quoteName('#__altacourses_seats'))
                ->set($db->quoteName('label') . ' = :label')->bind(':label', $label)
                ->set($db->quoteName('seats') . ' = :value')->bind(':value', $value, ParameterType::INTEGER)
                ->set($db->quoteName('state') . ' = :state')->bind(':state', $published, ParameterType::INTEGER)
                ->where($db->quoteName('id') . ' = :id')->bind(':id', $id, ParameterType::INTEGER);
            $db->setQuery($query)->execute();
            $db->transactionCommit();
            return $id;
        } catch (\Throwable $exception) {
            $db->transactionRollback();
            if ($exception->getCode() !== 409 && $exception->getCode() !== 404 && $this->valueExists($value, $id)) {
                throw new CourseValidationException([Text::_('COM_ALTACOURSES_SEAT_DUPLICATE')]);
            }
            throw $exception;
        }
    }

    private function valueExists(int $value, int $exceptId): bool
    {
        $db = $this->getDatabase();
        $q = $db->createQuery()->select('COUNT(*)')->from($db->quoteName('#__altacourses_seats'))
            ->where('seats=:value')->bind(':value', $value, ParameterType::INTEGER)
            ->where('id<>:except')->bind(':except', $exceptId, ParameterType::INTEGER);
        return (int) $db->setQuery($q)->loadResult() > 0;
    }

    public function valueLocked(object $record): bool
    {
        $this->requireAdministrator();
        $value = (int) $record->seats;
        if (in_array($value, [1, 2, 3, 4], true)) {
            return true;
        }
        $db = $this->getDatabase();
        $q = $db->createQuery()->select('COUNT(*)')->from($db->quoteName('#__altacourses_courses'))
            ->where('nr_of_participants=:value')->bind(':value', $value, ParameterType::INTEGER);
        return (int) $db->setQuery($q)->loadResult() > 0;
    }

    private function requireUnlocked(object $record): void
    {
        if ((int) $record->checked_out !== 0 && (int) $record->checked_out !== (int) $this->currentUser->id) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_AVAILABILITY_LOCKED'), 409);
        }
    }
}
