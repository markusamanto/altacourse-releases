<?php
/** @package Altacourses.Module @license GNU General Public License version 2 or later */
namespace Advenire\Module\Altacourses\Site\Dispatcher;
use Joomla\CMS\Dispatcher\AbstractModuleDispatcher;
use Joomla\CMS\Event\PageCache\IsExcludedEvent;
use Joomla\CMS\Helper\HelperFactoryAwareInterface;
use Joomla\CMS\Helper\HelperFactoryAwareTrait;
\defined('_JEXEC') or die;
final class Dispatcher extends AbstractModuleDispatcher implements HelperFactoryAwareInterface
{
    use HelperFactoryAwareTrait;
    protected function getLayoutData(): array|false
    {
        $data = parent::getLayoutData();
        // Availability, dates and previously empty lists must immediately reflect current records.
        $this->app->allowCache(false);
        $this->app->getDispatcher()->addListener('onPageCacheIsExcluded', static function (IsExcludedEvent $event): void { $event->addResult(true); });
        $result = $this->getHelperFactory()->getHelper('AltacoursesHelper')->render($this->app, $data['params']);
        if ($result === null) { return false; }
        $assets = $this->app->getDocument()->getWebAssetManager();
        $assets->getRegistry()->addRegistryFile('media/mod_altacourses/joomla.asset.json');
        $assets->useStyle('mod_altacourses.site');
        return $data + $result;
    }
}
