<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Model;

use Advenire\Component\Altacourses\Administrator\Service\MonthlyAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\MonthlyAwareTrait;
use Advenire\Component\Altacourses\Administrator\Service\CommissionAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\CommissionAwareTrait;

\defined('_JEXEC') or die;

final class MonthlyreportsModel extends EnquiriesModel implements MonthlyAwareInterface, CommissionAwareInterface
{
    use MonthlyAwareTrait;
    use CommissionAwareTrait;

    public function previousMonth(): string { $this->requireAdministrator(); return $this->getMonthlyReport()->previousMonth(); }
    public function validateMonth(string $month): void { $this->requireAdministrator(); $this->getCommissionReport()->bounds($month); }
    public function getMessages(string $month): array { $this->requireAdministrator(); return $this->getMonthlyReport()->messages($month); }
    public function blockedReason(): ?string { $this->requireAdministrator(); return $this->getMonthlyReport()->blockedReason(); }
    public function runPeriod(string $month): string { $this->requireAdministrator(); return $this->getMonthlyReport()->runPeriod($month, $this->currentActorId()); }
    public function review(string $month, int $id, string $token, bool $captured): void
    {
        $this->requireAdministrator();
        $this->getMonthlyReport()->review($month, $id, $token, $this->currentActorId(), $captured);
    }
    public function download(string $month, int $id): string
    {
        $this->requireAdministrator();
        $row = $this->getMonthlyReport()->getMessage($month, $id);
        if ($row->csv_payload === null) { throw new \RuntimeException('No monthly attachment', 404); }
        return $row->csv_payload;
    }
}
