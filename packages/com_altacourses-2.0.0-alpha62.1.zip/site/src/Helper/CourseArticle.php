<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Helper;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;
use Joomla\Component\Content\Site\Helper\RouteHelper;
\defined('_JEXEC') or die;
final class CourseArticle
{
    /** A new URI per link prevents coid leaking between courses sharing an article. */
    public static function href(array $articles,mixed $value,int $courseId): ?string
    {
        if (!is_scalar($value)||!ctype_digit((string)$value)) { return null; }
        $article=$articles[(int)$value]??null;if ($article===null) { return null; }
        $uri=new Uri(RouteHelper::getArticleRoute($article->id.':'.$article->alias,(int)$article->catid,$article->language));
        $uri->setVar('coid',$courseId);return Route::_($uri->toString(),false);
    }
}
