<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Controller;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;

final class NotificationController extends BaseController
{
    public function execute($task)
    {
        if (!in_array(strtolower((string) $task), ['prepare', 'send', 'retry', 'confirm'], true)) {
            throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'), 404);
        }
        return parent::execute($task);
    }

    public function prepare(): void { $this->perform('prepare'); }
    public function send(): void { $this->perform('send'); }
    public function retry(): void { $this->perform('retry'); }
    public function confirm(): void { $this->perform('confirm'); }

    private function perform(string $action): void
    {
        if ($this->input->getMethod() !== 'POST') { throw new \RuntimeException(Text::_('COM_ALTACOURSES_SAMPLE_POST_REQUIRED'), 405); }
        if (!$this->checkToken('post', false)) { throw new \RuntimeException(Text::_('JINVALID_TOKEN'), 403); }
        $id = $this->readId('id');
        $model = $this->getModel('Notifications', 'Site', ['ignore_request' => true]);
        try {
            if (in_array($action, ['retry', 'confirm'], true)) { $model->$action($id, $this->readId('message_id'), $this->input->post->get('reviewed', '', 'raw') === '1'); }
            elseif ($action === 'prepare') { $model->prepare($id); }
            else { $model->send($id); }
        } catch (\Throwable $error) {
            if (in_array($error->getCode(), [403, 404, 409], true)) { throw $error; }
            $this->app->getLogger()->error('Altacourses notification action failed');
            $this->setMessage(Text::_('COM_ALTACOURSES_NOTIFY_ACTION_FAILED'), 'warning');
        }
        $this->setRedirect(Route::_('index.php?option=com_altacourses&view=notifications&id=' . $id, false));
    }

    private function readId(string $name): int
    {
        $raw = $this->input->post->get($name, '', 'raw');
        if (!is_string($raw) || !ctype_digit($raw) || (float) $raw > 2147483647 || (int) $raw <= 0) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_FILTER'), 400);
        }
        return (int) $raw;
    }
}
