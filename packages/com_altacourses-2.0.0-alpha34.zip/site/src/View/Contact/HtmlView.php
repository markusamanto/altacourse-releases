<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\View\Contact;

\defined('_JEXEC') or die;

final class HtmlView extends \Advenire\Component\Altacourses\Site\View\Participant\HtmlView
{
    public string $detailView = 'contact';
    public string $backView = 'contacts';
    public bool $showMailActions = false;
    public bool $scopedContact = true;
}
