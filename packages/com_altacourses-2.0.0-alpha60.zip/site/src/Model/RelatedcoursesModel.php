<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Model;
use Advenire\Component\Altacourses\Administrator\Service\CoursePriceAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\CoursePriceAwareTrait;
use Joomla\Database\ParameterType;
\defined('_JEXEC') or die;
final class RelatedcoursesModel extends PubliccourseModel implements CoursePriceAwareInterface
{
    use CoursePriceAwareTrait;
    /** All matching published/upcoming/available courses, including either leader slot, once each. */
    public function forLeaderArticle(int $articleId): array
    {
        if ($articleId<1||$articleId>2147483647) { return []; }
        $first=$articleId;$second=$articleId;
        $q=$this->listingQuery()->where("((l1.url<>'' AND l1.url NOT REGEXP '[^0-9]' AND CAST(l1.url AS UNSIGNED)=:leader_article_1) OR (l2.url<>'' AND l2.url NOT REGEXP '[^0-9]' AND CAST(l2.url AS UNSIGNED)=:leader_article_2))")
            ->bind(':leader_article_1',$first,ParameterType::INTEGER)->bind(':leader_article_2',$second,ParameterType::INTEGER);
        $rows=$this->getDatabase()->setQuery($q)->loadObjectList();
        $sessions=$this->getCourseSchedule()->currentSessions(array_map(static fn($row)=>(int)$row->id,$rows));
        foreach ($rows as $row) {
            $row->sessions=$sessions[(int)$row->id]??[];
            $row->amount=$this->getCoursePrice()->formatTotal($row->course_price,$row->lodging_price,$row->lodging_included);
        }
        return $rows;
    }
}
