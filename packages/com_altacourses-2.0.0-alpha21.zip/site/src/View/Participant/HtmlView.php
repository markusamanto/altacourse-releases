<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\View\Participant;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;

\defined('_JEXEC') or die;

class HtmlView extends BaseHtmlView
{
    public ?object $item = null;
    public array $contact = [];
    public array $course = [];
    public array $history = [];
    public int $returnStart = 0;
    public string $detailView = 'participant';
    public string $backView = 'signups';
    public array $returnFilters = [];
    public bool $showMailActions = true;
    public bool $scopedContact = false;

    public function display($tpl = null): void
    {
        $record = $this->getModel()->getRecord((int) $this->getModel()->getState('request.id'));
        $this->item = $record['selected'];
        $this->history = $record['history'];
        $this->contact = json_decode($this->item->contact_json, true, 512, JSON_THROW_ON_ERROR);
        $this->course = json_decode($this->item->course_json, true, 512, JSON_THROW_ON_ERROR);
        $this->getDocument()->setTitle(Text::_('COM_ALTACOURSES_PARTICIPANT_TITLE'));
        $this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.site');
        parent::display($tpl);
    }
}
