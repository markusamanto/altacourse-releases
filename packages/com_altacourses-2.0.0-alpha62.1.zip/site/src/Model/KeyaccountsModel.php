<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Model;
use Advenire\Component\Altacourses\Site\Exception\CourseValidationException;
use Joomla\CMS\Language\Text;
use Joomla\Database\ParameterType;
use Joomla\Database\QueryInterface;
\defined('_JEXEC') or die;

/** Request billing and unlinked legacy billing share only their four editable values. */
final class KeyaccountsModel extends RequestrecordsModel
{
    private function query(bool $legacy): QueryInterface
    {
        $this->requireAdministrator();
        $db=$this->getDatabase();
        if ($legacy) {
            return $db->createQuery()->select(['k.*','k.id AS record_id','0 AS client_id',
                'k.organisation AS account_name', "NULLIF(CAST(k.startdate AS CHAR),'0000-00-00 00:00:00') AS course_start"])
                ->from('#__altacourses_keyaccount AS k')->where('(k.request_id IS NULL OR k.request_id=0)');
        }
        return $db->createQuery()->select(['k.id AS record_id','k.request_id AS saved_request_id','k.invoiced','k.received','k.no_invoicing','k.notes','k.ordering','k.state','k.checked_out','k.checked_out_time','k.created_by',
            'r.id AS request_id','r.asked_for_info','r.rebooked','r.courseid','r.clientid AS client_id',
            'cl.firstname','cl.lastname','cl.account AS account_reference','a.id AS account_id','a.name AS account_name',
            "NULLIF(CAST(co.start_date AS CHAR),'0000-00-00 00:00:00') AS course_start"])
            ->from('#__altacourses_requests AS r')
            ->join('INNER','#__altacourses_clients AS cl ON cl.id=r.clientid')
            ->join('INNER','#__altacourses_accounts AS a ON CAST(cl.account AS BINARY)=CAST(a.id AS BINARY)')
            ->join('LEFT','#__altacourses_courses AS co ON co.id=r.courseid')
            ->join('LEFT','#__altacourses_keyaccount AS k ON k.request_id=r.id')
            ->where('r.asked_for_info=0')->where('COALESCE(r.rebooked,0) IN (0,1)');
    }

    public function getItems(): array
    {
        $legacy=(bool)$this->getState('billing.legacy',false);
        $query=$this->query($legacy)->order('course_start DESC, '.($legacy?'k.id':'r.id').' DESC');
        return $this->getDatabase()->setQuery($query,(int)$this->getState('list.start',0),20)->loadObjectList();
    }

    public function getTotal(): int
    {
        return (int)$this->getDatabase()->setQuery($this->query((bool)$this->getState('billing.legacy',false))->clear('select')->select('COUNT(*)'))->loadResult();
    }

    public function getRecord(int $id, bool $legacy, bool $lock=false): object
    {
        $this->requireAdministrator();
        if ($id<=0) { throw new \RuntimeException(Text::_('COM_ALTACOURSES_BILLING_NOT_FOUND'),404); }
        $query=$this->query($legacy)->where(($legacy?'k.id':'r.id').'=:billing_id')->bind(':billing_id',$id,ParameterType::INTEGER);
        if ($lock) { $query->setQuery((string)$query.' FOR UPDATE'); }
        $row=$this->getDatabase()->setQuery($query)->loadObject();
        if ($row===null) { throw new \RuntimeException(Text::_('COM_ALTACOURSES_BILLING_NOT_FOUND'),404); }
        if ((int)$row->checked_out!==0 && (int)$row->checked_out!==$this->currentActorId()) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_AVAILABILITY_LOCKED'),409);
        }
        return $row;
    }

    public function version(object $row): string
    {
        return hash('sha256',json_encode($row,JSON_THROW_ON_ERROR));
    }

    public function saveBilling(int $id,bool $legacy,string $version,array $input): void
    {
        $this->requireAdministrator();
        $fields=['invoiced','received','no_invoicing','notes'];
        if (array_diff(array_keys($input),$fields)||array_diff($fields,array_keys($input))) {
            throw new CourseValidationException([Text::_('COM_ALTACOURSES_BILLING_INVALID')]);
        }
        foreach (['invoiced','received','no_invoicing'] as $field) {
            if (!is_string($input[$field])||!in_array($input[$field],['0','1'],true)) {
                throw new CourseValidationException([Text::_('COM_ALTACOURSES_BILLING_INVALID')]);
            }
        }
        if ($input['invoiced']==='1' && $input['no_invoicing']==='1') {
            throw new CourseValidationException([Text::_('COM_ALTACOURSES_BILLING_EXCLUSIVE')]);
        }
        if (!is_string($input['notes'])||!mb_check_encoding($input['notes'],'UTF-8')||strlen($input['notes'])>65535
            ||preg_match('/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/',$input['notes'])) {
            throw new CourseValidationException([Text::_('COM_ALTACOURSES_BILLING_INVALID')]);
        }
        $db=$this->getDatabase();$db->transactionStart();
        try {
            $row=$this->getRecord($id,$legacy,true);
            if (!hash_equals($this->version($row),$version)) {
                throw new \RuntimeException(Text::_('COM_ALTACOURSES_BILLING_CONFLICT'),409);
            }
            if ((int)$row->record_id>0) {
                // No legacy identity/date/organisation, metadata or request field can be written here.
                $update=(object)($input+['id'=>(int)$row->record_id]);
                $db->updateObject('#__altacourses_keyaccount',$update,'id');
            } else {
                $insert=(object)($input+['request_id'=>$id,'state'=>1,'created_by'=>$this->currentActorId()]);
                $db->insertObject('#__altacourses_keyaccount',$insert,'id');
            }
            $db->transactionCommit();
        } catch (\Throwable $e) { $db->transactionRollback();throw $e; }
    }
}
