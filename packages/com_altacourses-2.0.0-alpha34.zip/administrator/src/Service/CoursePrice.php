<?php

/**
 * @package     Altacourses.Administrator
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Administrator\Service;

\defined('_JEXEC') or die;

/** Read-only public totals; use integer öre so decimals are never added as floats. */
final class CoursePrice
{
    public function formatTotal(?string $fee, ?string $lodging, ?string $included): ?string
    {
        $course = $this->amount($fee);
        if ($course === null) {
            return null;
        }
        if ($lodging === null || trim($lodging) === '') {
            if ($included !== '1') {
                return null;
            }
            $extra = 0;
        } else {
            $extra = $this->amount($lodging);
            if ($extra === null) {
                return null;
            }
        }
        // Two stated prices are always added, including when the checkbox is checked.
        $total = $course + $extra;
        $whole = (string) intdiv($total, 100);
        $whole = preg_replace('/\B(?=(\d{3})+(?!\d))/', ' ', $whole);
        $fraction = $total % 100;
        return $whole . ($fraction ? ',' . str_pad((string) $fraction, 2, '0', STR_PAD_LEFT) : '');
    }

    private function amount(?string $value): ?int
    {
        if ($value === null || strlen($value) > 512) {
            return null;
        }
        $value = trim($value);
        // Recognised legacy currency/test suffixes only; never strip arbitrary text or digits.
        $value = preg_replace('/\s*(?:kr|SEK)\.?\s*(?:\(test\))?\s*$/iu', '', $value);
        $value = preg_replace('/:\s*[-–]\s*$/u', '', $value ?? '');
        if (preg_match('/^(\d{1,3}(?:\.\d{3})+)(?:,(\d{1,2}))?$/D', $value ?? '', $parts)) {
            $whole = str_replace('.', '', $parts[1]);
        } elseif (preg_match('/^(\d{1,3}(?:,\d{3})+)(?:\.(\d{1,2}))?$/D', $value ?? '', $parts)) {
            $whole = str_replace(',', '', $parts[1]);
        } elseif (preg_match('/^(\d+|\d{1,3}(?:[ \x{00a0}\x{202f}]\d{3})+)(?:[.,](\d{1,2}))?$/uD', $value ?? '', $parts)) {
            $whole = preg_replace('/[ \x{00a0}\x{202f}]/u', '', $parts[1]);
        } else {
            return null;
        }
        if (strlen($whole) > 12) {
            return null;
        }
        return (int) $whole * 100 + (int) str_pad($parts[2] ?? '', 2, '0');
    }
}
