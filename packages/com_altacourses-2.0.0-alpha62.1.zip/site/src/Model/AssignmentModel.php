<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Model;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\CMS\MVC\Model\BaseModel;
use Joomla\CMS\User\CurrentUserInterface;
use Joomla\CMS\User\User;
use Joomla\CMS\User\UserFactoryAwareInterface;
use Joomla\CMS\User\UserFactoryAwareTrait;
use Joomla\Database\DatabaseAwareInterface;
use Joomla\Database\DatabaseAwareTrait;

\defined('_JEXEC') or die;

final class AssignmentModel extends BaseModel implements DatabaseAwareInterface, CurrentUserInterface, UserFactoryAwareInterface
{
    use DatabaseAwareTrait;
    use UserFactoryAwareTrait;

    private ?User $currentUser = null;

    public function __construct($config = [], ?MVCFactoryInterface $factory = null)
    {
        parent::__construct($config);
    }

    public function setCurrentUser(User $currentUser): void
    {
        $this->currentUser = $currentUser;
    }

    /** Active Joomla accounts eligible to manage supplier courses; never infer a company ID. */
    public function getChoices(): array
    {
        $this->requireAdministrator();
        $db = $this->getDatabase();
        $ids = $db->setQuery($db->createQuery()->select('id')->from('#__users')
            ->where('block = 0')->order('name, id'))->loadColumn();
        $choices = [(object) ['id' => 0, 'label' => Text::_('COM_ALTACOURSES_UNASSIGNED')]];
        foreach ($ids as $id) {
            $user = $this->getUserFactory()->loadUserById((int) $id);
            if ($this->isEligible($user)) {
                $choices[] = (object) ['id' => (int) $user->id, 'label' => $user->name . ' (' . $user->username . ')'];
            }
        }
        return $choices;
    }

    private function isEligible(User $user): bool
    {
        return !$user->guest && !(bool) $user->block
            && $user->authorise('altacourses.supplier', 'com_altacourses');
    }

    private function requireAdministrator(): void
    {
        if ($this->currentUser === null || $this->currentUser->guest
            || !$this->currentUser->authorise('altacourses.manage', 'com_altacourses')) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }
    }
}
