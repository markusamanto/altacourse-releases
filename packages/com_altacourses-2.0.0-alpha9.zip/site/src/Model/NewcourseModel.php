<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Model;

use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareTrait;
use Advenire\Component\Altacourses\Site\Exception\CourseValidationException;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Form\FormFactoryAwareInterface;
use Joomla\CMS\Form\FormFactoryAwareTrait;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\CMS\MVC\Model\BaseModel;
use Joomla\CMS\User\CurrentUserInterface;
use Joomla\CMS\User\User;
use Joomla\Database\DatabaseAwareInterface;
use Joomla\Database\DatabaseAwareTrait;
use Joomla\Database\ParameterType;

\defined('_JEXEC') or die;

final class NewcourseModel extends BaseModel implements DatabaseAwareInterface, CurrentUserInterface, FormFactoryAwareInterface, CourseScheduleAwareInterface
{
    use DatabaseAwareTrait;
    use FormFactoryAwareTrait;
    use CourseScheduleAwareTrait;

    private ?User $currentUser = null;
    private ?MVCFactoryInterface $modelFactory;

    public const FIELDS = ['submission', 'start_date', 'stop_date', 'second_start', 'second_end', 'course_type',
        'course_place', 'course_leader_1', 'course_leader_2', 'course_price', 'lodging_price', 'lodging_included',
        'course_notes', 'availability', 'supplier'];

    public function __construct($config = [], ?MVCFactoryInterface $factory = null)
    {
        parent::__construct($config);
        $this->modelFactory = $factory;
    }

    public function setCurrentUser(User $currentUser): void
    {
        $this->currentUser = $currentUser;
    }

    public function isAdministrator(): bool
    {
        $user = $this->currentUser;
        if ($user === null || $user->guest || $user->block
            || (!$user->authorise('altacourses.manage', 'com_altacourses') && !$user->authorise('altacourses.supplier', 'com_altacourses'))) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }
        return $user->authorise('altacourses.manage', 'com_altacourses');
    }

    public function getForm(array $data = []): Form
    {
        $administrator = $this->isAdministrator();
        $form = $this->getFormFactory()->createForm('com_altacourses.newcourse', ['control' => 'jform']);
        if (!$form->loadFile(dirname(__DIR__, 2) . '/forms/newcourse.xml')) {
            throw new \RuntimeException('Course form could not be loaded');
        }
        foreach (['course_type' => ['coursetypes', 'COM_ALTACOURSES_COURSE_TYPE', true],
            'course_place' => ['courseplaces', 'COM_ALTACOURSES_PLACE', true],
            'course_leader_1' => ['courseleaders', 'COM_ALTACOURSES_NEW_LEADER1', true],
            'course_leader_2' => ['courseleaders', 'COM_ALTACOURSES_NEW_LEADER2', false],
            'availability' => ['seats', 'COM_ALTACOURSES_AVAILABILITY', true]] as $name => [$table, $label, $required]) {
            $this->addChoices($form, $name, $label, $this->lookup($table), $required);
        }
        if ($administrator) {
            $assignment = $this->modelFactory?->createModel('Assignment', 'Site', ['ignore_request' => true]);
            if ($assignment === null) {
                throw new \LogicException('MVC factory has not been supplied');
            }
            $assignment->setCurrentUser($this->currentUser);
            $choices = array_values(array_filter($assignment->getChoices(), static fn ($choice): bool => $choice->id > 0));
            $this->addChoices($form, 'supplier', 'COM_ALTACOURSES_ASSIGNMENT_SUPPLIER', $choices, true);
        }
        $form->bind($data);
        return $form;
    }

    private function lookup(string $table): array
    {
        $db = $this->getDatabase();
        $query = $db->createQuery()->select($table === 'seats' ? ['seats AS id', 'label'] : ['id', 'name AS label'])
            ->from($db->quoteName('#__altacourses_' . $table))->where('state=1')->order('ordering, id');
        if ($table === 'seats') {
            $query->where('seats IN (1,2,3,4)');
        }
        return $db->setQuery($query)->loadObjectList();
    }

    private function addChoices(Form $form, string $name, string $label, array $choices, bool $required): void
    {
        $field = new \SimpleXMLElement('<field type="list" filter="integer" validate="options" />');
        $field->addAttribute('name', $name);
        $field->addAttribute('label', $label);
        $field->addAttribute('required', $required ? 'true' : 'false');
        $empty = $field->addChild('option');
        $empty->addAttribute('value', $required ? '' : '0');
        $empty[0] = Text::_($required ? 'COM_ALTACOURSES_NEW_CHOOSE' : 'COM_ALTACOURSES_NEW_NONE');
        foreach ($choices as $choice) {
            $option = $field->addChild('option');
            $option->addAttribute('value', (string) $choice->id);
            $option[0] = (string) $choice->label;
        }
        $form->setField($field);
    }

    private function validateData(array $input): array
    {
        $administrator = $this->isAdministrator();
        $errors = [];
        if (array_diff(array_keys($input), self::FIELDS) || (!$administrator && array_key_exists('supplier', $input))) {
            $errors[] = Text::_('COM_ALTACOURSES_NEW_FIELDS_INVALID');
        }
        $data = [];
        foreach (self::FIELDS as $name) {
            $value = $input[$name] ?? '';
            if (!is_string($value) && !is_int($value)) {
                $errors[] = Text::_('COM_ALTACOURSES_NEW_FIELDS_INVALID');
                $value = '';
            }
            if (str_contains((string) $value, chr(0)) || mb_strlen((string) $value) > ($name === 'course_notes' ? 10000 : 255)) {
                $errors[] = Text::_('COM_ALTACOURSES_NEW_FIELDS_INVALID');
            }
            $data[$name] = trim((string) $value);
        }
        foreach (['course_type', 'course_place', 'course_leader_1', 'course_leader_2', 'availability', 'lodging_included', 'supplier'] as $name) {
            if ($data[$name] === '' && in_array($name, ['course_leader_2', 'lodging_included', 'supplier'], true)) {
                $data[$name] = '0';
            }
            if (!ctype_digit($data[$name]) || (float) $data[$name] > 2147483647) {
                $errors[] = Text::_('COM_ALTACOURSES_NEW_CHOICES_INVALID');
            } else {
                $data[$name] = (string) (int) $data[$name];
            }
        }
        $form = $this->getForm();
        if (!$form->validate($data)) {
            foreach ($form->getErrors() as $error) {
                $errors[] = $error instanceof \Exception ? $error->getMessage() : (string) $error;
            }
        }
        try {
            $data['ranges'] = $this->getCourseSchedule()->validateRanges($data['start_date'], $data['stop_date'], $data['second_start'], $data['second_end']);
        } catch (\InvalidArgumentException $exception) {
            $errors[] = Text::_('COM_ALTACOURSES_NEW_DATES_INVALID');
        }
        foreach (['course_price', 'lodging_price'] as $name) {
            if ($name === 'lodging_price' && $data[$name] === '') {
                continue;
            }
            $amount = preg_replace('/[\s\x{00a0}\x{202f}]/u', '', $data[$name]);
            if (!preg_match('/^\d{1,9}(?:[.,]\d{1,2})?$/D', $amount ?? '')) {
                $errors[] = Text::_('COM_ALTACOURSES_NEW_PRICE_INVALID');
            } else {
                $data[$name] = str_replace(',', '.', $amount);
            }
        }
        if ($data['course_leader_2'] !== '0' && $data['course_leader_1'] === $data['course_leader_2']) {
            $errors[] = Text::_('COM_ALTACOURSES_NEW_LEADERS_INVALID');
        }
        if (!in_array($data['lodging_included'], ['0', '1'], true) || mb_strlen($data['course_notes']) > 10000) {
            $errors[] = Text::_('COM_ALTACOURSES_NEW_FIELDS_INVALID');
        }
        if ($errors) {
            throw new CourseValidationException(array_unique($errors));
        }
        return $data;
    }

    public function createCourse(array $input, string $submission): int
    {
        $administrator = $this->isAdministrator();
        if (!preg_match('/^[a-f0-9]{64}$/D', $submission)) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_NEW_EXPIRED'), 409);
        }
        $token = hash('sha256', $this->currentUser->id . ':' . $submission);
        $existing = $this->existingSubmission($token, $administrator);
        if ($existing !== null) {
            $this->setState('creation.reused', true);
            return $existing;
        }
        $data = $this->validateData($input);
        $db = $this->getDatabase();
        $db->transactionStart();
        try {
            $course = (object) ['start_date' => $data['ranges'][0]['start_date'], 'stop_date' => $data['ranges'][0]['stop_date'],
                'course_type' => (int) $data['course_type'], 'course_place' => (int) $data['course_place'],
                'course_leader_1' => (int) $data['course_leader_1'], 'course_leader_2' => (int) $data['course_leader_2'] ?: null,
                'course_price' => $data['course_price'], 'lodging_price' => $data['lodging_price'],
                'course_notes' => $data['course_notes'], 'lodging_included' => $data['lodging_included'],
                'nr_of_participants' => (int) $data['availability'], 'cr' => $administrator ? (int) $data['supplier'] : (int) $this->currentUser->id,
                'created_by' => (int) $this->currentUser->id, 'state' => 1, 'ordering' => 0, 'checked_out' => 0,
                'availability_version' => 0, 'creation_token' => $token];
            $db->insertObject('#__altacourses_courses', $course, 'id');
            if (isset($data['ranges'][1])) {
                $session = (object) ($data['ranges'][1] + ['course_id' => (int) $course->id, 'ordering' => 2]);
                $db->insertObject('#__altacourses_course_sessions', $session, 'id');
            }
            $db->transactionCommit();
            return (int) $course->id;
        } catch (\Throwable $exception) {
            $db->transactionRollback();
            $existing = $this->existingSubmission($token, $administrator);
            if ($existing !== null) {
                $this->setState('creation.reused', true);
                return $existing;
            }
            throw $exception;
        }
    }

    private function existingSubmission(string $token, bool $administrator): ?int
    {
        $db = $this->getDatabase();
        $query = $db->createQuery()->select(['id', 'created_by', 'cr'])->from('#__altacourses_courses')
            ->where('creation_token=:token')->bind(':token', $token);
        $existing = $db->setQuery($query)->loadObject();
        if ($existing === null) {
            return null;
        }
        if ((int) $existing->created_by !== (int) $this->currentUser->id
            || (!$administrator && (int) $existing->cr !== (int) $this->currentUser->id)) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }
        return (int) $existing->id;
    }
}
