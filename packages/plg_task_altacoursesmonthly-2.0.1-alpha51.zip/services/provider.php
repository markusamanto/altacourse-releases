<?php

/** @package Altacourses.Task @license GNU General Public License version 2 or later */
\defined('_JEXEC') or die;

use Advenire\Component\Altacourses\Administrator\Service\MonthlyReport;
use Advenire\Plugin\Task\Altacoursesmonthly\Extension\Altacoursesmonthly;
use Advenire\Component\Altacourses\Administrator\Service\SupplierReminders;
use Joomla\CMS\Extension\PluginInterface;
use Joomla\CMS\Language\LanguageFactoryInterface;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;

return new class () implements ServiceProviderInterface {
    public function register(Container $container): void
    {
        $container->set(PluginInterface::class, static function (Container $container): PluginInterface {
            $provider = JPATH_ADMINISTRATOR . '/components/com_altacourses/services/business.php';
            $reports = null;$reminders=null;
            if (is_file($provider)) {
                $services = $container->createChild();
                $services->registerServiceProvider(require $provider);
                $reports = $services->get(MonthlyReport::class);
                if($services->has(SupplierReminders::class)){$reminders=$services->get(SupplierReminders::class);}
            }
            $tag = $reports?->settings()['language'] ?? 'sv-SE';
            $language = $container->get(LanguageFactoryInterface::class)->createLanguage($tag);
            $language->load('plg_task_altacoursesmonthly', JPATH_PLUGINS . '/task/altacoursesmonthly', $tag, true);
            return new Altacoursesmonthly((array) PluginHelper::getPlugin('task', 'altacoursesmonthly'), $reports, $language, $reminders);
        });
    }
};
