<?php
use Joomla\CMS\Helper\ModuleHelper;
use Joomla\CMS\Language\Text;
use Joomla\Registry\Registry;
\defined('_JEXEC') or die;
?>
<section class="altacourses-portal" aria-labelledby="altacourses-evaluation-thanks">
 <h1 id="altacourses-evaluation-thanks"><?php echo $this->escape($this->status==='thanks'&&$this->thanksModule!==null?$this->thanksModule->title:Text::_('COM_ALTACOURSES_EVALUATION_THANKS_TITLE')); ?></h1>
 <?php if ($this->status==='thanks') : ?>
  <?php if ($this->thanksModule!==null) :
   $module=clone $this->thanksModule;$params=new Registry($module->params);$params->set('cache',0);$module->params=$params->toString();$module->user=0;$module->name='custom';
   echo ModuleHelper::renderModule($module,['style'=>'none']);
  else : ?><p><?php echo $this->escape(Text::_('COM_ALTACOURSES_EVALUATION_THANKS')); ?></p><?php endif; ?>
 <?php else : ?><p><?php echo $this->escape(Text::_('COM_ALTACOURSES_EVALUATION_'.strtoupper($this->status))); ?></p><?php endif; ?>
</section>
