<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Model;
use Joomla\CMS\MVC\Model\BaseModel;
use Joomla\Database\DatabaseAwareInterface;
use Joomla\Database\DatabaseAwareTrait;
\defined('_JEXEC') or die;
/** Public allowlist only: never select feedback, corrections, responses or invitation codes. */
final class PublicevaluationsModel extends BaseModel implements DatabaseAwareInterface
{
    use DatabaseAwareTrait;
    public function published(int $limit): array
    {
        if($limit<1||$limit>1000){throw new \InvalidArgumentException('Invalid evaluation limit');}
        $db=$this->getDatabase();
        $query=$db->createQuery()->select(['e.id','e.rating_overall','e.review','cl.firstname','cl.lastname','co.start_date'])
            ->from('#__altacourses_evaluations AS e')
            ->join('INNER','#__altacourses_requests AS r ON r.id=e.request_id')
            ->join('INNER','#__altacourses_clients AS cl ON cl.id=r.clientid')
            ->join('INNER','#__altacourses_courses AS co ON co.id=r.courseid')
            ->where('e.state=1')->where('e.rating_overall IN (1,2,3,4,5)')
            ->where('co.start_date >= '.$db->quote('1000-01-01 00:00:00'))
            ->where("TRIM(CONCAT(COALESCE(cl.firstname,''),' ',COALESCE(cl.lastname,''))) <> ''")
            ->order(['co.start_date DESC','e.id DESC']);
        return $db->setQuery($query,0,$limit)->loadObjectList();
    }
}
