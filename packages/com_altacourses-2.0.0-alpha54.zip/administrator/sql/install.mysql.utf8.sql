-- Initial course-list schema. No production records or sample data.

CREATE TABLE IF NOT EXISTS `#__altacourses_courses` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `asset_id` int DEFAULT NULL COMMENT 'FK to the #__assets table.',
  `start_date` datetime DEFAULT NULL,
  `stop_date` datetime DEFAULT NULL,
  `course_type` int DEFAULT NULL,
  `course_place` int DEFAULT NULL,
  `course_leader_1` int DEFAULT NULL,
  `course_leader_2` int DEFAULT NULL,
  `nr_of_participants` int DEFAULT NULL,
  `availability_version` int UNSIGNED NOT NULL DEFAULT 0,
  `creation_token` char(64) DEFAULT NULL,
  `course_price` varchar(255) DEFAULT NULL,
  `lodging_price` varchar(225) DEFAULT NULL,
  `course_notes` text,
  `lodging_included` varchar(255) DEFAULT NULL,
  `alert` text,
  `reminder_sent` datetime DEFAULT NULL,
  `cr` int DEFAULT NULL,
  `ordering` int DEFAULT NULL,
  `state` tinyint(1) DEFAULT NULL,
  `checked_out` int DEFAULT NULL,
  `checked_out_time` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_course_listing` (`state`, `start_date`),
  KEY `idx_course_type` (`course_type`),
  KEY `idx_course_place` (`course_place`),
  KEY `idx_supplier_user` (`cr`),
  KEY `idx_availability` (`nr_of_participants`),
  UNIQUE KEY `idx_creation_token` (`creation_token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__altacourses_coursetypes` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `url` text,
  `params` text,
  `ordering` int DEFAULT '0',
  `state` tinyint(1) DEFAULT '0',
  `checked_out` int NOT NULL DEFAULT '0',
  `checked_out_time` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__altacourses_courseplaces` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `region_id` int DEFAULT '0',
  `url` varchar(255) DEFAULT NULL,
  `params` text,
  `ordering` int NOT NULL DEFAULT '0',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int NOT NULL DEFAULT '0',
  `checked_out_time` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_region` (`region_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__altacourses_courseleaders` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `params` text,
  `ordering` int NOT NULL DEFAULT '0',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int NOT NULL DEFAULT '0',
  `checked_out_time` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__altacourses_regions` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `params` text,
  `ordering` int NOT NULL DEFAULT '0',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int NOT NULL DEFAULT '0',
  `checked_out_time` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__altacourses_seats` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `seats` int NOT NULL,
  `label` varchar(255) NOT NULL,
  `ordering` int NOT NULL,
  `state` tinyint(1) NOT NULL,
  `checked_out` int NOT NULL,
  `checked_out_time` datetime DEFAULT NULL,
  `created_by` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_seat_code` (`seats`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Only additional sessions; the first session remains in the original courses columns.
CREATE TABLE IF NOT EXISTS `#__altacourses_course_sessions` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `course_id` int UNSIGNED NOT NULL,
  `start_date` datetime NOT NULL,
  `stop_date` datetime NOT NULL,
  `ordering` smallint UNSIGNED NOT NULL DEFAULT 2,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_course_session_order` (`course_id`, `ordering`),
  CONSTRAINT CHECK (`stop_date` >= `start_date`),
  CONSTRAINT CHECK (`ordering` >= 2),
  FOREIGN KEY (`course_id`) REFERENCES `#__altacourses_courses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Supplier profiles retain the legacy business columns and user-account link.
CREATE TABLE IF NOT EXISTS `#__altacourses_suppliers` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `company` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `postal_address` varchar(255) DEFAULT NULL,
  `postal_zip` varchar(255) DEFAULT NULL,
  `postal_city` varchar(255) DEFAULT NULL,
  `postal_state` varchar(255) DEFAULT NULL,
  `postal_country` varchar(255) DEFAULT NULL,
  `invoice_address` varchar(255) DEFAULT NULL,
  `invoice_city` varchar(255) DEFAULT NULL,
  `invoice_zip` varchar(255) DEFAULT NULL,
  `org_name` varchar(255) DEFAULT NULL,
  `newsletter` varchar(255) DEFAULT NULL,
  `terms` text,
  `notes` text,
  `bookingsurl` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `fee` int DEFAULT NULL,
  `ordering` int DEFAULT NULL,
  `state` tinyint(1) DEFAULT NULL,
  `checked_out` int DEFAULT NULL,
  `checked_out_time` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `profile_version` int UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_supplier_account` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Adds participant/request storage without importing production data.
CREATE TABLE IF NOT EXISTS `#__altacourses_clients` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `userid` int DEFAULT NULL,
  `account` varchar(255) DEFAULT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `newsletter` bigint NOT NULL DEFAULT '0',
  `age` varchar(255) DEFAULT NULL,
  `company` varchar(255) DEFAULT NULL,
  `specialmeal` varchar(255) DEFAULT NULL,
  `profession` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `postal_address` varchar(255) DEFAULT NULL,
  `postal_zip` varchar(255) DEFAULT NULL,
  `postal_city` varchar(255) DEFAULT NULL,
  `postal_state` varchar(255) DEFAULT NULL,
  `postal_country` varchar(255) DEFAULT NULL,
  `invoice_address` varchar(255) DEFAULT NULL,
  `invoice_city` varchar(255) DEFAULT NULL,
  `invoice_zip` varchar(255) DEFAULT NULL,
  `notes` text,
  `ordering` int NOT NULL DEFAULT '0',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int NOT NULL DEFAULT '0',
  `checked_out_time` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `modified_by` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_client_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__altacourses_requests` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `courseid` int DEFAULT NULL,
  `clientid` int DEFAULT NULL,
  `userid` int DEFAULT NULL,
  `participated` tinyint NOT NULL DEFAULT '0',
  `participation_version` int UNSIGNED NOT NULL DEFAULT '0',
  `reported_by` int DEFAULT NULL,
  `report_timezone` varchar(64) DEFAULT NULL,
  `commission_fee` int UNSIGNED DEFAULT NULL,
  `commission_captured_at` datetime DEFAULT NULL,
  `commission_captured_by` int DEFAULT NULL,
  `canceled` tinyint NOT NULL DEFAULT '0',
  `other_occasion` int NOT NULL DEFAULT '0',
  `note` text,
  `asked_for_info` tinyint NOT NULL DEFAULT '0',
  `date_reported` timestamp NULL DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_upgraded` timestamp NULL DEFAULT NULL,
  `rebooked` tinyint NOT NULL DEFAULT '0',
  `quality_control_email` tinyint(1) NOT NULL DEFAULT '0',
  `rate_code` varchar(255) DEFAULT NULL,
  `thesource` varchar(255) DEFAULT NULL,
  `received` tinyint(1) NOT NULL DEFAULT '0',
  `received_at` datetime DEFAULT NULL COMMENT 'First receipt link acknowledgement, UTC',
  `receipt_token_hash` char(64) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL,
  `ordering` int NOT NULL DEFAULT '0',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int NOT NULL DEFAULT '0',
  `checked_out_time` datetime DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  UNIQUE KEY `idx_receipt_token_hash` (`receipt_token_hash`),
  PRIMARY KEY (`id`),
  KEY `idx_request_course` (`courseid`),
  KEY `idx_request_client` (`clientid`),
  KEY `idx_request_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Immutable submitted details and intended supplier, independent of mutable client/profile rows.
CREATE TABLE IF NOT EXISTS `#__altacourses_request_submissions` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `request_id` int UNSIGNED NOT NULL,
  `supplier_id` int UNSIGNED NOT NULL,
  `supplier_user_id` int NOT NULL,
  `supplier_email` varchar(255) NOT NULL,
  `token_hash` char(64) NOT NULL,
  `contact_json` text NOT NULL,
  `course_json` mediumtext NOT NULL,
  `created_at` datetime NOT NULL,
  `delivery_state` varchar(20) NOT NULL DEFAULT 'not_sent',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_submission_token` (`token_hash`),
  UNIQUE KEY `idx_submission_request` (`request_id`),
  KEY `idx_submission_supplier` (`supplier_user_id`),
  CONSTRAINT CHECK (JSON_VALID(`contact_json`)),
  CONSTRAINT CHECK (JSON_VALID(`course_json`)),
  FOREIGN KEY (`request_id`) REFERENCES `#__altacourses_requests` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  FOREIGN KEY (`supplier_id`) REFERENCES `#__altacourses_suppliers` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- No historical messages are queued or sent by this migration.
CREATE TABLE IF NOT EXISTS `#__altacourses_notification_outbox` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `submission_id` int UNSIGNED NOT NULL,
  `role` varchar(20) NOT NULL,
  `recipient` varchar(255) NOT NULL,
  `reply_to` varchar(255) DEFAULT NULL,
  `subject` varchar(255) NOT NULL,
  `body` mediumtext NOT NULL,
  `message_id` varchar(255) NOT NULL,
  `state` varchar(20) NOT NULL DEFAULT 'pending',
  `attempts` int UNSIGNED NOT NULL DEFAULT 0,
  `attempt_token` char(64) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `claimed_at` datetime DEFAULT NULL,
  `sent_at` datetime DEFAULT NULL,
  `last_error` varchar(64) DEFAULT NULL,
  `reviewed_by` int DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_outbox_role` (`submission_id`, `role`),
  KEY `idx_outbox_state` (`state`),
  CONSTRAINT CHECK (`role` IN ('supplier', 'participant')),
  CONSTRAINT CHECK (`state` IN ('pending', 'sending', 'sent', 'uncertain')),
  FOREIGN KEY (`submission_id`) REFERENCES `#__altacourses_request_submissions` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Immutable monthly administrator messages/CSV; no automatic sending or historical backfill.
CREATE TABLE IF NOT EXISTS `#__altacourses_monthly_reports` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `period` char(7) NOT NULL,
  `kind` varchar(10) NOT NULL,
  `recipient` varchar(254) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `csv_payload` mediumtext DEFAULT NULL,
  `filename` varchar(120) DEFAULT NULL,
  `payload_hash` char(64) NOT NULL,
  `language` varchar(5) NOT NULL,
  `message_id` varchar(255) NOT NULL,
  `state` varchar(16) NOT NULL DEFAULT 'pending',
  `attempts` int UNSIGNED NOT NULL DEFAULT '0',
  `attempt_token` char(64) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `claimed_at` datetime DEFAULT NULL,
  `sent_at` datetime DEFAULT NULL,
  `last_error` varchar(80) DEFAULT NULL,
  `reviewed_by` int DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_monthly_period_kind` (`period`,`kind`),
  UNIQUE KEY `idx_monthly_message` (`message_id`),
  CONSTRAINT CHECK (`kind` IN ('report','alert')),
  CONSTRAINT CHECK (`state` IN ('pending','sending','sent','uncertain'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Append-only movement history. Request identity and original accepted submission stay intact.
CREATE TABLE IF NOT EXISTS `#__altacourses_request_rebookings` (
 `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
 `request_id` int UNSIGNED NOT NULL,
 `destination_request_id` int UNSIGNED DEFAULT NULL,
 `from_course_id` int UNSIGNED NOT NULL,
 `to_course_id` int UNSIGNED NOT NULL,
 `from_json` text NOT NULL,
 `to_json` text NOT NULL,
 `supplier_user_id` int NOT NULL,
 `created_at` datetime NOT NULL,
 `created_by` int NOT NULL,
 `request_version` int UNSIGNED NOT NULL,
 `previous_note` text NOT NULL,
 `note` text NOT NULL,
 PRIMARY KEY (`id`),
 UNIQUE KEY `idx_rebooking_revision` (`request_id`,`request_version`),
 UNIQUE KEY `idx_rebooking_destination` (`destination_request_id`),
 KEY `idx_rebooking_request` (`request_id`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Alerts retain the original columns and IDs. Existing imported tables are untouched.
CREATE TABLE IF NOT EXISTS `#__altacourses_alerts` (
 `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
 `name` varchar(255) NOT NULL,
 `alert` text NOT NULL,
 `ordering` int NOT NULL DEFAULT 0,
 `state` int NOT NULL DEFAULT 0,
 `checked_out` int NOT NULL DEFAULT 0,
 `checked_out_time` datetime DEFAULT NULL,
 `created_by` int NOT NULL DEFAULT 0,
 `modified_by` int DEFAULT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Existing imported rows and course_type NULL values are retained.
-- Conditional adoption of an existing table/column and the unique published key
-- is completed by the install/update lifecycle in script.php.
CREATE TABLE IF NOT EXISTS `#__altacourses_mailtemplates` (
 `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
 `type` int NOT NULL,
 `course_type` int DEFAULT NULL,
 `name` varchar(255) NOT NULL,
 `subject` varchar(255) NOT NULL,
 `from_name` varchar(255) NOT NULL,
 `from_email` varchar(255) NOT NULL,
 `message` text NOT NULL,
 `ordering` int NOT NULL DEFAULT 0,
 `state` int DEFAULT NULL,
 `checked_out` int NOT NULL DEFAULT 0,
 `checked_out_time` datetime DEFAULT NULL,
 `created_by` int NOT NULL DEFAULT 0,
 `published_course_type` int GENERATED ALWAYS AS (CASE WHEN `state` = 1 THEN COALESCE(`course_type`, 0) ELSE NULL END) STORED,
 PRIMARY KEY (`id`),
 UNIQUE KEY `idx_mailtemplate_published` (`type`, `published_course_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Accounts retain legacy IDs/columns; new country and note fields are additive.
CREATE TABLE IF NOT EXISTS `#__altacourses_accounts` (
 `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
 `asset_id` int UNSIGNED NOT NULL DEFAULT 0,
 `name` varchar(255) NOT NULL,
 `invoice_address` varchar(255) NOT NULL DEFAULT '',
 `invoice_address_2` varchar(255) NOT NULL DEFAULT '',
 `invoice_zip` varchar(255) NOT NULL DEFAULT '',
 `invoice_city` varchar(255) NOT NULL DEFAULT '',
 `invoice_country` varchar(255) NOT NULL DEFAULT '',
 `note` text NOT NULL,
 `ordering` int NOT NULL DEFAULT 0,
 `state` tinyint NOT NULL DEFAULT 0,
 `checked_out` int NOT NULL DEFAULT 0,
 `checked_out_time` datetime DEFAULT NULL,
 `created_by` int NOT NULL DEFAULT 0,
 `modified_by` int DEFAULT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed the editable global reminder introduction; never replace existing templates.
INSERT INTO `#__altacourses_mailtemplates`
 (`type`,`course_type`,`name`,`subject`,`from_name`,`from_email`,`message`,`state`,`ordering`,`checked_out`,`checked_out_time`,`created_by`)
SELECT 12,0,'Påminnelse om olästa kontakter','Påminnelse om olästa kontakter','Kursadministrationen','noreply@example.invalid',
 'Hej! Här kommer kontakter som enligt vårt system inte har kvitterats. Det kan betyda att mailet inte har kommit fram till dig, att du inte har klickat på läskvittolänken eller att något annat problem har uppstått.
Titta igenom kontakterna nedan, kontakta dem om de inte har blivit kontaktade och klicka på respektive Markera som läst-länk så att vi vet att du har fått kontakten. Mer information finns när du loggar in på sajten.
Varma hälsningar',1,0,0,UTC_TIMESTAMP(),0
WHERE NOT EXISTS (SELECT 1 FROM `#__altacourses_mailtemplates` WHERE `type`=12 AND COALESCE(`course_type`,0)=0);

-- Private delivery archive. No change to request outcomes, reporting dates or old mail.
CREATE TABLE IF NOT EXISTS `#__altacourses_supplier_reminders` (
 `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
 `period` char(7) NOT NULL,
 `supplier_user_id` int NOT NULL,
 `supplier_name` varchar(255) NOT NULL,
 `recipient` varchar(254) NOT NULL,
 `from_email` varchar(254) NOT NULL,
 `from_name` varchar(255) NOT NULL,
 `subject` varchar(255) NOT NULL,
 `body` mediumtext NOT NULL,
 `template_id` int UNSIGNED DEFAULT NULL,
 `message_id` varchar(255) NOT NULL,
 `payload_hash` char(64) NOT NULL,
 `state` varchar(16) NOT NULL DEFAULT 'pending',
 `attempts` int UNSIGNED NOT NULL DEFAULT 0,
 `attempt_token` char(64) DEFAULT NULL,
 `created_at` datetime NOT NULL,
 `claimed_at` datetime DEFAULT NULL,
 `sent_at` datetime DEFAULT NULL,
 `last_error` varchar(80) DEFAULT NULL,
 `reviewed_by` int DEFAULT NULL,
 `reviewed_at` datetime DEFAULT NULL,
 PRIMARY KEY (`id`),
 UNIQUE KEY `idx_supplier_reminder_period` (`period`,`supplier_user_id`),
 KEY `idx_supplier_reminder_state` (`state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Independent last-minute list; preserve imported rows/IDs and other tables.
-- Existing imports receive a primary/automatic ID conditionally in script.php.
CREATE TABLE IF NOT EXISTS `#__altacourses_lastminute` (
 `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
 `firstname` varchar(255) DEFAULT NULL,
 `lastname` varchar(255) DEFAULT NULL,
 `telephone` varchar(255) DEFAULT NULL,
 `email` varchar(255) DEFAULT NULL,
 `participated` varchar(11) DEFAULT '0',
 `notes` text DEFAULT NULL,
 `ordering` int DEFAULT '0',
 `state` tinyint(1) DEFAULT '0',
 `checked_out` int DEFAULT '0',
 `checked_out_time` datetime DEFAULT NULL,
 `created_by` int DEFAULT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Request-based billing plus retained unlinked legacy identities.
-- Conditional rename/engine conversion/index adoption is in script.php.
CREATE TABLE IF NOT EXISTS `#__altacourses_keyaccount` (
 `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
 `request_id` int UNSIGNED DEFAULT NULL,
 `firstname` varchar(255) DEFAULT '',
 `lastname` varchar(255) DEFAULT '',
 `organisation` varchar(255) DEFAULT '',
 `startdate` datetime DEFAULT NULL,
 `invoiced` varchar(11) DEFAULT '0',
 `received` tinyint(1) DEFAULT '0',
 `no_invoicing` tinyint(1) NOT NULL DEFAULT '0',
 `notes` text,
 `ordering` int DEFAULT '0',
 `state` tinyint(1) DEFAULT '1',
 `checked_out` int DEFAULT NULL,
 `checked_out_time` datetime DEFAULT NULL,
 `created_by` int DEFAULT '0',
 PRIMARY KEY (`id`),
 UNIQUE KEY `idx_keyaccount_request` (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Preserve existing evaluations verbatim; new installations use transactional Unicode storage.
CREATE TABLE IF NOT EXISTS `#__altacourses_evaluations` (
 `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
 `request_id` int NOT NULL,
 `rating_overall` tinyint(1) DEFAULT NULL,
 `rating_leaders` tinyint(1) DEFAULT NULL,
 `rating_place` tinyint(1) DEFAULT NULL,
 `review` text, `feedback` text, `response` text,
 `review_published` tinyint(1) DEFAULT NULL,
 `rating_date` datetime DEFAULT CURRENT_TIMESTAMP,
 `feedback_read` tinyint(1) NOT NULL DEFAULT 0,
 `rating_moderate_code` varchar(255) DEFAULT NULL,
 `ordering` int NOT NULL DEFAULT 0,
 `state` tinyint(1) NOT NULL DEFAULT 0,
 `checked_out` int NOT NULL DEFAULT 0,
 `checked_out_time` datetime DEFAULT NULL,
 `created_by` int DEFAULT NULL,
 PRIMARY KEY (`id`), KEY `idx_evaluation_request` (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Private delivery archive. No change to request outcomes, reporting dates or old mail.
CREATE TABLE IF NOT EXISTS `#__altacourses_evaluation_invitations` (
 `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
 `period` char(7) NOT NULL,
 `request_id` int UNSIGNED NOT NULL,
 `client_name` varchar(255) NOT NULL,
 `recipient` varchar(254) NOT NULL,
 `from_email` varchar(254) NOT NULL,
 `from_name` varchar(255) NOT NULL,
 `subject` varchar(255) NOT NULL,
 `body` mediumtext NOT NULL,
 `template_id` int UNSIGNED DEFAULT NULL,
 `message_id` varchar(255) NOT NULL,
 `token_hash` varchar(71) NOT NULL,
 `context_hash` char(64) NOT NULL,
 `payload_hash` char(64) NOT NULL,
 `state` varchar(16) NOT NULL DEFAULT 'pending',
 `attempts` int UNSIGNED NOT NULL DEFAULT 0,
 `attempt_token` char(64) DEFAULT NULL,
 `created_at` datetime NOT NULL,
 `claimed_at` datetime DEFAULT NULL,
 `sent_at` datetime DEFAULT NULL,
 `last_error` varchar(80) DEFAULT NULL,
 `reviewed_by` int DEFAULT NULL,
 `reviewed_at` datetime DEFAULT NULL,
 PRIMARY KEY (`id`),
 UNIQUE KEY `idx_evaluation_invitation_request` (`request_id`),
 KEY `idx_evaluation_invitation_state` (`state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
