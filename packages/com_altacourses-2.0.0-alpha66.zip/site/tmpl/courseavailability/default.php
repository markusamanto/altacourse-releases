<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
\defined('_JEXEC') or die;
?>
<section id="altacourses-courseavailability" aria-labelledby="courseavailability-heading" data-save-url="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&task=courseavailability.save&format=json',false)); ?>" data-refresh-url="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&task=courseavailability.refresh&format=json',false)); ?>">
<h1 id="courseavailability-heading"><?php echo $this->escape(Text::_('COM_ALTACOURSES_INLINE_TITLE')); ?></h1>
<p><?php echo $this->escape(Text::_('COM_ALTACOURSES_INLINE_HELP')); ?></p>
<noscript><p class="alert alert-warning"><?php echo $this->escape(Text::_('COM_ALTACOURSES_INLINE_NOJS')); ?></p></noscript>
<div data-availability-token hidden><?php echo HTMLHelper::_('form.token'); ?></div>
<form method="get" action="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=courseavailability',false)); ?>" class="row g-3 mb-3">
<input type="hidden" name="option" value="com_altacourses"><input type="hidden" name="view" value="courseavailability">
<div class="col-md-4"><label for="availability-period"><?php echo $this->escape(Text::_('COM_ALTACOURSES_MANAGED_PERIOD')); ?></label><select id="availability-period" class="form-select" name="period"><?php foreach(['future'=>'COM_ALTACOURSES_MANAGED_FUTURE','all'=>'COM_ALTACOURSES_MANAGED_ALL_DATES'] as $value=>$key): ?><option value="<?php echo $value; ?>"<?php echo $this->filters['period']===$value?' selected':''; ?>><?php echo $this->escape(Text::_($key)); ?></option><?php endforeach; ?></select></div>
<?php if($this->administrator): ?><div class="col-md-5"><label for="availability-supplier"><?php echo $this->escape(Text::_('COM_ALTACOURSES_OWNER')); ?></label><select id="availability-supplier" class="form-select" name="supplier"><option value="0"><?php echo $this->escape(Text::_('COM_ALTACOURSES_MANAGED_ALL_SUPPLIERS')); ?></option><?php foreach($this->suppliers as $supplier): ?><option value="<?php echo (int)$supplier->id; ?>"<?php echo (int)($this->filters['supplier']??0)===(int)$supplier->id?' selected':''; ?>><?php echo $this->escape($supplier->name); ?></option><?php endforeach; ?></select></div><?php endif; ?>
<div class="col-md-3 align-self-end"><button class="btn btn-primary" type="submit"><?php echo $this->escape(Text::_('COM_ALTACOURSES_FILTER')); ?></button></div>
</form>
<?php if(!$this->items): ?><p><?php echo $this->escape(Text::_('COM_ALTACOURSES_NO_MANAGED_COURSES')); ?></p><?php else: ?>
<div class="table-responsive"><table class="table table-striped"><thead><tr><?php foreach(['COURSE_ID','DATES','COURSE_TYPE','PLACE','LEADERS'] as $key): ?><th scope="col"><?php echo $this->escape(Text::_('COM_ALTACOURSES_'.$key)); ?></th><?php endforeach; ?><?php if($this->administrator): ?><th scope="col"><?php echo $this->escape(Text::_('COM_ALTACOURSES_OWNER')); ?></th><?php endif; ?><th scope="col"><?php echo $this->escape(Text::_('COM_ALTACOURSES_AVAILABILITY')); ?></th></tr></thead><tbody>
<?php foreach($this->items as $item): $current=$item->nr_of_participants===null?'':(string)$item->nr_of_participants;$known=false;foreach($this->choices as $c){if((string)$c->seats===$current){$known=true;}}$editable=$item->editable&&$this->choices!==[]; ?>
<tr data-availability-row="<?php echo (int)$item->id; ?>" data-version="<?php echo (int)$item->version; ?>" data-editable="<?php echo $editable?'1':'0'; ?>">
<td><?php echo (int)$item->id; ?></td><td><?php foreach(array_merge([$item],$this->sessions[(int)$item->id]??[]) as $part): ?><div><?php echo $this->escape(substr($part->start_date??'',0,10)); ?><?php if($part->stop_date&&substr($part->stop_date,0,10)!==substr($part->start_date??'',0,10)): ?> – <?php echo $this->escape(substr($part->stop_date,0,10)); ?><?php endif; ?></div><?php endforeach; ?></td>
<td><?php echo $this->escape($item->course_type??''); ?></td><td><?php echo $this->escape($item->course_place??''); ?></td><td><?php echo $this->escape($item->leader1); ?><?php if($item->leader2!==''): ?><br><?php echo $this->escape($item->leader2); ?><?php endif; ?></td>
<?php if($this->administrator): ?><td><?php echo $this->escape($item->supplier); ?></td><?php endif; ?>
<td><label class="visually-hidden" for="availability-course-<?php echo (int)$item->id; ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_AVAILABILITY')).' — '.(int)$item->id; ?></label><select class="form-select" id="availability-course-<?php echo (int)$item->id; ?>" data-availability-select disabled>
<?php if(!$known): ?><option value="<?php echo $this->escape($current); ?>" selected disabled><?php echo $this->escape(Text::_('COM_ALTACOURSES_INLINE_UNKNOWN')); ?></option><?php endif; ?>
<?php foreach($this->choices as $choice): ?><option value="<?php echo (int)$choice->seats; ?>"<?php echo (string)$choice->seats===$current?' selected':''; ?>><?php echo $this->escape($choice->label); ?></option><?php endforeach; ?></select>
<p class="small mb-1" data-availability-status role="status" aria-live="polite"><?php echo $editable?'':$this->escape($item->reason); ?></p>
<button type="button" class="btn btn-sm btn-secondary" data-availability-refresh hidden><?php echo $this->escape(Text::_('COM_ALTACOURSES_INLINE_RELOAD')); ?></button></td>
</tr><?php endforeach; ?></tbody></table></div>
<?php echo $this->pagination->getPagesLinks(); ?><p><?php echo $this->escape($this->pagination->getPagesCounter()); ?></p>
<?php endif; ?></section>
