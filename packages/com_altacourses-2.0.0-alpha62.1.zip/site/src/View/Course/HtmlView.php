<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\View\Course;

use Joomla\CMS\Language\Text;
use Advenire\Component\Altacourses\Site\Helper\CourseArticle;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;

\defined('_JEXEC') or die;

final class HtmlView extends BaseHtmlView
{

    public ?object $item = null;
    public array $articles = [];
    public array $sessions = [];
    public array $filters = [];
    public bool $canEnquire = false;
    public bool $canSignup = false;
    public string $heading = '';
    public string $totalPrice = '';

    public function articleHref(mixed $value): ?string
    {
        return CourseArticle::href($this->articles,$value,(int)$this->item->id);
    }

    public function display($tpl = null): void
    {
        $context=$this->getModel()->getPublicDetails();$this->item=$context['course'];$amount=$context['amount'];
        $this->totalPrice = $amount === null ? '—' : $amount . ' ' . Text::_('COM_ALTACOURSES_CURRENCY');
        $this->sessions=$context['sessions'];
        $this->articles=$this->getModel('Courses')->getArticles([$this->item->place_article,$this->item->leader1_article,$this->item->leader2_article],$this->getDocument()->getLanguage());
        $this->heading=Text::_('COM_ALTACOURSES_COURSE_INFO_TITLE');
        $this->getDocument()->setTitle($this->heading.' – '.($this->item->course_type??'').' – '.($this->item->course_place??''));
        $this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.site');
        parent::display($tpl);
    }
}
