<?php

/** @package Altacourses.Administrator @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Administrator\Service;

use Joomla\CMS\Language\LanguageFactoryInterface;
use Joomla\CMS\Mail\Mail;
use Joomla\CMS\Mail\MailerFactoryInterface;
use Joomla\CMS\String\PunycodeHelper;
use Joomla\Database\DatabaseInterface;
use Joomla\Registry\Registry;

\defined('_JEXEC') or die;

/** Private monthly archive. Claims precede SMTP; ambiguous sends require operator review. */
final class MonthlyReport
{
    public function __construct(private readonly DatabaseInterface $db, private readonly Registry $config,
        private readonly CommissionReport $commissions, private readonly NotificationService $notifications,
        private readonly MailerFactoryInterface $mailers, private readonly LanguageFactoryInterface $languages) {}

    public function settings(): array
    {
        $p = json_decode($this->db->setQuery("SELECT params FROM #__extensions WHERE element='com_altacourses' AND type='component' AND enabled=1")->loadResult() ?: '{}', true, flags: JSON_THROW_ON_ERROR);
        return ['mode' => $p['monthly_mode'] ?? 'off', 'recipient' => (string) ($p['monthly_recipient'] ?? ''),
            'language' => ($p['monthly_language'] ?? 'sv-SE') === 'en-GB' ? 'en-GB' : 'sv-SE'];
    }

    public function blockedReason(): ?string
    {
        $s = $this->settings();
        return $this->notifications->sandboxReason($s['mode'] === 'sandbox')
            ?? ($this->notifications->validAddress($s['recipient']) ? null : 'invalid_recipient');
    }

    public function previousMonth(): string { return $this->commissions->previousMonth(); }
    public function messages(string $month): array
    {
        $this->commissions->bounds($month);
        $q = $this->db->createQuery()->select('*')->from('#__altacourses_monthly_reports')->where('period=:period')->bind(':period', $month)->order('id');
        return $this->db->setQuery($q)->loadObjectList();
    }

    public function runDue(): string { return $this->runPeriod($this->previousMonth()); }

    /** Also used by the protected explicit test/recovery form; no manual CSV prerequisite. */
    public function runPeriod(string $month, int $actor = 0): string
    {
        $this->commissions->bounds($month);
        if ($this->blockedReason() !== null) { return 'blocked'; }
        $messages = $this->messages($month);
        $report = array_values(array_filter($messages, static fn ($r): bool => $r->kind === 'report'));
        if (!$report) {
            $data = $this->commissions->read($month);
            $settings = $this->settings();
            $language = $this->languages->createLanguage($settings['language']);
            $language->load('com_altacourses', JPATH_SITE . '/components/com_altacourses', $settings['language'], true);
            $text = static fn (string $key): string => $language->_('COM_ALTACOURSES_' . $key);
            if ($data['missing']) {
                $existing = array_filter($messages, static fn ($r): bool => $r->kind === 'alert');
                if (!$existing) {
                    $names = [];
                    foreach ($data['groups'] as $group) { if ($group['missing']) { $names[] = $group['name']; } }
                    $this->insert($month, 'alert', $settings, $text('MONTHLY_ALERT_SUBJECT'),
                        sprintf($text('MONTHLY_ALERT_BODY'), $month, implode(', ', $names)), null);
                }
            } else {
                $headers = array_map($text, ['COMMISSION_SUPPLIER', 'COURSE_TYPE', 'DATES', 'ENQUIRY_NAME', 'ENQUIRY_ORGANISATION', 'COMMISSION_AMOUNT', 'PARTICIPATION_NOTE']);
                // Fee snapshots and the corresponding attachment commit or roll back together.
                $this->commissions->captureCsv($month, $data['fingerprint'], $actor, $headers, true,
                    function (string $csv) use ($month, $settings, $text, $data): void {
                        $this->insert($month, 'report', $settings, $text('MONTHLY_REPORT_SUBJECT'),
                            sprintf($text('MONTHLY_REPORT_BODY'), $month, count($data['rows']), $data['total']), $csv);
                    });
            }
        }
        foreach ($this->messages($month) as $row) {
            // A resolved missing-rate alert need not be delivered after the report exists.
            if ($row->state === 'pending' && ($row->kind === 'report' || !$this->hasReport($month))) { $this->deliver($row); }
        }
        foreach ($this->messages($month) as $row) { if ($row->state !== 'sent' && ($row->kind === 'report' || !$this->hasReport($month))) { return 'review'; } }
        return 'complete';
    }

    private function hasReport(string $month): bool
    {
        foreach ($this->messages($month) as $row) { if ($row->kind === 'report') { return true; } }
        return false;
    }

    private function insert(string $month, string $kind, array $settings, string $title, string $body, ?string $csv): void
    {
        $row = (object) ['period' => $month, 'kind' => $kind, 'recipient' => $settings['recipient'],
            'subject' => '[TEST] ' . $title . ' ' . $month, 'body' => $body,
            'csv_payload' => $csv, 'filename' => $csv === null ? null : 'altacourses-' . $month . '.csv',
            'language' => $settings['language'], 'message_id' => '<' . bin2hex(random_bytes(24)) . '@altacourses.invalid>',
            'state' => 'pending', 'attempts' => 0, 'created_at' => $this->now()];
        $row->payload_hash = $this->digest($row);
        $this->db->insertObject('#__altacourses_monthly_reports', $row, 'id');
    }

    private function digest(object $row): string
    {
        return hash('sha256', json_encode([$row->period, $row->kind, $row->recipient, $row->subject, $row->body,
            $row->csv_payload, $row->filename, $row->language, $row->message_id], JSON_THROW_ON_ERROR));
    }

    private function deliver(object $row): void
    {
        if ($this->blockedReason() !== null) { return; }
        if (!hash_equals($row->payload_hash, $this->digest($row)) || !$this->notifications->validAddress($row->recipient)) {
            throw new \RuntimeException('Monthly archive integrity check failed');
        }
        $token = bin2hex(random_bytes(32));
        $q = $this->db->createQuery()->update('#__altacourses_monthly_reports')->set("state='sending', attempts=attempts+1")
            ->set('attempt_token=' . $this->db->quote($token))->set('claimed_at=' . $this->db->quote($this->now()))
            ->where('id=' . (int) $row->id)->where("state='pending'");
        $this->db->setQuery($q)->execute();
        if ($this->db->getAffectedRows() !== 1) { return; }
        $mailer = null; $accepted = false;
        try {
            $mailer = $this->mailers->createMailer(new Registry(['throw_exceptions' => true]));
            if (!$mailer instanceof Mail) { throw new \RuntimeException('Unsupported mailer'); }
            $mailer->SMTPAutoTLS = false; $mailer->Timeout = 10; $mailer->getSMTPInstance()->Timelimit = 10; $mailer->SMTPDebug = 0;
            $mailer->MessageID = $row->message_id;
            $mailer->setSender(PunycodeHelper::emailToPunycode((string) $this->config->get('mailfrom')), (string) $this->config->get('fromname'));
            $mailer->addRecipient($row->recipient); $mailer->setSubject($row->subject); $mailer->setBody($row->body);
            if ($row->csv_payload !== null) { $mailer->addStringAttachment($row->csv_payload, $row->filename, 'base64', 'text/csv'); }
            if ($mailer->send() !== true) { throw new \RuntimeException('No SMTP acceptance'); }
            $accepted = true;
            $this->finish((int) $row->id, $token, 'sent', null);
        } catch (\Throwable $error) {
            $this->finish((int) $row->id, $token, 'uncertain', $this->notifications->failureDiagnostic($mailer instanceof Mail ? $mailer : null, $error, $accepted));
        }
    }

    private function finish(int $id, string $token, string $state, ?string $diagnostic): void
    {
        $q = $this->db->createQuery()->update('#__altacourses_monthly_reports')
            ->set('state=' . $this->db->quote($state))->set('last_error=' . ($diagnostic === null ? 'NULL' : $this->db->quote($diagnostic)))
            ->where('id=' . $id)->where("state='sending'")->where('attempt_token=' . $this->db->quote($token));
        if ($state === 'sent') { $q->set('sent_at=' . $this->db->quote($this->now())); }
        $this->db->setQuery($q)->execute();
        if ($this->db->getAffectedRows() !== 1) { throw new \RuntimeException('Monthly delivery state changed'); }
    }

    public function getMessage(string $month, int $id): object
    {
        foreach ($this->messages($month) as $row) { if ((int) $row->id === $id) { return $row; } }
        throw new \RuntimeException('Monthly report not found', 404);
    }

    /** Review token prevents an old browser form from retrying a newer delivery attempt. */
    public function review(string $month, int $id, string $token, int $actor, bool $captured): void
    {
        $row = $this->getMessage($month, $id);
        if ($actor <= 0 || !hash_equals((string) $row->attempt_token, $token)
            || !($row->state === 'uncertain' || ($row->state === 'sending' && strtotime($row->claimed_at . ' UTC') < time() - 300))) {
            throw new \RuntimeException('Monthly delivery changed; reload and review Mailtrap', 409);
        }
        if (!$captured && $this->blockedReason() !== null) { throw new \RuntimeException('Monthly mail disabled or unsafe', 409); }
        $q = $this->db->createQuery()->update('#__altacourses_monthly_reports')
            ->set($captured ? "state='sent'" : "state='pending'")
            ->set('reviewed_by=' . $actor)->set('reviewed_at=' . $this->db->quote($this->now()))
            ->set('last_error=' . $this->db->quote($captured ? 'operator_confirmed' : 'operator_retry'))
            ->where('id=' . $id)->where('state=' . $this->db->quote($row->state))->where('attempt_token=' . $this->db->quote($token));
        if ($captured) { $q->set('sent_at=' . $this->db->quote($this->now())); }
        $this->db->setQuery($q)->execute();
        if ($this->db->getAffectedRows() !== 1) { throw new \RuntimeException('Monthly delivery changed', 409); }
        if (!$captured) { $row->state = 'pending'; $this->deliver($row); }
    }

    private function now(): string { return gmdate('Y-m-d H:i:s'); }
}
