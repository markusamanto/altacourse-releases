<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
\defined('_JEXEC') or die;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
$s=$this->statistics;$number=static fn($value,$places=0)=>number_format($value,$places,Text::_('DECIMALS_SEPARATOR'),Text::_('THOUSANDS_SEPARATOR'));$money=static fn($value)=>$number($value,2).' SEK';$action=$this->escape(Route::_('index.php?option=com_altacourses&view=dashboard',false));
?>
<section data-dashboard-statistics aria-labelledby="altacourses-statistics-heading">
 <h2 id="altacourses-statistics-heading"><?php echo $this->escape(Text::_('COM_ALTACOURSES_STATS_TITLE')); ?></h2>
 <form action="<?php echo $action; ?>" method="get" class="mb-3" data-statistics-filter>
  <input type="hidden" name="option" value="com_altacourses"><input type="hidden" name="view" value="dashboard">
  <?php if($s['year']!==null): ?><input type="hidden" name="stats_year" value="<?php echo (int)$s['year']; ?>"><?php endif; ?>
  <label for="statistics-type"><?php echo $this->escape(Text::_('COM_ALTACOURSES_STATS_TYPE')); ?></label>
  <select id="statistics-type" name="stats_type" class="form-select mb-2"><option value="0"><?php echo $this->escape(Text::_('COM_ALTACOURSES_STATS_ALL')); ?></option><?php foreach($this->statisticsTypes as $type): ?><option value="<?php echo (int)$type->id; ?>"<?php echo (int)$type->id===$s['type']?' selected':''; ?>><?php echo $this->escape($type->name); ?></option><?php endforeach; ?></select>
  <button type="submit" class="btn btn-primary"><?php echo $this->escape(Text::_('COM_ALTACOURSES_STATS_APPLY')); ?></button>
 </form>
 <?php if($s['sections']['activity']): ?>
 <section class="card mb-3" data-statistics-section="activity" aria-labelledby="statistics-activity-heading"><h3 class="card-header" id="statistics-activity-heading"><?php echo $this->escape(Text::_('COM_ALTACOURSES_STATS_ACTIVITY')); ?></h3><div class="card-body"><table class="table table-striped"><tbody>
 <?php foreach(['signups24'=>'SIGNUPS24','enquiries24'=>'ENQUIRIES24','signups7'=>'SIGNUPS7','enquiries7'=>'ENQUIRIES7'] as $key=>$label): ?><tr><th scope="row"><?php echo $this->escape(Text::_('COM_ALTACOURSES_STATS_'.$label)); ?></th><td data-statistic="<?php echo $key; ?>"><?php echo $this->escape($number($s['counts'][$key])); ?></td></tr><?php endforeach; ?>
 <tr><th scope="row"><?php echo $this->escape(Text::sprintf('COM_ALTACOURSES_STATS_AVERAGE',$s['currentYear'])); ?></th><td data-statistic="average"><?php echo $this->escape($number($s['average'],2)); ?></td></tr>
 </tbody></table><p class="small"><?php echo $this->escape(Text::_('COM_ALTACOURSES_STATS_COUNT_HELP')); ?></p></div></section>
 <?php endif; ?>
 <?php if($s['sections']['forecast']): ?>
 <section class="card mb-3" data-statistics-section="forecast" aria-labelledby="statistics-forecast-heading"><h3 class="card-header" id="statistics-forecast-heading"><?php echo $this->escape(Text::_('COM_ALTACOURSES_STATS_FORECAST')); ?></h3><div class="card-body"><table class="table table-striped"><tbody>
 <?php foreach(['predicted'=>'PREDICTED','income'=>'INCOME','goal'=>'GOAL'] as $key=>$label): ?><tr><th scope="row"><?php echo $this->escape(Text::_('COM_ALTACOURSES_STATS_'.$label)); ?></th><td data-statistic="<?php echo $key; ?>"><?php echo $this->escape($key==='predicted'?$number($s[$key]):$money($s[$key])); ?></td></tr><?php endforeach; ?>
 </tbody></table><p class="small"><?php echo $this->escape(Text::sprintf('COM_ALTACOURSES_STATS_COMMISSION_HELP',$money($s['commission']))); ?></p></div></section>
 <?php endif; ?>
 <?php if($s['sections']['analysis']): ?>
 <section class="card mb-3" data-statistics-section="analysis" aria-labelledby="statistics-analysis-heading"><h3 class="card-header" id="statistics-analysis-heading"><?php echo $this->escape(Text::_('COM_ALTACOURSES_STATS_ANALYSIS')); ?></h3><div class="card-body">
 <form action="<?php echo $action; ?>" method="get" data-statistics-analysis><input type="hidden" name="option" value="com_altacourses"><input type="hidden" name="view" value="dashboard"><input type="hidden" name="stats_type" value="<?php echo (int)$s['type']; ?>">
 <label for="statistics-year"><?php echo $this->escape(Text::_('COM_ALTACOURSES_STATS_YEAR')); ?></label><select id="statistics-year" name="stats_year" class="form-select mb-2" required><option value=""><?php echo $this->escape(Text::_('COM_ALTACOURSES_STATS_SELECT_YEAR')); ?></option><?php for($year=$s['currentYear'];$year>=2009;$year--): ?><option value="<?php echo $year; ?>"<?php echo $s['year']===$year?' selected':''; ?>><?php echo $year; ?></option><?php endfor; ?></select><button type="submit" class="btn btn-primary"><?php echo $this->escape(Text::_('COM_ALTACOURSES_STATS_ANALYSE')); ?></button></form>
 <?php if($s['analysis']!==null): ?><h4 class="mt-3"><?php echo $this->escape(Text::_('COM_ALTACOURSES_STATS_RESULT')); ?></h4><table class="table table-striped" data-statistics-result><tbody><?php foreach(['year'=>'YEAR','signups'=>'SIGNUPS','enquiries'=>'ENQUIRIES'] as $key=>$label): ?><tr><th scope="row"><?php echo $this->escape(Text::_('COM_ALTACOURSES_STATS_'.$label)); ?></th><td data-analysis="<?php echo $key; ?>"><?php echo $this->escape($key==='year'?(string)$s['analysis'][$key]:$number($s['analysis'][$key])); ?></td></tr><?php endforeach; ?></tbody></table><?php endif; ?>
 </div></section>
 <?php endif; ?>
</section>
