<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Model;

use Advenire\Component\Altacourses\Site\Exception\CourseValidationException;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Form\FormFactoryAwareInterface;
use Joomla\CMS\Form\FormFactoryAwareTrait;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\BaseModel;
use Joomla\CMS\User\CurrentUserInterface;
use Joomla\CMS\User\User;
use Joomla\CMS\User\UserFactoryAwareInterface;
use Joomla\CMS\User\UserFactoryAwareTrait;
use Joomla\Database\DatabaseAwareInterface;
use Joomla\Database\DatabaseAwareTrait;
use Joomla\Database\ParameterType;

\defined('_JEXEC') or die;

/** Mailtemplate management uses the original table and IDs; no delete operation. */
final class MailtemplatesModel extends BaseModel implements DatabaseAwareInterface, CurrentUserInterface, UserFactoryAwareInterface, FormFactoryAwareInterface
{
    use DatabaseAwareTrait;
    use UserFactoryAwareTrait;
    use FormFactoryAwareTrait;

    private ?User $currentUser = null;

    public function setCurrentUser(User $currentUser): void
    {
        $this->currentUser = $currentUser;
    }

    public function requireAdministrator(): void
    {
        $user = $this->currentUser;
        if ($user === null || $user->guest || $user->block
            || !$user->authorise('altacourses.manage', 'com_altacourses')) {
            throw new \RuntimeException(Text::_('JERROR_MAILTEMPLATENOAUTHOR'), 403);
        }
        $fresh = $this->getUserFactory()->loadUserById((int) $user->id);
        if ($fresh->guest || $fresh->block || !$fresh->authorise('altacourses.manage', 'com_altacourses')) {
            throw new \RuntimeException(Text::_('JERROR_MAILTEMPLATENOAUTHOR'), 403);
        }
    }

    public function getItems(?int $courseType = null): array
    {
        $this->requireAdministrator();
        $db = $this->getDatabase();
        $query = $db->createQuery()->select(['m.id', 'm.type', 'm.course_type', 'm.subject', 'm.from_name', 'm.from_email', 'm.state', 'c.name AS course_type_name'])
            ->from($db->quoteName('#__altacourses_mailtemplates', 'm'))
            ->join('LEFT', $db->quoteName('#__altacourses_coursetypes', 'c') . ' ON c.id = m.course_type')
            ->order('m.type, COALESCE(m.course_type, 0), m.id');
        if ($courseType !== null) {
            $query->where('COALESCE(m.course_type, 0) = :course_type')->bind(':course_type', $courseType, ParameterType::INTEGER);
        }
        return $db->setQuery($query)->loadObjectList();
    }

    public function getCourseTypeChoices(): array
    {
        $this->requireAdministrator();
        $db = $this->getDatabase();
        return $db->setQuery($db->createQuery()->select(['id', 'name', 'state'])
            ->from($db->quoteName('#__altacourses_coursetypes'))->where('state IN (0, 1, 2)')->order('name, id'))->loadObjectList();
    }

    public function getRecord(int $id): ?object
    {
        $this->requireAdministrator();
        if ($id === 0) {
            return null;
        }
        $db = $this->getDatabase();
        $query = $db->createQuery()->select('*')->from($db->quoteName('#__altacourses_mailtemplates'))
            ->where($db->quoteName('id') . ' = :id')->bind(':id', $id, ParameterType::INTEGER);
        $record = $db->setQuery($query)->loadObject();
        if ($record === null) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_MAILTEMPLATE_NOT_FOUND'), 404);
        }
        $this->requireUnlocked($record);
        return $record;
    }

    /** A fingerprint avoids adding a migration-only revision column to the legacy table. */
    public function formData(?object $record): array
    {
        return [
            'id' => (string) ($record->id ?? 0),
            'type' => $record === null ? '' : (string) $record->type,
            'course_type' => (string) ($record->course_type ?? 0),
            'subject' => (string) ($record->subject ?? ''),
            'from_name' => (string) ($record->from_name ?? ''),
            'from_email' => (string) ($record->from_email ?? ''),
            'message' => (string) ($record->message ?? ''),
            'state' => $record === null ? '1' : (string) $record->state,
            'version' => $record === null ? '' : hash('sha256', json_encode($record, JSON_THROW_ON_ERROR)),
        ];
    }

    public function getForm(array $data): Form
    {
        $this->requireAdministrator();
        $form = $this->getFormFactory()->createForm('com_altacourses.mailtemplate', ['control' => 'jform']);
        if (!$form->loadFile(dirname(__DIR__, 2) . '/forms/mailtemplate.xml')) {
            throw new \RuntimeException('Mail template form could not be loaded');
        }
        $field = new \SimpleXMLElement('<field name="course_type" type="list" label="COM_ALTACOURSES_COURSE_TYPE" filter="raw" required="true" />');
        $option = $field->addChild('option', Text::_('COM_ALTACOURSES_MAILTEMPLATE_ANY_TYPE'));
        $option->addAttribute('value', '0');
        $ids = [0];
        foreach ($this->getCourseTypeChoices() as $choice) {
            $option = $field->addChild('option');
            $option->addAttribute('value', (string) $choice->id);
            $option[0] = $choice->name . ' (#' . $choice->id . ')' . ((int) $choice->state === 1 ? '' : ' — ' . Text::_((int) $choice->state === 0 ? 'JUNPUBLISHED' : 'JARCHIVED'));
            $ids[] = (int) $choice->id;
        }
        $record = $this->getRecord((int) ($data['id'] ?? 0));
        $old = (int) ($record->course_type ?? 0);
        if ($old > 0 && !in_array($old, $ids, true)) {
            $option = $field->addChild('option', Text::sprintf('COM_ALTACOURSES_MAILTEMPLATE_KEEP_TYPE', $old));
            $option->addAttribute('value', (string) $old);
        }
        $form->setField($field);
        $form->bind($data);
        return $form;
    }

    public function saveMailtemplate(int $id, string $version, array $input): int
    {
        $this->requireAdministrator();
        $fields = ['type', 'course_type', 'subject', 'from_name', 'from_email', 'message', 'state'];
        if (array_diff(array_keys($input), $fields) || count($input) !== count($fields)) {
            throw new CourseValidationException([Text::_('COM_ALTACOURSES_MAILTEMPLATE_INVALID')]);
        }
        foreach ($input as $field => $value) {
            if (!is_string($value) || !mb_check_encoding($value, 'UTF-8')) {
                throw new CourseValidationException([Text::_('COM_ALTACOURSES_MAILTEMPLATE_INVALID')]);
            }
            if ($field === 'message') {
                if (strlen($value) > 65535 || preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', $value)) {
                    throw new CourseValidationException([Text::_('COM_ALTACOURSES_MAILTEMPLATE_INVALID')]);
                }
            } elseif (mb_strlen($value) > 255 || preg_match('/[\x00-\x1F\x7F]/u', $value)) {
                throw new CourseValidationException([Text::_('COM_ALTACOURSES_MAILTEMPLATE_INVALID')]);
            }
        }
        if (!preg_match('/^-?[0-9]+$/D', $input['type']) || (float) $input['type'] < -2147483648 || (float) $input['type'] > 2147483647
            || !ctype_digit($input['course_type']) || (float) $input['course_type'] > 2147483647 || !in_array($input['state'], ['0', '1'], true)) {
            throw new CourseValidationException([Text::_('COM_ALTACOURSES_MAILTEMPLATE_INVALID')]);
        }
        $input['type'] = (string) (int) $input['type'];
        $input['course_type'] = (string) (int) $input['course_type'];
        $record = $this->getRecord($id);
        if (($id === 0 && $version !== '') || ($record !== null && !hash_equals($this->formData($record)['version'], $version))) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_MAILTEMPLATE_CONFLICT'), 409);
        }
        $courseType = (int) $input['course_type'];
        if ($courseType > 0 && $courseType !== (int) ($record->course_type ?? 0)
            && !in_array($courseType, array_map(static fn ($choice): int => (int) $choice->id, $this->getCourseTypeChoices()), true)) {
            throw new CourseValidationException([Text::_('COM_ALTACOURSES_MAILTEMPLATE_INVALID')]);
        }
        $form = $this->getForm(['id' => $id] + $input);
        if (!$form->validate(['id' => $id] + $input)) {
            throw new CourseValidationException([Text::_('COM_ALTACOURSES_MAILTEMPLATE_INVALID')]);
        }
        $db = $this->getDatabase();
        $type = (int) $input['type'];
        if ($input['state'] === '1' && $this->publishedExists($type, $courseType, $id)) {
            throw new CourseValidationException([Text::_('COM_ALTACOURSES_MAILTEMPLATE_DUPLICATE')]);
        }
        $row = (object) $input;
        $row->type = $type;
        $row->course_type = $courseType;
        $row->state = (int) $input['state'];
        try {
            if ($id === 0) {
                $row->name = $row->subject;
                $row->ordering = 0;
                $row->checked_out = 0;
                $row->checked_out_time = gmdate('Y-m-d H:i:s');
                $row->created_by = (int) $this->currentUser->id;
                $db->insertObject('#__altacourses_mailtemplates', $row, 'id');
                return (int) $row->id;
            }
            $query = $db->createQuery()->update($db->quoteName('#__altacourses_mailtemplates'));
            $changes = get_object_vars($row);
            foreach ($changes as $column => &$value) {
                $query->set($db->quoteName($column) . ' = :new_' . $column)->bind(':new_' . $column, $value);
            }
            unset($value);
            $query->where('id = :id')->bind(':id', $id, ParameterType::INTEGER);
            $original = [];
            foreach (get_object_vars($record) as $column => $value) {
                $field = $db->quoteName($column);
                if ($value === null) { $query->where($field . ' IS NULL'); }
                else {
                    $key = ':original' . count($original);
                    $original[$key] = (string) $value;
                    $query->where('CAST(' . $field . ' AS BINARY) = CAST(' . $key . ' AS BINARY)')->bind($key, $original[$key]);
                }
            }
            $db->setQuery($query)->execute();
            if ($db->getAffectedRows() === 0) {
                $current = $this->getRecord($id);
                if (!hash_equals($this->formData($current)['version'], $version)
                    || array_diff_assoc($input, array_intersect_key($this->formData($current), $input))) {
                    throw new \RuntimeException(Text::_('COM_ALTACOURSES_MAILTEMPLATE_CONFLICT'), 409);
                }
            }
            return $id;
        } catch (\Throwable $exception) {
            // The unique generated key also protects concurrent publish/create attempts.
            if ($input['state'] === '1' && $this->publishedExists($type, $courseType, $id)) {
                throw new CourseValidationException([Text::_('COM_ALTACOURSES_MAILTEMPLATE_DUPLICATE')]);
            }
            throw $exception;
        }
    }

    private function publishedExists(int $type, int $courseType, int $exceptId): bool
    {
        $db = $this->getDatabase();
        $query = $db->createQuery()->select('COUNT(*)')->from($db->quoteName('#__altacourses_mailtemplates'))
            ->where('type = :type')->bind(':type', $type, ParameterType::INTEGER)
            ->where('COALESCE(course_type, 0) = :course_type')->bind(':course_type', $courseType, ParameterType::INTEGER)
            ->where('state = 1')->where('id <> :id')->bind(':id', $exceptId, ParameterType::INTEGER);
        return (int) $db->setQuery($query)->loadResult() > 0;
    }

    private function requireUnlocked(object $record): void
    {
        if ((int) $record->checked_out !== 0 && (int) $record->checked_out !== (int) $this->currentUser->id) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_AVAILABILITY_LOCKED'), 409);
        }
    }
}
