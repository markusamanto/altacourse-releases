<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\View\Courseplace;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;

\defined('_JEXEC') or die;

final class HtmlView extends BaseHtmlView
{
    public ?\Joomla\CMS\Form\Form $form = null;
    public int $courseplaceId = 0;

    public function display($tpl = null): void
    {
        $this->getModel()->requireAdministrator();

        $this->getDocument()->setTitle(Text::_(($this->courseplaceId === 0 ? 'COM_ALTACOURSES_COURSEPLACE_ADD' : 'COM_ALTACOURSES_COURSEPLACE_EDIT')));
        $this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.site');
        parent::display($tpl);
    }
}
