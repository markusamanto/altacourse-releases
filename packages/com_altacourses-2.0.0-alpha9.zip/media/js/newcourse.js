document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('altacourses-newcourse-form');
    const button = document.getElementById('altacourses-toggle-session');
    const group = document.getElementById('altacourses-second-session');
    if (!form || !button || !group) return;
    const dates = [...group.querySelectorAll('input[type="date"]')];
    const show = (visible) => {
        group.hidden = !visible;
        group.disabled = !visible;
        dates.forEach((input) => { input.required = visible; });
        button.setAttribute('aria-expanded', String(visible));
        button.textContent = visible ? button.dataset.remove : button.dataset.add;
    };
    button.hidden = false;
    show(dates.some((input) => input.value !== '' || input.getAttribute('value') !== ''));
    button.addEventListener('click', () => show(group.hidden));
});
