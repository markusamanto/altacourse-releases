-- Seed the editable global reminder introduction; never replace existing templates.
INSERT INTO `#__altacourses_mailtemplates`
 (`type`,`course_type`,`name`,`subject`,`from_name`,`from_email`,`message`,`state`,`ordering`,`checked_out`,`checked_out_time`,`created_by`)
SELECT 12,0,'Påminnelse om olästa kontakter','Påminnelse om olästa kontakter','Kursadministrationen','noreply@example.invalid',
 'Hej! Här kommer kontakter som enligt vårt system inte har kvitterats. Det kan betyda att mailet inte har kommit fram till dig, att du inte har klickat på läskvittolänken eller att något annat problem har uppstått.
Titta igenom kontakterna nedan, kontakta dem om de inte har blivit kontaktade och klicka på respektive Markera som läst-länk så att vi vet att du har fått kontakten. Mer information finns när du loggar in på sajten.
Varma hälsningar',1,0,0,UTC_TIMESTAMP(),0
WHERE NOT EXISTS (SELECT 1 FROM `#__altacourses_mailtemplates` WHERE `type`=12 AND COALESCE(`course_type`,0)=0);
