<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */
namespace Advenire\Component\Altacourses\Site\Controller;

\defined('_JEXEC') or die;

final class SignupController extends SubmissionController
{
    protected const MODE = 'signup';
    protected const MODEL = 'Signup';
}
