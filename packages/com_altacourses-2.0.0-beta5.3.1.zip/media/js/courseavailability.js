/** Independent row autosaves; uncertain results require an explicit read before another write. */
document.addEventListener('DOMContentLoaded', () => {
 const root = document.getElementById('altacourses-courseavailability');
 if (!root) return;
 const token = root.querySelector('[data-availability-token] input');
 if (!token) return;
 const text = key => Joomla.Text._('COM_ALTACOURSES_INLINE_' + key);
 let pending = 0;
 const send = async (url, data) => {
  const body = new URLSearchParams({ [token.name]: token.value });
  for (const [key, value] of Object.entries(data)) body.set('jform[' + key + ']', String(value));
  const controller = new AbortController(), timeout = setTimeout(() => controller.abort(), 12000);
  try {
   const response = await fetch(url, { method: 'POST', body, credentials: 'same-origin', cache: 'no-store', redirect: 'error', signal: controller.signal });
   if (!response.headers.get('content-type')?.includes('application/json')) throw new Error(text('ERROR'));
   const result = await response.json();
   if (!response.ok || result.success !== true) { const error = new Error(text('ERROR')); error.userMessage = response.status === 403 ? text('SESSION') : (typeof result.message === 'string' ? result.message : ''); throw error; }
   return result.data;
  } finally { clearTimeout(timeout); }
 };
 root.querySelectorAll('[data-availability-row]').forEach(row => {
  const select = row.querySelector('[data-availability-select]'), status = row.querySelector('[data-availability-status]'), reload = row.querySelector('[data-availability-refresh]');
  const id = Number(row.dataset.availabilityRow);
  let version = Number(row.dataset.version), busy = false;
  select.disabled = row.dataset.editable !== '1';
  const begin = key => { busy = true; pending++; select.disabled = true; reload.disabled = true; status.classList.remove('text-success', 'text-danger'); status.textContent = text(key); };
  const end = () => { busy = false; pending--; reload.disabled = false; };
  const fail = error => { select.disabled = true; reload.hidden = false; status.classList.add('text-danger'); status.textContent = (error.userMessage ? error.userMessage + ' ' : '') + text('ERROR'); };
  select.addEventListener('change', async () => {
   if (busy || select.disabled) return;
   const value = Number(select.value), previous = version;
   begin('SAVING');
   try {
    const data = await send(root.dataset.saveUrl, { id, availability: value, version: previous });
    if (data.id !== id || data.availability !== value || data.version !== previous + 1) throw new Error(text('ERROR'));
    version = data.version; row.dataset.version = String(version); select.disabled = false; reload.hidden = true; status.classList.add('text-success'); status.textContent = text('SAVED');
   } catch (error) { fail(error); } finally { end(); }
  });
  reload.addEventListener('click', async () => {
   if (busy) return;
   begin('REFRESHING');
   try {
    const data = await send(root.dataset.refreshUrl, { id });
    if (data.id !== id || !Number.isInteger(data.version) || data.version < 0 || !Array.isArray(data.choices) || typeof data.editable !== 'boolean') throw new Error(text('ERROR'));
    const current = data.availability === null ? '' : String(data.availability);
    if (data.choices.some(choice => !Number.isInteger(choice.value) || ![1, 2, 3, 4].includes(choice.value) || typeof choice.label !== 'string')) throw new Error(text('ERROR'));
    select.replaceChildren();
    if (!data.choices.some(choice => String(choice.value) === current)) { const option = new Option(text('UNKNOWN'), current, true, true); option.disabled = true; select.add(option); }
    data.choices.forEach(choice => select.add(new Option(choice.label, String(choice.value), false, String(choice.value) === current)));
    version = data.version; row.dataset.version = String(version); row.dataset.editable = data.editable ? '1' : '0'; select.disabled = !data.editable; reload.hidden = true; status.textContent = data.editable ? text('REFRESHED') : (data.reason || text('READONLY'));
   } catch (error) { fail(error); } finally { end(); }
  });
 });
 window.addEventListener('beforeunload', event => { if (pending) { event.preventDefault(); event.returnValue = ''; } });
});
