<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;
?>
<section class="altacourses-portal" aria-labelledby="altacourses-courseplaces-heading">
    <h1 id="altacourses-courseplaces-heading"><?php echo $this->escape(Text::_('COM_ALTACOURSES_COURSEPLACES_TITLE')); ?></h1>
    <p><a href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=dashboard', false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_BACK_TO_DASHBOARD')); ?></a></p>
    <p><a class="btn btn-success" href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=courseplace&fresh=1', false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_COURSEPLACE_ADD')); ?></a></p>
    <?php if (!$this->items) : ?>
        <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_COURSEPLACES_EMPTY')); ?></p>
    <?php else : ?>
        <table class="table table-striped">
            <caption><?php echo $this->escape(Text::_('COM_ALTACOURSES_COURSEPLACES_TITLE')); ?></caption>
            <thead><tr>
                <th scope="col"><?php echo $this->escape(Text::_('JGRID_HEADING_ID')); ?></th>
                <th scope="col"><?php echo $this->escape(Text::_('COM_ALTACOURSES_COURSEPLACE_NAME')); ?></th>
                <th scope="col"><?php echo $this->escape(Text::_('COM_ALTACOURSES_REGION')); ?></th>
                <th scope="col"><?php echo $this->escape(Text::_('JSTATUS')); ?></th>
                <th scope="col"><?php echo $this->escape(Text::_('COM_ALTACOURSES_ACTIONS')); ?></th>
            </tr></thead>
            <tbody>
                <?php foreach ($this->items as $item) : ?>
                    <tr data-courseplace-id="<?php echo (int) $item->id; ?>">
                        <td><?php echo (int) $item->id; ?></td>
                        <th scope="row"><?php echo $this->escape((string) $item->name); ?></th>
                        <td><?php echo $this->escape($item->region_name !== null ? (string) $item->region_name : ((int) $item->region_id === 0 ? Text::_('COM_ALTACOURSES_PLACE_REGION_NONE') : Text::sprintf('COM_ALTACOURSES_PLACE_REGION_MISSING', (string) $item->region_id))); ?></td>
                        <td><?php echo $this->escape(Text::_(match ((string) $item->state) { '1' => 'JPUBLISHED', '0' => 'JUNPUBLISHED', default => 'COM_ALTACOURSES_COURSEPLACE_OTHER_STATE' })); ?></td>
                        <td><a class="btn btn-success" href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=courseplace&id=' . (int) $item->id . '&fresh=1', false)); ?>"><?php echo $this->escape(Text::_('JEDIT')); ?></a></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</section>
