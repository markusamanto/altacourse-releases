<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Controller;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Event\PageCache\IsExcludedEvent;

\defined('_JEXEC') or die;

final class ReceiptController extends BaseController
{
    public function execute($task)
    {
        $this->app->allowCache(false);
        $this->app->setHeader('Cache-Control', 'private, no-store, no-cache, must-revalidate', true);
        $this->app->setHeader('Referrer-Policy', 'no-referrer', true);
        $this->app->setHeader('X-Robots-Tag', 'noindex, nofollow', true);
        $this->app->getDispatcher()->addListener('onPageCacheIsExcluded', static function (IsExcludedEvent $event): void { $event->addResult(true); });
        $this->app->sendHeaders();
        if (strtolower((string) $task) !== 'received') {
            throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'), 404);
        }
        return parent::execute($task);
    }

    public function received(): void
    {
        // This capability link intentionally needs no login or session CSRF token.
        if ($this->input->getMethod() !== 'GET') {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_RECEIPT_GET_REQUIRED'), 405);
        }
        $this->getModel('Readreceipt', 'Site', ['ignore_request' => true])->acknowledge($this->input->get('token', null, 'raw'));
        $this->setMessage(Text::_('COM_ALTACOURSES_RECEIPT_THANKS'));
        $this->setRedirect(Route::_('index.php?option=com_altacourses&view=readreceipt', false));
    }
}
