<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */
namespace Advenire\Component\Altacourses\Site\Controller;

use Advenire\Component\Altacourses\Site\Exception\CourseValidationException;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;

abstract class SubmissionController extends BaseController
{
    protected const MODE = 'enquiry';
    protected const MODEL = 'Enquiry';

    public function execute($task)
    {
        if (strtolower((string) $task) !== 'save') { throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'), 404); }
        return parent::execute($task);
    }

    public function save(): void
    {
        if ($this->input->getMethod() !== 'POST') { throw new \RuntimeException(Text::_('COM_ALTACOURSES_SAMPLE_POST_REQUIRED'), 405); }
        if (!$this->checkToken('post', false)) { throw new \RuntimeException(Text::_('JINVALID_TOKEN'), 403); }
        $raw = $this->input->post->get('jform', [], 'array');
        $id = $raw['coid'] ?? '';
        if (!is_string($id) || !ctype_digit($id) || (float) $id > 2147483647 || (int) $id <= 0) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_FILTER'), 400);
        }
        $id = (int) $id;
        $key = 'com_altacourses.' . static::MODE . '.' . $id;
        $model = $this->getModel(static::MODEL, 'Site', ['ignore_request' => true]);
        $draft = [];
        foreach ($model::FIELDS as $field) {
            if (isset($raw[$field]) && is_string($raw[$field])) { $draft[$field] = mb_substr($raw[$field], 0, 255); }
        }
        $token = $raw['submission'] ?? '';
        $tickets = $this->app->getUserState('com_altacourses.' . static::MODE . '.tickets', []);
        $ticket = is_string($token) ? ($tickets[$token] ?? null) : null;
        if (!is_string($token) || !preg_match('/^[a-f0-9]{64}$/D', $token) || !is_array($ticket)
            || $ticket['course_id'] !== $id || $ticket['time'] < time() - 14400) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_ENQUIRY_EXPIRED'), 409);
        }
        $draft['submission'] = $token;
        $this->app->setUserState($key . '.draft', $draft);
        unset($raw['coid'], $raw['submission']);
        try {
            $requestId = $model->submit($id, $ticket['revision'], $token, $raw, $ticket['agreement'] ?? null);
        } catch (CourseValidationException $exception) {
            foreach ($exception->messages as $message) { $this->app->enqueueMessage($message, 'warning'); }
            $this->setRedirect(Route::_('index.php?option=com_altacourses&view=' . static::MODE . '&coid=' . $id, false));
            return;
        } catch (\Throwable $exception) {
            if (in_array($exception->getCode(), [404, 409], true)
                && in_array($exception->getMessage(), [Text::_('COM_ALTACOURSES_ENQUIRY_UNAVAILABLE'), Text::_('COM_ALTACOURSES_ENQUIRY_EXPIRED'), Text::_('COM_ALTACOURSES_ENQUIRY_CONFLICT'), Text::_('COM_ALTACOURSES_SIGNUP_CONFLICT'), Text::_('COM_ALTACOURSES_SIGNUP_UNAVAILABLE')], true)) {
                throw $exception;
            }
            $this->app->getLogger()->error('Altacourses submission persistence failed', ['exception' => $exception]);
            $this->setMessage(Text::_('COM_ALTACOURSES_' . strtoupper(static::MODE) . '_FAILED'), 'warning');
            $this->setRedirect(Route::_('index.php?option=com_altacourses&view=' . static::MODE . '&coid=' . $id, false));
            return;
        }
        $this->app->setUserState($key . '.draft', null);
        $this->app->setUserState($key . '.receipt', ['course_id' => $id, 'request_id' => $requestId]);
        $this->setRedirect(Route::_('index.php?option=com_altacourses&view=' . static::MODE . 'receipt&coid=' . $id, false));
    }
}
