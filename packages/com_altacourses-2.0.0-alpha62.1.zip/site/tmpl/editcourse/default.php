<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 * @var         \Advenire\Component\Altacourses\Site\View\Editcourse\HtmlView $this
 */

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;
?>
<section aria-labelledby="altacourses-edit-heading">
    <h1 id="altacourses-edit-heading"><?php echo $this->escape(Text::_('COM_ALTACOURSES_EDIT_TITLE')); ?></h1>
    <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_EDIT_HELP')); ?></p>
    <form id="altacourses-editcourse-form" data-altacourses-course-form action="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&task=editcourse.save')); ?>" method="post">
        <?php echo $this->form->getInput('id') . $this->form->getInput('version'); ?>
        <?php if ($this->isCourseAdministrator) : ?><?php echo $this->form->renderField('supplier'); ?><?php endif; ?>
        <?php echo $this->form->renderField('course_type'); ?>
        <fieldset><legend><?php echo $this->escape(Text::sprintf('COM_ALTACOURSES_SESSION_NUMBER', 1)); ?></legend>
            <?php echo $this->form->renderField('start_date'); ?>
            <?php echo $this->form->renderField('stop_date'); ?>
        </fieldset>
        <button id="altacourses-toggle-session" type="button" class="btn btn-secondary" hidden aria-controls="altacourses-second-session"
            data-add="<?php echo $this->escape(Text::_('COM_ALTACOURSES_NEW_ADD_SESSION')); ?>"
            data-remove="<?php echo $this->escape(Text::_('COM_ALTACOURSES_NEW_REMOVE_SESSION')); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_NEW_ADD_SESSION')); ?></button>
        <fieldset id="altacourses-second-session" data-persisted="<?php echo $this->hasStoredSecond ? '1' : '0'; ?>"><legend><?php echo $this->escape(Text::sprintf('COM_ALTACOURSES_SESSION_NUMBER', 2)); ?></legend>
            <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_NEW_SECOND_HELP')); ?></p>
            <?php echo $this->form->renderField('second_start'); ?>
            <?php echo $this->form->renderField('second_end'); ?>
        </fieldset>
        <?php if ($this->hasStoredSecond) : ?><p><?php echo $this->escape(Text::_('COM_ALTACOURSES_EDIT_KEEP_SESSIONS')); ?></p><?php endif; ?>
        <?php if ($this->laterSessions) : ?>
            <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_EDIT_LATER_SESSIONS')); ?></p>
            <?php foreach ($this->laterSessions as $index => $session) : ?>
                <p><?php echo $this->escape(Text::sprintf('COM_ALTACOURSES_SESSION_NUMBER', $index + 3) . ': ' . $session->start_date . ' – ' . $session->stop_date); ?></p>
            <?php endforeach; ?>
        <?php endif; ?>
        <?php foreach (['course_place', 'course_leader_1', 'course_leader_2', 'course_price', 'lodging_price', 'lodging_included', 'availability', 'course_notes'] as $field) : ?>
            <?php echo $this->form->renderField($field); ?>
        <?php endforeach; ?>
        <?php if ($this->isCourseAdministrator) : ?><?php echo $this->form->renderField('state'); ?><?php endif; ?>
        <?php echo HTMLHelper::_('form.token'); ?>
        <button type="submit" class="btn btn-primary"><?php echo $this->escape(Text::_('JSAVE')); ?></button>
        <a class="btn btn-secondary" href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=managecourses')); ?>"><?php echo $this->escape(Text::_('JCANCEL')); ?></a>
        <a class="btn btn-secondary" href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=editcourse&id=' . $this->courseId . '&fresh=1')); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_EDIT_RELOAD')); ?></a>
    </form>
</section>
