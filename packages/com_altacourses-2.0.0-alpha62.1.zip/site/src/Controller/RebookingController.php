<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Controller;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;
\defined('_JEXEC') or die;
final class RebookingController extends BaseController
{
    public function execute($task)
    {
        if (strtolower((string) $task) !== 'save') { throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'), 404); }
        return parent::execute($task);
    }
    public function save(): void
    {
        $model = $this->getModel('Rebooking', 'Site', ['ignore_request' => true]); $model->requireContactAccess();
        if ($this->input->getMethod() !== 'POST') { throw new \RuntimeException(Text::_('COM_ALTACOURSES_SAMPLE_POST_REQUIRED'), 405); }
        if (!$this->checkToken('post', false)) { throw new \RuntimeException(Text::_('JINVALID_TOKEN'), 403); }
        $raw = $this->input->post->get('jform', [], 'array');
        if (array_diff(array_keys($raw), ['id', 'version', 'destination', 'note']) || count($raw) !== 4
            || !is_string($raw['id'] ?? null) || !ctype_digit($raw['id']) || (float) $raw['id'] > 2147483647
            || !is_string($raw['version'] ?? null) || !is_string($raw['destination'] ?? null) || !is_string($raw['note'] ?? null)
            || !preg_match('/^([1-9][0-9]*):([a-f0-9]{64})$/D', $raw['destination'], $parts) || (float) $parts[1] > 2147483647) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_REBOOK_INVALID'), 400);
        }
        $row = $model->getRecord((int) $raw['id']);
        $model->rebook((int) $raw['id'], $raw['version'], (int) $parts[1], $parts[2], $raw['note']);
        $this->setMessage(Text::_('COM_ALTACOURSES_REBOOK_SAVED'));
        $this->setRedirect(Route::_('index.php?option=com_altacourses&view=client&id=' . (int) $row->clientid, false));
    }
}
