-- Availability revisions prevent stale forms from overwriting newer changes.
ALTER TABLE `#__altacourses_courses`
    ADD COLUMN `availability_version` int UNSIGNED NOT NULL DEFAULT 0;
