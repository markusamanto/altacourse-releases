<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Model;

\defined('_JEXEC') or die;

final class DeliveriesModel extends RequestrecordsModel
{
    public function getTotal(): int
    {
        $this->requireAdministrator();
        return (int) $this->getDatabase()->setQuery('SELECT COUNT(*) FROM #__altacourses_request_submissions')->loadResult();
    }

    public function getItems(): array
    {
        $this->requireAdministrator();
        $query = $this->getDatabase()->createQuery()->select(['s.request_id', 's.created_at', 's.contact_json', 's.course_json', "CASE WHEN o.needs_review>0 THEN 'uncertain' WHEN o.accepted=2 AND o.messages=2 THEN 'sent' WHEN o.accepted>0 THEN 'partial' ELSE 'not_sent' END AS delivery_state", 'r.asked_for_info'])
            ->from('#__altacourses_request_submissions AS s')->join('INNER', '#__altacourses_requests AS r ON r.id=s.request_id')
            ->join('LEFT', "(SELECT submission_id, SUM(CASE WHEN state IN ('sending','uncertain') THEN 1 ELSE 0 END) AS needs_review, SUM(CASE WHEN state='sent' THEN 1 ELSE 0 END) AS accepted, COUNT(*) AS messages FROM #__altacourses_notification_outbox GROUP BY submission_id) AS o ON o.submission_id=s.id")
            ->order('s.id DESC');
        return $this->getDatabase()->setQuery($query, (int) $this->getState('list.start', 0), 20)->loadObjectList();
    }
}
