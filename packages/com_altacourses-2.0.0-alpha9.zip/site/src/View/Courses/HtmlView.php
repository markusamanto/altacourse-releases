<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\View\Courses;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Pagination\Pagination;

use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareTrait;

\defined('_JEXEC') or die;

final class HtmlView extends BaseHtmlView implements CourseScheduleAwareInterface
{
    use CourseScheduleAwareTrait;

    public array $sessions = [];
    public array $items = [];
    public array $types = [];
    public array $regions = [];
    public array $filters = [];
    public ?Pagination $pagination = null;

    public function display($tpl = null): void
    {
        $model = $this->getModel();
        $this->items = $model->getItems();
        $this->sessions = $this->getCourseSchedule()->additionalSessions(array_map(static fn ($course): int => (int) $course->id, $this->items));
        $this->types = $model->getOptions('coursetypes');
        $this->regions = $model->getOptions('regions');
        $this->getDocument()->setTitle(Text::_('COM_ALTACOURSES_COURSES_TITLE'));
        $this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.site');
        parent::display($tpl);
    }
}
