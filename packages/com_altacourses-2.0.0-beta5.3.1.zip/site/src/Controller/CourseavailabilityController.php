<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Controller;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Response\JsonResponse;
\defined('_JEXEC') or die;
final class CourseavailabilityController extends BaseController
{
    public function execute($task)
    {
        $this->app->allowCache(false);$this->app->setHeader('Cache-Control','private, no-store, no-cache, must-revalidate',true);
        $status=200;$data=null;$message=null;
        try{
            if(!in_array(strtolower((string)$task),['save','refresh'],true)||$this->input->getCmd('format')!=='json'){throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'),404);}
            $list=$this->getModel('Courseavailability','Site',['ignore_request'=>true]);$list->requireContactAccess();
            if($this->input->getMethod()!=='POST'){throw new \RuntimeException(Text::_('COM_ALTACOURSES_AVAILABILITY_POST_REQUIRED'),405);}
            if(!$this->checkToken('post',false)){throw new \RuntimeException(Text::_('JINVALID_TOKEN'),403);}
            $raw=$this->input->post->get('jform',[],'array');$save=strtolower((string)$task)==='save';$allowed=$save?['id','availability','version']:['id'];
            if(count($raw)!==count($allowed)||array_diff(array_keys($raw),$allowed)){throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_AVAILABILITY'),400);}
            foreach($allowed as $key){$v=$raw[$key]??null;$max=$key==='version'?4294967294:4294967295;if(!is_string($v)||!ctype_digit($v)||strlen($v)>10||(float)$v>$max||($key==='id'&&(int)$v<1)){throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_AVAILABILITY'),400);}}
            if($save){$model=$this->getModel('Availability','Site',['ignore_request'=>true]);$model->saveAvailability((int)$raw['id'],(int)$raw['availability'],(int)$raw['version']);$data=['id'=>(int)$raw['id'],'availability'=>(int)$raw['availability'],'version'=>(int)$raw['version']+1];$message=Text::_('COM_ALTACOURSES_INLINE_SAVED');}
            else{$data=$list->readState((int)$raw['id']);$message=Text::_('COM_ALTACOURSES_INLINE_REFRESHED');}
        }catch(\Throwable $e){$code=(int)$e->getCode();$status=in_array($code,[400,403,404,405,409],true)?$code:500;$message=$status===500?Text::_('COM_ALTACOURSES_AVAILABILITY_FAILED'):$e->getMessage();}
        http_response_code($status);$this->app->setHeader('Content-Type','application/json; charset=utf-8',true);$this->app->sendHeaders();
        echo new JsonResponse($data,$message,$status!==200,true);$this->app->close();
        return $this;
    }
}
