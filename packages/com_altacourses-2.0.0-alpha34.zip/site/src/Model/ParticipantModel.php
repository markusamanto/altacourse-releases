<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Model;

use Joomla\CMS\Language\Text;
use Joomla\Database\ParameterType;
use Joomla\Database\QueryInterface;

\defined('_JEXEC') or die;

/** Read-only submitted contact details and history linked by the stored participant ID. */
class ParticipantModel extends EnquiriesModel
{
    public function getRecord(int $requestId): array
    {
        $db = $this->getDatabase();
        $query = $db->createQuery()
            ->select(['s.request_id', 's.created_at', 's.contact_json', 's.course_json', 's.supplier_email',
                'r.clientid', 'r.asked_for_info'])
            ->from('#__altacourses_request_submissions AS s')
            ->join('INNER', '#__altacourses_requests AS r ON r.id=s.request_id')
            ->where('r.asked_for_info IN (0, 1)')
            ->where('r.id=:request')->bind(':request', $requestId, ParameterType::INTEGER);
        $this->scopeHistory($query);
        $selected = $db->setQuery($query)->loadObject();

        if ($requestId <= 0 || $selected === null || (int) $selected->clientid <= 0) {
            throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'), 404);
        }

        $clientId = (int) $selected->clientid;
        $query = $db->createQuery()
            ->select(['s.request_id', 's.created_at', $this->currentCourseExpression() . ' AS course_json', 'r.asked_for_info'])
            ->from('#__altacourses_request_submissions AS s')
            ->join('INNER', '#__altacourses_requests AS r ON r.id=s.request_id')
            ->where('r.asked_for_info IN (0, 1)')
            ->where('r.clientid=:client')->bind(':client', $clientId, ParameterType::INTEGER)
            ->order('s.created_at DESC, s.request_id DESC');
        $this->scopeHistory($query);

        $history = $db->setQuery($query)->loadObjectList();
        $ids = array_map(static fn ($entry): int => (int) $entry->request_id, $history);
        $events = $db->createQuery()->select('*')->from('#__altacourses_request_rebookings')
            ->whereIn('request_id', $ids)->order('created_at DESC,id DESC');
        return ['selected' => $selected, 'history' => $history, 'rebookings' => $db->setQuery($events)->loadObjectList()];
    }

    protected function scopeHistory(QueryInterface $query): void
    {
        $this->requireAdministrator();
    }
}
