<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Field;
use Joomla\CMS\Factory;
use Joomla\CMS\Form\Field\ListField;
use Joomla\CMS\HTML\HTMLHelper;
\defined('_JEXEC') or die;

/** Native menu selector reuses supplier eligibility, including the Super User exclusion. */
final class MenusupplierField extends ListField
{
    protected $type = 'Menusupplier';
    protected function getOptions(): array
    {
        $options = parent::getOptions();
        $app = Factory::getApplication();
        $user = $app->getIdentity();
        if ($user->guest || !$user->authorise('altacourses.manage', 'com_altacourses')) { return $options; }
        $model = $app->bootComponent('com_altacourses')->getMVCFactory()->createModel('Supplierprofile', 'Site', ['ignore_request' => true]);
        $model->setCurrentUser($user);
        foreach ($model->getSuppliers() as $supplier) {
            $options[] = HTMLHelper::_('select.option', (int)$supplier->user_id,
                trim((string) $supplier->company) ?: $supplier->name);
        }
        return $options;
    }
}
