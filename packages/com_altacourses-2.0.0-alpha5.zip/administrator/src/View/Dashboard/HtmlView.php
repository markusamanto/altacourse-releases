<?php

/**
 * @package     Altacourses.Administrator
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Administrator\View\Dashboard;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Toolbar\ToolbarHelper;

\defined('_JEXEC') or die;

final class HtmlView extends BaseHtmlView
{
    public function display($tpl = null): void
    {
        $this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.administrator');

        ToolbarHelper::title(Text::_('COM_ALTACOURSES_DASHBOARD_TITLE'), 'calendar');

        if ($this->getCurrentUser()->authorise('core.admin', 'com_altacourses')) {
            ToolbarHelper::preferences('com_altacourses');
        }

        parent::display($tpl);
    }
}
