<?php
/** @package Altacourses.Module @license GNU General Public License version 2 or later */
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use \Advenire\Component\Altacourses\Administrator\Service\PriceDisplay as PriceDisplay;
\defined('_JEXEC') or die;
$escape=static fn(mixed $v):string=>htmlspecialchars((string)$v,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');
$date=static fn(?string $v):string=>$v&&preg_match('/^[1-9][0-9]{3}-[0-9]{2}-[0-9]{2}/',$v)?HTMLHelper::_('date',substr($v,0,10).' 12:00:00',Text::_('MOD_ALTARELATEDCOURSES_DATE_FORMAT'),false):Text::_('MOD_ALTARELATEDCOURSES_UNKNOWN');
?>
<div class="altarelatedcourses" data-altarelatedcourses="<?php echo $escape($mode); ?>">
 <?php echo PriceDisplay::paragraphs('altarelatedcourses-price', 'MOD_ALTARELATEDCOURSES_VARIABLE_SUFFIX_'.strtoupper($mode)); ?>
 <div class="table-responsive"><table class="table table-striped">
  <caption class="visually-hidden"><?php echo $escape(Text::_('MOD_ALTARELATEDCOURSES_'.strtoupper($mode).'_TITLE')); ?></caption>
  <thead><tr><?php foreach(['DATES',$mode==='place'?'LEADERS':'PLACE','TOTAL','SEATS','SIGNUP','INFORMATION'] as $f): ?><th scope="col"><?php echo $escape(($f==='TOTAL' ? PriceDisplay::label('MOD_ALTARELATEDCOURSES_TOTAL') : Text::_('MOD_ALTARELATEDCOURSES_'.$f))); ?></th><?php endforeach; ?></tr></thead>
  <tbody><?php foreach($rows as $row): ?><tr data-related-course-id="<?php echo (int)$row->id; ?>">
   <td><?php foreach($row->sessions as $part): ?><div class="related-session"><time datetime="<?php echo $escape(substr($part['start_date']??'',0,10)); ?>"><?php echo $escape($date($part['start_date'])); ?></time><?php if(substr($part['stop_date']??'',0,10)!==substr($part['start_date']??'',0,10)): ?> – <time datetime="<?php echo $escape(substr($part['stop_date']??'',0,10)); ?>"><?php echo $escape($date($part['stop_date'])); ?></time><?php endif; ?><br><small><?php echo $escape(Text::_('MOD_ALTARELATEDCOURSES_WEEK').' '.HTMLHelper::_('date',substr($part['start_date'],0,10).' 12:00:00','W',false)); ?></small></div><?php endforeach; ?></td>
   <?php if($mode==='place'): ?>
   <td><?php foreach([1,2] as $slot): ?><?php $name=$row->{'leader'.$slot};$link=$row->{'leader'.$slot.'Link'}; ?><?php if($name!==null&&$name!==''): ?><div><?php if($link!==null): ?><a data-related-leader="<?php echo $slot; ?>" href="<?php echo $escape($link); ?>"><?php echo $escape($name); ?></a><?php else: ?><?php echo $escape($name); ?><?php endif; ?></div><?php endif; ?><?php endforeach; ?></td>
   <?php else: ?>
   <td><?php if($row->placeLink!==null): ?><a data-related-venue href="<?php echo $escape($row->placeLink); ?>"><?php echo $escape($row->course_place); ?></a><?php else: ?><?php echo $escape($row->course_place); ?><?php endif; ?></td>
   <?php endif; ?>
   <td class="text-nowrap" data-related-price><?php echo $escape($row->price); ?><?php echo PriceDisplay::marker($row->residential); ?></td><td><?php echo $escape($row->seats_label?:Text::_('MOD_ALTARELATEDCOURSES_UNKNOWN')); ?></td>
   <td><?php if($row->signup!==null): ?><a class="btn btn-primary" data-related-signup href="<?php echo $escape($row->signup); ?>"><?php echo $escape(Text::_('MOD_ALTARELATEDCOURSES_SIGNUP')); ?></a><?php else: ?><span class="btn btn-secondary disabled" aria-disabled="true"><?php echo $escape(Text::_('MOD_ALTARELATEDCOURSES_SIGNUP')); ?></span><?php endif; ?></td>
   <td><a data-related-information href="<?php echo $escape($row->information); ?>"><?php echo $escape(Text::_('MOD_ALTARELATEDCOURSES_INFORMATION')); ?></a></td>
  </tr><?php endforeach; ?></tbody>
 </table></div>
 <p><?php echo $escape(Text::_('MOD_ALTARELATEDCOURSES_FOOTER_'.strtoupper($mode))); ?> <a data-related-listing href="<?php echo $escape($listing); ?>"><?php echo $escape(Text::_('MOD_ALTARELATEDCOURSES_LISTING')); ?></a>.</p>
</div>
