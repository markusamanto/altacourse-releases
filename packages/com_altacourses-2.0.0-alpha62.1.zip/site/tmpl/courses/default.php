<?php

/**
 * @package Altacourses.Site
 * @license GNU General Public License version 2 or later
 * @var \Advenire\Component\Altacourses\Site\View\Courses\HtmlView $this
 */

use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;
?>
<section class="altacourses-list" aria-labelledby="altacourses-courses-heading">
    <h1 id="altacourses-courses-heading"><?php echo $this->escape(Text::_('COM_ALTACOURSES_COURSES_TITLE')); ?></h1>
    <details id="altacourses-public-search">
    <summary class="btn btn-outline-secondary"><?php echo $this->escape(Text::_('COM_ALTACOURSES_PUBLIC_SEARCH_TOGGLE')); ?></summary>
    <form id="altacourses-public-search-form" action="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=courses')); ?>" method="get" class="altacourses-filters">
        <input type="hidden" name="option" value="com_altacourses">
        <input type="hidden" name="view" value="courses">
        <?php if ($this->multipleTypes) : ?><div>
            <label for="altacourses-type"><?php echo $this->escape(Text::_('COM_ALTACOURSES_COURSE_TYPE')); ?></label>
            <select id="altacourses-type" name="type" class="form-select">
                <option value="0"><?php echo $this->escape(Text::_('COM_ALTACOURSES_ALL_TYPES')); ?></option>
                <?php foreach ($this->types as $type) : ?>
                    <option value="<?php echo (int) $type->id; ?>"<?php echo (int) $type->id === $this->filters['type'] ? ' selected' : ''; ?>><?php echo $this->escape($type->name ?? ''); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php endif; ?>
        <div>
            <label for="altacourses-from"><?php echo $this->escape(Text::_('COM_ALTACOURSES_FROM_DATE')); ?></label>
            <input type="date" class="form-control" name="from" id="altacourses-from" min="1000-01-01" value="<?php echo $this->escape($this->filters['from']); ?>">
        </div>
        <div>
            <label for="altacourses-to"><?php echo $this->escape(Text::_('COM_ALTACOURSES_TO_DATE')); ?></label>
            <input type="date" class="form-control" name="to" id="altacourses-to" min="1000-01-01" value="<?php echo $this->escape($this->filters['to']); ?>">
        </div>
        <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_PUBLIC_DATES_HELP')); ?></p>
        <fieldset class="altacourses-public-regions">
            <legend><?php echo $this->escape(Text::_('COM_ALTACOURSES_REGION')); ?></legend>
            <?php foreach ($this->regions as $region) : ?>
                <div class="form-check"><input type="checkbox" class="form-check-input" name="regions[]" id="altacourses-region-<?php echo (int)$region->id; ?>" value="<?php echo (int)$region->id; ?>"<?php echo in_array((int)$region->id,$this->filters['regions'],true)?' checked':''; ?>>
                <label class="form-check-label" for="altacourses-region-<?php echo (int)$region->id; ?>"><?php echo $this->escape($region->name??''); ?></label></div>
            <?php endforeach; ?>
            <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_PUBLIC_REGIONS_HELP')); ?></p>
        </fieldset>
        <div class="altacourses-filter-actions">
            <button type="submit" class="btn btn-primary"><?php echo $this->escape(Text::_('COM_ALTACOURSES_PUBLIC_SEARCH')); ?></button>
        </div>
    </form>
    </details>
    <h2><?php echo $this->escape(Text::_('COM_ALTACOURSES_PUBLIC_DATES_PRICES')); ?></h2>
    <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_PUBLIC_PRICE_INTRO')); ?></p>
    <?php if (!$this->items) : ?>
        <p role="status"><?php echo $this->escape(Text::_('COM_ALTACOURSES_NO_COURSES')); ?></p>
    <?php else : ?>
        <div class="table-responsive">
            <table class="table table-striped">
                <caption><?php echo $this->escape(Text::_('COM_ALTACOURSES_COURSES_CAPTION')); ?></caption>
                <thead><tr>
                    <?php foreach (array_merge($this->multipleTypes?['COURSE_TYPE']:[],['DATES','PLACE','LEADERS','TOTAL_PRICE','PUBLIC_SIGNUP']) as $column) : ?>
                        <th scope="col"><?php echo $this->escape(Text::_('COM_ALTACOURSES_' . $column)); ?></th>
                    <?php endforeach; ?>
                </tr></thead>
                <tbody>
                    <?php foreach ($this->items as $item) : ?>
                        <tr data-course-id="<?php echo (int) $item->id; ?>">
                            <?php if ($this->multipleTypes) : ?><td><?php echo $this->escape($item->course_type ?? ''); ?></td><?php endif; ?>
                            <td>
                                <?php $parts = array_merge([$item], $this->sessions[(int) $item->id] ?? []); ?>
                                <?php foreach ($parts as $partIndex => $part) : ?>
                                    <div data-session="<?php echo $partIndex + 1; ?>">
                                        <?php if (count($parts) > 1) : ?>
                                            <span><?php echo $this->escape(Text::sprintf('COM_ALTACOURSES_SESSION_NUMBER', $partIndex + 1)); ?>:</span>
                                        <?php endif; ?>
                                        <?php if ($part->start_date) : ?><time datetime="<?php echo $this->escape(substr($part->start_date, 0, 10)); ?>"><?php echo $this->escape(substr($part->start_date, 0, 10)); ?></time><?php endif; ?>
                                        <?php if ($part->stop_date && substr($part->stop_date, 0, 10) !== substr($part->start_date ?? '', 0, 10)) : ?>
                                            – <time datetime="<?php echo $this->escape(substr($part->stop_date, 0, 10)); ?>"><?php echo $this->escape(substr($part->stop_date, 0, 10)); ?></time>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </td>
                            <td><?php $href=$this->articleHref($item->place_article,(int)$item->id); ?><?php if ($href!==null) : ?><a data-course-article="place" href="<?php echo $this->escape($href); ?>"><?php echo $this->escape($item->course_place??''); ?></a><?php else : ?><?php echo $this->escape($item->course_place??''); ?><?php endif; ?></td>
                            <td><?php foreach (['leader1','leader2'] as $leader) : if (trim((string)($item->$leader??''))==='') { continue; } $href=$this->articleHref($item->{$leader.'_article'},(int)$item->id); ?><div><?php if ($href!==null) : ?><a data-course-article="<?php echo $leader; ?>" href="<?php echo $this->escape($href); ?>"><?php echo $this->escape($item->$leader); ?></a><?php else : ?><?php echo $this->escape($item->$leader); ?><?php endif; ?></div><?php endforeach; ?></td>
                            <td data-total-price><?php echo $this->escape($this->totalPrices[(int) $item->id]); ?></td>
                            <td><?php if ($this->signupAvailable[(int)$item->id]) : ?><a class="btn btn-primary" data-course-signup href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=signup&coid='.(int)$item->id,false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_PUBLIC_SIGNUP')); ?><span class="visually-hidden">: <?php echo $this->escape(($item->course_type??'').' '.substr($item->start_date??'',0,10).' '.($item->course_place??'')); ?></span></a><?php else : ?><span class="btn btn-secondary disabled" aria-disabled="true"><?php echo $this->escape(Text::_('COM_ALTACOURSES_PUBLIC_SIGNUP')); ?></span><?php endif; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php echo $this->pagination->getPagesLinks(); ?>
        <p><?php echo $this->escape($this->pagination->getPagesCounter()); ?></p>
    <?php endif; ?>
</section>
