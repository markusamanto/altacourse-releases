<?php
namespace Advenire\Component\Altacourses\Site\Model;
use Advenire\Component\Altacourses\Administrator\Service\ZenlerNewsletter;
\defined('_JEXEC') or die;
final class NewsletterModel extends RequestrecordsModel
{
    private ?ZenlerNewsletter $enrollments=null;
    public function setZenlerNewsletter(ZenlerNewsletter $service): void { $this->enrollments=$service; }
    private function service(): ZenlerNewsletter { $this->requireAdministrator();return $this->enrollments??throw new \RuntimeException('Newsletter service unavailable'); }
    public function settings(): array { return $this->service()->settings(); }
    public function history(): array { return $this->service()->history(); }
    public function review(int $id,int $revision,bool $confirmed): void { $this->service()->review($id,$revision,$confirmed); }
}
