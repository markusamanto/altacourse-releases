<?php
use Joomla\CMS\Layout\LayoutHelper;
\defined('_JEXEC') or die;
echo LayoutHelper::render('billing',['view'=>$this],dirname(__DIR__,2).'/layouts');
