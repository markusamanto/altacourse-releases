<?php

/** @package Altacourses.Administrator @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Administrator\Service;

\defined('_JEXEC') or die;

trait NotificationAwareTrait
{
    private ?NotificationService $notifications = null;

    public function setNotifications(NotificationService $notifications): void
    {
        $this->notifications = $notifications;
    }

    protected function getNotifications(): NotificationService
    {
        return $this->notifications ?? throw new \LogicException('Notification service has not been injected');
    }
}
