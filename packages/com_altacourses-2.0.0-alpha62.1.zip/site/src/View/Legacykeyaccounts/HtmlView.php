<?php
namespace Advenire\Component\Altacourses\Site\View\Legacykeyaccounts;
\defined('_JEXEC') or die;
final class HtmlView extends \Advenire\Component\Altacourses\Site\View\Keyaccounts\HtmlView {}
