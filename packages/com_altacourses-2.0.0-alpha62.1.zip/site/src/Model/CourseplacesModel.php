<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Model;

use Advenire\Component\Altacourses\Site\Exception\CourseValidationException;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Form\FormFactoryAwareInterface;
use Joomla\CMS\Form\FormFactoryAwareTrait;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\BaseModel;
use Joomla\CMS\User\CurrentUserInterface;
use Joomla\CMS\User\User;
use Joomla\CMS\User\UserFactoryAwareInterface;
use Joomla\CMS\User\UserFactoryAwareTrait;
use Joomla\Database\DatabaseAwareInterface;
use Joomla\Database\DatabaseAwareTrait;
use Joomla\Database\ParameterType;

\defined('_JEXEC') or die;

/** Courseplace management uses the original table and IDs; no delete operation. */
final class CourseplacesModel extends BaseModel implements DatabaseAwareInterface, CurrentUserInterface, UserFactoryAwareInterface, FormFactoryAwareInterface
{
    use DatabaseAwareTrait;
    use UserFactoryAwareTrait;
    use FormFactoryAwareTrait;
    use ArticleSelectionTrait;

    protected function articleLanguagePrefix(): string { return 'PLACE'; }

    private ?User $currentUser = null;
    public function setCurrentUser(User $currentUser): void
    {
        $this->currentUser = $currentUser;
    }

    public function requireAdministrator(): void
    {
        $user = $this->currentUser;
        if ($user === null || $user->guest || $user->block
            || !$user->authorise('altacourses.manage', 'com_altacourses')) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }
        $fresh = $this->getUserFactory()->loadUserById((int) $user->id);
        if ($fresh->guest || $fresh->block || !$fresh->authorise('altacourses.manage', 'com_altacourses')) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }
    }

    public function getItems(): array
    {
        $this->requireAdministrator();
        $db = $this->getDatabase();
        return $db->setQuery($db->createQuery()->select(['p.id', 'p.name', 'p.state', 'p.region_id', 'r.name AS region_name'])
            ->from($db->quoteName('#__altacourses_courseplaces', 'p'))
            ->join('LEFT', $db->quoteName('#__altacourses_regions', 'r') . ' ON r.id = p.region_id')
            ->order('p.name, p.id'))->loadObjectList();
    }

    public function getRecord(int $id): ?object
    {
        $this->requireAdministrator();
        if ($id === 0) {
            return null;
        }
        $db = $this->getDatabase();
        $query = $db->createQuery()->select('*')->from($db->quoteName('#__altacourses_courseplaces'))
            ->where($db->quoteName('id') . ' = :id')->bind(':id', $id, ParameterType::INTEGER);
        $record = $db->setQuery($query)->loadObject();
        if ($record === null) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_COURSEPLACE_NOT_FOUND'), 404);
        }
        $this->requireUnlocked($record);
        return $record;
    }

    /** A fingerprint avoids adding a migration-only revision column to the legacy table. */
    public function formData(?object $record): array
    {
        return [
            'id' => (string) ($record->id ?? 0),
            'name' => (string) ($record->name ?? ''),
            'state' => $record === null ? '1' : (string) $record->state,
            'url' => $this->linkSelection($record),
            'region_id' => $record === null || $record->region_id === null || (int) $record->region_id === 0 ? '' : (string) $record->region_id,
            'version' => $record === null ? '' : hash('sha256', json_encode($record, JSON_THROW_ON_ERROR)),
        ];
    }

    public function getForm(array $data): Form
    {
        $this->requireAdministrator();
        $form = $this->getFormFactory()->createForm('com_altacourses.courseplace', ['control' => 'jform']);
        if (!$form->loadFile(dirname(__DIR__, 2) . '/forms/courseplace.xml')) {
            throw new \RuntimeException('Courseplace form could not be loaded');
        }
        $record = $this->getRecord((int) ($data['id'] ?? 0));
        $data = $this->addArticleField($form, $data, $record);
        $data = $this->addRegionField($form, $data, $record);
        $form->bind($data);
        return $form;
    }

    public function savePlace(int $id, string $version, array $input): int
    {
        $this->requireAdministrator();
        $name = $input['name'] ?? null;
        $state = $input['state'] ?? null;
        if (array_diff(array_keys($input), ['name', 'state', 'url', 'region_id']) || !is_string($name) || !is_string($state)
            || !in_array($state, ['0', '1'], true)) {
            throw new CourseValidationException([Text::_('COM_ALTACOURSES_COURSEPLACE_INVALID')]);
        }
        $name = trim($name);
        if ($name === '' || mb_strlen($name) > 100 || preg_match('/[\x00-\x1F\x7F]/u', $name)) {
            throw new CourseValidationException([Text::_('COM_ALTACOURSES_COURSEPLACE_INVALID')]);
        }
        $form = $this->getForm([]);
        if (!$form->validate(['id' => $id, 'name' => $name, 'state' => $state])) {
            throw new CourseValidationException([Text::_('COM_ALTACOURSES_COURSEPLACE_INVALID')]);
        }
        $db = $this->getDatabase();
        if ($id === 0) {
            if ($version !== '') {
                throw new \RuntimeException(Text::_('COM_ALTACOURSES_COURSEPLACE_CONFLICT'), 409);
            }
            $url = $this->validateLink($input, null);
            $region = $this->validateRegion($input, null);
            $row = (object) ['region_id' => $region, 'url' => $url, 'name' => $name, 'state' => (int) $state, 'created_by' => (int) $this->currentUser->id];
            $db->insertObject('#__altacourses_courseplaces', $row, 'id');
            return (int) $row->id;
        }
        $db->transactionStart();
        try {
            $query = $db->createQuery()->select('*')->from($db->quoteName('#__altacourses_courseplaces'))
                ->where($db->quoteName('id') . ' = :id')->bind(':id', $id, ParameterType::INTEGER);
            $query->setQuery((string) $query . ' FOR UPDATE');
            $record = $db->setQuery($query)->loadObject();
            if ($record === null) {
                throw new \RuntimeException(Text::_('COM_ALTACOURSES_COURSEPLACE_NOT_FOUND'), 404);
            }
            $this->requireUnlocked($record);
            if (!hash_equals($this->formData($record)['version'], $version)) {
                throw new \RuntimeException(Text::_('COM_ALTACOURSES_COURSEPLACE_CONFLICT'), 409);
            }
            $url = $this->validateLink($input, $record);
            $region = $this->validateRegion($input, $record);
            $published = (int) $state;
            $query = $db->createQuery()->update($db->quoteName('#__altacourses_courseplaces'))
                ->set($db->quoteName('name') . ' = :name')->bind(':name', $name)
                ->set($db->quoteName('state') . ' = :state')->bind(':state', $published, ParameterType::INTEGER)
                ->where($db->quoteName('id') . ' = :id')->bind(':id', $id, ParameterType::INTEGER);
            if ($region !== $record->region_id) {
                if ($region === null) { $query->set($db->quoteName('region_id') . ' = NULL'); }
                else { $query->set($db->quoteName('region_id') . ' = :region')->bind(':region', $region, ParameterType::INTEGER); }
            }
            if ($url !== $record->url) {
                if ($url === null) { $query->set($db->quoteName('url') . ' = NULL'); }
                else { $query->set($db->quoteName('url') . ' = :article')->bind(':article', $url); }
            }
            $db->setQuery($query)->execute();
            $db->transactionCommit();
            return $id;
        } catch (\Throwable $exception) {
            $db->transactionRollback();
            throw $exception;
        }
    }

    public function getRegionChoices(): array
    {
        $this->requireAdministrator();
        $db = $this->getDatabase();
        return $db->setQuery($db->createQuery()->select(['id', 'name', 'state'])
            ->from($db->quoteName('#__altacourses_regions'))->where('state IN (0,1,2)')->order('ordering, name, id'))->loadObjectList();
    }

    private function addRegionField(Form $form, array $data, ?object $record): array
    {
        $original = $record === null || $record->region_id === null || (int) $record->region_id === 0 ? '' : (string) $record->region_id;
        $field = new \SimpleXMLElement('<field name="region_id" type="list" filter="raw" label="COM_ALTACOURSES_REGION" description="COM_ALTACOURSES_PLACE_REGION_HELP" />');
        $empty = $field->addChild('option'); $empty->addAttribute('value', ''); $empty[0] = Text::_('COM_ALTACOURSES_PLACE_REGION_NONE');
        $values = [''];
        foreach ($this->getRegionChoices() as $choice) {
            $value = (string) $choice->id;
            $option = $field->addChild('option'); $option->addAttribute('value', $value);
            $option[0] = $choice->name . ' (#' . $value . ')' . ((int) $choice->state === 1 ? '' : ' — ' . Text::_((int) $choice->state === 0 ? 'JUNPUBLISHED' : 'JARCHIVED'));
            $values[] = $value;
        }
        if ($original !== '' && !in_array($original, $values, true)) {
            $option = $field->addChild('option'); $option->addAttribute('value', '__keep_region');
            $option[0] = Text::sprintf('COM_ALTACOURSES_PLACE_REGION_KEEP', $original);
            if (($data['region_id'] ?? $original) === $original) { $data['region_id'] = '__keep_region'; }
            $original = '__keep_region'; $values[] = $original;
        }
        if (!isset($data['region_id']) || !is_string($data['region_id']) || !in_array($data['region_id'], $values, true)) { $data['region_id'] = $original; }
        $form->setField($field);
        return $data;
    }

    private function validateRegion(array $input, ?object $record): ?int
    {
        $old = $record === null ? 0 : ($record->region_id === null ? null : (int) $record->region_id);
        if (!array_key_exists('region_id', $input)) { return $old; }
        $value = $input['region_id'];
        if (is_string($value)) {
            if ($value === '') { return $old === null || $old === 0 ? $old : 0; }
            if ($value === '__keep_region' && $old !== null && $old !== 0) { return $old; }
            if (ctype_digit($value) && (float) $value <= 2147483647 && (int) $value > 0) {
                if ((int) $value === $old) { return $old; }
                foreach ($this->getRegionChoices() as $choice) {
                    if ((int) $value === (int) $choice->id) { return (int) $value; }
                }
            }
        }
        throw new CourseValidationException([Text::_('COM_ALTACOURSES_PLACE_REGION_INVALID')]);
    }

    private function requireUnlocked(object $record): void
    {
        if ((int) $record->checked_out !== 0 && (int) $record->checked_out !== (int) $this->currentUser->id) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_AVAILABILITY_LOCKED'), 409);
        }
    }
}
