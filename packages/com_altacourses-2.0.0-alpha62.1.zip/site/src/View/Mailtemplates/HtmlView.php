<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\View\Mailtemplates;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;

\defined('_JEXEC') or die;

final class HtmlView extends BaseHtmlView
{
    public array $items = [];
    public array $courseTypes = [];
    public ?int $filterCourseType = null;

    public function display($tpl = null): void
    {
        $this->getModel()->requireAdministrator();
        $this->items = $this->getModel()->getItems($this->filterCourseType);
        $this->courseTypes = $this->getModel()->getCourseTypeChoices();
        $this->getDocument()->setTitle(Text::_('COM_ALTACOURSES_MAILTEMPLATES_TITLE'));
        $this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.site');
        parent::display($tpl);
    }
}
