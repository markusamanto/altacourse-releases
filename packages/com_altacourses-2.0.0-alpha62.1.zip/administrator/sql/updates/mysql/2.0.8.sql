-- No automatic fee backfill: historical amounts require reviewed export.
ALTER TABLE `#__altacourses_requests`
  ADD COLUMN `commission_fee` int UNSIGNED DEFAULT NULL,
  ADD COLUMN `commission_captured_at` datetime DEFAULT NULL,
  ADD COLUMN `commission_captured_by` int DEFAULT NULL;
