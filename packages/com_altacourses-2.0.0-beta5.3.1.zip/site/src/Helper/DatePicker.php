<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Helper;

use Advenire\Component\Altacourses\Site\Field\CoursedateField;

\defined('_JEXEC') or die;

/** Render the same native calendar for standalone listing filters. */
final class DatePicker
{
    public static function input(string $name, string $id, string $value): string
    {
        $element = new \SimpleXMLElement('<field />');
        $element->addAttribute('name', $name);
        $element->addAttribute('id', $id);
        $field = new CoursedateField();
        $field->setup($element, $value);
        return $field->input;
    }
}
