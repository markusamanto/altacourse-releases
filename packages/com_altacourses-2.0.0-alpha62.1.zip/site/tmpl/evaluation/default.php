<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
\defined('_JEXEC') or die;
$date=static fn(mixed $v):string=>is_string($v)&&preg_match('/^[1-9][0-9]{3}-[0-9]{2}-[0-9]{2}/',$v)?substr($v,0,10):Text::_('COM_ALTACOURSES_EVALUATION_UNKNOWN');
?>
<section class="altacourses-portal" aria-labelledby="altacourses-evaluation-heading">
 <h1 id="altacourses-evaluation-heading"><?php echo $this->escape(Text::_('COM_ALTACOURSES_EVALUATION_TITLE')); ?></h1>
 <?php if ($this->status!=='ready') : ?>
  <p role="status" data-evaluation-status="<?php echo $this->escape($this->status); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_EVALUATION_'.strtoupper($this->status))); ?></p>
 <?php else : $course=$this->page['course']; ?>
  <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_EVALUATION_INTRO')); ?></p>
  <dl class="altacourses-account-summary" id="evaluation-course-details">
   <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_EVALUATION_COURSETYPE')); ?></dt><dd><?php echo $this->escape((string)($course->course_type??Text::_('COM_ALTACOURSES_EVALUATION_UNKNOWN'))); ?></dd>
   <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_EVALUATION_DATES')); ?></dt><dd><?php foreach ($this->page['sessions'] as $session) : ?><div><?php echo $this->escape($date($session['start_date']).' – '.$date($session['stop_date'])); ?></div><?php endforeach; ?><?php if (!$this->page['sessions']) : ?><?php echo $this->escape(Text::_('COM_ALTACOURSES_EVALUATION_UNKNOWN')); ?><?php endif; ?></dd>
   <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_EVALUATION_PLACE')); ?></dt><dd><?php echo $this->escape((string)($course->course_place??Text::_('COM_ALTACOURSES_EVALUATION_UNKNOWN'))); ?></dd>
   <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_EVALUATION_LEADERS')); ?></dt><dd><?php foreach (['leader1','leader2'] as $leader) : ?><?php if (trim((string)($course->$leader??''))!=='') : ?><div><?php echo $this->escape((string)$course->$leader); ?></div><?php endif; ?><?php endforeach; ?></dd>
  </dl>
  <form id="altacourses-evaluation-form" action="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&task=evaluation.submit',false)); ?>" method="post">
   <input type="hidden" name="jform[ticket]" value="<?php echo $this->escape($this->ticket); ?>">
   <?php echo HTMLHelper::_('form.token'); ?>
   <details id="evaluation-corrections" class="mb-4"<?php echo trim($this->draft['correction']??'')!==''?' open':''; ?>>
    <summary class="text-primary"><?php echo $this->escape(Text::_('COM_ALTACOURSES_EVALUATION_CORRECTION_LINK')); ?></summary>
    <label class="mt-3" for="evaluation-correction"><?php echo $this->escape(Text::_('COM_ALTACOURSES_EVALUATION_CORRECTION_HELP')); ?></label>
    <textarea class="form-control" id="evaluation-correction" name="jform[correction]" rows="3" maxlength="16000"><?php echo $this->escape($this->draft['correction']??''); ?></textarea>
    <p class="small"><?php echo $this->escape(Text::_('COM_ALTACOURSES_EVALUATION_CORRECTION_PRIVATE')); ?></p>
   </details>
   <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_EVALUATION_PUBLIC_NOTICE')); ?></p>
   <?php foreach (['rating_overall','rating_leaders','rating_place'] as $field) : ?>
    <div class="mb-4"><label for="evaluation-<?php echo $field; ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_EVALUATION_'.strtoupper($field))); ?></label>
     <select class="form-select" name="jform[<?php echo $field; ?>]" id="evaluation-<?php echo $field; ?>" required>
      <option value=""><?php echo $this->escape(Text::_('COM_ALTACOURSES_EVALUATION_CHOOSE')); ?></option>
      <?php foreach ([5,4,3,2,1] as $rating) : ?><option value="<?php echo $rating; ?>"<?php echo ($this->draft[$field]??'')===(string)$rating?' selected':''; ?>><?php echo $rating; ?></option><?php endforeach; ?>
     </select></div>
   <?php endforeach; ?>
   <label for="evaluation-review"><?php echo $this->escape(Text::_('COM_ALTACOURSES_EVALUATION_REVIEW')); ?></label>
   <textarea class="form-control mb-4" name="jform[review]" id="evaluation-review" rows="4" maxlength="16000"><?php echo $this->escape($this->draft['review']??''); ?></textarea>
   <hr>
   <label for="evaluation-feedback"><?php echo $this->escape(Text::_('COM_ALTACOURSES_EVALUATION_FEEDBACK')); ?></label>
   <textarea class="form-control mb-4" name="jform[feedback]" id="evaluation-feedback" rows="4" maxlength="16000"><?php echo $this->escape($this->draft['feedback']??''); ?></textarea>
   <button type="submit" class="btn btn-success"><?php echo $this->escape(Text::_('COM_ALTACOURSES_EVALUATION_SUBMIT')); ?></button>
  </form>
 <?php endif; ?>
</section>
