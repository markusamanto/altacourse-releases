<?php

/**
 * @package     Altacourses.Administrator
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Administrator\Service;

\defined('_JEXEC') or die;

/** Shared legacy-price interpretation; totals use integer öre, never floating point. */
final class CoursePrice
{
    public function formatTotal(?string $fee, ?string $lodging, ?string $included): ?string
    {
        $course = $this->amount($fee);
        if ($course === null) {
            return null;
        }
        if ($this->isIncludedLodging($lodging)) {
            $extra = 0;
        } elseif ($lodging === null || trim($lodging) === '') {
            if ($included !== '1') {
                return null;
            }
            $extra = 0;
        } else {
            $extra = $this->amount($lodging);
            if ($extra === null) {
                return null;
            }
        }
        // Two stated prices are always added, including when the checkbox is checked.
        $total = $course + $extra;
        $whole = (string) intdiv($total, 100);
        $whole = preg_replace('/\B(?=(\d{3})+(?!\d))/', ' ', $whole);
        $fraction = $total % 100;
        return $whole . ($fraction ? ',' . str_pad((string) $fraction, 2, '0', STR_PAD_LEFT) : '');
    }

    /** A display adapter only: reading a legacy record never updates its stored values. */
    public function formValues(?string $fee, ?string $lodging, ?string $included): array
    {
        $legacyIncluded = $this->isIncludedLodging($lodging);
        return [
            'course_price' => $this->normaliseAmount($fee) ?? (string) $fee,
            'lodging_price' => $legacyIncluded ? '' : ($this->normaliseAmount($lodging) ?? (string) $lodging),
            'lodging_included' => $legacyIncluded || !empty($included) ? '1' : '0',
        ];
    }

    public function isIncludedLodging(?string $value): bool
    {
        if ($value === null || strlen($value) > 512 || !mb_check_encoding($value, 'UTF-8')) {
            return false;
        }
        $value = trim(preg_replace('/[\s\x{00a0}\x{202f}]+/u', ' ', $value) ?? '');
        $value = preg_replace('/\.$/u', '', $value ?? '');
        return in_array(mb_strtolower($value ?? '', 'UTF-8'), [
            'included in course price', 'included in the course price', 'inkluderat i kursavgiften',
        ], true);
    }

    /** Return a canonical decimal string, or NULL for ambiguous/unrecognised text. */
    public function normaliseAmount(?string $value): ?string
    {
        $parts = $this->parts($value);
        return $parts === null ? null : $parts[0] . ($parts[1] === '' ? '' : '.' . $parts[1]);
    }

    private function amount(?string $value): ?int
    {
        $parts = $this->parts($value);
        return $parts === null ? null : (int) $parts[0] * 100 + (int) str_pad($parts[1], 2, '0');
    }

    private function parts(?string $value): ?array
    {
        if ($value === null || strlen($value) > 512 || !mb_check_encoding($value, 'UTF-8')) {
            return null;
        }
        $value = preg_replace('/^[\s\x{00a0}\x{202f}]+|[\s\x{00a0}\x{202f}]+$/u', '', $value);
        // Currency/test suffixes only: expressions, negatives and descriptive prices stay intact.
        $value = preg_replace('/\s*(?:kr|SEK)\.?\s*(?:\(test\))?\s*$/iu', '', $value);
        $value = preg_replace('/:\s*[-–]\s*$/u', '', $value ?? '');
        if (preg_match('/^(\d{1,3}(?:\.\d{3})+)(?:,(\d{1,2}))?$/D', $value ?? '', $parts)) {
            $whole = str_replace('.', '', $parts[1]);
        } elseif (preg_match('/^(\d{1,3}(?:,\d{3})+)(?:\.(\d{1,2}))?$/D', $value ?? '', $parts)) {
            $whole = str_replace(',', '', $parts[1]);
        } elseif (preg_match('/^(\d+|\d{1,3}(?:[ \x{00a0}\x{202f}]\d{3})+)(?:[.,](\d{1,2}))?$/uD', $value ?? '', $parts)) {
            $whole = preg_replace('/[ \x{00a0}\x{202f}]/u', '', $parts[1]);
        } else {
            return null;
        }
        $whole = ltrim($whole, '0') ?: '0';
        return strlen($whole) > 12 ? null : [$whole, $parts[2] ?? ''];
    }
}
