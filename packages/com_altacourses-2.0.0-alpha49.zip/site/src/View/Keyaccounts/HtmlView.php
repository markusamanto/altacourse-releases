<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\View\Keyaccounts;

\defined('_JEXEC') or die;

final class HtmlView extends \Advenire\Component\Altacourses\Site\View\Accountclients\HtmlView
{
}
