<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 * @var         \Advenire\Component\Altacourses\Site\View\Assignment\HtmlView $this
 */

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;
?>
<section class="altacourses-assignment" aria-labelledby="altacourses-assignment-heading">
    <h1 id="altacourses-assignment-heading"><?php echo $this->escape(Text::_('COM_ALTACOURSES_ASSIGN_SUPPLIER')); ?></h1>
    <p><?php echo $this->escape(Text::sprintf('COM_ALTACOURSES_AVAILABILITY_COURSE', (int) $this->course->id, $this->course->start_date ?? '')); ?></p>
    <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_ASSIGNMENT_HELP')); ?></p>
    <form id="altacourses-assignment-form" action="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&task=assignment.save')); ?>" method="post">
        <?php echo $this->form->getInput('id'); ?>
        <?php echo $this->form->getInput('version'); ?>
        <?php echo $this->form->renderField('supplier'); ?>
        <?php echo HTMLHelper::_('form.token'); ?>
        <button type="submit" class="btn btn-primary"><?php echo $this->escape(Text::_('JSAVE')); ?></button>
        <a class="btn btn-secondary" href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=managecourses&id=' . (int) $this->course->id)); ?>"><?php echo $this->escape(Text::_('JCANCEL')); ?></a>
    </form>
</section>
