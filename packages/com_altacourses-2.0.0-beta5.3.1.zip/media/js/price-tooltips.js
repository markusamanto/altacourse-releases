/** Delegated, dependency-free price explanations shared by component and modules. */
(() => {
  'use strict';
  const guard = Symbol.for('altacourses.price-tooltips');
  if (document[guard]) return;
  document[guard] = true;
  const selector = 'button[data-price-tooltip]';
  const records = new WeakMap();
  const dismissed = new WeakSet();
  let active = null;
  let closing = 0;
  let frame = 0;
  let sequence = 0;
  let activation = null;
  const resizing = new ResizeObserver(() => reposition());
  const buttonAt = node => node instanceof Element ? node.closest(selector) : null;
  const clearClose = () => { window.clearTimeout(closing); closing = 0; };
  function initialise(button) {
    if (records.has(button)) return records.get(button);
    const tip = button.parentElement?.querySelector('[role="tooltip"]');
    if (!tip) return null;
    if (!tip.id || document.getElementById(tip.id) !== tip) {
      do { tip.id = `altacourses-price-js-${++sequence}`; } while (document.getElementById(tip.id) && document.getElementById(tip.id) !== tip);
    }
    button.setAttribute('aria-describedby', tip.id);
    const record = { button, tip, parent: tip.parentNode, hovered: false };
    records.set(button, record);
    return record;
  }
  function close(suppress = false) {
    clearClose();
    if (!active) return;
    const old = active;
    active = null;
    resizing.disconnect();
    old.tip.hidden = true;
    old.hovered = false;
    if (suppress) dismissed.add(old.button);
    if (old.parent.isConnected) old.parent.append(old.tip);
    else old.tip.remove();
  }
  function position() {
    frame = 0;
    if (!active) return;
    const { button, tip } = active;
    if (!button.isConnected) { close(); return; }
    const v = window.visualViewport;
    const left = (v?.offsetLeft || 0) + 8;
    const top = (v?.offsetTop || 0) + 8;
    const width = v?.width || document.documentElement.clientWidth;
    const height = v?.height || window.innerHeight;
    const right = left + width - 16;
    const bottom = top + height - 16;
    const rect = button.getBoundingClientRect();
    if (rect.bottom < top || rect.top > bottom || rect.right < left || rect.left > right) { close(); return; }
    tip.style.maxWidth = `${Math.max(1, Math.min(352, width - 16))}px`;
    tip.style.maxHeight = `${Math.max(1, height - 16)}px`;
    const box = tip.getBoundingClientRect();
    const x = Math.max(left, Math.min(right - box.width, rect.left + (rect.width - box.width) / 2));
    const preferred = rect.bottom + 8 + box.height <= bottom ? rect.bottom + 8 : rect.top - box.height - 8;
    tip.style.left = `${x}px`;
    tip.style.top = `${Math.max(top, Math.min(bottom - box.height, preferred))}px`;
  }
  function reposition() { if (!frame) frame = window.requestAnimationFrame(position); }
  function open(button) {
    if (dismissed.has(button)) return;
    const record = initialise(button);
    if (!record) return;
    clearClose();
    if (active === record) return;
    close();
    active = record;
    document.body.append(record.tip);
    record.tip.hidden = false;
    resizing.observe(button);
    resizing.observe(record.tip);
    position();
  }
  function deferClose() {
    clearClose();
    closing = window.setTimeout(() => {
      if (active && !active.hovered && document.activeElement !== active.button) close();
    }, 300);
  }
  document.addEventListener('pointerover', event => {
    if (event.pointerType === 'touch') return;
    const button = buttonAt(event.target);
    if (button && !button.contains(event.relatedTarget)) {
      dismissed.delete(button);
      open(button);
      if (active?.button === button) { active.hovered = true; clearClose(); }
    } else if (active?.tip.contains(event.target)) { active.hovered = true; clearClose(); }
  });
  document.addEventListener('pointerout', event => {
    if (event.pointerType === 'touch') return;
    const departing = buttonAt(event.target);
    if (departing && !departing.contains(event.relatedTarget)) dismissed.delete(departing);
    if (!active) return;
    if (active.button.contains(event.target) || active.tip.contains(event.target)) {
      if (active.button.contains(event.relatedTarget) || active.tip.contains(event.relatedTarget)) return;
      active.hovered = false;
      if (document.activeElement !== active.button) dismissed.delete(active.button);
      deferClose();
    }
  });
  document.addEventListener('focusin', event => {
    const button = buttonAt(event.target);
    if (button) { dismissed.delete(button); open(button); }
  });
  document.addEventListener('focusout', event => {
    const button = buttonAt(event.target);
    if (button) { dismissed.delete(button); deferClose(); }
  });
  document.addEventListener('pointerdown', event => {
    const button = buttonAt(event.target);
    activation = button ? { button, wasOpen: active?.button === button } : null;
    if (active && !active.button.contains(event.target) && !active.tip.contains(event.target)) close(true);
  });
  document.addEventListener('click', event => {
    const button = buttonAt(event.target);
    if (!button) {
      if (active && !active.tip.contains(event.target)) close(true);
      activation = null;
      return;
    }
    event.preventDefault();
    const wasOpen = event.detail === 0 ? active?.button === button : activation?.button === button && activation.wasOpen;
    activation = null;
    if (wasOpen) close(true);
    else { dismissed.delete(button); open(button); }
  });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && active) { event.preventDefault(); close(true); }
  });
  document.fonts?.addEventListener('loadingdone', reposition);
  window.addEventListener('resize', reposition, { passive: true });
  document.addEventListener('scroll', reposition, { capture: true, passive: true });
  window.visualViewport?.addEventListener('resize', reposition, { passive: true });
  window.visualViewport?.addEventListener('scroll', reposition, { passive: true });
  function scan(node) {
    if (!(node instanceof Element || node instanceof Document)) return;
    if (node instanceof Element && node.matches(selector)) initialise(node);
    node.querySelectorAll(selector).forEach(initialise);
  }
  scan(document);
  new MutationObserver(changes => {
    if (active && !active.button.isConnected) close();
    else if (active) reposition();
    changes.forEach(change => change.addedNodes.forEach(scan));
  }).observe(document.documentElement, { childList: true, subtree: true });
})();
