/** Administrator last-minute copy convenience; all changes use protected server forms. */
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('[data-cancel-delete]').forEach(button => {
    button.addEventListener('click', () => { button.closest('details').open = false; });
  });
  const button = document.getElementById('lastminute-copy');
  if (!button) return;
  button.addEventListener('click', async () => {
    const field = document.getElementById('lastminute-copy-addresses');
    const status = document.getElementById('lastminute-copy-status');
    try {
      if (!navigator.clipboard || !window.isSecureContext) throw new Error('clipboard unavailable');
      await navigator.clipboard.writeText(field.value);
      status.textContent = button.dataset.success;
    } catch {
      document.getElementById('lastminute-copy-fallback').open = true;
      field.focus();
      field.select();
      status.textContent = button.dataset.failure;
    }
  });
});
