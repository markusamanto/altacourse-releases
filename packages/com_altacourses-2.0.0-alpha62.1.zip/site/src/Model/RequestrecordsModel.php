<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */
namespace Advenire\Component\Altacourses\Site\Model;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\CMS\MVC\Model\BaseModel;
use Joomla\CMS\User\CurrentUserInterface;
use Joomla\CMS\User\User;
use Joomla\CMS\User\UserFactoryAwareInterface;
use Joomla\CMS\User\UserFactoryAwareTrait;
use Joomla\Database\DatabaseAwareInterface;
use Joomla\Database\DatabaseAwareTrait;

\defined('_JEXEC') or die;

class RequestrecordsModel extends BaseModel implements DatabaseAwareInterface, CurrentUserInterface, UserFactoryAwareInterface
{
    use DatabaseAwareTrait;
    use UserFactoryAwareTrait;
    private ?User $currentUser = null;

    public function __construct($config = [], ?MVCFactoryInterface $factory = null) { parent::__construct($config); }
    public function setCurrentUser(User $currentUser): void { $this->currentUser = $currentUser; }

    public function requireAdministrator(): void
    {
        if (!$this->getActor()->authorise('altacourses.manage', 'com_altacourses')) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }
    }

    protected function getActor(): User
    {
        if ($this->currentUser === null || $this->currentUser->guest) { throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403); }
        $user = $this->getUserFactory()->loadUserById((int) $this->currentUser->id);
        if ($user->guest || $user->block) {
            throw new \RuntimeException(Text::_('JERROR_ALERTNOAUTHOR'), 403);
        }
        return $user;
    }

    protected function currentActorId(): int
    {
        $this->requireAdministrator();
        return (int) $this->currentUser->id;
    }

    /** Original agreement stays in s.course_json; operational lists show the latest movement. */
    protected function currentCourseExpression(): string
    {
        return 'COALESCE((SELECT rb.to_json FROM #__altacourses_request_rebookings AS rb WHERE rb.request_id=r.id AND rb.destination_request_id IS NULL ORDER BY rb.id DESC LIMIT 1),s.course_json)';
    }

}
