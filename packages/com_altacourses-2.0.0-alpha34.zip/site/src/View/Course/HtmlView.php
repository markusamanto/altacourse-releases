<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\View\Course;

use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareTrait;
use Advenire\Component\Altacourses\Administrator\Service\CoursePriceAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\CoursePriceAwareTrait;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;

\defined('_JEXEC') or die;

final class HtmlView extends BaseHtmlView implements CourseScheduleAwareInterface, CoursePriceAwareInterface
{
    use CourseScheduleAwareTrait;
    use CoursePriceAwareTrait;

    public ?object $item = null;
    public array $sessions = [];
    public array $filters = [];
    public bool $canEnquire = false;
    public bool $canSignup = false;
    public string $heading = '';
    public string $totalPrice = '';

    public function display($tpl = null): void
    {
        $this->item = $this->getModel()->getItem();
        $amount = $this->getCoursePrice()->formatTotal($this->item->course_price, $this->item->lodging_price, $this->item->lodging_included);
        $this->totalPrice = $amount === null ? '—' : $amount . ' ' . Text::_('COM_ALTACOURSES_CURRENCY');
        $this->sessions = $this->getCourseSchedule()->additionalSessions([(int) $this->item->id])[(int) $this->item->id] ?? [];
        $this->heading = Text::sprintf('COM_ALTACOURSES_COURSE_HEADING', $this->item->course_type ?? '', $this->item->course_place ?? '');
        $this->getDocument()->setTitle($this->heading);
        $this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.site');
        parent::display($tpl);
    }
}
