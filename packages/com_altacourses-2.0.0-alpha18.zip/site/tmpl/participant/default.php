<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;
?>
<section aria-labelledby="altacourses-participant-heading">
    <h1 id="altacourses-participant-heading"><?php echo $this->escape(Text::_('COM_ALTACOURSES_PARTICIPANT_TITLE')); ?></h1>
    <p><a data-back-signups href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=signups&limitstart=' . $this->returnStart, false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_PARTICIPANT_BACK')); ?></a></p>
    <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_PARTICIPANT_SNAPSHOT')); ?></p>
    <dl data-participant-contact>
        <?php foreach (['firstname' => 'SUPPLIER_FIRSTNAME', 'lastname' => 'SUPPLIER_LASTNAME', 'company' => 'ENQUIRY_ORGANISATION', 'email' => 'ENQUIRY_EMAIL', 'phone' => 'SUPPLIER_PHONE', 'mobile' => 'SUPPLIER_MOBILE', 'age' => 'SIGNUP_AGE', 'profession' => 'SIGNUP_PROFESSION', 'specialmeal' => 'SIGNUP_SPECIALMEAL', 'postal_address' => 'SIGNUP_POSTAL_ADDRESS', 'postal_zip' => 'SIGNUP_POSTAL_ZIP', 'postal_city' => 'SIGNUP_POSTAL_CITY', 'invoice_address' => 'SIGNUP_INVOICE_ADDRESS', 'invoice_zip' => 'SIGNUP_INVOICE_ZIP', 'invoice_city' => 'SIGNUP_INVOICE_CITY'] as $field => $label) : ?>
            <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_' . $label)); ?></dt><dd><?php echo $this->escape($this->contact[$field] ?? ''); ?></dd>
        <?php endforeach; ?>
    </dl>

    <h2><?php echo $this->escape(Text::_('COM_ALTACOURSES_PARTICIPANT_HISTORY')); ?></h2>
    <div class="table-responsive"><table class="table table-striped"><thead><tr>
        <?php foreach (['SIGNUP_CREATED', 'PARTICIPANT_KIND', 'COURSE_TYPE', 'PLACE', 'DATES', 'SIGNUP_VIEW'] as $label) : ?>
            <th scope="col"><?php echo $this->escape(Text::_('COM_ALTACOURSES_' . $label)); ?></th>
        <?php endforeach; ?>
    </tr></thead><tbody>
    <?php foreach ($this->history as $entry) : ?>
        <?php $course = json_decode($entry->course_json, true, 512, JSON_THROW_ON_ERROR); ?>
        <tr data-history-id="<?php echo (int) $entry->request_id; ?>"<?php if ((int) $entry->request_id === (int) $this->item->request_id) : ?> class="table-active"<?php endif; ?>>
            <td><?php echo $this->escape($entry->created_at); ?></td>
            <td><?php echo $this->escape(Text::_((int) $entry->asked_for_info === 1 ? 'COM_ALTACOURSES_ENQUIRY_TITLE' : 'COM_ALTACOURSES_SIGNUP_TITLE')); ?></td>
            <td><?php echo $this->escape($course['course_type'] ?? ''); ?></td>
            <td><?php echo $this->escape($course['course_place'] ?? ''); ?></td>
            <td><?php foreach ($course['sessions'] ?? [] as $part) : ?><div><?php echo $this->escape(substr($part['start_date'] ?? '', 0, 10) . ' – ' . substr($part['stop_date'] ?? '', 0, 10)); ?></div><?php endforeach; ?></td>
            <td><a data-history-view href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=participant&id=' . (int) $entry->request_id . '&return_start=' . $this->returnStart, false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_SIGNUP_VIEW')); ?></a></td>
        </tr>
    <?php endforeach; ?>
    </tbody></table></div>

    <h2><?php echo $this->escape(Text::_('COM_ALTACOURSES_PARTICIPANT_SELECTED')); ?></h2>
    <dl data-selected-submission>
        <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_PARTICIPANT_KIND')); ?></dt><dd><?php echo $this->escape(Text::_((int) $this->item->asked_for_info === 1 ? 'COM_ALTACOURSES_ENQUIRY_TITLE' : 'COM_ALTACOURSES_SIGNUP_TITLE')); ?></dd>
        <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_SIGNUP_CREATED')); ?></dt><dd><?php echo $this->escape($this->item->created_at); ?></dd>
        <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_LEADERS')); ?></dt><dd><?php echo $this->escape(implode(', ', array_filter([$this->course['leader1'] ?? '', $this->course['leader2'] ?? '']))); ?></dd>
        <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_ENQUIRY_SUPPLIER')); ?></dt><dd><?php echo $this->escape($this->item->supplier_email); ?></dd>
        <?php if ((int) $this->item->asked_for_info === 0) : ?>
            <?php $booking = $this->course['booking'] ?? []; ?>
            <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_TOTAL_PRICE')); ?></dt><dd><?php echo $this->escape(($booking['total_price'] ?? '') . ' ' . Text::_('COM_ALTACOURSES_CURRENCY')); ?></dd>
            <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_SUPPLIER_TERMS')); ?></dt><dd><?php echo nl2br($this->escape($booking['terms'] ?? '')); ?></dd>
            <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_SIGNUP_ACCEPTED_AT')); ?></dt><dd><?php echo $this->escape($booking['accepted_at'] ?? ''); ?></dd>
        <?php endif; ?>
    </dl>
</section>
