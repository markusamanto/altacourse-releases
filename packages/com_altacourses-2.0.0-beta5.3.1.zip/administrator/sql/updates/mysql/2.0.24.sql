-- Widen only the Alpha62 enrolment references to match unsigned legacy request/client IDs.
-- Joomla's schema checker requires one MODIFY per statement, without optional COLUMN.
ALTER TABLE `#__altacourses_mailchimp_enrollments`
 MODIFY `request_id` int unsigned NOT NULL;
ALTER TABLE `#__altacourses_mailchimp_enrollments`
 MODIFY `client_id` int unsigned NOT NULL;
