<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
\defined('_JEXEC') or die;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
?>
<h1 id="altacourses-invitations-heading"><?php echo Text::_('COM_ALTACOURSES_EVINV_TITLE'); ?></h1>
<p><?php echo Text::_('COM_ALTACOURSES_EVINV_INTRO'); ?></p>
<form method="get" action="<?php echo Route::_('index.php'); ?>">
<input type="hidden" name="option" value="com_altacourses"><input type="hidden" name="view" value="invitations">
<label for="monthly-period"><?php echo Text::_('COM_ALTACOURSES_COMMISSION_MONTH'); ?></label>
<input id="monthly-period" type="month" name="month" required value="<?php echo $this->escape($this->month); ?>">
<button class="btn btn-primary" type="submit"><?php echo Text::_('COM_ALTACOURSES_FILTER'); ?></button>
</form>
<?php if ($this->blockedReason !== null) : ?>
<p class="alert alert-warning"><?php echo Text::_('COM_ALTACOURSES_EVINV_BLOCKED'); ?> (<?php echo $this->escape($this->blockedReason); ?>)</p>
<?php endif; ?>
<?php if ($this->month === $this->currentMonth) : ?>
<form method="post" action="<?php echo Route::_('index.php?option=com_altacourses&task=invitations.send'); ?>">
<input type="hidden" name="jform[month]" value="<?php echo $this->escape($this->month); ?>">
<?php echo HTMLHelper::_('form.token'); ?>
<button class="btn btn-primary" type="submit"><?php echo Text::_('COM_ALTACOURSES_EVINV_TEST'); ?></button>
</form>
<?php endif; ?>
<?php if (!$this->messages) : ?><p role="status"><?php echo Text::_('COM_ALTACOURSES_EVINV_EMPTY'); ?></p><?php endif; ?>
<?php foreach ($this->messages as $message) : ?>
<section class="card card-body my-3 text-break">
<h2><?php echo $this->escape($message->client_name); ?> (#<?php echo (int)$message->request_id; ?>)</h2>
<?php if ($message->subject !== '') : ?><h3><?php echo $this->escape($message->subject); ?></h3><?php endif; ?>
<p><?php echo Text::_('COM_ALTACOURSES_MAILTEMPLATE_FROM_NAME'); ?>: <?php echo $this->escape($message->from_name . ' <' . $message->from_email . '>'); ?></p>
<p><?php echo Text::_('COM_ALTACOURSES_EVINV_REFERENCE'); ?>: <code><?php echo $this->escape($message->message_id); ?></code></p>
<p><?php echo Text::_('COM_ALTACOURSES_MONTHLY_RECIPIENT'); ?>: <?php echo $this->escape($message->recipient); ?></p>
<p><?php echo Text::_('COM_ALTACOURSES_EVINV_STATUS_' . strtoupper($message->state)); ?></p>
<?php if ($message->last_error !== null) : ?><p><?php echo $this->escape($message->last_error); ?></p><?php endif; ?>
<p><?php echo nl2br($this->escape($message->body)); ?></p>
<?php if ($message->state === 'uncertain' || ($message->state === 'sending' && strtotime($message->claimed_at . ' UTC') < time() - 300)) : ?>
<form method="post" action="<?php echo Route::_('index.php?option=com_altacourses&task=invitations.confirm'); ?>">
<input type="hidden" name="jform[month]" value="<?php echo $this->escape($this->month); ?>"><input type="hidden" name="jform[id]" value="<?php echo (int) $message->id; ?>">
<input type="hidden" name="jform[token]" value="<?php echo $this->escape($message->attempt_token); ?>">
<label><input type="checkbox" name="jform[review]" value="1" required> <?php echo Text::_('COM_ALTACOURSES_MONTHLY_REVIEW'); ?></label>
<?php echo HTMLHelper::_('form.token'); ?>
<button type="submit" class="btn btn-secondary"><?php echo Text::_('COM_ALTACOURSES_MONTHLY_CONFIRM'); ?></button>
<?php if ($this->blockedReason === null) : ?>
<button type="submit" class="btn btn-warning" formaction="<?php echo Route::_('index.php?option=com_altacourses&task=invitations.retry'); ?>"><?php echo Text::_('COM_ALTACOURSES_MONTHLY_RETRY'); ?></button>
<?php endif; ?>
</form>
<?php endif; ?>
</section>
<?php endforeach; ?>
