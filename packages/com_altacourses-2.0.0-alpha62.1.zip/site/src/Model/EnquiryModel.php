<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Model;

\defined('_JEXEC') or die;

final class EnquiryModel extends SubmissionModel
{
    public function createEnquiry(int $courseId, int $expectedRevision, string $token, array $input): int
    {
        return $this->submit($courseId, $expectedRevision, $token, $input);
    }
}
