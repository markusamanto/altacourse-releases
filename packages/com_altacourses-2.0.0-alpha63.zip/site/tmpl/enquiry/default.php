<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
\defined('_JEXEC') or die;
?>
<section class="altacourses-portal" aria-labelledby="altacourses-enquiry-heading">
    <h1 id="altacourses-enquiry-heading"><?php echo $this->escape(Text::_('COM_ALTACOURSES_ENQUIRY_TITLE')); ?></h1>
    <dl class="altacourses-enquiry-summary">
        <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_COURSE_TYPE')); ?></dt><dd><?php echo $this->escape($this->summary['course_type']); ?></dd>
        <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_DATES')); ?></dt><dd>
            <?php foreach ($this->summary['sessions'] as $index => $session) : ?>
                <div data-session="<?php echo $index + 1; ?>">
                    <?php if (count($this->summary['sessions']) > 1) : ?><strong><?php echo $this->escape(Text::sprintf('COM_ALTACOURSES_SESSION_NUMBER', $index + 1)); ?>:</strong><?php endif; ?>
                    <time datetime="<?php echo $this->escape(substr($session['start_date'] ?? '', 0, 10)); ?>"><?php echo $this->escape(substr($session['start_date'] ?? '', 0, 10)); ?></time>
                    <?php if (!empty($session['stop_date']) && substr($session['stop_date'], 0, 10) !== substr($session['start_date'] ?? '', 0, 10)) : ?>
                        – <time datetime="<?php echo $this->escape(substr($session['stop_date'], 0, 10)); ?>"><?php echo $this->escape(substr($session['stop_date'], 0, 10)); ?></time>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </dd>
        <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_PLACE')); ?></dt><dd><?php echo $this->escape($this->summary['course_place']); ?></dd>
        <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_LEADERS')); ?></dt><dd><?php echo $this->escape(implode(', ', array_filter([$this->summary['leader1'], $this->summary['leader2']]))); ?></dd>
    </dl>
    <form id="altacourses-enquiry-form" action="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&task=enquiry.save', false)); ?>" method="post">
        <?php echo $this->form->getInput('coid') . $this->form->getInput('submission'); ?>
        <?php foreach (['firstname', 'lastname', 'company', 'email', 'phone', 'mobile'] as $field) : ?><?php echo $this->form->renderField($field); ?><?php endforeach; ?>
        <?php echo $this->form->renderField('newsletter'); ?>
        <?php echo HTMLHelper::_('form.token'); ?>
        <button type="submit" class="btn btn-primary"><?php echo $this->escape(Text::_('COM_ALTACOURSES_ENQUIRY_SUBMIT')); ?></button>
        <a class="btn btn-secondary" href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=course&id=' . (int) $this->summary['id'], false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_ENQUIRY_BACK')); ?></a>
    </form>
</section>
