<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\Router\Route;
\defined('_JEXEC') or die;
$navigation = ['return_start' => $this->returnStart] + $this->returnFilters;
?>
<section aria-labelledby="altacourses-client-heading" data-client-id="<?php echo $this->clientId; ?>">
    <h1 id="altacourses-client-heading"><?php echo $this->escape(Text::_('COM_ALTACOURSES_CLIENT_TITLE')); ?></h1>
    <p><a data-back-contacts href="<?php echo $this->escape(Route::_('index.php?' . http_build_query(['option' => 'com_altacourses', 'view' => 'contacts', 'limitstart' => $this->returnStart] + $this->returnFilters), false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_CONTACTS_BACK')); ?></a></p>
    <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_CLIENT_CURRENT')); ?></p>
    <?php if ($this->accountForm !== null) : ?>
        <form id="altacourses-clientaccount-form" action="<?php echo $this->escape(Route::_('index.php?' . http_build_query(['option' => 'com_altacourses', 'task' => 'clientaccount.save'] + $navigation), false)); ?>" method="post">
            <?php foreach (['client_id', 'version'] as $field) : ?><?php echo $this->accountForm->getInput($field); ?><?php endforeach; ?>
            <?php echo $this->accountForm->renderField('account'); ?><?php echo HTMLHelper::_('form.token'); ?>
            <button type="submit" class="btn btn-success"><?php echo $this->escape(Text::_('JSAVE')); ?></button>
        </form>
    <?php endif; ?>
    <?php if ($this->administrator) : ?><p><a class="btn btn-primary" data-client-edit href="<?php echo $this->escape(Route::_('index.php?' . http_build_query(['option'=>'com_altacourses','view'=>'editclient','id'=>$this->clientId]+$navigation), false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_CLIENT_EDIT')); ?></a></p><?php endif; ?>
    <?php echo LayoutHelper::render('contactfields', ['view' => $this], dirname(__DIR__, 2) . '/layouts'); ?>
    <?php if (!$this->administrator) : ?><p><?php echo $this->escape(Text::_('COM_ALTACOURSES_CONTACTS_HISTORY_SCOPE')); ?></p><?php endif; ?>
    <h2><?php echo $this->escape(Text::_('COM_ALTACOURSES_PARTICIPANT_HISTORY')); ?></h2>
    <?php if (!$this->history) : ?><p><?php echo $this->escape(Text::_('COM_ALTACOURSES_CLIENT_NO_HISTORY')); ?></p><?php else : ?>
    <div class="table-responsive"><table class="table table-striped"><thead><tr>
        <?php foreach (['SIGNUP_CREATED', 'PARTICIPANT_KIND', 'COURSE_TYPE', 'PLACE', 'DATES', 'FORMDATA_TITLE'] as $label) : ?><th scope="col"><?php echo $this->escape(Text::_('COM_ALTACOURSES_' . $label)); ?></th><?php endforeach; ?>
    </tr></thead><tbody>
    <?php foreach ($this->history as $entry) : ?>
        <?php $course = json_decode($entry->course_json, true, 512, JSON_THROW_ON_ERROR); ?>
        <tr data-history-id="<?php echo (int) $entry->request_id; ?>">
            <td><?php echo $this->escape($entry->created_at ?? Text::_('COM_ALTACOURSES_ACCOUNTCLIENTS_NO_DATE')); ?></td>
            <td><?php echo $this->escape(Text::_((int) $entry->rebooked === 1 ? 'COM_ALTACOURSES_REBOOK_KIND' : ((int) $entry->asked_for_info === 1 ? 'COM_ALTACOURSES_ENQUIRY_TITLE' : 'COM_ALTACOURSES_SIGNUP_TITLE'))); ?></td>
            <td><?php echo $this->escape($course['course_type'] ?? ''); ?></td><td><?php echo $this->escape($course['course_place'] ?? ''); ?></td>
            <td><?php foreach ($course['sessions'] ?? [] as $part) : ?><div><?php echo $this->escape(substr($part['start_date'] ?? '', 0, 10) . ' – ' . substr($part['stop_date'] ?? '', 0, 10)); ?></div><?php endforeach; ?></td>
            <td><?php if ($entry->submission_id === null) : ?>
                    <span data-no-formdata><?php echo $this->escape(Text::_('COM_ALTACOURSES_FORMDATA_MISSING_SHORT')); ?></span>
                <?php else : ?>
                    <a data-formdata-view href="<?php echo $this->escape(Route::_('index.php?' . http_build_query(['option' => 'com_altacourses', 'view' => 'formdata', 'id' => (int) $entry->request_id] + $navigation), false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_FORMDATA_VIEW')); ?></a>
                    <?php if ($this->administrator) : ?><br /><a data-client-mail href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=notifications&id=' . (int) $entry->request_id, false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_NOTIFY_TITLE')); ?></a><?php endif; ?>
                <?php endif; ?>
                <?php
                $canRebook = false;
                try { $this->getModel('Rebooking')->getRecord((int) $entry->request_id); $canRebook = true; }
                catch (\RuntimeException $error) { if (!in_array($error->getCode(), [403,404,409], true)) { throw $error; } }
                ?>
                <?php if ($canRebook) : ?><br /><a class="btn btn-success btn-sm" data-rebook-request="<?php echo (int) $entry->request_id; ?>" href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=rebooking&id=' . (int) $entry->request_id, false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_REBOOK_ACTION')); ?></a><?php endif; ?>
            </td>
        </tr>
        <?php if (in_array((int) $entry->rebooked, [1,2], true)) : ?>
        <tr data-rebooking-info="<?php echo (int) $entry->request_id; ?>"><td colspan="6">
            <?php echo $this->escape(Text::_((int) $entry->rebooked === 1 ? 'COM_ALTACOURSES_REBOOK_NEW_INFO' : 'COM_ALTACOURSES_REBOOK_OLD_INFO')); ?>
            <?php echo $this->escape($entry->created_at ?? Text::_('COM_ALTACOURSES_ACCOUNTCLIENTS_NO_DATE')); ?>
            <?php if ($entry->creator_name) : ?> · <?php echo $this->escape($entry->creator_name); ?><?php endif; ?>
            <?php if ($entry->rebooked_at !== null) : ?><br /><?php echo $this->escape(Text::_('COM_ALTACOURSES_REBOOK_EVENT') . ' ' . $entry->rebooked_at . ($entry->rebooked_by ? ' · ' . $entry->rebooked_by : '')); ?><?php endif; ?>
        </td></tr>
        <?php endif; ?>
    <?php endforeach; ?>
    </tbody></table></div>
    <?php endif; ?>
</section>
