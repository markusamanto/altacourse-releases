<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Model;
use Advenire\Component\Altacourses\Site\Exception\CourseValidationException;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Form\FormFactoryAwareInterface;
use Joomla\CMS\Form\FormFactoryAwareTrait;
use Joomla\CMS\Language\Text;
use Joomla\CMS\String\PunycodeHelper;
\defined('_JEXEC') or die;

/** Only live contact fields change; submitted forms and delivery records are immutable. */
final class EditclientModel extends RequestrecordsModel implements FormFactoryAwareInterface
{
    use FormFactoryAwareTrait;
    public const FIELDS = ['firstname','lastname','company','email','phone','mobile','age','profession','specialmeal','postal_address','postal_zip','postal_city','postal_state','postal_country','invoice_address','invoice_zip','invoice_city'];

    public function getRecord(int $id): object
    {
        $this->requireAdministrator();
        $db=$this->getDatabase();
        $r=$db->setQuery('SELECT * FROM #__altacourses_clients WHERE id='.$id)->loadObject();
        if($id<=0||$r===null){throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'),404);}
        return $r;
    }
    public function formData(object $r): array
    {
        $data=['id'=>(string)$r->id,'version'=>hash('sha256',json_encode($r,JSON_THROW_ON_ERROR))];
        foreach(self::FIELDS as $f){$data[$f]=(string)($r->$f??'');}
        return $data;
    }
    public function getForm(array $data): Form
    {
        $this->requireAdministrator();
        $form=$this->getFormFactory()->createForm('com_altacourses.editclient',['control'=>'jform']);
        if(!$form->loadFile(dirname(__DIR__,2).'/forms/editclient.xml')){throw new \RuntimeException('Client form unavailable');}
        $form->bind($data);return $form;
    }
    public function save(int $id,string $version,array $input): void
    {
        $this->requireAdministrator();
        if(array_diff(array_keys($input),self::FIELDS)||array_diff(self::FIELDS,array_keys($input))){throw new CourseValidationException([Text::_('COM_ALTACOURSES_NEW_FIELDS_INVALID')]);}
        $db=$this->getDatabase();$db->transactionStart();
        try{
            $r=$db->setQuery('SELECT * FROM #__altacourses_clients WHERE id='.$id.' FOR UPDATE')->loadObject();
            if($id<=0||$r===null){throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'),404);}
            if(!preg_match('/^[a-f0-9]{64}$/D',$version)||!hash_equals(hash('sha256',json_encode($r,JSON_THROW_ON_ERROR)),$version)){throw new \RuntimeException(Text::_('COM_ALTACOURSES_CLIENT_EDIT_CONFLICT'),409);}
            if((int)$r->checked_out!==0&&(int)$r->checked_out!==$this->currentActorId()){throw new \RuntimeException(Text::_('COM_ALTACOURSES_AVAILABILITY_LOCKED'),409);}
            $changes=[];$errors=[];
            foreach(self::FIELDS as $field){
                $value=$input[$field];
                if(!is_string($value)){$errors[]=Text::_('COM_ALTACOURSES_NEW_FIELDS_INVALID');continue;}
                // Preserve unchanged legacy NULLs, whitespace and nonstandard values verbatim.
                if($value===(string)($r->$field??'')){continue;}
                $value=trim($value);
                if(mb_strlen($value)>255||preg_match('/[\x00-\x1f\x7f]/',$value)){$errors[]=Text::_('COM_ALTACOURSES_NEW_FIELDS_INVALID');}
                if(in_array($field,['firstname','lastname'],true)&&$value===''){$errors[]=Text::_('COM_ALTACOURSES_CLIENT_EDIT_NAME_REQUIRED');}
                if($field==='email'){
                    try{$value=PunycodeHelper::emailToPunycode($value);}catch(\Throwable){$value='';}
                    if(strlen($value)>254||!filter_var($value,FILTER_VALIDATE_EMAIL)){$errors[]=Text::_('COM_ALTACOURSES_CLIENT_EDIT_EMAIL_INVALID');}
                }
                if($value!==(string)($r->$field??'')){$changes[$field]=$value;}
            }
            if($errors){throw new CourseValidationException(array_values(array_unique($errors)));}
            $this->requireAdministrator();
            if($changes){$update=(object)(['id'=>$id,'modified_by'=>$this->currentActorId()]+$changes);$db->updateObject('#__altacourses_clients',$update,'id');}
            $db->transactionCommit();
        }catch(\Throwable $e){$db->transactionRollback();throw $e;}
    }
}
