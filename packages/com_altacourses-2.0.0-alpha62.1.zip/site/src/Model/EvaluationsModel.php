<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Model;
use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareInterface;
use Advenire\Component\Altacourses\Administrator\Service\CourseScheduleAwareTrait;
use Joomla\CMS\Language\Text;
use Joomla\Database\ParameterType;
\defined('_JEXEC') or die;

/** Administrator moderation; state is the legacy public-module publication flag. */
final class EvaluationsModel extends RequestrecordsModel implements CourseScheduleAwareInterface
{
    use CourseScheduleAwareTrait;
    public function getItems(): array
    {
        $this->requireAdministrator();$db=$this->getDatabase();
        $q=$db->createQuery()->select(['e.*','cl.firstname','cl.lastname','co.id AS course_id','cp.name AS course_place','l1.name AS leader1','l2.name AS leader2','sp.company AS supplier'])
            ->from('#__altacourses_evaluations AS e')
            ->join('LEFT','#__altacourses_requests AS r ON r.id=e.request_id')
            ->join('LEFT','#__altacourses_clients AS cl ON cl.id=r.clientid')
            ->join('LEFT','#__altacourses_courses AS co ON co.id=r.courseid')
            ->join('LEFT','#__altacourses_courseplaces AS cp ON cp.id=co.course_place')
            ->join('LEFT','#__altacourses_courseleaders AS l1 ON l1.id=co.course_leader_1')
            ->join('LEFT','#__altacourses_courseleaders AS l2 ON l2.id=co.course_leader_2')
            ->join('LEFT','#__altacourses_suppliers AS sp ON sp.id=(SELECT s.id FROM #__altacourses_suppliers AS s WHERE s.user_id=co.cr ORDER BY s.id LIMIT 1)')
            ->order('e.rating_date DESC, e.id DESC');
        $rows=$db->setQuery($q,(int)$this->getState('list.start',0),20)->loadObjectList();
        $schedules=$this->getCourseSchedule()->currentSessions(array_values(array_unique(array_map(static fn($r)=>(int)$r->course_id,$rows))));
        foreach ($rows as $row) { $row->sessions=$schedules[(int)$row->course_id]??[]; }
        return $rows;
    }
    public function isLocked(object $row): bool
    {
        return (int)$row->checked_out!==0&&(int)$row->checked_out!==$this->currentActorId();
    }
    public function getTotal(): int
    {
        $this->requireAdministrator();return (int)$this->getDatabase()->setQuery('SELECT COUNT(*) FROM #__altacourses_evaluations')->loadResult();
    }
    /** Only stored evaluation fields enter the fingerprint; joined display context is read-only. */
    public function version(object $row): string
    {
        $values=[];
        foreach (['id','request_id','rating_overall','rating_leaders','rating_place','review','feedback','correction','response','review_published','rating_date','feedback_read','rating_moderate_code','ordering','state','checked_out','checked_out_time','created_by'] as $f) { $values[$f]=$row->$f??null; }
        return hash('sha256',json_encode($values,JSON_THROW_ON_ERROR));
    }
    public function publish(int $id,int $state,string $version): void
    {
        $this->requireAdministrator();
        if ($id<1||$id>4294967295||!in_array($state,[0,1],true)||!preg_match('/^[a-f0-9]{64}$/D',$version)) { throw new \RuntimeException(Text::_('COM_ALTACOURSES_EVALADMIN_INVALID'),400); }
        $db=$this->getDatabase();$db->transactionStart();
        try {
            $q=$db->createQuery()->select('*')->from('#__altacourses_evaluations')->where('id=:evaluation_id')->bind(':evaluation_id',$id,ParameterType::INTEGER);
            $q->setQuery((string)$q.' FOR UPDATE');$row=$db->setQuery($q)->loadObject();
            if ($row===null) { throw new \RuntimeException(Text::_('COM_ALTACOURSES_EVALADMIN_NOT_FOUND'),404); }
            if ((int)$row->checked_out!==0&&(int)$row->checked_out!==$this->currentActorId()) { throw new \RuntimeException(Text::_('COM_ALTACOURSES_AVAILABILITY_LOCKED'),409); }
            if (!hash_equals($this->version($row),$version)) { throw new \RuntimeException(Text::_('COM_ALTACOURSES_EVALADMIN_CONFLICT'),409); }
            // The legacy public module uses state=1. Never rewrite answers or unused review_published.
            $update=(object)['id'=>$id,'state'=>$state];$db->updateObject('#__altacourses_evaluations',$update,'id');
            $db->transactionCommit();
        } catch (\Throwable $e) { $db->transactionRollback();throw $e; }
    }
}
