<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;
$id = (int) $this->record['id'];
?>
<section aria-labelledby="altacourses-notifications-heading">
    <h1 id="altacourses-notifications-heading"><?php echo $this->escape(Text::_('COM_ALTACOURSES_NOTIFY_TITLE')); ?> #<?php echo $id; ?></h1>
    <p><a href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=deliveries', false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_NOTIFY_BACK')); ?></a></p>
    <p><a href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=client&id=' . (int) $this->record['client_id'], false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_CLIENT_BACK')); ?></a></p>
    <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_NOTIFY_TEST_ONLY')); ?></p>
    <?php if ($this->record['blocked'] !== null) : ?><p class="alert alert-warning" data-mail-blocked><?php echo $this->escape(Text::_('COM_ALTACOURSES_NOTIFY_REASON_' . strtoupper($this->record['blocked']))); ?></p><?php endif; ?>
    <?php if (!$this->record['messages']) : ?>
        <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_NOTIFY_HISTORIC')); ?></p>
        <form action="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&task=notification.prepare', false)); ?>" method="post">
            <input type="hidden" name="id" value="<?php echo $id; ?>" /><?php echo HTMLHelper::_('form.token'); ?>
            <button class="btn btn-secondary" type="submit"><?php echo $this->escape(Text::_('COM_ALTACOURSES_NOTIFY_PREPARE')); ?></button>
        </form>
    <?php else : ?>
        <?php foreach ($this->record['messages'] as $message) : ?>
            <section data-message-id="<?php echo (int) $message->id; ?>">
                <h2><?php echo $this->escape(Text::_('COM_ALTACOURSES_NOTIFY_ROLE_' . strtoupper($message->role))); ?></h2>
                <dl>
                    <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_NOTIFY_RECIPIENT')); ?></dt><dd><?php echo $this->escape($message->recipient); ?></dd>
                    <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_NOTIFY_STATE')); ?></dt><dd data-mail-state><?php echo $this->escape(Text::_('COM_ALTACOURSES_NOTIFY_STATE_' . strtoupper($message->state))); ?></dd>
                    <?php $failure = explode('|', (string) $message->last_error); ?>
                    <?php if (in_array($failure[0], ['rate_limit', 'authentication', 'connection', 'recipient_rejected', 'smtp_rejected', 'smtp_unconfirmed', 'status_unconfirmed'], true)) : ?>
                        <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_NOTIFY_FAILURE_LABEL')); ?></dt>
                        <dd data-mail-diagnostic><?php echo $this->escape(Text::_('COM_ALTACOURSES_NOTIFY_FAILURE_' . strtoupper($failure[0]))); ?>
                            <?php if (isset($failure[1]) && preg_match('/^[45][0-9]{2}$/D', $failure[1])) : ?>
                                (SMTP <?php echo $this->escape($failure[1]); ?><?php if (isset($failure[2]) && preg_match('/^[45]\.[0-9]{1,3}\.[0-9]{1,3}$/D', $failure[2])) : ?> / <?php echo $this->escape($failure[2]); ?><?php endif; ?>)
                            <?php endif; ?>
                        </dd>
                    <?php endif; ?>
                    <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_NOTIFY_ATTEMPTS')); ?></dt><dd><?php echo (int) $message->attempts; ?></dd>
                    <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_NOTIFY_SENT_AT')); ?></dt><dd><?php echo $this->escape($message->sent_at ?? ''); ?></dd>
                    <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_NOTIFY_MESSAGE_ID')); ?></dt><dd><?php echo $this->escape($message->message_id); ?></dd>
                    <dt><?php echo $this->escape(Text::_('COM_ALTACOURSES_NOTIFY_SUBJECT')); ?></dt><dd><?php echo $this->escape($message->subject); ?></dd>
                </dl>
                <?php if ($message->last_error === 'operator_confirmed') : ?><p><?php echo $this->escape(Text::_('COM_ALTACOURSES_NOTIFY_OPERATOR_CONFIRMED') . ' ' . ($message->reviewed_at ?? '')); ?></p><?php endif; ?>
                <pre class="altacourses-mail-preview"><?php echo $this->escape($message->body); ?></pre>
                <?php if ($message->state === 'uncertain' || ($message->state === 'sending' && strtotime($message->claimed_at . ' UTC') < time() - 300)) : ?>
                    <p class="alert alert-warning"><?php echo $this->escape(Text::_('COM_ALTACOURSES_NOTIFY_UNCERTAIN_HELP')); ?></p>
                    <form action="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&task=notification.confirm', false)); ?>" method="post">
                        <input type="hidden" name="id" value="<?php echo $id; ?>" /><input type="hidden" name="message_id" value="<?php echo (int) $message->id; ?>" />
                        <label><input type="checkbox" name="reviewed" value="1" required /> <?php echo $this->escape(Text::_('COM_ALTACOURSES_NOTIFY_CONFIRM_REVIEW')); ?></label>
                        <?php echo HTMLHelper::_('form.token'); ?><button class="btn btn-secondary" type="submit"><?php echo $this->escape(Text::_('COM_ALTACOURSES_NOTIFY_CONFIRM')); ?></button>
                    </form>
                    <?php if ($this->record['blocked'] === null) : ?>
                        <form action="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&task=notification.retry', false)); ?>" method="post">
                            <input type="hidden" name="id" value="<?php echo $id; ?>" /><input type="hidden" name="message_id" value="<?php echo (int) $message->id; ?>" />
                            <label><input type="checkbox" name="reviewed" value="1" required /> <?php echo $this->escape(Text::_('COM_ALTACOURSES_NOTIFY_REVIEW')); ?></label>
                            <?php echo HTMLHelper::_('form.token'); ?><button class="btn btn-secondary" type="submit"><?php echo $this->escape(Text::_('COM_ALTACOURSES_NOTIFY_RETRY')); ?></button>
                        </form>
                    <?php endif; ?>
                <?php endif; ?>
            </section>
        <?php endforeach; ?>
        <?php if ($this->record['blocked'] === null) : ?>
            <form action="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&task=notification.send', false)); ?>" method="post">
                <input type="hidden" name="id" value="<?php echo $id; ?>" /><?php echo HTMLHelper::_('form.token'); ?>
                <button class="btn btn-primary" type="submit"><?php echo $this->escape(Text::_('COM_ALTACOURSES_NOTIFY_SEND_PENDING')); ?></button>
            </form>
        <?php endif; ?>
    <?php endif; ?>
</section>
