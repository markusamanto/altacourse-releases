<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\View\Readreceipt;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;

\defined('_JEXEC') or die;

final class HtmlView extends BaseHtmlView
{
    public function display($tpl = null): void
    {
        $this->getDocument()->setTitle(Text::_('COM_ALTACOURSES_RECEIPT_TITLE'));
        $this->getDocument()->setMetaData('robots', 'noindex, nofollow');
        $this->getDocument()->setMetaData('referrer', 'no-referrer');
        parent::display($tpl);
    }
}
