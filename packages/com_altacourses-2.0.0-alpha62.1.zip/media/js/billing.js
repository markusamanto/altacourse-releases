/** Financial disposition choices are also validated on the server. */
document.addEventListener('DOMContentLoaded', () => {
 const invoiced = document.getElementById('billing-invoiced');
 const exempt = document.getElementById('billing-no_invoicing');
 if (!invoiced || !exempt) return;
 invoiced.addEventListener('change', () => { if (invoiced.checked) exempt.checked = false; });
 exempt.addEventListener('change', () => { if (exempt.checked) invoiced.checked = false; });
});
