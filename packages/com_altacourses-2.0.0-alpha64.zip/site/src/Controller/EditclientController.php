<?php
/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Controller;
use Advenire\Component\Altacourses\Site\Exception\CourseValidationException;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;
\defined('_JEXEC') or die;
final class EditclientController extends BaseController
{
    public function execute($task)
    {
        if(strtolower((string)$task)!=='save'||$this->app->getDocument()->getType()!=='html'){throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'),404);}
        return parent::execute($task);
    }
    public function save(): void
    {
        $model=$this->getModel('Editclient','Site',['ignore_request'=>true]);$model->requireAdministrator();
        if($this->input->getMethod()!=='POST'){throw new \RuntimeException(Text::_('COM_ALTACOURSES_SAMPLE_POST_REQUIRED'),405);}
        if(!$this->checkToken('post',false)){throw new \RuntimeException(Text::_('JINVALID_TOKEN'),403);}
        $raw=$this->input->post->get('jform',[],'array');$id=$raw['id']??null;$version=$raw['version']??null;
        if(!is_string($id)||!ctype_digit($id)||(float)$id<1||(float)$id>4294967295||!is_string($version)||!preg_match('/^[a-f0-9]{64}$/D',$version)||array_diff(array_keys($raw),array_merge(['id','version'],$model::FIELDS))){throw new \RuntimeException(Text::_('COM_ALTACOURSES_NEW_FIELDS_INVALID'),400);}
        $navigation=['return_start'=>$this->input->get('return_start','0','raw')];
        if(!is_string($navigation['return_start'])||!ctype_digit($navigation['return_start'])||(float)$navigation['return_start']>2147483647){throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_FILTER'),400);}
        foreach(['kind'=>10,'search'=>120,'type'=>255] as $key=>$length){$value=$this->input->get($key,$key==='kind'?'all':'','raw');if(!is_string($value)||mb_strlen($value)>$length||preg_match('/[\x00-\x1f\x7f]/',$value)){throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_FILTER'),400);}$navigation[$key]=trim($value);}
        if(!in_array($navigation['kind'],['all','signup','enquiry'],true)){throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_FILTER'),400);}
        $key='com_altacourses.editclient.'.(int)$this->app->getIdentity()->id.'.draft.'.(int)$id;
        $draft=['id'=>$id,'version'=>$version];foreach($model::FIELDS as $f){if(isset($raw[$f])&&is_string($raw[$f])){$draft[$f]=mb_substr($raw[$f],0,255);}}
        $this->app->setUserState($key,$draft);unset($raw['id'],$raw['version']);
        try{$model->save((int)$id,$version,$raw);}
        catch(CourseValidationException $e){foreach($e->messages as $message){$this->app->enqueueMessage($message,'warning');}$this->setRedirect(Route::_('index.php?'.http_build_query(['option'=>'com_altacourses','view'=>'editclient','id'=>(int)$id]+$navigation),false));return;}
        catch(\Throwable $e){if($e->getCode()!==409){throw $e;}$this->setMessage($e->getMessage(),'warning');$this->setRedirect(Route::_('index.php?'.http_build_query(['option'=>'com_altacourses','view'=>'editclient','id'=>(int)$id]+$navigation),false));return;}
        $this->app->setUserState($key,null);$this->setMessage(Text::_('COM_ALTACOURSES_CLIENT_EDIT_SAVED'));
        $this->setRedirect(Route::_('index.php?'.http_build_query(['option'=>'com_altacourses','view'=>'client','id'=>(int)$id]+$navigation),false));
    }
}
