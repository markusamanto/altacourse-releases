<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */
namespace Advenire\Component\Altacourses\Site\View\Enquiryreceipt;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
\defined('_JEXEC') or die;
final class HtmlView extends BaseHtmlView
{
    public int $courseId = 0;
    public function display($tpl = null): void
    {
        $this->getDocument()->setTitle(Text::_('COM_ALTACOURSES_ENQUIRY_RECEIPT_TITLE'));
        $this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.site');
        parent::display($tpl);
    }
}
