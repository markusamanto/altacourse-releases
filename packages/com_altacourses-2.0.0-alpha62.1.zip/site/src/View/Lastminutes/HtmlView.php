<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\View\Lastminutes;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;

\defined('_JEXEC') or die;

final class HtmlView extends BaseHtmlView
{
    public array $items = [];
    public array $emails = [];
    public array $filters = [];
    public ?\Joomla\CMS\Pagination\Pagination $pagination = null;

    public function display($tpl = null): void
    {
        $this->getModel()->requireAdministrator();
        $this->items = $this->getModel()->getItems();
        $this->emails = $this->getModel()->getCopyEmails();
        $this->getDocument()->setTitle(Text::_('COM_ALTACOURSES_LASTMINUTES_TITLE'));
        $this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.site')->useScript('com_altacourses.lastminute');
        parent::display($tpl);
    }
}
