<?php

/** @package Altacourses.Task @license GNU General Public License version 2 or later */
namespace Advenire\Plugin\Task\Altacoursesmonthly\Extension;

use Advenire\Component\Altacourses\Administrator\Service\MonthlyReport;
use Advenire\Plugin\Task\Altacoursesmonthly\Task\MonthlyOption;
use Joomla\CMS\Language\Language;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\Component\Scheduler\Administrator\Event\ExecuteTaskEvent;
use Joomla\Component\Scheduler\Administrator\Task\Status;
use Joomla\Event\EventInterface;
use Joomla\Event\SubscriberInterface;

\defined('_JEXEC') or die;

final class Altacoursesmonthly extends CMSPlugin implements SubscriberInterface
{
    public function __construct(array $config, private readonly ?MonthlyReport $reports, private readonly Language $language)
    {
        parent::__construct($config);
    }

    public static function getSubscribedEvents(): array
    {
        return ['onTaskOptionsList' => 'advertise', 'onExecuteTask' => 'executeMonthly'];
    }

    public function advertise(EventInterface $event): void
    {
        $event->getArgument('subject')->options[] = new MonthlyOption($this->language);
    }

    public function executeMonthly(ExecuteTaskEvent $event): void
    {
        if ($event->getRoutineId() !== 'altacourses.monthly') { return; }
        $start = microtime(true);
        try { $status = $this->reports?->runDue() === 'complete' ? Status::OK : Status::NO_RUN; }
        catch (\Throwable) { $status = Status::NO_RUN; }
        $end = microtime(true);
        $event->setResult(['startTime' => $start, 'endTime' => $end, 'duration' => $end - $start, 'status' => $status,
            'plugin' => 'altacoursesmonthly', 'logCategory' => $event->getArgument('subject')->logCategory]);
    }
}
