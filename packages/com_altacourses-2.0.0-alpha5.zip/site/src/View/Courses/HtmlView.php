<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\View\Courses;

use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Pagination\Pagination;

\defined('_JEXEC') or die;

final class HtmlView extends BaseHtmlView
{
    public array $items = [];
    public array $types = [];
    public array $regions = [];
    public array $filters = [];
    public ?Pagination $pagination = null;

    public function display($tpl = null): void
    {
        $model = $this->getModel();
        $this->items = $model->getItems();
        $this->types = $model->getOptions('coursetypes');
        $this->regions = $model->getOptions('regions');
        $this->getDocument()->setTitle(Text::_('COM_ALTACOURSES_COURSES_TITLE'));
        $this->getDocument()->getWebAssetManager()->useStyle('com_altacourses.site');
        parent::display($tpl);
    }
}
