<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Controller;

use Advenire\Component\Altacourses\Site\Exception\CourseValidationException;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;

final class RegionController extends BaseController
{
    public function execute($task)
    {
        if (strtolower((string) $task) !== 'save') {
            throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'), 404);
        }
        return parent::execute($task);
    }

    public function save(): void
    {
        $model = $this->getModel('Regions', 'Site', ['ignore_request' => true]);
        $model->requireAdministrator();
        if ($this->input->getMethod() !== 'POST') {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_SAMPLE_POST_REQUIRED'), 405);
        }
        if (!$this->checkToken('post', false)) {
            throw new \RuntimeException(Text::_('JINVALID_TOKEN'), 403);
        }
        $raw = $this->input->post->get('jform', [], 'array');
        if (!isset($raw['id'], $raw['version']) || !is_string($raw['id']) || !ctype_digit($raw['id'])
            || (float) $raw['id'] > 2147483647 || !is_string($raw['version'])
            || ($raw['version'] !== '' && !preg_match('/^[a-f0-9]{64}$/D', $raw['version']))) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_REGION_INVALID'), 400);
        }
        $id = (int) $raw['id'];
        $key = 'com_altacourses.region.' . (int) $this->app->getIdentity()->id;
        $tickets = $this->app->getUserState($key . '.tickets', []);
        $ticket = $raw['ticket'] ?? '';
        if ($id === 0) {
            if (!is_string($ticket) || !isset($tickets[$ticket]) || $tickets[$ticket]['time'] < time() - 14400) {
                throw new \RuntimeException(Text::_('JINVALID_TOKEN'), 403);
            }
            if ($tickets[$ticket]['id'] > 0) {
                $this->setRedirect(Route::_('index.php?option=com_altacourses&view=regions', false));
                return;
            }
        }
        $draft = array_intersect_key($raw, array_flip(['id', 'version', 'ticket', 'name', 'state']));
        foreach ($draft as $field => $value) {
            if (!is_string($value) || strlen($value) > 4096) { unset($draft[$field]); }
        }
        $this->app->setUserState($key . '.draft.' . $id, $draft);
        $version = $raw['version'];
        unset($raw['id'], $raw['version'], $raw['ticket']);
        try {
            $savedId = $model->saveRegion($id, $version, $raw);
        } catch (CourseValidationException $exception) {
            foreach ($exception->messages as $message) { $this->app->enqueueMessage($message, 'warning'); }
            $this->setRedirect(Route::_('index.php?option=com_altacourses&view=region&id=' . $id, false));
            return;
        } catch (\Throwable $exception) {
            if (in_array($exception->getCode(), [403, 404, 409], true)) { throw $exception; }
            $this->app->getLogger()->error('Altacourses region save failed', ['exception' => $exception]);
            $this->setMessage(Text::_('COM_ALTACOURSES_REGION_FAILED'), 'warning');
            $this->setRedirect(Route::_('index.php?option=com_altacourses&view=region&id=' . $id, false));
            return;
        }
        if ($id === 0) {
            $tickets[$ticket]['id'] = $savedId;
            $this->app->setUserState($key . '.tickets', $tickets);
        }
        $this->app->setUserState($key . '.draft.' . $id, null);
        $this->setMessage(Text::_('COM_ALTACOURSES_REGION_SAVED'));
        $this->setRedirect(Route::_('index.php?option=com_altacourses&view=regions', false));
    }
}
