<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Controller;

use Advenire\Component\Altacourses\Site\Exception\CourseValidationException;
use Advenire\Component\Altacourses\Site\Model\SupplierprofileModel;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;

final class SupplierprofileController extends BaseController
{
    public function execute($task)
    {
        if (strtolower((string) $task) !== 'save') {
            throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'), 404);
        }
        return parent::execute($task);
    }

    public function save(): void
    {
        $model = $this->getModel('Supplierprofile', 'Site', ['ignore_request' => true]);
        $model->isAdministrator();
        if ($this->input->getMethod() !== 'POST') {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_SAMPLE_POST_REQUIRED'), 405);
        }
        if (!$this->checkToken('post', false)) {
            throw new \RuntimeException(Text::_('JINVALID_TOKEN'), 403);
        }
        $raw = $this->input->post->get('jform', [], 'array');
        foreach (['user_id', 'id', 'version'] as $field) {
            if (!isset($raw[$field]) || !is_string($raw[$field]) || !ctype_digit($raw[$field]) || (float) $raw[$field] > 2147483647) {
                throw new \RuntimeException(Text::_('COM_ALTACOURSES_INVALID_FILTER'), 400);
            }
        }
        $userId = (int) $raw['user_id'];
        $id = (int) $raw['id'];
        $version = (int) $raw['version'];
        $record = $model->getRecord($userId);
        $original = $model->formData($record);
        $key = 'com_altacourses.supplierprofile.' . (int) $this->app->getIdentity()->id . '.' . $userId;
        $draft = ['user_id' => (string) $userId, 'id' => (string) $id, 'version' => (string) $version];
        foreach (SupplierprofileModel::FIELDS as $field) {
            if (isset($raw[$field]) && is_string($raw[$field])) {
                $limit = $field === 'terms' ? 15000 : 255;
                if (mb_strlen($raw[$field]) <= $limit) {
                    $draft[$field] = $raw[$field];
                } elseif ($raw[$field] !== $original[$field]) {
                    $draft[$field] = mb_substr($raw[$field], 0, $limit);
                }
            }
        }
        $this->app->setUserState($key, $draft);
        unset($raw['user_id'], $raw['id'], $raw['version']);
        $url = 'index.php?option=com_altacourses&view=supplierprofile&user_id=' . $userId;
        try {
            $model->saveProfile($userId, $id, $version, $raw);
        } catch (CourseValidationException $exception) {
            foreach ($exception->messages as $message) {
                $this->app->enqueueMessage($message, 'warning');
            }
            $this->setRedirect(Route::_($url, false));
            return;
        } catch (\Throwable $exception) {
            if (in_array($exception->getCode(), [403, 404, 409], true)
                && in_array($exception->getMessage(), [Text::_('JERROR_ALERTNOAUTHOR'), Text::_('COM_ALTACOURSES_SUPPLIER_NOT_FOUND'),
                    Text::_('COM_ALTACOURSES_AVAILABILITY_LOCKED'), Text::_('COM_ALTACOURSES_SUPPLIER_CONFLICT')], true)) {
                throw $exception;
            }
            $this->app->getLogger()->error('Altacourses supplier profile save failed', ['exception' => $exception]);
            $this->setMessage(Text::_('COM_ALTACOURSES_SUPPLIER_FAILED'), 'warning');
            $this->setRedirect(Route::_($url, false));
            return;
        }
        $this->app->setUserState($key, null);
        $this->setMessage(Text::_('COM_ALTACOURSES_SUPPLIER_SAVED'));
        $this->setRedirect(Route::_($url . '&fresh=1', false));
    }
}
