-- A server-issued submission key makes concurrent/retried course creation idempotent.
ALTER TABLE `#__altacourses_courses`
    ADD COLUMN `creation_token` char(64) DEFAULT NULL,
    ADD UNIQUE KEY `idx_creation_token` (`creation_token`);
