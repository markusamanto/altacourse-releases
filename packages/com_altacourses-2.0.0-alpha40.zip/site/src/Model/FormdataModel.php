<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Model;

use Joomla\CMS\Language\Text;
use Joomla\Database\ParameterType;

\defined('_JEXEC') or die;

/** Saved form data is addressed by request ID, independently of the live client record. */
final class FormdataModel extends RequestrecordsModel
{
    use ContactScopeTrait;

    public function getRecord(int $requestId): object
    {
        $db = $this->getDatabase();
        $query = $db->createQuery()->select(['r.id AS request_id', 'r.clientid', 'r.asked_for_info',
            's.id AS submission_id', 's.created_at', 's.contact_json', 's.course_json', 's.supplier_email'])
            ->from('#__altacourses_requests AS r')
            ->join('LEFT', '#__altacourses_courses AS co ON co.id=r.courseid')
            ->join('LEFT', '#__altacourses_request_submissions AS s ON s.request_id=r.id')
            ->where('r.asked_for_info IN (0,1)')->where('r.id=:id')->bind(':id', $requestId, ParameterType::INTEGER);
        $this->scopeClientRecords($query);
        $record = $db->setQuery($query)->loadObject();
        if ($requestId <= 0 || $record === null || (int) $record->clientid <= 0) {
            throw new \RuntimeException(Text::_('JERROR_LAYOUT_PAGE_NOT_FOUND'), 404);
        }
        return $record;
    }
}
