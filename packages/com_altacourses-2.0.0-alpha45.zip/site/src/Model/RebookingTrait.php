<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
namespace Advenire\Component\Altacourses\Site\Model;

use Joomla\CMS\Language\Text;

\defined('_JEXEC') or die;

/** Retired movement entry point rejects stale Alpha26 forms until participation rebooking is rebuilt. */
trait RebookingTrait
{
    public function getRebookingOptions(int $requestId): array
    {
        return []; // Participation rebooking is deferred until Alpha46 or later.
    }

    public function getRebookingForm(object $row, string $control): \Joomla\CMS\Form\Form
    {
        return $this->getForm(['id' => $row->id, 'version' => $row->participation_version, 'status' => 0, 'note' => $row->note], $control);
    }

    private function validateRebooking(string $value): void
    {
        if ($value !== '0' && (!preg_match('/^([1-9][0-9]*):([0-9]+)$/D', $value, $parts)
            || (float) $parts[1] > 2147483647 || (float) $parts[2] > 2147483647)) {
            throw new \RuntimeException(Text::_('COM_ALTACOURSES_REBOOK_INVALID'), 400);
        }
    }

    /** Called only for an unreported locked source row in saveCourseReports(). */
    private function moveRequest(object $row, array $report, string $now): void
    {
        throw new \RuntimeException(Text::_('COM_ALTACOURSES_REBOOK_DEFERRED'), 409);
    }

}
