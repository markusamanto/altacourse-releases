document.addEventListener('DOMContentLoaded', () => {
    const form = document.querySelector('[data-altacourses-course-form]');
    const button = document.getElementById('altacourses-toggle-session');
    const group = document.getElementById('altacourses-second-session');
    if (!form || !button || !group) return;
    const dates = [...group.querySelectorAll('input[type="date"]')];
    const show = (visible) => {
        group.hidden = !visible;
        group.disabled = !visible;
        dates.forEach((input) => { input.required = visible; });
        button.setAttribute('aria-expanded', String(visible));
        button.textContent = visible ? button.dataset.remove : button.dataset.add;
    };
    if (group.dataset.persisted === '1') { show(true); return; }
    button.hidden = false;
    show(dates.some((input) => input.value !== '' || input.getAttribute('value') !== ''));
    button.addEventListener('click', () => show(group.hidden));
});

// Cosmetic input cleanup only; server-side price validation remains authoritative.
document.addEventListener('DOMContentLoaded', () => {
    const form = document.querySelector('[data-altacourses-course-form]');
    if (!form) return;
    const normaliseAmount = (raw) => {
        if (raw.length > 512) return null;
        const value = raw.trim().replace(/\s*(?:kr|SEK)\.?\s*(?:\(test\))?\s*$/iu, '').replace(/:\s*[-–]\s*$/u, '');
        let match;
        let whole;
        if ((match = value.match(/^(\d{1,3}(?:\.\d{3})+)(?:,(\d{1,2}))?$/u))) whole = match[1].replaceAll('.', '');
        else if ((match = value.match(/^(\d{1,3}(?:,\d{3})+)(?:\.(\d{1,2}))?$/u))) whole = match[1].replaceAll(',', '');
        else if ((match = value.match(/^(\d+|\d{1,3}(?:[ \u00a0\u202f]\d{3})+)(?:[.,](\d{1,2}))?$/u))) whole = match[1].replace(/[ \u00a0\u202f]/gu, '');
        else return null;
        whole = whole.replace(/^0+/u, '') || '0';
        return whole.length > 12 ? null : whole + (match[2] ? '.' + match[2] : '');
    };
    for (const name of ['course_price', 'lodging_price']) {
        const input = form.querySelector(`[name="jform[${name}]"]`);
        if (!input) continue;
        input.addEventListener('blur', () => {
            const marker = input.value.trim().replace(/[\s\u00a0\u202f]+/gu, ' ').replace(/\.$/u, '').toLowerCase();
            if (name === 'lodging_price' && ['included in course price', 'included in the course price', 'inkluderat i kursavgiften'].includes(marker)) {
                const checkbox = form.querySelector('[name="jform[lodging_included]"]');
                if (checkbox) { input.value = ''; checkbox.checked = true; }
                return;
            }
            const amount = normaliseAmount(input.value);
            if (amount !== null) input.value = amount;
        });
    }
});
