<?php

/** @package Altacourses.Site @license GNU General Public License version 2 or later */
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
\defined('_JEXEC') or die;
?>
<section aria-labelledby="altacourses-deliveries-heading">
    <h1 id="altacourses-deliveries-heading"><?php echo $this->escape(Text::_('COM_ALTACOURSES_DELIVERIES_TITLE')); ?></h1>
    <p><a href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=dashboard', false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_BACK_TO_DASHBOARD')); ?></a></p>
    <p><?php echo $this->escape(Text::_('COM_ALTACOURSES_NOTIFY_TEST_ONLY')); ?></p>
    <div class="table-responsive"><table class="table table-striped"><thead><tr>
        <?php foreach (['SIGNUP_CREATED', 'ENQUIRY_NAME', 'PARTICIPANT_KIND', 'ENQUIRY_COURSE', 'NOTIFY_STATE', 'SIGNUP_VIEW'] as $key) : ?><th scope="col"><?php echo $this->escape(Text::_('COM_ALTACOURSES_' . $key)); ?></th><?php endforeach; ?>
    </tr></thead><tbody>
    <?php foreach ($this->items as $item) : ?>
        <?php $contact = json_decode($item->contact_json, true, 512, JSON_THROW_ON_ERROR); $course = json_decode($item->course_json, true, 512, JSON_THROW_ON_ERROR); ?>
        <tr data-delivery-request="<?php echo (int) $item->request_id; ?>">
            <td><?php echo $this->escape($item->created_at); ?></td><td><?php echo $this->escape(($contact['firstname'] ?? '') . ' ' . ($contact['lastname'] ?? '')); ?></td>
            <td><?php echo $this->escape(Text::_((int) $item->asked_for_info === 1 ? 'COM_ALTACOURSES_ENQUIRY_TITLE' : 'COM_ALTACOURSES_SIGNUP_TITLE')); ?></td>
            <td><?php echo $this->escape(($course['course_type'] ?? '') . ' — ' . ($course['course_place'] ?? '')); ?></td>
            <td><?php echo $this->escape(Text::_('COM_ALTACOURSES_NOTIFY_AGGREGATE_' . strtoupper($item->delivery_state))); ?></td>
            <td><a href="<?php echo $this->escape(Route::_('index.php?option=com_altacourses&view=notifications&id=' . (int) $item->request_id, false)); ?>"><?php echo $this->escape(Text::_('COM_ALTACOURSES_SIGNUP_VIEW')); ?></a></td>
        </tr>
    <?php endforeach; ?>
    </tbody></table></div><?php echo $this->pagination->getPagesLinks(); ?>
</section>
