<?php
/** @package Altacourses.Module @license GNU General Public License version 2 or later */
namespace Advenire\Module\Altacoursesletter\Site\Field;
use Joomla\CMS\Factory;
use Joomla\CMS\Form\Field\EditorField;
use Joomla\CMS\Language\Text;
\defined('_JEXEC') or die;
/** Seed an editable letter for new/legacy instances; an explicitly empty body stays empty. */
final class LetterField extends EditorField
{
    public $type='Letter';
    public function setup(\SimpleXMLElement $element,$value,$group=null)
    {
        Factory::getApplication()->getLanguage()->load('mod_altacoursesletter',JPATH_SITE.'/modules/mod_altacoursesletter');
        $path=($group?$group.'.':'').(string)$element['name'];
        if($this->form->getData()->exists($path)){$value=$this->form->getValue((string)$element['name'],$group,'');}
        if($value===null||$value==='__ALTACOURSESLETTER_DEFAULT__'){$value=Text::_('MOD_ALTACOURSESLETTER_DEFAULT');}
        return parent::setup($element,$value,$group);
    }
}
