<?php
/** @package Altacourses.Module @license GNU General Public License version 2 or later */
namespace Advenire\Module\Altacoursesletter\Site\Helper;
use Joomla\CMS\Application\SiteApplication;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\Registry\Registry;
\defined('_JEXEC') or die;
final class AltacoursesletterHelper
{
    public function render(SiteApplication $app,Registry $params,?\DateTimeImmutable $now=null): ?array
    {
        if($app->getDocument()->getType()!=='html'||!ComponentHelper::isEnabled('com_altacourses')){return null;}
        $file=JPATH_ADMINISTRATOR.'/components/com_altacourses/altacourses.xml';$m=is_file($file)?simplexml_load_file($file):false;
        if(!$m||(string)$m->namespace!=='Advenire\\Component\\Altacourses'||version_compare((string)$m->version,'2.0.0-alpha67','<')){return null;}
        $type=$params->get('course_type',0);
        if(!is_scalar($type)||!ctype_digit((string)$type)||strlen((string)$type)>10||(float)$type>4294967295){return null;}
        $letter=$params->exists('letter')?$params->get('letter'):Text::_('MOD_ALTACOURSESLETTER_DEFAULT');
        if(!is_string($letter)||trim($letter)===''){return null;}
        $model=$app->bootComponent('com_altacourses')->getMVCFactory()->createModel('Courses','Site',['ignore_request'=>true]);
        foreach(['type'=>(int)$type,'regions'=>[],'region'=>0,'from'=>'','to'=>''] as $key=>$value){$model->setState('filter.'.$key,$value);}
        $number=$model->getTotal();
        $date=Factory::getDate($now?$now->setTimezone(new \DateTimeZone('UTC'))->format('Y-m-d H:i:s'):'now','UTC');
        $date->setTimezone(new \DateTimeZone((string)$app->get('offset','UTC')));
        $today=$date->format(Text::_('DATE_FORMAT_LC'),true);
        $body=strtr($letter,['{course_count}'=>(string)$number,'{today}'=>htmlspecialchars($today,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8')]);
        return ['body'=>$body,'number'=>$number];
    }
}
