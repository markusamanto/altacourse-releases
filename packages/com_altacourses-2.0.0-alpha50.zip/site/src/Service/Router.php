<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Service;

use Joomla\CMS\Application\SiteApplication;
use Joomla\CMS\Categories\CategoryFactoryInterface;
use Joomla\CMS\Component\Router\RouterView;
use Joomla\CMS\Component\Router\RouterViewConfiguration;
use Joomla\CMS\Component\Router\Rules\MenuRules;
use Joomla\CMS\Component\Router\Rules\NomenuRules;
use Joomla\CMS\Component\Router\Rules\StandardRules;
use Joomla\CMS\Menu\AbstractMenu;
use Joomla\Database\DatabaseInterface;

\defined('_JEXEC') or die;

final class Router extends RouterView
{
    /**
     * The standard factory supplies optional category/database services.
     * This dashboard route needs only the application and menu.
     */
    public function __construct(
        SiteApplication $app,
        AbstractMenu $menu,
        ?CategoryFactoryInterface $categoryFactory = null,
        ?DatabaseInterface $database = null
    ) {
        $this->registerView(new RouterViewConfiguration('dashboard'));
        $this->registerView(new RouterViewConfiguration('readreceipt'));
        $this->registerView(new RouterViewConfiguration('accounts'));
        $this->registerView(new RouterViewConfiguration('account'));
        $this->registerView(new RouterViewConfiguration('accountclients'));
        $this->registerView(new RouterViewConfiguration('keyaccounts'));

        $this->registerView(new RouterViewConfiguration('courseplaces'));
        $this->registerView(new RouterViewConfiguration('courseplace'));
        $this->registerView(new RouterViewConfiguration('courseleaders'));
        $this->registerView(new RouterViewConfiguration('courseleader'));
        $this->registerView(new RouterViewConfiguration('mailtemplates'));
        $this->registerView(new RouterViewConfiguration('mailtemplate'));
        $this->registerView(new RouterViewConfiguration('alerts'));
        $this->registerView(new RouterViewConfiguration('alert'));
        $this->registerView(new RouterViewConfiguration('seats'));
        $this->registerView(new RouterViewConfiguration('seat'));
        $this->registerView(new RouterViewConfiguration('regions'));
        $this->registerView(new RouterViewConfiguration('region'));
        $this->registerView(new RouterViewConfiguration('coursetypes'));
        $this->registerView(new RouterViewConfiguration('coursetype'));
        $this->registerView(new RouterViewConfiguration('courses'));
        $this->registerView(new RouterViewConfiguration('course'));
        $this->registerView(new RouterViewConfiguration('managecourses'));
        $this->registerView(new RouterViewConfiguration('availability'));
        $this->registerView(new RouterViewConfiguration('assignment'));
        $this->registerView(new RouterViewConfiguration('newcourse'));
        $this->registerView(new RouterViewConfiguration('editcourse'));
        $this->registerView(new RouterViewConfiguration('suppliers'));
        $this->registerView(new RouterViewConfiguration('supplierprofile'));
        $this->registerView(new RouterViewConfiguration('enquiry'));
        $this->registerView(new RouterViewConfiguration('enquiryreceipt'));
        $this->registerView(new RouterViewConfiguration('enquiries'));
        $this->registerView(new RouterViewConfiguration('signup'));
        $this->registerView(new RouterViewConfiguration('signupreceipt'));
        $this->registerView(new RouterViewConfiguration('signups'));
        $this->registerView(new RouterViewConfiguration('participant'));
        $this->registerView(new RouterViewConfiguration('unconfirmed'));
        $this->registerView(new RouterViewConfiguration('unreads'));
        $this->registerView(new RouterViewConfiguration('deliveries'));
        $this->registerView(new RouterViewConfiguration('notifications'));
        $this->registerView(new RouterViewConfiguration('contacts'));
        $this->registerView(new RouterViewConfiguration('client'));
        $this->registerView(new RouterViewConfiguration('rebooking'));
        $this->registerView(new RouterViewConfiguration('formdata'));
        $this->registerView(new RouterViewConfiguration('contact'));
        $this->registerView(new RouterViewConfiguration('participations'));
        $this->registerView(new RouterViewConfiguration('participation'));
        $this->registerView(new RouterViewConfiguration('commissions'));
        $this->registerView(new RouterViewConfiguration('monthlyreports'));
        $this->registerView(new RouterViewConfiguration('commissionrate'));
        parent::__construct($app, $menu);

        $this->attachRule(new MenuRules($this));
        $this->attachRule(new StandardRules($this));
        $this->attachRule(new NomenuRules($this));
    }
}
