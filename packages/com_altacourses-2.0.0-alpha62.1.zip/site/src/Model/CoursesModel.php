<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Model;

use Joomla\Database\ParameterType;
use Joomla\CMS\User\UserFactoryAwareInterface;
use Joomla\CMS\User\UserFactoryAwareTrait;
use Joomla\Database\QueryInterface;

\defined('_JEXEC') or die;

final class CoursesModel extends PubliccourseModel implements UserFactoryAwareInterface
{
    use UserFactoryAwareTrait;
    public function getItems(): array
    {
        return $this->getDatabase()->setQuery($this->buildQuery(false),
            (int) $this->getState('list.start', 0), (int) $this->getState('list.limit', 20))->loadObjectList();
    }

    public function getTotal(): int
    {
        return (int) $this->getDatabase()->setQuery($this->buildQuery(true))->loadResult();
    }

    public function getOptions(string $kind): array
    {
        if (!in_array($kind, ['coursetypes', 'regions'], true)) {
            throw new \InvalidArgumentException('Unsupported lookup');
        }
        $db = $this->getDatabase();
        return $db->setQuery($db->createQuery()->select(['id', 'name'])
            ->from($db->quoteName('#__altacourses_' . $kind))->where('state = 1')->order('ordering, name, id'))->loadObjectList();
    }

    /** Public links must resolve to currently guest-visible Joomla articles/categories. */
    public function getArticles(array $values,string $language): array
    {
        $ids=[];
        foreach ($values as $value) { if (is_scalar($value)&&ctype_digit((string)$value)&&(int)$value>0&&(float)$value<=2147483647) { $ids[]=(int)$value; } }
        $ids=array_values(array_unique($ids));if (!$ids) { return []; }
        $db=$this->getDatabase();$levels=implode(',',array_map('intval',$this->getUserFactory()->loadUserById(0)->getAuthorisedViewLevels())?:[0]);$now=$db->quote(gmdate('Y-m-d H:i:s'));
        $q=$db->createQuery()->select(['a.id','a.alias','a.catid','a.language'])->from('#__content AS a')
            ->join('INNER','#__categories AS c ON c.id=a.catid')->whereIn('a.id',$ids,ParameterType::INTEGER)
            ->where('a.state=1')->where('a.access IN ('.$levels.')')->where("c.extension='com_content'")
            ->where("(a.language='*' OR a.language=:article_language)")->bind(':article_language',$language)
            ->where("(c.language='*' OR c.language=:category_language)")->bind(':category_language',$language)
            ->where('(a.publish_up IS NULL OR CAST(a.publish_up AS CHAR) LIKE '.$db->quote('0000-%').' OR a.publish_up<='.$now.')')
            ->where('(a.publish_down IS NULL OR CAST(a.publish_down AS CHAR) LIKE '.$db->quote('0000-%').' OR a.publish_down>='.$now.')')
            ->where("NOT EXISTS (SELECT 1 FROM #__categories AS parent WHERE parent.extension='com_content' AND parent.lft<=c.lft AND parent.rgt>=c.rgt AND (parent.published<>1 OR parent.access NOT IN (".$levels.')))');
        $articles=[];foreach ($db->setQuery($q)->loadObjectList() as $article) { $articles[(int)$article->id]=$article; }return $articles;
    }

    private function buildQuery(bool $count): QueryInterface
    {
        $query=$count?$this->publicQuery()->select('COUNT(*)'):$this->listingQuery();

        $type = (int) $this->getState('filter.type', 0);
        $region = (int) $this->getState('filter.region', 0);
        $from = (string) $this->getState('filter.from', '');
        $to = (string) $this->getState('filter.to', '');
        if ($type > 0) {
            $query->where('co.course_type = :type')->bind(':type', $type, ParameterType::INTEGER);
        }
        $regions=$this->getState('filter.regions',null);
        if ($regions===null) { $regions=$region>0?[$region]:[]; }
        $regions=array_values(array_unique(array_filter(array_map('intval',$regions),static fn($id)=>$id>0&&$id<=2147483647)));
        if ($regions) { $query->whereIn('cp.region_id',$regions,ParameterType::INTEGER); }
        if ($from !== '') {
            $from .= ' 00:00:00';
            $query->where('co.start_date >= :from_date')->bind(':from_date', $from);
        }
        $this->getCourseSchedule()->applyEndDateFilter($query, $to);
        return $query;
    }
}
