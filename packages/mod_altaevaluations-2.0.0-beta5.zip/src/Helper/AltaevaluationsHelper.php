<?php
/** @package Altacourses.Module @license GNU General Public License version 2 or later */
namespace Advenire\Module\Altaevaluations\Site\Helper;
use Joomla\CMS\Application\SiteApplication;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Router\Route;
use Joomla\Component\Content\Site\Helper\RouteHelper;
use Joomla\Registry\Registry;
\defined('_JEXEC') or die;
final class AltaevaluationsHelper
{
    public function render(SiteApplication $app,Registry $params): ?array
    {
        if($app->getDocument()->getType()!=='html'||!ComponentHelper::isEnabled('com_altacourses')){return null;}
        $file=JPATH_ADMINISTRATOR.'/components/com_altacourses/altacourses.xml';$manifest=is_file($file)?simplexml_load_file($file):false;
        if(!$manifest||(string)$manifest->namespace!=='Advenire\\Component\\Altacourses'||version_compare((string)$manifest->version,'2.0.0-beta1','<')){return null;}
        $raw=$params->get('evaluationstoshow',5);
        if(!is_scalar($raw)||!ctype_digit((string)$raw)||strlen((string)$raw)>4||(int)$raw<1||(int)$raw>1000){return null;}
        $mvc=$app->bootComponent('com_altacourses')->getMVCFactory();
        $evaluations=$mvc->createModel('Publicevaluations','Site',['ignore_request'=>true])->published((int)$raw);
        if(!$evaluations){return null;}
        $readMore=null;$articleId=$params->get('readmorearticle',0);
        if(in_array($params->get('showreadmore',0),[1,'1'],true)&&is_scalar($articleId)&&ctype_digit((string)$articleId)&&(float)$articleId<=2147483647&&(int)$articleId>0){
            $articles=$mvc->createModel('Courses','Site',['ignore_request'=>true])->getArticles([(int)$articleId],$app->getLanguage()->getTag());$article=$articles[(int)$articleId]??null;
            if($article!==null){$readMore=Route::_(RouteHelper::getArticleRoute($article->id.':'.$article->alias,(int)$article->catid,$article->language),false);}
        }
        return compact('evaluations','readMore');
    }
}
