<?php
namespace Advenire\Component\Altacourses\Site\View\Evaluationthanks;
\defined('_JEXEC') or die;
final class HtmlView extends \Advenire\Component\Altacourses\Site\View\Evaluation\HtmlView {}
