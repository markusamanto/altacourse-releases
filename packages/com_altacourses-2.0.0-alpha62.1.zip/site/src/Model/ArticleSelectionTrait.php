<?php

/**
 * @package     Altacourses.Site
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Site\Model;

use Advenire\Component\Altacourses\Site\Exception\CourseValidationException;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Language\Text;
use Joomla\Database\ParameterType;

\defined('_JEXEC') or die;

/** Shared article-ID selection for leader and location management. */
trait ArticleSelectionTrait
{
    abstract protected function articleLanguagePrefix(): string;

    private int $articleCategory = 0;

    public function setArticleCategory(int $category): void
    {
        $this->articleCategory = $category > 0 && $category <= 2147483647 ? $category : 0;
    }

    /** Choices are scoped to the configured exact category and the administrator's view access. */
    public function getArticleChoices(): array
    {
        $this->requireAdministrator();
        if ($this->articleCategory === 0) { return []; }
        $db = $this->getDatabase();
        $category = $this->articleCategory;
        $levels = array_map('intval', $this->currentUser->getAuthorisedViewLevels());
        $access = implode(',', $levels ?: [0]);
        $query = $db->createQuery()->select(['a.id', 'a.title', 'a.state'])
            ->from($db->quoteName('#__content', 'a'))
            ->join('INNER', $db->quoteName('#__categories', 'c') . ' ON c.id = a.catid')
            ->where('a.catid = :category')->bind(':category', $category, ParameterType::INTEGER)
            ->where("c.extension = 'com_content'")->where('c.published IN (0,1,2)')
            ->where('a.state IN (0,1,2)')->where('a.access IN (' . $access . ')')->where('c.access IN (' . $access . ')')
            ->order('a.title, a.id');
        return $db->setQuery($query)->loadObjectList();
    }

    private function articleId(?string $value): ?string
    {
        if ($value === null || !ctype_digit($value) || (float) $value > 2147483647 || (int) $value <= 0) { return null; }
        return (string) (int) $value;
    }

    private function linkSelection(?object $record): string
    {
        $value = $record->url ?? null;
        return $value === null || $value === '' || $value === '0' ? '' : ($this->articleId($value) ?? '__keep');
    }

    /** Omitted URL preserves older forms/API calls; only explicit clearing removes a stored link. */
    private function validateLink(array $input, ?object $record): ?string
    {
        if (!array_key_exists('url', $input)) { return $record->url ?? null; }
        $value = $input['url'];
        if (!is_string($value) || strlen($value) > 255) {
            throw new CourseValidationException([Text::_('COM_ALTACOURSES_' . $this->articleLanguagePrefix() . '_ARTICLE_INVALID')]);
        }
        if ($value === '') {
            // Preserve existing empty representations; new/explicitly cleared active links use NULL.
            return $this->linkSelection($record) === '' ? ($record->url ?? null) : null;
        }
        if ($value === '__keep' && $this->linkSelection($record) !== '') { return $record->url; }
        $id = $this->articleId($value);
        if ($id !== null) {
            if ($id === $this->articleId($record->url ?? null)) { return $record->url; }
            foreach ($this->getArticleChoices() as $choice) {
                if ($id === (string) $choice->id) { return $id; }
            }
        }
        throw new CourseValidationException([Text::_('COM_ALTACOURSES_' . $this->articleLanguagePrefix() . '_ARTICLE_INVALID')]);
    }

    private function addArticleField(Form $form, array $data, ?object $record): array
    {
        $choices = $this->getArticleChoices();
        $default = $this->linkSelection($record);
        $field = new \SimpleXMLElement('<field />');
        foreach (['name' => 'url', 'type' => 'list', 'filter' => 'raw', 'label' => 'COM_ALTACOURSES_' . $this->articleLanguagePrefix() . '_ARTICLE',
            'description' => $this->articleCategory === 0 ? 'COM_ALTACOURSES_' . $this->articleLanguagePrefix() . '_ARTICLE_UNCONFIGURED' : 'COM_ALTACOURSES_' . $this->articleLanguagePrefix() . '_ARTICLE_HELP'] as $key => $value) {
            $field->addAttribute($key, $value);
        }
        $empty = $field->addChild('option'); $empty->addAttribute('value', '');
        $empty[0] = Text::_('COM_ALTACOURSES_' . $this->articleLanguagePrefix() . '_ARTICLE_NONE');
        $values = [''];
        foreach ($choices as $choice) {
            $value = (string) $choice->id;
            $option = $field->addChild('option'); $option->addAttribute('value', $value);
            $label = $choice->title . ' (#' . $value . ')';
            if ((int) $choice->state !== 1) { $label .= ' — ' . Text::_((int) $choice->state === 0 ? 'JUNPUBLISHED' : 'JARCHIVED'); }
            $option[0] = $label;
            $values[] = $value;
        }
        if ($default !== '' && !in_array($default, $values, true)) {
            $option = $field->addChild('option'); $option->addAttribute('value', '__keep');
            $id = $this->articleId($record->url ?? null);
            $option[0] = $id === null ? Text::_('COM_ALTACOURSES_' . $this->articleLanguagePrefix() . '_ARTICLE_KEEP_LEGACY') : Text::sprintf('COM_ALTACOURSES_' . $this->articleLanguagePrefix() . '_ARTICLE_KEEP_ID', $id);
            if (($data['url'] ?? $default) === $default) { $data['url'] = '__keep'; }
            $default = '__keep'; $values[] = '__keep';
        }
        if (!isset($data['url']) || !is_string($data['url']) || !in_array($data['url'], $values, true)) { $data['url'] = $default; }
        $form->setField($field);
        return $data;
    }
}
