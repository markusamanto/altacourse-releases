<?php
/** @package Altacourses.Module @license GNU General Public License version 2 or later */
namespace Advenire\Module\Altacoursesletter\Site\Dispatcher;
use Joomla\CMS\Dispatcher\AbstractModuleDispatcher;
use Joomla\CMS\Event\PageCache\IsExcludedEvent;
use Joomla\CMS\Helper\HelperFactoryAwareInterface;
use Joomla\CMS\Helper\HelperFactoryAwareTrait;
\defined('_JEXEC') or die;
final class Dispatcher extends AbstractModuleDispatcher implements HelperFactoryAwareInterface
{
    use HelperFactoryAwareTrait;
    protected function getLayoutData(): array|false
    {
        $data=parent::getLayoutData();$result=$this->getHelperFactory()->getHelper('AltacoursesletterHelper')->render($this->app,$data['params']);
        if($result===null){return false;}
        $this->app->allowCache(false);$this->app->getDispatcher()->addListener('onPageCacheIsExcluded',static function(IsExcludedEvent $e):void{$e->addResult(true);});
        $wa=$this->app->getDocument()->getWebAssetManager();$wa->getRegistry()->addRegistryFile('media/mod_altacoursesletter/joomla.asset.json');$wa->useStyle('mod_altacoursesletter.site');
        return $data+$result;
    }
}
