-- Only additional sessions; the first session remains in the original courses columns.
CREATE TABLE IF NOT EXISTS `#__altacourses_course_sessions` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `course_id` int UNSIGNED NOT NULL,
  `start_date` datetime NOT NULL,
  `stop_date` datetime NOT NULL,
  `ordering` smallint UNSIGNED NOT NULL DEFAULT 2,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_course_session_order` (`course_id`, `ordering`),
  CONSTRAINT CHECK (`stop_date` >= `start_date`),
  CONSTRAINT CHECK (`ordering` >= 2),
  FOREIGN KEY (`course_id`) REFERENCES `#__altacourses_courses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
