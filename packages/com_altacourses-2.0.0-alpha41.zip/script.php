<?php

/**
 * @package     Altacourses.Installer
 * @license     GNU General Public License version 2 or later
 */

namespace Advenire\Component\Altacourses\Installer;

use Joomla\CMS\Installer\InstallerAdapter;
use Joomla\CMS\Installer\InstallerScriptInterface;
use Joomla\CMS\Language\Text;
use Joomla\Database\DatabaseInterface;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;

\defined('_JEXEC') or die;

return new class () implements ServiceProviderInterface {
    public function register(Container $container): void
    {
        $container->set(
            InstallerScriptInterface::class,
            static fn (Container $container): InstallerScriptInterface => new class ($container->get(DatabaseInterface::class)) implements InstallerScriptInterface {
                private ?string $previousSchema = null;

                public function __construct(private readonly DatabaseInterface $database)
                {
                }

                public function preflight(string $type, InstallerAdapter $adapter): bool
                {
                    if ($type === 'uninstall') {
                        return true;
                    }

                    if (version_compare(JVERSION, '6.2.0', '<') || version_compare(PHP_VERSION, '8.4.0', '<')) {
                        throw new \RuntimeException(Text::_('COM_ALTACOURSES_INSTALL_REQUIREMENTS'));
                    }

                    if ($this->database->getServerType() !== 'mysql') {
                        throw new \RuntimeException(Text::_('COM_ALTACOURSES_INSTALL_DATABASE'));
                    }

                    $manifest = JPATH_ADMINISTRATOR . '/components/com_altacourses/altacourses.xml';
                    $installed = null;

                    if (is_file($manifest)) {
                        $installed = simplexml_load_file($manifest);

                        if ($installed === false || (string) $installed->namespace !== 'Advenire\\Component\\Altacourses') {
                            throw new \RuntimeException(Text::_('COM_ALTACOURSES_INSTALL_LEGACY'));
                        }
                    }

                    $prefix = $this->database->getPrefix() . 'altacourses_';
                    $owned = array_map(static fn (string $name): string => $prefix . $name,
                        ['courses', 'coursetypes', 'courseplaces', 'courseleaders', 'regions', 'seats']);
                    $mayHaveSchema = $installed !== null
                        && version_compare((string) $installed->version, '2.0.0-alpha4', '>=');
                    $mayHaveSessions = $mayHaveSchema && version_compare((string) $installed->version, '2.0.0-alpha8', '>=');
                    if ($mayHaveSessions) {
                        $owned[] = $prefix . 'course_sessions';
                    }
                    $mayHaveSuppliers = $mayHaveSchema && version_compare((string) $installed->version, '2.0.0-alpha15', '>=');
                    if ($mayHaveSuppliers) {
                        $owned[] = $prefix . 'suppliers';
                    }
                    $mayHaveEnquiries = $mayHaveSchema && version_compare((string) $installed->version, '2.0.0-alpha16', '>=');
                    if ($mayHaveEnquiries) {
                        foreach (['clients', 'requests', 'request_submissions'] as $table) { $owned[] = $prefix . $table; }
                    }
                    $mayHaveNotifications = $mayHaveEnquiries && version_compare((string) $installed->version, '2.0.0-alpha19', '>=');
                    if ($mayHaveNotifications) { $owned[] = $prefix . 'notification_outbox'; }
                    if ($mayHaveNotifications && version_compare((string) $installed->version, '2.0.0-alpha25', '>=')) { $owned[] = $prefix . 'monthly_reports'; }
                    if ($mayHaveNotifications && version_compare((string) $installed->version, '2.0.0-alpha26', '>=')) { $owned[] = $prefix . 'request_rebookings'; }
                    $schema = null;

                    if ($mayHaveSchema) {
                        $schema = $this->database->setQuery(
                            "SELECT s.version_id FROM #__schemas AS s INNER JOIN #__extensions AS e ON e.extension_id = s.extension_id WHERE e.element = 'com_altacourses' AND e.type = 'component'"
                        )->loadResult();
                    }

                    $expectedSchema = $mayHaveNotifications ? (version_compare((string) $installed->version, '2.0.0-alpha24', '>=') ? (version_compare((string) $installed->version, '2.0.0-alpha25', '>=') ? (version_compare((string) $installed->version, '2.0.0-alpha26', '>=') ? '2.0.10' : '2.0.9') : '2.0.8') : (version_compare((string) $installed->version, '2.0.0-alpha22', '>=') ? '2.0.7' : '2.0.6')) : ($mayHaveEnquiries ? '2.0.5' : ($mayHaveSuppliers ? '2.0.4' : ($mayHaveSchema && version_compare((string) $installed->version, '2.0.0-alpha9', '>=')
                        ? '2.0.3' : ($mayHaveSessions
                        ? '2.0.2' : ($mayHaveSchema && version_compare((string) $installed->version, '2.0.0-alpha6', '>=')
                        ? '2.0.1' : '2.0.0')))));

                    if ($installed !== null && version_compare((string) $installed->version, '2.0.0-alpha34', '>=')) {
                        $owned[] = $prefix . 'alerts';
                        $expectedSchema = '2.0.11';
                    }

                    if ($installed !== null && version_compare((string) $installed->version, '2.0.0-alpha35', '>=')) {
                        $owned[] = $prefix . 'mailtemplates';
                        $expectedSchema = '2.0.12';
                    }
                    if ($installed !== null && version_compare((string) $installed->version, '2.0.0-alpha38', '>=')) {
                        $owned[] = $prefix . 'accounts';
                        $expectedSchema = '2.0.13';
                    }
                    $this->previousSchema = $schema;

                    // Older recognised releases may already contain these imported tables.
                    // Detailed checks below validate them before conditional schema adoption.
                    $retainedLegacy = [$prefix . 'alerts', $prefix . 'mailtemplates'];

                    foreach ($this->database->getTableList() as $table) {
                        if (str_starts_with($table, $prefix)
                            && (!$mayHaveSchema || $schema !== $expectedSchema || (!in_array($table, $owned, true) && !in_array($table, $retainedLegacy, true)))) {
                            throw new \RuntimeException(Text::_('COM_ALTACOURSES_INSTALL_EXISTING_DATA'));
                        }
                    }

                    if (in_array($prefix . 'alerts', $this->database->getTableList(), true)) {
                        $columns = $this->database->getTableColumns($prefix . 'alerts');
                        if (array_diff(['id', 'name', 'alert', 'ordering', 'state', 'checked_out', 'checked_out_time', 'created_by', 'modified_by'], array_keys($columns))) {
                            throw new \RuntimeException(Text::_('COM_ALTACOURSES_INSTALL_ALERTS_SCHEMA'));
                        }
                    }

                    if (in_array($prefix . 'mailtemplates', $this->database->getTableList(), true)) {
                        $columns = $this->database->getTableColumns($prefix . 'mailtemplates');
                        if (array_diff(['id', 'type', 'name', 'subject', 'from_name', 'from_email', 'message', 'ordering', 'state', 'checked_out', 'checked_out_time', 'created_by'], array_keys($columns))
                            || (isset($columns['course_type']) && !preg_match('/^int(?:\\([0-9]+\\))?(?: unsigned)?$/i', $columns['course_type']))) {
                            throw new \RuntimeException(Text::_('COM_ALTACOURSES_INSTALL_MAIL_SCHEMA'));
                        }
                        if (isset($columns['published_course_type'])) { $this->verifyPublishedColumn($prefix . 'mailtemplates'); }
                        $this->verifyPublishedIndex($prefix . 'mailtemplates');
                        $courseType = isset($columns['course_type']) ? 'COALESCE(course_type, 0)' : 'COALESCE(NULL, 0)';
                        $duplicates = $this->database->setQuery('SELECT type, ' . $courseType . ' AS course_type, GROUP_CONCAT(id ORDER BY id) AS ids FROM #__altacourses_mailtemplates WHERE state=1 GROUP BY type, ' . $courseType . ' HAVING COUNT(*) > 1', 0, 10)->loadObjectList();
                        if ($duplicates) {
                            $details = implode('; ', array_map(static fn ($row): string => 'type=' . $row->type . ', course_type=' . $row->course_type . ', IDs=' . $row->ids, $duplicates));
                            throw new \RuntimeException(Text::sprintf('COM_ALTACOURSES_INSTALL_MAIL_DUPLICATES', $details));
                        }
                    }

                    return true;
                }

                public function install(InstallerAdapter $adapter): bool
                {
                    $this->ensureMailtemplateSchema();
                    return true;
                }

                public function update(InstallerAdapter $adapter): bool
                {
                    $this->ensureMailtemplateSchema();
                    return true;
                }

                /** Idempotent conditional part of versioned migration 2.0.12. */
                private function ensureMailtemplateSchema(): void
                {
                    $db = $this->database;
                    $table = $db->getPrefix() . 'altacourses_mailtemplates';
                    $mode = (string) $db->setQuery('SELECT @@SESSION.sql_mode')->loadResult();
                    try {
                        // Preserve old zero-date values while ALTER copies old table layouts.
                        // Only this install connection changes; strict data checks remain enabled.
                        $ddlMode = implode(',', array_diff(explode(',', $mode), ['NO_ZERO_DATE', 'NO_ZERO_IN_DATE']));
                        $db->setQuery('SET SESSION sql_mode=' . $db->quote($ddlMode))->execute();
                        $columns = $db->getTableColumns($table);
                        if (!isset($columns['course_type'])) {
                            $db->setQuery('ALTER TABLE ' . $db->quoteName($table) . ' ADD COLUMN course_type INT DEFAULT NULL')->execute();
                        }
                        if (!isset($columns['published_course_type'])) {
                            $db->setQuery('ALTER TABLE ' . $db->quoteName($table) . ' ADD COLUMN published_course_type INT GENERATED ALWAYS AS (CASE WHEN state=1 THEN COALESCE(course_type,0) ELSE NULL END) STORED')->execute();
                        }
                        $this->verifyPublishedColumn($table);
                        if (!$this->verifyPublishedIndex($table)) {
                            $db->setQuery('ALTER TABLE ' . $db->quoteName($table) . ' ADD UNIQUE KEY idx_mailtemplate_published (type,published_course_type)')->execute();
                        }
                    } catch (\Throwable $exception) {
                        // A retry must still see the previous recognised schema if DDL failed.
                        if ($this->previousSchema !== null) {
                            $db->setQuery('UPDATE #__schemas AS s JOIN #__extensions AS e ON e.extension_id=s.extension_id SET s.version_id=' . $db->quote($this->previousSchema) . " WHERE e.element='com_altacourses' AND e.type='component'")->execute();
                        }
                        throw $exception;
                    } finally {
                        $db->setQuery('SET SESSION sql_mode=' . $db->quote($mode))->execute();
                    }
                }

                private function verifyPublishedColumn(string $table): void
                {
                    $db = $this->database;
                    $query = $db->createQuery()->select('GENERATION_EXPRESSION')->from('information_schema.COLUMNS')
                        ->where('TABLE_SCHEMA=DATABASE()')->where('TABLE_NAME=:table')->bind(':table', $table)
                        ->where("COLUMN_NAME='published_course_type'");
                    $expression = strtolower((string) $db->setQuery($query)->loadResult());
                    if (preg_replace('/[\s`()]+/', '', $expression) !== 'casewhenstate=1thencoalescecourse_type,0elsenullend') {
                        throw new \RuntimeException(Text::_('COM_ALTACOURSES_INSTALL_MAIL_SCHEMA'));
                    }
                }

                private function verifyPublishedIndex(string $table): bool
                {
                    $keys = array_values(array_filter($this->database->getTableKeys($table), static fn ($key): bool => $key->Key_name === 'idx_mailtemplate_published'));
                    if (!$keys) { return false; }
                    usort($keys, static fn ($a, $b): int => (int) $a->Seq_in_index <=> (int) $b->Seq_in_index);
                    if (array_column($keys, 'Column_name') !== ['type', 'published_course_type'] || (int) $keys[0]->Non_unique !== 0) {
                        throw new \RuntimeException(Text::_('COM_ALTACOURSES_INSTALL_MAIL_SCHEMA'));
                    }
                    return true;
                }

                public function uninstall(InstallerAdapter $adapter): bool
                {
                    return true;
                }

                public function postflight(string $type, InstallerAdapter $adapter): bool
                {
                    if ($type !== 'uninstall') {
                        foreach (['src/View/Assignment/HtmlView.php', 'tmpl/assignment/default.php', 'forms/assignment.xml', 'src/Model/EnquiriesModel.php', 'src/Model/SignupsModel.php', 'src/Model/ParticipantModel.php', 'src/Model/ContactModel.php', 'src/View/Enquiries/HtmlView.php', 'src/View/Signups/HtmlView.php', 'src/View/Participant/HtmlView.php', 'src/View/Contact/HtmlView.php', 'tmpl/enquiries/default.php', 'tmpl/signups/default.php', 'tmpl/participant/default.php', 'tmpl/contact/default.php', 'layouts/participant.php'] as $file) {
                            $path = JPATH_SITE . '/components/com_altacourses/' . $file;
                            if (is_file($path) && !\Joomla\Filesystem\File::delete($path)) {
                                throw new \RuntimeException('Retired extension screen could not be removed');
                            }
                        }
                    }
                    return true;
                }
            }
        );
    }
};
